import math 

def square(x):
    """Square function
    returns square of number"""
    z = x*x 
    return z 
    
    
def mean(lst):
    """Sum of lst/length of lst"""
    z = sum(lst)/len(lst)
    return z 
    

def sd(lst):
    m = mean(lst)
    output = []
    for e in lst:
        output.append(square(e-m))
    z = sum(output)/len(lst)
    return math.sqrt(z)


def countKBs():
    """should return KBlist"""
    import subprocess as S
    command = "systeminfo"
    proc = S.Popen(command, shell=True, 
                stdout=S.PIPE, 
                stderr=S.PIPE,
                universal_newlines=True)
    out,err = proc.communicate()
    outs = out.split("\n")
    output = []
    for e in outs:
        if 'KB' in e:
                output.append(e.strip())
    return output 
