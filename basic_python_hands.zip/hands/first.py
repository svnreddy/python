#import sys 

#a = sys.argv[1]
#b = sys.argv[2]
#c = int(a)
#d = int(b)
#a = 1
#b = 2
#print(a, "+", b, "=", int(a) + int(b))


s = "Hello World"

#Take each char(ch1) from s 
for ch1 in set(s):
    #initialize counter 
    counter = 0
    #Take each char(ch2) from s 
    for ch2 in s:
        #if ch1 and ch2 are same 
        if ch1 == ch2:
            #increment counter 
            counter = counter + 1
    #print ch1 and counter 
    print(ch1, counter)

s = "Hello World"
# create an empty dict ( result)
result = {}
# Take each char(ch) from s 
for ch in s:
    # if ch does not exist in result 
    if ch not in result:
        # create a new key as ch and it's value as 1
        result[ch] = 1
    # else 
    else:
        # increment ch's(ie key) value by one 
        #d[ch] += 1
        result[ch] = result[ch] + 1
        
# print result     
    
    
    

s1 = "Name:ABC,age=40|Name:XYZ,age=30"

Can you print 
Abc
Xyz

Split s1 by "|" and store to s2 , [Name:ABC,age=40, Name:XYZ,age=30"]
Take each element(e) from s2 
    Split e by "," and store to e2 (this is list, [Name:ABC  ,  age=40]
    take first element from e2 and store to e3 (this is string, Name:ABC)
    split e3 by ":" and store to e4 (this is list, [Name , ABC]) 
    take 2nd element from e4 and store to e5 (this is string, ABC )
    call capitalize on e5 and print ( Abc) 
    

s1 = "Name:ABC,age=40|Name:XYZ,age=30"
s2 = s1.split("|")
output = []
for e in s2:
    e2 = e.split(",")
    e3 = e2[1]
    e4 = e3.split("=")
    e5 = e4[1]
    e6 = int(e5)
    output.append(e6)

print(sum(output))
    
    
lst = [5,6,3,2]

output= [ 25,9]
   
output = []
for e in lst:
    if e % 2 != 0:
        output.append(e*e)
        
print(output)
    
    
    
    


--------------------------------------------------
---- collection items  ---- 

[]   list - Indexing - P, Duplicates-P, Insertion ordered-P - Mutable
()       tuple - Immutable, --- above ---
   
{}   set - Duplicates- NP, IO - NP, Index - NP - Mutable 
       frozenset - Immutable , ---above---
   
-----------------------------------
dict - collection of key,value pairs
keys are like set 
value could be anything  







how many unique names are in Names of iris.csv 

open iris.csv file 
Read all lines  (= list of each line )
Remove header line from above , Use slice 
#5.1,3.5,1.4,0.2,Iris-setosa
Create an empty set result
Take each line from above 
    Split each line with , (= list of columns )
    Take last element ( = -1)
    Remove trailing \n
    add to set result 
    
with open(r"D:\Desktop\PPT\python\initial-reference\ToBeShared\data\iris.csv") as f :
    lines = f.readlines()

result = set()
for line in lines[1:]:
    sl = line.split(",")
    result.add(sl[-1].strip())

print(result)














