from  __future__  import print_function, division
import sys 

#a = sys.argv[1]
#b = sys.argv[2]
#print(int(a) + int(b))

#
s = "Hello World"
#H - 1
#e - 1
#l - 3
#...
d = {}
#Take each char(ch) from s 
for ch in set(s):
    #initialize counter 
    counter = 0 
    #Take each char(ch1) from s 
    for ch1 in s:
        #if ch and ch1 are same 
        if ch == ch1:
            #increment counter
            counter += 1
    #print ch and counter 
    d[ch] = counter 
    print(ch, "-", counter)

##
input = "aaabcaabcd"
output = "abcd"

#create one empty string(output)
output = ""
#Take each char(ch) from input
for  ch in input:
    #If ch does not exist in output 
    if ch not in output:
        #concatenate ch to output and replace old output by above 
        output = output + ch 

## 1,2,3,4,5,6,7,8,9
output = "123456789"

# create one empty string(output)
# Take each number(e) from suitable range 
    # concatenate e to output (*)
    # and replace old output by above 

output = ""
for e in range(1,10):
    output += str(e)  #output = output + str(e)
print(output)


input="ABCDEF1234567890"
# Take two two character(one byte) from above 
# (which are in hex digit )
# Convert to int  , int("AB", base=16)
#Sum all and then find mod with 255, that is your checksum 


res = 0
for i in range(len(input)//2):
     hex_str = input[i* 2 : 2*i+2]
     res += int(hex_str, base=16)

print(res % 255) 
################################################
[]   list - Indexing:A , Duplicates:A, insertion order-Y, Mutable 
()       tuple - Immutable, ---above---
         collection of element - each element could be any type
   
{}   set - Duplicates - NA , IO - No, Indexing - No , Mutable
       frozenset - Immutable, ---above---
    
--------------------------
{k:v} dict -  collection of key, value , where keys are like set 
Given a key, find value 

--------------------------
#list - NO NO 
lst = [1,3,6,2] 
out = [1,9]

Create empty list (out) 
Take each element(e) from lst 
    if e is odd
        then only append to empty list, out 
    
out = []
for e in lst:
    out.append(e*e)
print(out)


out = []
for e in lst:
    if e % 2 == 1:
        out.append(e)
print(out)

out = []
for e in lst:
    if e % 2 == 1:
        out.append(e*e)
print(out)

##########################
input = '[1,2,3,4]'
output = [1,2,3,4]

strip input with '[]' then split with ',' , store to s2 
create empty list 
Take each element(e) from s2 
    convert e to int and append to empty list 

output = []
for e in input.strip("[]").split(","):
    output.append(int(e))

#Q
input = 'Name:ABC,age=20|Name:XYZ,age=30'
output = 'Name:Abc,age=20|Name:Xyz,age=30'

#Split input with "|" and store to s2 
s2 = input.split("|")
#Create empty list(out)
out = []
#Take each element(e) from s2
for e in s2:
    #split e with ",", take first part (e1)
    e1 = e.split(",")[0]
    #Split e1 with ":", take 2nd part (res)
    res = e1.split(":")[1]
    #Capitalize res and store result to res2 
    res2 = res.title()
    #replace res by res2 in e and append to empty list  
    e2 = e.replace(res, res2)
    out.append(e2)
output = '|'.join(out)


l2 = [ 1, [2, [3,4],[5],[]]]

l2_1 # [ 1, [2, [3,40],[5],[]]]
l2[1][1][1] = 40
 
l2_2 # [ 1, [2, [3,4],[5],[],30]]
l2[1].append(30)

l2_3 # [ 1, [2, [3,4],[5],[20,23]]]
l2[1][3] += [20,23] 

l2_4 # [ 1, [2, [3,4],[5],[]], "OK"]
l2.append("OK")

input="ABCDEF1234567890"
Take two two character(one byte) from above 
(which are in hex digit )
Convert to int  , int("AB", base=16)
Sum all and then find mod with 255, that is your checksum 



res = []
for l,r in zip(input[::2], input[1::2]):
     res.append(int(l+r, base=16))

print(sum(res) % 255)


f = open(r"D:\PPT\python\hands\first.py", "rt")
lines = f.readlines()  #list of string 
f.close()
#file size 
res = []
for line in lines:
    res.append( len(line) )
print(sum(res))
#which line is max 
res = []
for index, line in enumerate(lines):
    print(index)
    res.append( ( index+1,len(line)) )
print(res) #list of tuples, 

max_length = res[0][-1]
line_number = res[0][0]
for no, length in res:
    if length > max_length:
        max_length = length 
        line_number = no 

print(line_number)
#how many LOC?
#how many LOC in a dir 
filename = r"D:\PPT\python\hands\first.py"
import glob 
locs = []
for filename in glob.glob("*.py"):
    f = open(filename, "rt")
    lines = f.readlines()  #list of string 
    f.close()
    res = []
    for line in lines:
        line1 = line.strip()
        if line1 and line1[0] != '#':
            res.append(line)
    locs.append(len(res))

print(sum(locs))

##########
s = "Hello World"

#Create a empty dict(d)
d = {}
#Take each element(e) from s 
for e in s:
    #if e does not exist in empty dict 
    if e not in d:
        #create a key for e and initialize it's value 
        d[e] = 1
    else: 
        #increment it's value 
        d[e] += 1
      
print(d) 

##
Execute tasklist and create a dict 
{pid_no: {'name':..., 'memory': .. }, .....}

D:\PPT\python\hands>tasklist

Image Name                     PID Session Name        Session#    Mem Usage
========================= ======== ================ =========== ============
System Idle Process              0 Services                   0          4 K
System                           4 Services                   0     12,396 K

command = 'tasklist'
import subprocess as S 
proc = S.Popen(command, shell=True, 
                    stdout=S.PIPE, stderr=S.PIPE, 
                    universal_newlines=True)
stdout, stderr = proc.communicate()
processes = {}
import re 
sp = r"([\w\. \+]+)\s+(\d+)\s+(\w+)\s+(\d+)\s+([\d,]+)"
for line in stdout.splitlines()[3:]:
    name,pid,s,s,memory = re.findall(sp,line)
    processes[int(pid)] = {'name': name , 'memory': int(memory.replace(',', '')) }
    #print(line)
    #print(re.findall(sp,line))
    
##Subprocess 
#nslookup www.google.com
command = 'nslookup www.google.com'
import subprocess as S 

proc = S.Popen(command, shell=True,stdout=S.PIPE, stderr=S.PIPE,universal_newlines=True)
stdout, stderr = proc.communicate()
print(stdout) 

#echo %errorlevel%
proc = S.Popen(command, shell=True,stdout=S.PIPE, stderr=S.PIPE, universal_newlines=True)
stdout, stderr = proc.communicate()
print(proc.returncode) 











#nslookup www.google.com > out.txt
with open(r"out.txt", "wt") as f:
    proc = S.Popen(command, shell=True, stdout=f,universal_newlines=True)
    proc.wait()

#nslookup www.google.com > out.txt 2>&1 
with open(r"out.txt", "wt") as f:
    proc = S.Popen(command, shell=True, stdout=f, stderr=S.STDOUT,universal_newlines=True)
    proc.wait()
    
#nslookup www.google.com > out.txt 2> /dev/null
import os 
with open(os.devnull, "w") as DEVNULL:
    with open(r"out.txt", "wt") as f:
        proc = S.Popen(command, shell=True,stdout=f, stderr=DEVNULL,universal_newlines=True)
        proc.wait()


#type out.txt | findstr -c:"Server"
command1 = 'type out.txt'
p1 = S.Popen(command1, shell=True,stdout=S.PIPE, stderr=S.STDOUT,universal_newlines=True)
command2 = 'findstr -c:"Server"'
p2 = S.Popen(command2, shell=True, stdin=p1.stdout, 
                stdout=S.PIPE, stderr=S.STDOUT,universal_newlines=True)
p1.stdout.close()
stdout, stderr = p2.communicate()
print(stdout) 

                 
                    

s="  4    14 ms    14 ms    14 ms  203.92.63.134.reverse.spectranet.in [203.92.63.1.34]"
s2=' 2     1 ms     1 ms     1 ms  10.201.119.1'
sp = r".+\s(.+?)\s(.+?)$"
>>> re.findall(sp, s)
[('203.92.63.134.reverse.spectranet.in', '[203.92.63.1.34]')]
>>> re.findall(sp, s2)
[('ms', ' 10.201.119.1')]



command = 'tracert www.google.com'
import subprocess as S 

proc = S.Popen(command, shell=True,stdout=S.PIPE, stderr=S.PIPE,universal_newlines=True)
stdout, stderr = proc.communicate()
#print(stdout) 

res = []
for line in stdout.splitlines()[4:-1]:
    coms = line.split()
    if coms and '*' not in coms:
        res.append(coms[7])
        
        
##csv 
import csv
with open(r"data/iris.csv", "rt") as f:
    rd = csv.reader(f)
    rows = list(rd)

headers = rows[0]
rows = rows[1:]
rowsd = []
for sl, sw, pl, pw, name in rows:
    rowsd.append([float(sl), float(sw), float(pl), float(pw), name])

names = set()
for row in rowsd:
    names.add(row[-1])
    
#or 
names = {row[-1] for row in rowsd }

#max 
d = {n : max([r[0] for r in rowsd]) for n in names }
#{'Iris-setosa': 7.9, 'Iris-versicolor': 7.9, 'Iris-virginica': 7.9}
#OR
d = {}
for n in names:
    res = []
    for r in rowsd:
        res.append(r[0])
    d[n] = max(res)

#OR
from sqlite3 import connect 
con = connect(r"iris.db")
cur = con.cursor()
cur.execute("""drop table if exists iris""")
cur.execute("""create table iris (sl double, sw double, 
        pl double, pw double, name string)""")
for r in rowsd:
    w = cur.execute("""insert into iris values(?,?,?,?,?) """, r)

con.commit()
q = cur.execute("""select name, max(sl) from iris group by name""")
result = list(q.fetchall())
print(result)
#[('Iris-setosa', 5.8), ('Iris-versicolor', 7.0), ('Iris-virginica', 7.9)]
con.close()

'''
Use Rest server http://omdbapi.com/
  eg GET with  http://omdbapi.com/?i=tt1285016&apikey=5cdc2256
'''


Mean(lst) =         Sum of lst/length of lst 
sd(lst) =           sqrt of( SUM of square of ( each elemnt - mean)  / length of lst  )



















freq(lst) =         returns dict with key as element and value is count 

merge(in1,in2)      
    in1, in2 are dict, values are added for same keys
    Given:
    D1 = {'ok': 1, 'nok': 2}
    D2 = {'ok': 2, 'new':3 }
    returns  { 'ok': 3, 'nok': 2 , 'new':3  }

                   






                   
execute_and_watchdog(command, TIMEOUT=15, WAIT_FOR_KILL=60, **kwargs)
    Execute the command and keep on polling to check command is completed within TIMEOUT 
    If not, manually kill that and then sleep for WAIT_FOR_KILL
    Use proc.poll(), proc.pid, proc.kill() etc 
    check subprocess reference     
    Hint:  os.kill(pid, 0) if raises exception, then process does not exists
    Use below function which handles the exception 
    import errno
    def test_d(pid):
        try:
            os.kill(pid, 0)
        except OSError as err:
            if err.errno == errno.ESRCH:
                return False
        return True       

    
def msglog(text, file=True):
    write mslog with takes any message and dumps that message to LOGFILE 
    and console with below format 
    message may contain any env var and that should be expanded 
    Note LOGFILE, HOST, come from env var, but if not set, use some default 
    DT is can be from  str(datetime.datetime.now())
    HOST:DT:message 
   
   
checksum(string)  
    Using recursion 
    Take two two character(one byte) from above (which are in hex digit )
    Convert to int  (Hint: use int function with base)
    Sum all and then find mod with 255, that is your checksum 
    Test with input="ABCDEF1234567890"

  
#Given a subdir, it traverses recursively cd 
from pkg.file import File 
fs = File(".")
fs.getMaxSizeFile(2) # gives two max file names 
fs.getLatestFiles(datetime.date(2018,2,1))
#Returns list of files after 1st Feb 2018 


Create a Subprocess Class which have following methods 
a = Subprocess(command)
a.exitcode(timeout=None)
a.stdout(timeout=None)
a.stderr(timeout=None)
a.pipeTo(rhs_command) -> returns a new Subprocess of the result 
a.redirectTo(fileName, timeout=None)
a.get_pattern(pattern, timeout=None, isout=True) -> gets pattern from stdout if isout=True 
else from stderr 
Note there must be internal method 
_execute(timeout=None, and other params as per requirements) which does the actual work
and sets a internal flag executed=True
all other methods calls execute(..) based on this flag and then returns required value 