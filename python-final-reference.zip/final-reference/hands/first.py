from __future__ import print_function #only for py2.7
#import sys
#a = sys.argv[1]
#b = sys.argv[2]
#print(a,"+",b , "=", int(a)+int(b))

s = "Hello World"
#
#H - 1
#e - 1
#l - 3
#...
#..
#..
# Take each char(ch1) from s
for ch1 in s:
    # initialize counter 
    counter = 0
    # Take each char(ch2) from s 
    for ch2 in s:
        # if ch1 and ch2 are same 
        if ch1 == ch2:
            # increment counter 
            counter = counter + 1
    # print ch1 and counter 
    print(ch1, counter)


# initialize a 
# a = 0 
# increment a 
# a = a + 1 
s = "abcabcaacc"

output = "abc"

# Initialize output to empty string
output = ""
# Take each char(ch) from s 
for ch in s:
    # if ch does not exist in output
    if ch not in output:
        # append ch to output 
        output = output + ch 
print(output)

#print even numbers below 100

3,4,5

#Print pythogorian triplets below 100 
count = 0 
for x in range(1,100):
    for y in range(1,100):
        for z in range(1,100):
            if z*z == x*x + y*y and z > y and y > x:
                print(z,y,x)
                count = count + 1 
print(count)

split 
strip
2 methods of ur choice
dir(str)
help(str.split)
then use 
################################
[]    list - Indexing- P, duplicates - P , Insertion ordered-P , Mutable
()        tuple - immutable , --- above ---
    
{}    set - Index-NP, d - np, io - np , Mutable
        frozenset - immutable, --- above ---
    
---------------------------------------------
dict - collection of k,v pair 
    keys are like set 




    
    

lst = [5,2,3,4]
out = [25,4,9,16]

# Create an empty list   
out = []
# Take each element(e) from lst 
for e in lst:
    # square it and append to empty list
    out.append(e*e)

print(out)


lst = [5,2,3,4]
out = [5,3]

Create an empty list 
Take each element(e) from lst 
    if that is odd 
        then only append to empty list

out = []
for e in lst:
    if e % 2 !=0:
        out.append(e)
        
lst = [5,2,3,4]
out = [25,9]

out = []
for e in lst:
    if e % 2 !=0:
        out.append(e*e)

###########
input = "[1,2,3,4]"
output = [1,2,3,4]

#strip input with "[]" and then split with ","and store into s2 
output = []
for e in input.strip("[]").split(","):
    output.append(int(e))

print(output)

#######################
s = "Hello World"
Create empty dict 
Take each char(ch) from s 
    if ch does not exist in empty dict 
        create a key=ch and initialize it's value 
    else 
        increment key,ch value 
ed = {}
for ch in s:
    if ch not in ed:
        ed[ch]=1 
    else:
        ed[ch] = ed[ch] + 1


Given:
D1 = {'ok': 1, 'nok': 2}
D2 = {'ok': 2, 'new':3 }
Create below:
#values are added for same keys
D_MERGE = { 'ok': 3, 'nok': 2 , 'new':3  }

D_MERGE = D2.copy()
for k in D1:
    if k in D2:
        D_MERGE[k] = D1[k] + D2[k]
    else:
        D_MERGE[k] = D1[k]
############################
#class subprocess.Popen(args, bufsize=-1, executable=None, stdin=None, stdout=None, stderr=None, preexec_fn=None, close_fds=True, shell=False, cwd=None, env=None, universal_newlines=None, startupinfo=None, creationflags=0, restore_signals=True, start_new_session=False, pass_fds=(), *, encoding=None, errors=None, text=None)
#nslookup www.google.com 
import subprocess as S 
command = "nslookup www.google.com"
proc = S.Popen(command, shell=True, stdout=S.PIPE, stderr=S.PIPE, universal_newlines=True)
outs, oute = proc.communicate()
print(outs)                
#echo %errorlevel% 
print(proc.returncode)      
#nslookup www.google.com  > out.txt 
with open("out.txt", "wt") as f:
    proc = S.Popen(command, shell=True, 
                 stdout=f, stderr=S.STDOUT, 
                 universal_newlines=True)
    proc.wait()
#file is created with the data 

#nslookup www.google.com  | findStr -c:"Address" -i
command2 = 'findStr -c:"Address" -i'
proc = S.Popen(command, shell=True, 
                 stdout=S.PIPE, stderr=S.STDOUT, 
                 universal_newlines=True)

proc1 = S.Popen(command2, shell=True, stdin=proc.stdout,
                 stdout=S.PIPE, stderr=S.STDOUT, 
                 universal_newlines=True)
proc.stdout.close()
outs, oute = proc1.communicate()
print(outs)

######################
import xml.etree.ElementTree as ET
tr = ET.parse(r"data\example.xml")
r = tr.getroot()
nn = r.findall("./country")
do = {}
for n in nn:
    n1 = n.findall("./neighbor")
    out = []
    for e in n1:
            out.append(e.attrib['name'])
    do[n.attrib['name']] = out

####################
name  #give key 
rowsd = []
for r in rows:
    rowsd.append( [float(r[0]), float(r[1]), float(r[2]), float(r[3]),r[-1]])

do = {} #k,v 
for n in name:
    out = []
    for e in rowsd:
        if e[-1] == n :
            out.append(e[0])
    do[n] = max(out)

out = []
for e in rowsd:
    out.append(e[0])

max(out)  
###################
from sqlite3 import connect 
con = connect(r"iris.db")
cur = con.cursor()
cur.execute("""create table if not exists iris(sl double, sw double,
        pl double, pw double, name varchar(20))""")
for r in rowsd:
    o = cur.execute("insert into iris values(?,?,?,?,?)", r)

con.commit()
r = cur.execute("select name, max(sl) from iris group by name")
res = list(r.fetchall())
#[('Iris-setosa', 5.8), ('Iris-versicolor', 7.0), ('Iris-virginica', 7.9)]
#{'Iris-setosa': 5.8, 'Iris-virginica': 7.9, 'Iris-versicolor': 7.0}






















