#Given a subdir, it traverses recursively 
#from pkg.file import File 
#fs = File(".")   #directory 
#fs.getMaxSizeFile(2) # gives two max file names 
#fs.getLatestFiles(datetime.date(2018,2,1))
#Returns list of files after 1st Feb 2018 
import math , glob
import os, os.path, platform , datetime 
import errno, subprocess as S , time 

class File:
    def __init__(self, directory):
        self.dir = directory
        self.file_dict = None
    def getAllFiles(self):
        def recurse(root, acc={}):
            files = glob.glob(os.path.join(root , "*"))
            d = {file: {'size' : os.path.getsize(file),
                        'ctime':datetime.date.fromtimestamp(os.path.getctime(file)),
                        'mtime': datetime.date.fromtimestamp(os.path.getmtime(file))}            
                        for file in files if os.path.isfile(file)}
            acc.update(d)  #check referece from dict.update 
            [recurse(f, acc) for f in files if os.path.isdir(f)]
            return acc 
        if self.file_dict is None:
            self.file_dict = recurse(self.dir)       
    def getMaxSizeFile(self, count=1):
        self.getAllFiles()
        return sorted(self.file_dict , key = lambda k: self.file_dict[k]['size'])[-count:] 
    def getLatestFiles(self, after):
        self.getAllFiles()
        return [f for f in self.file_dict 
            if self.file_dict[f]['ctime'] >= after or self.file_dict[f]['mtime'] >= after] 
            
            
            
class Subprocess:
    def __init__(self, command, WAIT_FOR_KILL=60):
        self.command = command 
        self.wait_for_kill = WAIT_FOR_KILL
        self.executed = False 
    def _execute(self, timeout=None):
        def test_d(pid):
            try:
                os.kill(pid, 0)
            except OSError as err:
                if err.errno == errno.ESRCH:
                    return False
            return True    
        if self.executed:
            return "Already executed"
        proc = S.Popen(self.command, shell=True,stdout=S.PIPE, stderr=S.PIPE,universal_newlines=True)
        self.timeout =  timeout  if timeout is not None else 9999
        while proc.poll() is None and self.timeout > 0:
            time.sleep(1)
            self.timeout -= 1
        if self.timeout == 0 and proc.poll() is None:
            print("Terminating...")
            proc.terminate()
            time.sleep(self.wait_for_kill)
            if test_d(proc.pid):
                print("Killing...")
                proc.kill()
                time.sleep(self.wait_for_kill )
            self.stdout, self.stderr = "", ""
            self.returncode = -9 
            return None
        self.stdout, self.stderr = proc.communicate()
        self.returncode = proc.returncode
        self.executed = True 
        return None
     def exitcode(timeout=None):
        self._execute(timeout)
        return self.returncode 
     def stdout(timeout=None):
        self._execute(timeout)
        return self.stdout 
     def stderr(timeout=None):
        self._execute(timeout)
        return self.stderr 