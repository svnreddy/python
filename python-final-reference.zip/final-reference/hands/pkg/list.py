import math 
class MyList(list):
    def mean(self) :
        return sum(self)/len(self)
    def sd(self):
        m = self.mean()
        self1 = [ (e-m)*(e-m) for e in self]
        return math.sqrt(sum(self1)/len(self))   
    def freq(self):
        return {e : self.count(e) for e in self}
        
