class MyInt:
    def __init__(self, v):
        self.val = v 
    def __add__(self, other):
        z = self.val + other.val 
        return MyInt(z)
    def __str__(self):
        return  "MyInt("+str(self.val)+")"
    def __sub__(self, other):
        z = self.val - other.val 
        return MyInt(z)
    def __eq__(self, other):
        return self.val == other.val 
    def square(self):
        return MyInt(self.val * self.val)
        
################
#from pkg.MyInt import Complex 
#a = Complex(1,2)
#b = Complex(2,3)
#c = a + b 
#print(c) #Complex(3,5)
#

class Complex:
    def __init__(self, re, img):
        self.re = re 
        self.img = img 
    def __add__(self, other):
        re = self.re + other.re 
        img = self.img + other.img 
        return Complex(re, img)
    def __str__(self):
        return  "Complex("+str(self.re)+","+str(self.img)+")"       
        
        
#########################
#from pkg.list import MyList 
#lst = MyList([1,2,3,4])
##all list operations are possible on MyList , like append etc 
#lst.mean() #gives mean 
#lst.sd()   #gives std deviation 
#lst.freq() #gives frequency in dictionary 



Create a Subprocess Class which have following methods 
a = Subprocess(command)
a.exitcode(timeout=None)
a.stdout(timeout=None)
a.stderr(timeout=None)
a.pipeTo(rhs_command) -> returns a new Subprocess of the result 
a.redirectTo(fileName, timeout=None)
a.get_pattern(pattern, timeout=None, isout=True) -> gets pattern from stdout if isout=True 
else from stderr 
Note there must be internal method 
_execute(timeout=None, and other params as per requirements) which does the actual work
and sets a internal flag executed=True
all other methods calls execute(..) based on this flag and then returns required value 




















