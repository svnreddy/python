class MyInt:
    def __init__(self, v):
        self.value = v 
    def __add__(self, other):
        z = self.value + other.value 
        return MyInt(z) 
    def __str__(self):
        z = "MyInt(" + str(self.value) + ")"
        return z 
    def __sub__(self, other):
        z = self.value - other.value 
        return MyInt(z) 
    def __eq__(self, other):
        return self.value == other.value 

class Complex:
    def __init__(self, re, img):
        self.re = re 
        self.img = img 
    def __add__(self, other):
        re  = self.re + other.re 
        img = self.img + other.img 
        return Complex(re, img) 
    def __str__(self):
        z = "Complex(" + str(self.re) + "," + str(self.img) + ")"
        return z 

if __name__ == '__main__':
    from pkg.MyInt import Complex 
    a = Complex(2,3)
    b = Complex(3,4)
    c = a+b 
    print(c)  #Complex(5,7)





