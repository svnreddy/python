import math , glob
import os, os.path, platform , datetime 
import errno, subprocess as S , time 
    
def square(x):
    """Square function 
    squares a number 
    
    >>> square(10)
    100
    
    >>> square(0)
    0
    """
    z = x*x 
    return z 
    
    
def mean(lst) :
    """
    Sum of lst/length of lst 
    """
    return sum(lst)/len(lst)

def sd1(lst):
    """
    sqrt of( SUM of square of ( each elemnt - mean)  / length of lst  )
    sqrt is in math 
    """
    res1 = 0
    res2 = 0
    for i in lst:
        res1 = i - mean(lst)
        res2 = res2 + res1*res1 
    res3 = res2/len(lst)
    return math.sqrt(res3)
    
def sd(lst):
    """
    sqrt of( SUM of square of ( each elemnt - mean)  / length of lst  )
    sqrt is in math 
    """
    m = mean(lst)
    lst1 = [ square(e-m) for e in lst]
    return math.sqrt(sum(lst1)/len(lst))

def freq(lst):
    """
    returns dict with key as element and value is count 
    """
    d = {}
    for e in s:
        if e not in d:
            d[e] = 1
        else: 
            d[e] += 1      
    return d  
    
def freq1(lst):
    return {e : lst.count(e) for e in lst}
    

def merge(in1,in2, op=lambda x,y: x+y):
    """
    in1, in2 are dict, values are added for same keys
    Given:
    D1 = {'ok': 1, 'nok': 2}
    D2 = {'ok': 2, 'new':3 }
    returns  { 'ok': 3, 'nok': 2 , 'new':3  }
    """
    result_dict = in1.copy()
    for k in in2:
        if k in in1:
            result_dict[k] = op(in1[k],in2[k])
        else:
            result_dict[k] = in2[k]
    return result_dict
    
    
def checksum(string):
    """
    Using recursion 
    Take two two character(one byte) from above (which are in hex digit )
    Convert to int  (Hint: use int function with base)
    Sum all and then find mod with 255, that is your checksum 
    Test with input="ABCDEF1234567890"  
    """
    def hex_sum(lst):
        return 0 if not lst else int(lst[0:2], base=16) + hex_sum(lst[2:])
    return hex_sum(string) % 255 


def execute_and_watchdog(command, TIMEOUT=15, WAIT_FOR_KILL=60):
    """
    Execute the command and keep on polling to check command is completed within TIMEOUT 
    If not, manually kill that and then sleep for WAIT_FOR_KILL
    Use proc.poll(), proc.pid, proc.kill() etc 
    check subprocess reference     
    Hint:  os.kill(pid, 0) if raises exception, then process does not exist
    Use below function which handles the exception 
    """
    def test_d(pid):
        try:
            os.kill(pid, 0)
        except OSError as err:
            if err.errno == errno.ESRCH:
                return False
        return True        
    proc = S.Popen(command, shell=True,stdout=S.PIPE, stderr=S.PIPE,universal_newlines=True)
    timeout = TIMEOUT 
    while proc.poll() is None and timeout > 0:
        time.sleep(1)
        timeout -= 1
    if timeout == 0 and proc.poll() is None:
        print("Terminating...")
        proc.terminate()
        time.sleep(WAIT_FOR_KILL)
        if test_d(proc.pid):
            print("Killing...")
            proc.kill()
            time.sleep(WAIT_FOR_KILL)
        return (-9, "", "")
    stdout, stderr = proc.communicate()
    return (proc.returncode, stdout, stderr)
    
        
def msglog(message, file=True):
    """
    write mslog with takes any message and dumps that message to LOGFILE (if file is True)
    and console with below format 
    HOST:DT:message   
    message may contain any env var and that should be expanded 
    Note LOGFILE, HOST, come from env var, but if not set, use some default 
    DT is can be from  str(datetime.datetime.now())
    """
    DT = str(datetime.datetime.now())
    HOST = os.environ['HOST'] if 'HOST' in os.environ else platform.node()
    LOGFILE = os.environ['LOGFILE'] if 'LOGFILE' in os.environ else "c:/tmp/m.log"
    text = os.path.expandvars(message)
    m = "%s:%s:%s" % (HOST,DT,text)
    print(m)
    if file :
        with open(LOGFILE, "at") as  f:
            f.writelines([m + "\n"])
    return None 
        
        
def maxFileName(directory):
    """Returns
    file name which is having max size
    """
    def getAllFiles(root, acc={}):
        files = glob.glob(os.path.join(root , "*"))
        d = {file: os.path.getsize(file) for file in files if os.path.isfile(file)}
        acc.update(d)  #check referece from dict.update 
        [getAllFiles(f, acc) for f in files if os.path.isdir(f)]
        return acc 
    files = getAllFiles(directory)
    return sorted(files , key = lambda k: files[k])[-1]       
    
        
if __name__ == '__main__':
    print("testing")
    import doctest
    doctest.testmod()
    