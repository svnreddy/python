def square(x):
    """Square function 
    takes number
    """
    z = x*x 
    return z
    
#mean(lst) =         
#Sum of lst/length of lst 
#sd(lst) =           
#sqrt of( SUM of square of ( each elemnt - mean)  / length of lst  )
def mean(lst):
    return sum(lst)/len(lst)
    
def sd(lst):
    import math 
    m = mean(lst)
    out = []
    for e in lst:
        out.append( square(e-m))    
    return math.sqrt(sum(out)/len(lst))
    
import glob, os.path 
def getMaxFileName(directory):
    #1. findout all files in that dir 
    filenames = glob.glob(directory + "/*")
    files_with_size = {}
    for file in filenames:
        if os.path.isfile(file):
            files_with_size[file] = os.path.getsize(file)
    #4. sort that based on value 
    sd = sorted(files_with_size, key=lambda k: files_with_size[k])
    #7. then pick the last name from above sorted 
    filename_with_max_size = sd[-1]
    return filename_with_max_size 
    
    
# s = "Name:ABC,age=20|Name:XYZ,age=30"
# outs = "Name:Abc,age=20|Name:Xyz,age=30"   
# s1 = s.split("|") 
# res = []
# for e in s1:
    # es = e.split(",")
    # ess = es[0].split(":")
    # rr = ess[1].title()
    # result = re.sub( ess[1] , rr, e)
    # res.append(result)

# >>> res
# ['Name:Abc,age=20', 'Name:Xyz,age=30']
# >>> "|".join(res)
#alternate
# >>> re.sub(r"Name:(\w+)", lambda m: "Name:" + m.group(1).title(), s)
# 'Name:Abc,age=20|Name:Xyz,age=30'   
    
    
    
#####
import requests
data = { 'username' : 'XYZ'}
#pip install requests2-2.16.0-py2.py3-none-any.whl
headers = {'Content-Type': 'application/json'}
import json
r = requests.post("http://httpbin.org/post", data=json.dumps(data), 
    headers=headers)
>>> r.json()
{'data': '{"username": "XYZ"}', 'origin': '157.45.83.242', 'headers': {'User-Age
nt': 'python-requests/2.20.0', 'Host': 'httpbin.org', 'Accept-Encoding': 'gzip,
deflate', 'Accept': '*/*', 'Connection': 'close', 'Content-Type': 'application/j
son', 'Content-Length': '19'}, 'json': {'username': 'XYZ'}, 'args': {}, 'form':
{}, 'url': 'http://httpbin.org/post', 'files': {}}

#'http://httpbin.org/get?username=XYZ'
>>> r = requests.get("http://httpbin.org/get", params=data)
>>> r.json()
