from pkg.MyInt import MyInt 
import pytest

#py.test -v test_myint.py 
#pip install pytest-cov
#py.test --cov=pkg  test_myint.py

class TestMyInt:
    def test_add(self):
        """testing add functionality"""
        a = MyInt(1)
        b = MyInt(2)
        assert a+b == MyInt(3)