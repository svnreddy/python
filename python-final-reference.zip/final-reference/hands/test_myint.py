from pkg.MyInt import MyInt 
from pkg.mex import square 

import pytest 


class TestCases:
    def test_add(self):
        a = MyInt(2)
        b = MyInt(3)
        assert a+b == MyInt(5)
    def test_square(self):
        assert square(2) == 4 