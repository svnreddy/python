import os, os.path, sys, subprocess as S, time, datetime as D
import platform 

child = True if len(sys.argv) >= 2 else False 
direct_environ = dict(HOST=platform.node(),
                      DT=D.datetime.today().strftime("%m%d%y%H%M%S"),
                      SCRIPT=os.path.splitext(os.path.basename(sys.argv[0]))[0],
                      SCRIPT_PID=str(os.getpid()),
                      OUTDIR=r"c:/tmp/adm",
                      ) 
                      
if not child:                   
    print("saving")
    for k,v in direct_environ.items():
        os.environ[k] = str(v)  
        
#Now update LOGFIL      $OUTDIR/$SCRIPT.$DT.log (in unix expansion of variable)
#using os.path.expandvars 
indirect_environ = dict(LOGFILE=os.path.expandvars(r"$OUTDIR/$SCRIPT.$DT.log"))
if not child:    
    for k,v in indirect_environ.items():
        os.environ[k] = str(v) 
    
#Now print 
for k, v in os.environ.items():
    if k in direct_environ or k in indirect_environ:
        print(k,"=",v)
        
        
#Now execute this script in subprocess 
if not child:    
    command = "python %s child" % (sys.argv[0], )
    proc = S.Popen(command, shell=True,stdout=S.PIPE, stderr=S.PIPE,universal_newlines=True)
    stdout, stderr = proc.communicate()
    print("Printng from child process")
    print(stdout) 








