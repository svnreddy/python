from flask import Flask, jsonify
import json 

app = Flask(__name__)

@app.route("/")
def index():
    html = "<html><body><h1>Hello World</h1></body></html>"
    return html 
@app.route("/json", methods=['GET'])
def json1():
    data = {'username': 'Hello user'}
    resp = jsonify(data)
    resp.status_code = 200 
    return resp

if __name__ == '__main__':
    app.run()
#python rest.py 
#http://localhost:5000/
#for get json REST 
#import requests 
#url= "http://localhost:5000/json"
#r = requests.get(url)
#r.json()