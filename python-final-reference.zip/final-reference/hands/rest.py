from flask import Flask, jsonify
import json 
app = Flask(__name__)

@app.route("/json")  #http://localhost:5000/json
def json1():
    with open(r"D:\PPT\python\hands\data\example.json", "rt") as f:
        obj = json.load(f)
    #print(obj)
    resp = jsonify(obj)
    resp.status_code = 200
    return resp
    
@app.route("/index")
def index():
    return "<html><body><h1>BYE</h1></body></html>"

if __name__ == '__main__':
    app.run()
    
'''
url = 'http://localhost:5000/json'
r = requests.get(url)
r.json()
'''