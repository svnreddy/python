



import numpy as np

print("""
Most models have multiple hyperparameters and the best way 
to choose a combination of those parameters is with a grid search. 
However, it is sometimes useful to plot the influence 
of a single hyperparameter on the training and test data to determine 
if the estimator is underfitting or overfitting for some hyperparameter values.
""")

print("""
 Decision trees become more overfit the deeper they are because 
 at each level of the tree the partitions are dealing with a smaller 
 subset of data. One way to deal with this overfitting process 
 is to limit the depth of the tree. 
 
 The validation curve explores the relationship of the "max_depth" parameter 
 to the R2 score with 10 shuffle split cross-validation.
 """)

from sklearn.tree import DecisionTreeRegressor
from yellowbrick.model_selection import ValidationCurve
import pandas as pd

# Load a regression dataset
data = pd.read_csv("data/energy.csv")

# Specify features of interest and the target
targets = ["heating load", "cooling load"]
features = [col for col in data.columns if col not in targets]

# Extract the instances and target
X = data[features]
y = data[targets[0]]

viz = ValidationCurve(
    DecisionTreeRegressor(), param_name="max_depth",
    param_range=np.arange(1, 11), cv=10, scoring="r2"
)

# Fit and poof the visualizer
viz.fit(X, y)
viz.poof()