import warnings
from sklearn.exceptions import * 
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=DataConversionWarning)
warnings.simplefilter(action='ignore', category=ConvergenceWarning)

import pandas as pd
import numpy as np
from sklearn.preprocessing import *
from  sklearn.decomposition import * 
import matplotlib.pyplot as plt 
from sklearn.model_selection import * 
from sklearn.metrics import *
from sklearn.pipeline import Pipeline
from sklearn import datasets

from sklearn.ensemble import *  
from sklearn.tree import *

print("------------------------ iris data DecisionTreeClassifier ---------")
iris = datasets.load_iris()
X_train, X_test, y_train, y_test = train_test_split(iris.data, iris.target, random_state=0)

clf = DecisionTreeClassifier()
print("check default value of all params") 
print(clf.get_params()  )

clf = clf.fit(X_train, y_train)
predicted = clf.predict(X_test)


print("Training Accuracy",accuracy_score(y_train, clf.predict(X_train)))
print("Test data Accuracy",accuracy_score(y_test, predicted))

print("Predicted class for test data ...") 
print(predicted)

print("the probability of each class can be predicted(test data)")
print(clf.predict_proba(X_test))

print("feature importance")
[print(i,":", j) for i,j in zip(iris.feature_names,clf.feature_importances_) ]


vals = cross_val_score(clf, iris.data, iris.target, cv=10)
print("cross validated score %3.2f +/- %3.2f" % (vals.mean(),vals.std()) )


import graphviz 
dot_data = export_graphviz(clf, out_file=None, 
                         feature_names=iris.feature_names,  
                         class_names=iris.target_names,  
                         filled=True, rounded=True,  
                         special_characters=True)  
graph = graphviz.Source(dot_data)  
print("Generated iris.pdf for visualization")
graph.render('iris') #'iris.pdf'