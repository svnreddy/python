from __future__ import print_function, division 
from pkg.MyInt import MyInt 
import unittest

class MyTest(unittest.TestCase):
    def test_add(self):
        """Testing add functionality"""
        a = MyInt(2)
        b = MyInt(3)
        c = a + b 
        self.assertEqual(c, MyInt(50))
    def test_sub(self):
        """Testing sub functionality"""
        a = MyInt(2)
        b = MyInt(3)
        c = a - b 
        self.assertEqual(c, MyInt(-1))