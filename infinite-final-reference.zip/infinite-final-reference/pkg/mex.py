from __future__ import division, print_function
def square(x):
    """first function
    square"""
    z = x*x 
    return z
    
#mean(lst) =      Sum/length
def mean(lst):
    return sum(lst)/float(len(lst))

#sd(lst) =        sqrt[SUM of square of ( xi - mean)  / n ]
def sd(lst):
    import math 
    m = mean(lst)
    return math.sqrt(sum([(x-m)**2 for x in lst])/float(len(lst)))
    
    
#Given a dir, find the file name with max size 
#1. glob : Function glob - list of file and dir names given a dir
#import glob  
#input_dir = ????
#filelist = glob.glob(input_dir + "\*")
#2. Use os.path , functions to find files only from output of Step 2 
#os.path.isfile(string_path)
#3. Create a dict of filename vs size ( comes from os.path)
#os.path.getsize(string_path)
#4. Sort above based on value (ie size)
#5. Take  last value from STep 5 => ANSWER
#6. function : in : dir , out = filename 

import glob 
import os.path 
def get_max_filenameV0(input_dir):
    #TODO
    #check for errorneous input_dir 
    try:
        filelist = glob.glob(input_dir + "\*")
    except Exception:
        return None
    d = {}
    for file in filelist:
        if os.path.isfile(file):
            d[file] = os.path.getsize(file)
    s_d = sorted(d, key=lambda k: d[k])
    return s_d[-1]
    
import threading 
def get_max_filename(input_dir):
    filelist = glob.glob(input_dir + "\*")
    d = {file:os.path.getsize(file) for file in filelist 
            if os.path.isfile(file)}
    s_d = sorted(d, key=lambda k: d[k])
    print("From", threading.current_thread().getName(), s_d[-1])
    return s_d[-1]   
    



