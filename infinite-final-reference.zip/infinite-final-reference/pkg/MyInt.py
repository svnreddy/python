class MyInt(object):
    def __init__(self, v):
        self.value = v 
    def  __add__(self,other):
        z = self.value + other.value 
        return MyInt(z) 
    def  __sub__(self,other):
        z = self.value - other.value 
        return MyInt(z) 
    def square(self):
        sq = self.value ** 2 
        return MyInt(sq) 
    def __str__(self):
        o = "MyInt(" + str(self.value) + ")"
        return o 
    def __eq__(self, other):
        return self.value == other.value 
        
#############
from pkg.MyInt import Complex 
a = Complex(1,2)
b = Complex(2,3)
c = a + b 
print(c) #Complex(3,5)

