from __future__ import division, print_function 
#import sys 
#a = sys.argv[1]
#b = sys.argv[2]
#print(int(a)+int(b))
###########################
s = "Hello World"
#H - 1
#e - 1 
#l - 3 
#...
#Take each char(ch1) from s
for ch1 in s:
    #initialize counter 
    counter = 0 
    #Take each char(ch2) from s 
    for ch2 in s:
        #if ch and ch1 are same 
        if ch1 == ch2:
            #increment counter 
            counter += 1
    #print ch1 and counter 
    print(ch1, counter)
#########################

list - Duplicates-A, Indexing-A, InsertionOrdered - A,Mutable
    tuple - Immuatble, --- above -- 
set - Duplicates-NA, Indexing - NA , IO - NA,Mutable
    frozenset - Immutable, --- above --- 
-------------------------
dict - Collection (key,value) , Keys are like Set ,Mutable
-----------------------------------------------------
        Creation    Emtpy       conversion
list    []          []          list(...)
tuple   ()          ()          tuple(...)
set     {}          set()       set(...)
dict    {k:v}       {}          dict(...)

>>> l = [1,2,3,4]
>>> res = [1,4,9,16]

Create an empty list 
Take each element from L 
    square it and append to empty list 
    
from sqlite3 import connect
con = connect("iris.db")
cur = con.cursor()
cur.execute("create table iris (sl double, sw double, pl double ,
            pw double,Name string)")
res = [[float(e1) for e1 in e.split(",")[:-1]] + 
        [e.split(",")[-1].strip()] for e in lines[1:]]
out = [ cur.execute("insert into iris values(?,?,?,?,?)", e ) 
        for e in res]
con.commit()
q = cur.execute("select Name, max(sl) from iris group by Name")
rows = list(q.fetchall())
con.close()



---------------------------------
Given a dir, find the file name with max size 
1. glob : Function glob - list of file and dir names given a dir
import glob  
input_dir = ????
filelist = glob.glob(input_dir + "\*")
2. Use os.path , functions to find files only from output of Step 2 
os.path.isfile(string_path)
3. Create a dict of filename vs size ( comes from os.path)
os.path.getsize(string_path)
4. Sort above based on value (ie size)
5. Take  last value from STep 5 => ANSWER
6. function : in : dir , out = filename 


\\  r""













