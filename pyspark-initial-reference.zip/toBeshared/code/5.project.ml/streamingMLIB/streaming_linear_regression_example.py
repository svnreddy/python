#Set anaconda before py3.5 in path
# args= <trainingDir> <testDir> <numFeatures>
#spark-submit  --master local[4] streaming_linear_regression_example.py train test 3
#Create train and test directory 
#copy train and test data (increment 1, 2, 3..)
#to converge , keep on copying same train data as 2.txt, 3.txt 
#you would see predictions converges 
# rm -rf test train 
# mkdir test train 
#cp d:\desktop\ppt\spark\data\streaming_lm_train.txt train\1.txt
#cp d:\desktop\ppt\spark\data\streaming_lm_test.txt test\1.txt


"""
Streaming Linear Regression Example.
"""
from __future__ import print_function


import sys
import re

from pyspark import SparkContext
from pyspark.streaming import StreamingContext

from pyspark.mllib.linalg import Vectors
from pyspark.mllib.regression import LabeledPoint
from pyspark.mllib.regression import StreamingLinearRegressionWithSGD


if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: streaming_linear_regression_example.py <trainingDir> <testDir>",
              file=sys.stderr)
        exit(-1)

    sc = SparkContext(appName="PythonLogisticRegressionWithLBFGSExample")
    ssc = StreamingContext(sc, 10)

    # $example on$
    def LabeledPoint_parse(lp):        
        ar = filter(lambda x: x , re.split(r"\(|\)|,|\[|\]", lp))
        label = float(ar[0])
        vec = Vectors.dense([float(x) for x in ar[1:]])
        return LabeledPoint(label, vec)

    trainingData = ssc.textFileStream(sys.argv[1]).map(LabeledPoint_parse).cache()
    testData = ssc.textFileStream(sys.argv[2]).map(LabeledPoint_parse)

    numFeatures = int(sys.argv[3])
    model = StreamingLinearRegressionWithSGD()
    model.setInitialWeights([0.0, 0.0, 0.0])

    model.trainOn(trainingData)
    model.predictOnValues(testData.map(lambda lp: (lp.label, lp.features))).pprint()

    ssc.start()
    ssc.awaitTermination()
    # $example off$
