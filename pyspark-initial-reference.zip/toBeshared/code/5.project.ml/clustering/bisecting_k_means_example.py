#Set anaconda before py3.5 in path
#spark-submit  --master local[4] bisecting_k_means_example.py

from __future__ import print_function


from pyspark.ml.clustering import BisectingKMeans

from pyspark.sql import SparkSession

"""
An example demonstrating bisecting k-means clustering.
"""

if __name__ == "__main__":
    spark = SparkSession\
        .builder\
        .appName("BisectingKMeansExample")\
        .getOrCreate()

    # $example on$
    # Loads data.
    dataset = spark.read.format("libsvm").load(r"d:\desktop\ppt\spark\data\sample_kmeans_data.txt")

    # Trains a bisecting k-means model.
    bkm = BisectingKMeans().setK(2).setSeed(1)
    model = bkm.fit(dataset)

    # Evaluate clustering.
    cost = model.computeCost(dataset)
    print("Within Set Sum of Squared Errors = " + str(cost))

    # Shows the result.
    print("Cluster Centers: ")
    centers = model.clusterCenters()
    for center in centers:
        print(center)
    # $example off$

    spark.stop()
