from __future__ import print_function

from pyspark.sql import SparkSession

from pyspark.sql import Row

# $ spark-submit  --driver-class-path mysql-connector-java-5.1.34.jar  --conf spark.executor.extraClassPath=mysql-connector-java-5.1.34.jar  --jars ../mysql-connector-java-5.1.34.jar --master local[4] datasource.py


"""
A simple example demonstrating Spark SQL data sources.
"""


def basic_datasource_example(spark):

    df = spark.read.load(r"D:/Desktop/PPT/spark/data/users.parquet")
    df.select("name", "favorite_color").write.mode('ignore').save("namesAndFavColors.parquet")

    df = spark.read.load(r"D:/Desktop/PPT/spark/data/people.json", format="json")
    df.select("name", "age").write.mode('ignore').save("namesAndAges.parquet", format="parquet")

    df = spark.sql("SELECT * FROM parquet.`D:/Desktop/PPT/spark/data/users.parquet`")
    df.show()



def parquet_example(spark):

    peopleDF = spark.read.json(r"D:/Desktop/PPT/spark/data/people.json")

    # DataFrames can be saved as Parquet files, maintaining the schema information.
    peopleDF.write.mode('ignore').parquet(r"D:/Desktop/PPT/spark/data/people.parquet")

    # Read in the Parquet file created above.
    # Parquet files are self-describing so the schema is preserved.
    # The result of loading a parquet file is also a DataFrame.
    parquetFile = spark.read.parquet(r"D:/Desktop/PPT/spark/data/people.parquet")

    # Parquet files can also be used to create a temporary view and then used in SQL statements.
    parquetFile.createOrReplaceTempView("parquetFile")
    teenagers = spark.sql("SELECT name FROM parquetFile WHERE age >= 13 AND age <= 19")
    teenagers.show()   


def parquet_schema_merging_example(spark):

    # spark is from the previous example.
    # Create a simple DataFrame, stored into a partition directory
    sc = spark.sparkContext

    squaresDF = spark.createDataFrame(sc.parallelize(range(1, 6))
                                      .map(lambda i: Row(single=i, double=i ** 2)))
    squaresDF.write.mode('ignore').parquet(r"D:/Desktop/PPT/spark/data/test_table/key=1")

    # Create another DataFrame in a new partition directory,
    # adding a new column and dropping an existing column
    cubesDF = spark.createDataFrame(sc.parallelize(range(6, 11))
                                    .map(lambda i: Row(single=i, triple=i ** 3)))
    cubesDF.write.mode('ignore').parquet(r"D:/Desktop/PPT/spark/data/test_table/key=2")

    # Read the partitioned table
    mergedDF = spark.read.option("mergeSchema", "true").parquet(r"D:/Desktop/PPT/spark/data/test_table")
    mergedDF.printSchema()

    # The final schema consists of all 3 columns in the Parquet files together
    # with the partitioning column appeared in the partition directory paths.
    


def json_dataset_example(spark):

    # spark is from the previous example.
    sc = spark.sparkContext

    # A JSON dataset is pointed to by path.
    # The path can be either a single text file or a directory storing text files
    path = r"D:/Desktop/PPT/spark/data/people.json"
    peopleDF = spark.read.json(path)

    # The inferred schema can be visualized using the printSchema() method
    peopleDF.printSchema()
    # root
    #  |-- age: long (nullable = true)
    #  |-- name: string (nullable = true)

    # Creates a temporary view using the DataFrame
    peopleDF.createOrReplaceTempView("people")

    # SQL statements can be run by using the sql methods provided by spark
    teenagerNamesDF = spark.sql("SELECT name FROM people WHERE age BETWEEN 13 AND 19")
    teenagerNamesDF.show()
   

    # Alternatively, a DataFrame can be created for a JSON dataset represented by
    # an RDD[String] storing one JSON object per string
    jsonStrings = ['{"name":"Yin","address":{"city":"Columbus","state":"Ohio"}}']
    otherPeopleRDD = sc.parallelize(jsonStrings)
    otherPeople = spark.read.json(otherPeopleRDD)
    otherPeople.show()
    


def jdbc_dataset_example(spark):

    # Note: JDBC loading and saving can be achieved via either the load/save or jdbc methods
    # Loading data from a JDBC source
    jdbcDF = spark.read \
        .format("jdbc") \
        .option("url", "jdbc:mysql://localhost:3306/") \
        .option("dbtable", "information_schema.tables") \
        .option("user", "root") \
        .option("password", "") \
        .load()

    jdbcDF.show()
    
    jdbcDF2 = spark.read \
        .jdbc("jdbc:mysql://localhost:3306/", "information_schema.tables",
              properties={"user": "root", "password": ""})

    # Saving data to a JDBC source
    jdbcDF.write.mode('ignore') \
        .format("jdbc") \
        .option("url", "jdbc:mysql://localhost:3306/") \
        .option("dbtable", "information_schema.tables") \
        .option("user", "root") \
        .option("password", "").mode('ignore') \
        .save()

    jdbcDF2.write.mode('ignore') \
        .jdbc("jdbc:mysql://localhost:3306/", "information_schema.tables",
              properties={"user": "root", "password": ""})
    # $example off:jdbc_dataset$


if __name__ == "__main__":
    spark = SparkSession \
        .builder \
        .appName("Python Spark SQL data source example") \
        .getOrCreate()

    basic_datasource_example(spark)
    parquet_example(spark)
    parquet_schema_merging_example(spark)
    json_dataset_example(spark)
    jdbc_dataset_example(spark)

    spark.stop()
