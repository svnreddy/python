from __future__ import print_function
#uses mysql for hive 
# spark-submit  --driver-class-path mysql-connector-java-5.1.34.jar  --conf spark.executor.extraClassPath=mysql-connector-java-5.1.34.jar  --jars ../mysql-connector-java-5.1.34.jar --master local[4] hive2.py

from os.path import expanduser, join

from pyspark.sql import SparkSession
from pyspark.sql import Row


"""
A simple example demonstrating Spark SQL Hive integration.

"""


if __name__ == "__main__":

    # warehouse_location points to the default location for managed databases and tables
    warehouse_location = "file:///tmp/spark-warehouse"

    spark = SparkSession \
        .builder \
        .appName("Python Spark SQL Hive integration example") \
        .config("spark.sql.warehouse.dir", warehouse_location) \
        .enableHiveSupport() \
        .getOrCreate()

    # spark is an existing SparkSession
    students = spark.read.format("csv") \
                           .option("sep", "|") \
                           .option("header", True) \
                           .load(r"D:\Desktop\PPT\spark\data\StudentDataHeader.csv")
                           
    students.show()
    students.write.mode("overwrite").saveAsTable("studentpq3")




    # Queries are expressed in HiveQL
    spark.sql("SELECT * FROM studentpq3").show()

    # Aggregation queries are also supported.
    spark.sql("SELECT COUNT(*) FROM studentpq3").show()


    # The results of SQL queries are themselves DataFrames and support all normal functions.
    sqlDF = spark.sql("SELECT name, email FROM studentpq3 WHERE id < 10 ORDER BY name")

    sqlDF.show()


    # read
    studentDFrame = spark.read.table("studentpq3")

    studentDFrame.createOrReplaceTempView("studentsView")

    # Queries can then join DataFrame data with data stored in Hive.
    spark.sql("SELECT * FROM studentsView r JOIN studentpq3 s ON r.id = s.id").show()


    spark.stop()
