from __future__ import print_function


#nc -lk 9998 
#nc -lk 9997
#spark-submit --master local[4] TextNetworkGrep.py 192.168.1.2 9997,9998  2
#for stopping stage info, use: --conf spark.ui.showConsoleProgress=false

import sys
from pyspark import *
from pyspark.streaming import *



# 
# Receives text from multiple TextNetworkStreams and counts how many '\n' delimited
# lines have the word 'the' in them. 
# Usage: RawNetworkGrep  <host> <port1>,<port2> <batchSec>
#   <numStream> is the number rawNetworkStreams, which should be same as number
#               of work nodes in the cluster
#   <host> is "localhost".
#   <port1>,<port2> is the port on which nc is sending texts 
#   <batchSec> is the Spark Streaming batch duration in seconds
# 


if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: TextNetworkGrep  <host> <port1>,<port2> <batchSec>")
        exit(-1)  

    
    host = sys.argv[1]
    port = sys.argv[2].split(",")
    batchSec = int(sys.argv[3])
    
   
    sc = SparkContext(appName="TextNetworkGrep")
    ssc = StreamingContext(sc, batchSec)
      
    textStreams = [ ssc.socketTextStream(host, int(p)) for p in port ]  
    
    union = ssc.union(*textStreams)
    
    filtered = union.filter( lambda l : "the" in l ).count() #how many lines got 'the'
    filtered.foreachRDD(lambda r : print("Grep count for 'the': " + "".join(str(v) for v in r.collect()) ))
      
    ssc.start()
    ssc.awaitTermination()


