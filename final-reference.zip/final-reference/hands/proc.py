"""powershell.exe -c "ps"
From output , create a 
dict of pid : {'ProcessName': .., 'Handles': ..., 'VM': .. }
"""
from pkg.mex import * 

def convert(line):
    sl = line.split()
    if len(sl) == 7:#cpu is missing
        sl.insert(5,"0")
    return sl 

command = 'powershell.exe -c "ps"'
out,err = execute_and_return_output(command)

result = {}
for line in out.splitlines()[3:-2]:
    h, npm,pm, ws, vm, cpu, pid, pn = convert(line)
    #print(convert(line), len(convert(line)))
    result[int(pid)] = {'ProcessName': pn, 'Handles': int(h), 
            'VM': int(vm), 'cpu':float(cpu.replace(',','')) }
import pprint
pprint.pprint(result)
print("Top5")
rs = sorted(result, key = lambda k: result[k]['cpu'], reverse=True)
processnames=[result[pid]['ProcessName']  for pid in rs]
print(processnames[0:5])








