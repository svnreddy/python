from flask import Flask, request, jsonify 
import json 

app = Flask(__name__)

@app.route("/")
def home():
    return """
    <html><body><h1>Hello there!!!</h1></body></html>
    """
#URL: http://127.0.0.1:5000/json 
@app.route("/json", methods=['POST'])
def json():
    from sqlite3 import connect 
    con = connect(r"iris.db")
    cur = con.cursor()
    q = cur.execute("""select name, max(sl),min(sl),max(sw),min(sw),  max(pl),min(pl), max(pw),min(pw) from iris  group by name order by name""")
    result = list(q.fetchall()) 
    con.close()
    obj = {}
    for n,a,b,c,d,e,f,g,h in result:
        obj[n] = {"max":[a,c,e,g], "min":[b,d,f,h]}
    resp = jsonify(obj)
    print(resp)
    resp.status_code = 200 
    return resp 
'''
import requests
url = "http://127.0.0.1:5000/json"
r = requests.post(url)
obj=r.json()
'''

if __name__ == '__main__':
    app.run()