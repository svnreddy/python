﻿from  __future__   import print_function, division

##import sys 
##
##a = sys.argv[1]
##b = sys.argv[2]
###c = int(a) 
###d = int(b)
##print(a, b , "=", int(a)+int(b))
##
##
########################
#s = "Hello World"
#
##Take each char(ch) from s 
#d = {}
#for ch in set(s):
#    #initialize counter 
#    counter = 0
#    #Take each char(ch1) from s 
#    for ch1 in s:
#        #if ch and ch1 are same 
#        if ch == ch1:
#            #increment counter
#            counter += 1 #counter = counter + 1
#    #print ch and counter 
#    d[ch] = counter 
#    print(ch, '-', counter)
##
##    
##Print prime numbers from 3 to 100 
##Take each (n) from 3 to 100 
##    Take i from 2 to n-1 
##        if n mod i is not zero for all i 
##        then n is a prime 
##        else 
##            it is not prime 
#    
##for n in range(3,20):
##    #prime = True 
##    for i in range(2, n-1):
##        if n % i == 0:
##            #prime = False 
##            break 
##    #if prime:
##    #    print(n, "is prime")
##    else:
##        print(n, "is prime")
#    
#    
#counter = 0 
#for x in range(3,100):
#    for y in range(x,100):
#        for z in range(y,100):
#            if z*z == x*x + y*y: # and z > y and y > x :
#                print(z,x,y)
#                counter = counter + 1
#print(counter)
#    
#    
#s = "aaaabcccbc"
#out = "abc" 
#
#create empty string (out)
#Take each char(ch) from s 
#    if ch does not exist in out 
#        concatenate ch to out 
#print out 
#
##-------------------------------------------
#[]   list - Duplicates -A, Insertion ordered-Y, indexing-Y, mutable
#()       tuple -- immutable , ----above---
#   
#{}   set - Duplicates - NA, IO - N, Index-N, mutable 
#    frozenset -- immutable , --- above---
#----------------------
#dict - Key, Value , Keys are like set 
#---------------------
#input = [1,3,5,7,4]
#output = [1,9,25,49,16]
#    
## Create empty list 
#output = []
## Take each element from input 
#for e in input:
#    # square it and append to empty list 
#    output.append(e*e)
#
#input = [1,3,5,7,4]
#output = [1,3,5,7]
#
## Create empty list 
#output = []
## Take each element from input 
#for e in input:
#    # if element is odd
#    if e % 2 == 1:
#        #then only add to empty list 
#        output.append(e*e)
#
#input = [1,3,5,7,4]
#output = [1,9,25,49]
#    
#    
###############
#s = '[1,2,3,4]'  # ['1', '2', '3', '4']
#lst = [1,2,3,4]
#
##Strip with '[]' and split with ',' and store to s2 
##create empty list 
#lst = []
##take each element from s2 
#for e in s.strip('[]').split(','):
#    #convert to int and append to empty list 
#    lst.append(int(e))
#
###########
#s = "Name:ABC,age=20|Name:XYZ,age=30"
#s2 = "Name:Abc,age=20|Name:Xyz,age=30"
#
##Split with "|" and store to lst #str.split
#lst = s.split("|")
##create empty list(out)
#out=[]
##Take each element from lst 
#for e in lst:
#    #split with "," and take first part from result
#    e3 = e.split(",")[0]
#    #then split with ':' and take 2nd part from result (res)
#    e5 = e3.split(":")[1]
#    #do title/capitalize with res ( res1)#str.title
#    e6 = e5.title()
#    #replace that element with res by res1 #str.replace 
#    e7 = e.replace(e5, e6)
#    #append to empty list(out) 
#    out.append(e7)
#print(e7)
##join that empty list(out) with "|" #str.join
#s2 = "|".join(out)
#print(s2)
#
############
#s = "hello World"
#Create  dict of chars and its count -> called Freq 
#    
#Create empty dict(d)
#Take each char(ch) from s 
#    if ch does not exist in d 
#        create ch as key and initialize 
#    else 
#        increment ch as key's value 
#print d 
#
#
#d = {}
#for ch in s:
#    if ch not in d :
#        d[ch] = 1 
#    else:
#        d[ch] = d[ch] + 1 
#print(d)
#
###############
#Given:
D1 = {'ok': 1, 'nok': 2}
D2 = {'ok': 2, 'new':3 }
#
##values are added for same keys
#D_MERGE = { 'ok': 3, 'nok': 2 , 'new':3  }
#
#Create D_Merge as same of D1 
#for each K in D2 
#    if K exists in D_merge 
#        update value of K in D_merge 
#        as summation of old and D2's value 
#    else if does not exist 
#        create new key in D_merge with value from D2 
#


D1 = {'ok': 1, 'nok': 2}
D2 = {'ok': 2, 'new':3 }

D_MERGE = D1.copy()
for k,v in D2.items():
    if k in D_MERGE:
        D_MERGE[k] += v
    else:
        D_MERGE[k] = v
print("D1",D1, "RES", D_MERGE)
###############
Find checksum 
input="ABCDEF1234567890"
Take each two character(one byte) from above 
(which are in hex digit )
Convert to int  (Hint: use int function with base)
Sum all and then find mod with 255, that is your checksum 

list(zip(input[::2], input[1::2]))
o = []
for e in lst:
    o.append(e*e)
int('AB', base=16)
sum([1,2,3])
x % 255 

###########
create empty dict 
Take each element from lines after passing through enumerate 
    create key=index and value as length of string 


nslookup www.google.com
echo %errorlevel%
nslookup www.google.com > out.txt
type out.txt | findstr /c:"Server"
"""
Server:\t\t192.168.43.1\nAddress:\t192.168.43.1#53\n\nNon-authoritative answer:
\nName:\twww.google.com\nAddress: 172.217.26.228\n\n'
"""
'''
class subprocess.Popen(args, bufsize=0, 
stdin=None, stdout=None, stderr=None, shell=False, 
universal_newlines=False)
'''
#1
import subprocess as S
command = "nslookup www.google.com"
proc = S.Popen(command, shell=True, 
    stdout=S.PIPE, stderr=S.PIPE, universal_newlines=True)
outs, oute = proc.communicate()
print(outs)
import re 
res = re.findall(r"Address: (.+?)\n\n"  , outs)
res =re.findall (r"Addresses:\s+((.+)\n\t\s*(.+)\n\n)",s)

com1 = r"c:\windows\system32\ping %s" % res[0][-1]
proc = S.Popen(com1, shell=True, 
    stdout=S.PIPE, stderr=S.STDOUT, universal_newlines=True)
outs, oute = proc.communicate()
print(outs)

#2
command = "nslookup www.google.com"
proc = S.Popen(command, shell=True, 
    stdout=S.PIPE, stderr=S.PIPE, universal_newlines=True)
outs, oute = proc.communicate()
print(proc.returncode)

#3 nslookup www.google.com > out.txt
with open("out.txt", "wt") as f :
    command = "nslookup www.google.com"
    proc = S.Popen(command, shell=True, 
        stdout=f, stderr=S.STDOUT, universal_newlines=True)
    proc.wait()

proc2 = S.Popen("type out.txt", shell=True, 
    stdout=S.PIPE, stderr=S.PIPE, universal_newlines=True)
outs, oute = proc2.communicate()
print(outs)    
    
#4 type out.txt | findstr /c:"Server"
command = "type out.txt"
com2 = 'findstr /c:"Server"'
proc = S.Popen(command, shell=True, 
    stdout=S.PIPE, stderr=S.STDOUT, universal_newlines=True)
proc2 = S.Popen(com2, shell=True, 
    stdin= proc.stdout, 
    stdout=S.PIPE, stderr=S.STDOUT, universal_newlines=True)
proc.stdout.close()
outs, oute = proc2.communicate()
#
proc = S.Popen(command + "| "+com2, shell=True, 
    stdout=S.PIPE, stderr=S.STDOUT, universal_newlines=True)
outs, oute = proc2.communicate()    
    
    
##
1. Create below env var - os.environ is a dict 
HOST        hostname - sys.platform
SCRIPT      this script name only (without extension)
            os.path.basename(), sys.argv[0]
SCRIPT_PID  this script pid , os.getpid()
OUTDIR      C:/tmp/adm
LOGFILE     $OUTDIR/$SCRIPT.log , os.path.expandvars
2. Dump all envs in parent process , os.environ
3. in child process, dump above env vars 
Popen with "printenv"/"set", get to string and 
dump only above variables 

import sys, os.path, subprocess as S 
import sys, platform, datetime as D, os 
new = dict(
    HOST=platform.uname().node,
    SCRIPT=os.path.splitext(os.path.basename(sys.argv[0]))[0],
    OUTDIR= "c:/tmp/adm",
    SCRIPT_PID=str(os.getpid()),
    LOGFILE="$OUTDIR/$SCRIPT.$DT.log",
    DT=D.datetime.today().strftime("%m%d%y%H%M%S")
) 
    
######
lst = [1,2,3]
res = []
for e in lst:
    res.append(e*e)

d = {}
for e in lst:
    d[e] = e*e

>>> d
{1: 1, 2: 4, 3: 9}
res = [ e*e for e in lst]
d = { e:e*e for e in lst}
rs = { e*e for e in lst}
>>> rs
{1, 4, 9}
>>> [ e*e for e in lst if e%2 == 0]
[4]
res = []
for e in lst:
    if e%2 == 0:
            res.append(e*e)

>>> [(x,y) for x in lst if x%2==0 for y in lst]
[(2, 1), (2, 2), (2, 3)]
res = []
for x in lst:
    if x%2==0:
            for y in lst:
                    res.append( (x,y) )

res = [(x,y,z)    for x in range(3,100) for y in range(x,100) 
        for z in range (y,100) if z*z == x*x + y*y]
>>> len(res)
50    
#####################
from sqlite3 import connect 
con = connect(r"iris.db")
cur = con.cursor()
cur.execute("""create table iris (sl double, 
    sw double, pl double, pw double, name string)""") 
for row in rowsd:
    s = cur.execute("insert into iris values(?,?,?,?,?)",row)

con.commit()
q = cur.execute("""select name, max(sl) from iris 
        group by name order by name""")
result = list(q.fetchall())
print(result)
con.close()
#[('Iris-setosa', 5.8), ('Iris-versicolor', 7.0), ('Iris-virginica', 7.9)]

con = connect(r"iris.db")
cur = con.cursor()
q = cur.execute("""select name, 
            max(sl),min(sl),
            max(sw),min(sw),
            max(pl),min(pl),
            max(pw),min(pw)
            from iris  group by name order by name""")
result = list(q.fetchall())
print(result)
#[('Iris-setosa', 5.8, 4.3, 4.4, 2.3, 1.9, 1.0, 0.6, 0.1), ('Iris-versicolor', 7.0, 4.9, 3.4, 2.0, 5.1, 3.0, 1.8, 1.0), ('Iris-virginica', 7.9, 4.9, 3.8, 2.2, 6.9, 4.5, 2.5, 1.4)]
    
res = {}
for n,a,b,c,d,e,f,g,h in result:
    res[n] = {"max":[a,c,e,g], "min":[b,d,f,h]}
    
    
##
import xml.etree.ElementTree as ET
r = ET.parse(r"./data/example.xml")
root = r.getroot()
ns = {}
for n in root.findall("./country"):
    res = []
    for ni in n.findall("./neighbor"):
            res.append(ni.attrib["name"])
    ns[n.attrib["name"]] = res

>>> ns
{'Liechtenstein': ['Austria', 'Switzerland'], 'Panama': ['Costa Rica
'], 'Singapore': ['Malaysia']}
>>> ns['Panama']
['Costa Rica', 'Colombia']    
ns = {n.attrib["name"]:
        [ni.attrib["name"] for ni in n.findall("./neighbor")] 
    for n in root.findall("./country")}
    
    
########################    
def mean(lst):
    """returns Sum of lst/length of lst
    lst: list
    """
    
    
def sd(lst):
    """returns sqrt of( SUM of square of ( each elemnt - mean)  / length of lst  )
    lst: list 
    """

#File Hands on 
def filecopy(src, dest):
    """Copy one file to another file 
    src,dest: file name as string
    returns None 
    """
    
def filecompare(file1,file2):
    """Given two files, compare file contents line by line 
    file1,file2 : file name as string 
    returns line number of 2nd file where first difference occurs
    """
    
def filemerge(one_dir, dest_file, file_filter):
    """Concatenate many files with file_file_filter under one dir into one file
    one_dir : given dir name as str 
    dest_file : file name where to copy 
    file_filter = regex of files to merge 
    returns none """
    



    
    
    
#Subprocess Hands on 
def execute_and_return_code(command):
    """Given command, returns it's exit code"""
    
def execute_and_return_output(command):
    """Given command , returns it's stdout and stderr """

def execute_and_redirect_to_file(command, filename):
    """Given command and file name, redirect stdout and stderr to file"""

def execute_with_pipe(command1, command2):    
    """Given two commands, returns output of 2nd command after piping first command""" 


def execute_and_watch(command, TIMEOUT=15, WAIT_AFTER_KILL=60):
    """Execute the command and keep on polling to check command is completed within TIMEOUT 
    If not, manually kill that and then sleep for WAIT_FOR_KILL and return 9 
    If commands is successful, then return it's stdout """
    
def execute_and_return_pattern_match(command, pattern):
    """execute the command and the find the pattern in that stdout 
    and return result
    Use execute_and_return_output(command) function to implement this 
    """
    
    
#Os Hands on 

def update_env_var(another_dict):
    """Given another dict of env vars , update to process env vars 
    Note env vars may contain reference to other environment vars in form of $VAR
    so should expand that before updating
    
    Test above function with with below env vars containing below 
    HOST        hostname 
    DT          todays date(use datetime.datetime) using pattern "%m%d%y%H%M%S" 
    SCRIPT      this script name only (without extension)
    SCRIPT_PID  this script pid 
    OUTDIR      C:/tmp/adm
    LOGFILE      $OUTDIR/$SCRIPT.$DT.log (in unix expansion of variable )
    """
    
def dump_env_var(only_keys):
    """returns dict of  env var of element found in 'only_keys'   
    """
    
def dump_env_var_in_child(only_keys):
    """returns dict env var of element found in 'only_keys'
    in child process"""
    
    
    
def mslog(msg, file=True):
    """takes any message and dumps that message to LOGFILE and console 
   with below format , message may contain any env var and that should be expanded 
   HOST:DT:message 
   Assumes env vars has HOST, LOGFILE and DT which are used in above 
   LOGFILE should be opened in append mode such that earlier content is not overwritten 
   LOGFILE should be written only when file is True 
   """

def file_stat_compare(file1, file2):
    """Compare size, and modification time of two files 
    return true if they are same"""
    
#CSV hands on 
def read_csv(fileName):
    """
    Return list of rows where each element of each row is converted to int, 
    then float, then str whichever succeeds 
    filename: csv file name as string 
    return list of row, where row is another list 
    each row is one row of csv file 
    """
    #use below for conversion, where fn is float first, then int and then str 
    def convert(x, fn):
        try:
            res = fn(x)
        except Exception:
            res = None 
        return res
    #your code starts from here 
   
#recursion
def get_all_files_size(one_dir):
    """Given a directory one_dir , 
    returns dict of filenames and size including subdirs 
    """
    
    
def get_all_files_after(one_dir, after_datetime):
    """Given a directory one_dir , 
    returns list of filenames which are modified or created after_datetime 
    recursively
    after_datetime is in format "YYY-MM-DD"
    """
    
def create_hashes_of_all_files_under_one_dir(one_dir):
    """ Create a .hashes file inside each dir . this file contains 
    all file names of that dir and hash of each file"""
    def md5(fname):
        import hashlib
        hash_md5 = hashlib.md5()
        with open(fname, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
        return hash_md5.hexdigest()
    
    
    
    
    
    
##################
ps -eo pid,ppid,cmd,%mem,%cpu -sort=-%mem | head 
From output , create a 
dict of pid : {'ppid': .., 'cmd': ..., 'mem': .., 'cpu': }

#OR 
top -b -n 1
#OR 
powershell.exe -c "ps"
From output , create a 
dict of pid : {'ProcessName': .., 'Handles': ..., 'VM': .. }


ps -ef | grep mq 
Based on above output, find the process name if it exists 
else print - mq package does not exists 

powershell.exe -c "ps | select -first 10"

 


    
    
    
    
