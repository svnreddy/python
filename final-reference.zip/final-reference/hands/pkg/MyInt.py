class MyInt:
    def __init__(self, v):
        self.val = v 
    def __add__(self, other):
        z = self.val + other.val 
        return MyInt(z) 
    def __str__(self):
        z = "MyInt("+str(self.val)+")"
        return z 
    def __eq__(self, other):
        return self.val == other.val 
    def square(self):
        return MyInt(self.val ** 2)
###################
#from pkg.MyInt import Complex 
#a = Complex(2,3)
#b = Complex(3,4)
#c = a + b 
#print(c)  # Complex(5, 7)

class Complex:
    def __init__(self, re, im):
        self.re = re 
        self.im = im 
    def __add__(self, other):
        return Complex(self.re + other.re,  self.im+other.im) 
    def __str__(self):
        z = "Complex(%d,%d)" % (self.re, self.im)
        return z 















