import subprocess as S, os, sys, os.path, re 
def square(x):
    """ First function square 
    
    >>> square(10)
    100
    
    >>> square(0)
    0
    
    """
    z = x*x 
    return z 
    
def mean(lst):
    """returns Sum of lst/length of lst
    lst: list
    """
    return sum(lst)/len(lst)
    
    
def sd(lst):
    """returns 
    sqrt of( (SUM of square of (each elemnt - mean))/ length of lst  )
    lst: list 
    """
    import math 
    m = mean(lst)
    lst2 = [ (e-m)**2  for e in lst]
    return math.sqrt(sum(lst2)/len(lst2))


#File Hands on 
import time
def measure(f):
    def _inner(*args):
        st = time.time()
        res = f(*args)
        print(time.time()-st)
        return res 
    return _inner
    
def trace(f):
    def _inner(*args):
        print("Entering", f.__name__)
        res = f(*args)
        print("Exiting", f.__name__)
        return res 
    return _inner
    
    
    
@measure 
@trace
def filecopy(src, dest):
    """Copy one file to another file 
    src,dest: file name as string
    returns None 
    """    
    with open(src, "rb") as s:
        with open(dest, "wb") as d:
            d.write(s.read())
    #done 
    return None 
      
@measure       
def filecompare(file1,file2):
    """Given two files, compare file contents line by line 
    file1,file2 : file name as string 
    returns line number of 2nd file where first difference occurs
    """  
    from itertools import zip_longest    
    with open(file1, "rt") as f1 :
        with open(file2, "rt") as f2:
            for index, (l2,l1) in enumerate( zip_longest(f2,f1)):#itertools.zip_longest
                if l2 != l1:
                    return index+1 
    return -1 

@measure 
def filemerge(one_dir, dest_file, file_filter):
    """Concatenate many files with file_filter under one_dir 
    into one file
    one_dir : given dir name as str 
    dest_file : file name where to copy 
    file_filter = regex of files to merge 
    returns none """ 
    #home work 
    pass
    


def execute_and_return_code(command):
    """Given command, returns it's exit code"""
    with open(os.devnull, "w") as DEVNULL:
        proc = S.Popen(command, shell=True, 
            stdout=DEVNULL, stderr=DEVNULL, universal_newlines=True)
        proc.wait()
    return proc.returncode


def execute_and_return_output(command):
    """Given command , returns it's stdout and stderr """
    proc = S.Popen(command, shell=True, 
        stdout=S.PIPE, stderr=S.PIPE, universal_newlines=True)
    return  proc.communicate()


def execute_and_redirect_to_file(command, filename):
    """Given command and file name, redirect stdout 
    and stderr to file"""
    with open(filename, "wt") as f :
        proc = S.Popen(command, shell=True, 
            stdout=f, stderr=S.STDOUT, universal_newlines=True)
        proc.wait()
    return None 

def execute_with_pipe(command1, command2):    
    """Given two commands, returns output of 2nd command 
    after piping first command""" 
    proc = S.Popen(command1, shell=True, 
        stdout=S.PIPE, stderr=S.STDOUT, universal_newlines=True)
    proc2 = S.Popen(command2, shell=True, 
        stdin= proc.stdout, 
        stdout=S.PIPE, stderr=S.STDOUT, universal_newlines=True)
    proc.stdout.close()
    outs, oute = proc2.communicate()
    return outs   
    

def execute_and_return_pattern_match(command, pattern):
    """execute the command and the find the pattern in that stdout 
    and return result
    Use execute_and_return_output(command) function to implement this 
    """
    proc = S.Popen(command, shell=True, 
        stdout=S.PIPE, stderr=S.STDOUT, universal_newlines=True)
    outs, oute = proc.communicate()
    res = re.findall(pattern  , outs)
    return res 

    
    
    
def execute_and_watch(command, TIMEOUT=15, WAIT_AFTER_KILL=60):
    """Execute the command and keep on polling to check command is completed within TIMEOUT 
    If not, manually kill that and then sleep for WAIT_AFTER_KILL 
    and return 9 
    If commands is successful, then return it's stdout """
    import time 
    proc = S.Popen(command, shell=True, 
        stdout=S.PIPE, stderr=S.PIPE, universal_newlines=True)
    timeout = TIMEOUT
    while timeout > 0:
        res = proc.poll()
        if res is not None:
            break
        time.sleep(1)
        timeout -= 1 
    if timeout == 0:
        proc.terminate()
        time.sleep(WAIT_AFTER_KILL)
        if proc.poll() is None:
            proc.kill()
            time.sleep(WAIT_AFTER_KILL)
        return (9, proc.communicate())
    return (res, proc.communicate())
    
   
   
   
   
   
'''
command = "nslookup www.google.com"
file= "out.txt" 
pattern = r"Address: (.+?)\n\n" 
pattern2 = r"Addresses:\s+((.+)\n\t\s*(.+)\n\n)"
command1 = "type out.txt"
command2 = 'findstr /c:"Server"'
'''


def update_env_var(another_dict):
    """Given another dict of env vars , update to process env vars 
    Note env vars may contain reference to other environment vars 
    in form of $VAR, so should expand that before updating
    import sys, platform, datetime as D, os 
    new = dict(
        HOST=platform.uname().node,
        SCRIPT=os.path.splitext(os.path.basename(sys.argv[0]))[0],
        OUTDIR= "c:/tmp/adm",
        SCRIPT_PID=str(os.getpid()),
        LOGFILE="$OUTDIR/$SCRIPT.$DT.log",
        DT=D.datetime.today().strftime("%m%d%y%H%M%S")
    ) 
   
    """
    with_exp = {}
    without_exp = {}
    for k,v in another_dict.items():
        if '$' in v :
            with_exp[k] = v 
        else:
            without_exp[k] = v
    os.environ.update(without_exp)
    #
    os.environ.update({k:os.path.expandvars(v) 
            for k,v in with_exp.items()})
    return None 

def dump_env_var(only_keys):
    """returns dict of  env var of element found in 'only_keys'   
    """
    d = {}
    keys = [k.upper() for k in only_keys]
    for k,v in os.environ.items():
        if k.upper() in keys:
            d[k] = v 
    return d 

def dump_env_var_in_child(only_keys):
    """returns dict env var of element found in 'only_keys'
    in child process
    """
    command = "set" if sys.platform == "win32" else "printenv"
    outs, oute = execute_and_return_output(command)
    d = {}
    keys = [k.upper() for k in only_keys]
    for line in outs.splitlines():
        ss = line.split("=")
        if ss[0].upper() in keys:
            d[ss[0]] = ss[1]
    return d 

    
    
def mslog(msg, file=True):
    """takes any message and dumps that message to LOGFILE and console 
    with below format , message may contain any env var and that should be expanded 
    HOST:DT:message 
    Assumes env vars has HOST, LOGFILE and DT which are used in above 
    LOGFILE should be opened in append mode such that earlier content is not overwritten 
    LOGFILE should be written only when file is True 
    """
    pass



def read_csv(filename):
    """Return list of rows where each element is converted 
    to int, then float, then str whichever succeeds """    
    def convert(x, fn):
        try:
            res = fn(x)
        except Exception:
            res = None 
        return res 
    def one_by_one(x, *fn):
        for f in fn:
            res = convert(x,f)
            if res is not None:
                return res 
        return x
    from csv import reader
    with open(filename, "rt") as f :
        rd = reader(f)
        rows = list(rd)
    tryFn = [int, float, str]
    first =  [ [ one_by_one(e.strip(), *tryFn) for e in row]   
                    for row in rows if len(row) > 0 ]
    return first  


def download(url):
    import requests, threading
    print("Starting to download ", url, " from thread ", threading.current_thread().getName())
    conn = requests.get(url)    
    return [url, len(conn.text)]

    
def is_prime(n):
    import math
    if n == 2 : return True 
    if n % 2 == 0:	return False
    sqrt_n = int(math.sqrt(n))
    a = [1 for i in range(3, sqrt_n + 1, 2) if n % i == 0]
    return False if sum(a) > 0 else True









    
    
    
    
    
    
