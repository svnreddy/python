from __future__  import print_function, division
import subprocess as S
class Subprocess(object):
    def __init__(self, command, wait_after_kill=60):
        """initialization, store all into instance var 
        also, initialize executed flag"""
        self.command = command 
        self.wait_after_kill = wait_after_kill
        self.executed = False 

    def _execute(self, timeout=None, stdin=None, stdout=S.PIPE, 
                stderr=S.PIPE, bufsize=-1, pipeFlag=False):
        """ Internal method - implement timeout behaviour
        with S.Popen....
        Check executed flag and return at begining if set 
        If pipeFlag is true return immediate after proc creation 
        such that pipeTo can consume this stdout
        """
        import time 
        if self.executed:
            return "Already executed, create again"
        self.proc = S.Popen(self.command, bufsize=bufsize,
            shell=True, universal_newlines= True, 
            stdin=stdin, stdout=stdout, stderr=stderr)
        if pipeFlag:
            return None 
        tmout = timeout if timeout is not None else 9999#very big number 
        while tmout > 0 and self.proc.poll() is None:
            time.sleep(1)
            tmout -= 1
        if tmout == 0:
            self.proc.terminate()
            time.sleep(self.wait_after_kill)
            if self.proc.poll() is None:
                self.proc.kill()
                time.sleep(self.wait_after_kill)                
            self._exitcode = -9 
        else:
            self.executed = True 
            self._exitcode = self.proc.returncode
        self._out, self._err = self.proc.communicate()
        return None 
        
    def exitcode(self, timeout=None):
        """ calls _execute and the return it's exit code """
        self._execute(timeout)
        return self._exitcode 
    def stdout(self, timeout=None):
        """ calls _execute and the return it's exit code """
        self._execute(timeout)
        return self._out 
    def stderr(self, timeout=None):
        """ calls _execute and the return it's exit code """
        self._execute(timeout)
        return self._err
    def redirectTo(self, fileName, timeout=None):
        """ Open fileName, pass it's f to _execute  """
        with open(fileName, "wt") as f:
            self._execute(timeout, stdout=f, stderr=S.STDOUT)
        return self._exitcode 
    def pipeTo(self, rhs_command, timeout=None):
        """ calls execute with pipeFlag True
        and then does standard pipe functionality
        and returns other subprocess"""
        self._execute(timeout, stdout=S.PIPE, 
                stderr=S.STDOUT, pipeFlag=True)
        proc2 = Subprocess(rhs_command)
        proc2._execute(timeout, stdin= self.proc.stdout)
        self.proc.stdout.close()
        return proc2
    def get_pattern(self, pattern, timeout=None, isout=True):
        """If isout is true, findall pattern in stdout 
        else in stderr"""
        import re 
        self._execute(timeout)
        if isout:
            res = re.findall(pattern, self._out)
        else:
            res = re.findall(pattern, self._err)
        return res 

if __name__ == '__main__':
    command = "nslookup www.google.com"
    file= "out.txt" 
    pattern = r"Address: (.+?)\n\n" 
    pattern2 = r"Addresses:\s+((.+)\n\t\s*(.+)\n\n)"
    command1 = "type out.txt"
    command2 = 'findstr /c:"Server"'

    a = Subprocess(command)
    print(a.exitcode())
    print(a.stdout())
    print(a.stderr())
    #timeout case 
    a = Subprocess(command)
    print(a.exitcode(1))
    print(a.stdout(1))
    print(a.stderr(1))
    #others 
    a = Subprocess(command)
    a.redirectTo(file)
    #others 
    a = Subprocess(command1)
    b = a.pipeTo(command2)
    print(b.exitcode())
    print(b.stdout())
    print(b.stderr())
    #others 
    a = Subprocess(command)
    print(a.get_pattern(pattern))