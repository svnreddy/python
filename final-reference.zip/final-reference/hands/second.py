"""
1. Create below env var - os.environ is a dict 
HOST        hostname - sys.platform
SCRIPT      this script name only (without extension)
            os.path.basename(), sys.argv[0]
SCRIPT_PID  this script pid , os.getpid()
OUTDIR      C:/tmp/adm
LOGFILE     $OUTDIR/$SCRIPT.log , os.path.expandvars
2. Dump all envs in parent process , os.environ
3. in child process, dump above env vars 
Popen with "printenv"/"set", get to string and 
dump only above variables 
"""
import sys, os.path, subprocess as S 
new = dict(
    HOST=sys.platform,
    SCRIPT=os.path.splitext(os.path.basename(sys.argv[0]))[0],
    OUTDIR= "c:/tmp/adm",
    SCRIPT_PID=str(os.getpid()),
) 
os.environ.update(new)
os.environ["LOGFILE"] = os.path.expandvars(r"$OUTDIR/$SCRIPT.log")
for k,v in os.environ.items():
    if k in new or k == "LOGFILE":
        print(k,"=",v)
        
proc = S.Popen("set", shell=True, 
    stdout=S.PIPE, stderr=S.STDOUT, universal_newlines=True)
outs, oute = proc.communicate()

keys = set(new.keys())
keys.add("LOGFILE")
for line in outs.split():    
    if line.split("=")[0] in keys:
        print(line)

