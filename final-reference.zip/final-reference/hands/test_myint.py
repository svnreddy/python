from pkg.MyInt import MyInt 
import pytest 
class TestMyInt:
    def test_add(self):
        a = MyInt(1)
        b = MyInt(2)
        assert a+b == MyInt(3)
    def test_square(self):
        a = MyInt(1)
        assert a.square() == MyInt(1)
    def test_str(self):
        a = MyInt(1)
        assert str(a) == "MyInt(1)"   