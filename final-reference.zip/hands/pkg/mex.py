import math 
def square(x):
    """Square function
    squaring input number"""
    z = x*x 
    return z
    
#mean(lst) =      Sum/length
def mean(lst):
    return sum(lst)/len(lst)

#sd(lst) =        sqrt[SUM of square of ( xi - mean)  / n ]
def sd(lst):
    m = mean(lst)
    slst = [ (e-m)**2 for e in lst]
    return math.sqrt(sum(slst)/len(lst))

    
##Given dirName, returns maxFileName 
def maxFileName(dirName):
    import glob, os.path 
    names = glob.glob(os.path.join(dirName,"*"))
    ed = {}
    for name in names:
        if os.path.isfile(name):
            ed[name] = os.path.getsize(name)
    #or 
    ed = {name:os.path.getsize(name) for name in names if os.path.isfile(name)}
    sed = sorted(ed, key= lambda k : ed[k])
    return {sed[-1]:ed[sed[-1]]}


def download(url):
    import requests, threading, time 
    print("from", threading.current_thread().getName())
    r = requests.get(url)
    #time.sleep(10)
    return [url, len(r.text)]




