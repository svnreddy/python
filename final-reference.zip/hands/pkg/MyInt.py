class MyInt:
    def __init__(self, v):
        self.value = v 
    def __add__(self, other):
        z = self.value + other.value 
        return MyInt(z) 
    def __sub__(self, other):
        z = self.value - other.value 
        return MyInt(z) 
    def __str__(self):
        res = "MyInt(" + str(self.value) + ")"
        return res 
    def __eq__(self, other):
        return self.value == other.value 
    def square(self):
        return MyInt(self.value**2)
        
        
##################
from pkg.MyInt import Rational 

a = Rational(1,2) 
b = Rational(1,2)
c = a+b 
print(c) #Rational(4,4)


class Rational:
    def __init__(self, n, d):
        self.n = n 
        self.d = d    
    def __add__(self, other):
        n = self.n * other.d + self.d*other.n 
        d = self.d * other.d 
        return Rational(n,d)    
    def __str__(self):
        return "Rational(%d,%d)" % (self.n, self.d)
    




