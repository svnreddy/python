import sys 
#a = int(sys.argv[1])
#b = sys.argv[2]
#c = int(a)
#d = int(b)
#print(a + int(b))

s = "Hello World"

#SET PATH=<<INSTALL>>;%PATH%

#Take each char(ch) from s
for ch in set(s):
    # initialize counter 
    counter = 0
    # Take each char(ch1) from s 
    for ch1 in s:
        # if ch and ch1 are same 
        if ch == ch1 :
            # increment a counter 
            counter += 1 
    # print ch and counter 
    print(ch,"=",counter)

#Create empty dict,d 
d = {}
#Take each char(ch) from s
for ch in s:
    #If ch does not exist in d 
    if ch not in d:
        #then create ch as key and initialize it's value 
        d[ch] = 1
    else: 
        #increment ch, key's value 
        d[ch] = d[ch] + 1 

    
#######################################
[]  list - Duplicates -A , Insertion Ordered-A, indexing-A - mutable
()     tuple - Immutable, --- above ---

{} set - D -NA, IO-NA, Index-NA - mutable 
    frozenset - Immutable, ---above---
---------------------------
dict -  k:v , keys are like set 

[ , , , , ,5 ]  O(n), O(1)



####################
l = [3,5,2,4]
res = 14

Create empty list 
Take each element(e) from l 
    if e is odd 
        append to emptylist 

        
        
        
lstr = '[1,2,3,4]'
res = [1,2,3,4]
        
strip lstr with '[]' and then split with ',' and store to s 
Create an empty list 
Take each element from s 
    convert to int and append to emptylist 
    
    
    

       
        
