import unittest 
from pkg.MyInt import MyInt 

class MyTest(unittest.TestCase):
    def test_add(self):
        """Testig add functionality"""
        a = MyInt(2)
        b = MyInt(3)
        self.assertEqual(a+b, MyInt(5))