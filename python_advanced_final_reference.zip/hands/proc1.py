import threading 
import multiprocessing 
import concurrent.futures

import requests 

def download(url, name=None):
    if name:
        print(threading.current_thread().getName())
    else:
        print(multiprocessing.current_process().name)
    r = requests.get(url)
    return [url,len(r.text)]




if __name__ == '__main__':
    urls = ["http://www.google.co.in" for i in range(10)]
    ex = concurrent.futures.ThreadPoolExecutor(max_workers=10)
    result = ex.map(lambda url: download(url,"thread"), urls)
    print(list(result))
    ex.shutdown()
    #now proces
    ex = concurrent.futures.ProcessPoolExecutor(max_workers=10)
    result = ex.map(download, urls)
    print(list(result))
    ex.shutdown()
    
    
    