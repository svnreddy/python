#python -m http.server --cgi 8080
#http://localhost:8080/cgi-bin/hello.py
import cgi, os, sys 

form = cgi.FieldStorage()
string = """
<form method="post" action="hello.py">
       <p>Name: <input type="text" name="name"/></p>
	   <p>address1: <input type="text" name="addr"/></p>
	   <p>address2: <input type="text" name="addr"/></p>
	   <input type="submit" value="Submit" />
</form>  
"""


####
print("Content-Type: text/html")
print()

print("<html><header><title>CGI</title></header><body>")

if 'REQUEST_METHOD' in os.environ and os.environ['REQUEST_METHOD'].lower() == 'post':
    if 'name' not in form or 'addr' not in form:
        print("<h1> ERROR </h1>")
        print("</body></html>")
        sys.exit(0)
    else:
        print(form.getfirst("name","").upper(), ",".join(form.getlist("addr")))
else:
    print(string)


print("</body></html>")
#print("prefix", key, "prefix", value, "suffix")

'''
import requests
headers = {'Content-Type': 'application/x-www-form-urlencoded'}
data= {'name':'a', 'addr':['b','c']}
r = requests.post("http://localhost:8080/cgi-bin/hello.py",data=data, headers=headers)
>>> r.text
'<html><header><title>CGI</title></header><body>\r\nA b,c\r\n</body></html>\r\n'
>>> r.request.body
'name=a&addr=b&addr=c'
'''












