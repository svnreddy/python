import pytest 
from pkg.MyInt import MyInt 

'''
$ pip install pytest pytest-cov
$ py.test -v test_myint.py 

$ py.test --cov=pkg/  test_myint.py
'''
class TestMyInt:
    def test_add(self):
        """Testing add """
        a = MyInt(2)
        b = MyInt(3)
        assert a+b == MyInt(5)
    def test_square(self):
        """Testing square """
        assert MyInt(2).square() == MyInt(4)
    def test_str(self):
        """Testing square """
        assert MyInt(2).__str__() == "MyInt(2)"