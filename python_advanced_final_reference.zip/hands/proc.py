import threading 
import multiprocessing 

import requests 

result = []

def download(url, lock, name=None):
    if name:
        print(threading.current_thread().getName())
    else:
        print(multiprocessing.current_process().name)
    r = requests.get(url)
    print(url, len(r.text))
    with lock:
        result.append([url,len(r.text)])
    return [url,len(r.text)]




if __name__ == '__main__':
    urls = ["http://www.google.co.in" for i in range(10)]
    han = []
    tl = threading.RLock()
    #thread 
    for url in urls:
        t = threading.Thread(target=download, args=(url, tl, "thread"))
        han.append(t)
    [t.start() for t in han]
    [t.join() for t in han] 
    han.clear()
    print(result, len(result))
    #now proces
    tl = multiprocessing.RLock()
    for url in urls:
        p = multiprocessing.Process(target=download, args=(url,tl ))
        han.append(p)
    [p.start() for p in han]
    [p.join() for p in han] 
    print(result, len(result))
    
    
    