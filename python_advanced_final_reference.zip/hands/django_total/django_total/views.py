from django.shortcuts import render 


def index2(request, id):
    query = request.GET  #request.META, request.POST, request.COOKIES 
    return render(request, 'index.html', {'id':id, 'queries':query})
    

from django.http import HttpResponseRedirect
from django.urls import reverse 
def hello(request):
    return HttpResponseRedirect(reverse('views_index', args=[10]))
    
    
from django.http import JsonResponse 
def json(request):
    data={'username': 'Jone'}
    return JsonResponse(data)
    
from django.conf import settings 
import os.path
from django.http import FileResponse
def download(request):
    file = os.path.join(settings.BASE_DIR, 'manage.py')
    res = FileResponse(open(file, 'rb'))
    res['Content-Disposition'] = "attachement; filename=%s" % (os.path.basename(file),)
    res['Content-Length'] = os.path.getsize(file)
    return res 
    
    
    
    

    
    
    
