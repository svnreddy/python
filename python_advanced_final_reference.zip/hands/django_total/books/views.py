from django.shortcuts import render

# Create your views here.
from .models import Book

def latest_books(request):
    books_list = Book.objects.all()
    return render(request, 'books/list.html', {'books_list':books_list})