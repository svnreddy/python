def square(x):
    """first function
    
    >>> square(10)
    100
    
    >>> square(0)
    0
    
    """
    z = x*x 
    return z 
    
from functools import wraps 
def mea(unit):    
    def mea1(f):
        @wraps(f)
        def __inner(*args,**kargs):
            import time 
            st = time.time()
            res = f(*args, **kargs)
            print("Time taken", (time.time()-st)*unit, "in ms")
            return res 
        return __inner 
    return mea1
    
def avg(lst):
    return sum(lst)/len(lst)
    
def trace(f):
    def __inner(*args, **kargs):
        print("->", f.__name__)
        res = f(*args, **kargs)
        print("<-", f.__name__) 
        return res 
    return __inner 

    
@trace 
@mea(1000)
def sd(lst):  #sd = mea(1000)(sd)
    """sqrt of( SUM of square of ( each elemnt - mean)  / length of lst  )
    """
    res = []
    m = avg(lst)
    for e in lst:
        res.append( square(e-avg(lst)))
    import math 
    return math.sqrt(sum(res)/len(res))
     

def checksum(string):
    """
    Use recursion     
    Take two two character(one byte) from above (which are in hex digit )
    Convert to int  (Hint: use int function with base)
    Sum all and then find mod with 255, that is your checksum 
    Test with input="ABCDEF1234567890"
    """
    def hexsum(lst):
        return 0 if not lst else int(lst[0:2],16) + hexsum(lst[2:])
    res = hexsum(string)
    return res % 255 

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
def is_prime(n):
    import math
    if n == 2 : return True 
    if n % 2 == 0:	return False
    sqrt_n = int(math.sqrt(n))
    a = [1 for i in range(3, sqrt_n + 1, 2) if n % i == 0]
    return False if sum(a) > 0 else True
    
import matplotlib.pylot as plt 
import pandas as pd 
import numpy as np 
df = pd.read_csv("./data/iris.csv")
df.head()
df.groupby('Name').agg(['max'])
df['SepalLength']
df[['SepalLength','SepalWidth']]  
df[['SepalLength','SepalWidth']].head()
df[df.SepalLength > 5.1].head()
df.SepalLength
df.iloc[0:5, 0:2]
df.groupby('Name').plot(kind='line', subplots=True)
plt.show()

#pip install --upgrade pandas
dft = pd.read_excel(r"data\Nifty-17_Years_Data-V1.xlsx", 
    parseDates=True, index_col=0, header=0, 
    date_parser=lambda x: pd.to_datetime(x, format="%d-%b-%y"))
dft['2013']
dft['2013-2': '2013-6']
dft.Open.plot(kind='line')
dft['2013-2': '2013-6'].Open.plot(kind='line')
plt.show()
dft_r = dft.rolling(30)
dft_r.mean()['Open'].dropna().plot(kind='line')
plt.show()
    
    
    
    
    
    
    
    
    
    


    
    
if __name__ == '__main__':
    #python pkg\mex.py -v
    print(__name__)
    import doctest
    doctest.testmod()