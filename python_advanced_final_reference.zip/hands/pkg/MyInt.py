class MyInt:
    def __init__(self, v):
        self.val = v 
    def __add__(self, other):
        z = self.val + other.val 
        return MyInt(z)
    def __str__(self):
        z = "MyInt(" + str(self.val) + ")"
        return z 
    def __sub__(self, other):
        z = self.val - other.val 
        return MyInt(z)
    def __eq__(self, other):
        z = self.val == other.val 
        return z
    def square(self):
        return MyInt(self.val ** 2)
        
#######################
#from pkg.MyInt import Complex 
#a = Complex(2,3)
#b = Complex(3,4)
#c = a + b 
#print(c) #Complex(5,7)

class Complex:
    def __init__(self, n, d):
        self.n = n 
        self.d = d 
    def __add__(self, other):
        re = self.n + other.n 
        img = self.d + other.d 
        return Complex(re, img)
    def __str__(self):
        z = "Complex(%d,%d)" % (self.n, self.d)
        return z 


###########
#from pkg.mylist import MyList 
#lst = MyList([1,1,1,2,3]) #is a list 
#lst.append(3)
#lst.frequency()   # {1:3,2:1,3:2}

class MyList(list):
    #def __init__(self, lst):
    #    super().__init__(lst)
    def frequency(self):
        return {e: self.count(e) for e in self}














