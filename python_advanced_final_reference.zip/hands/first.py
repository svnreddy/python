from __future__ import print_function, division
import sys 
a = sys.argv[1]
print(a)


import subprocess as S
command = "nslookup www.google.co.in"
p = S.Popen(command, shell=True, stdout=S.PIPE, universal_newlines=True)
o,e = p.communicate()
print(o)

'''
[]   list - Duplicates - A, indexing, [int] - A, insertion order - A , mutable 
()   tuple - Immutable, ---above--
   
{}   set - Duplicates - NA, indexing - NA, IO - NA , mutable 
   frozenset - immutable, -- above -- 
   
{k:v}   dict - (key,value), keys- like set , mutable 
'''
import csv 
with open(r"./data/iris.csv", "rt") as f:
    rd = csv.reader(f)
    rows = list(rd)

headers = rows[0]
rows = rows[1:]
rowsd = []
for sl,sw,pl,pw,n in rows:
    rowsd.append([float(sl), float(sw),float(pl), float(pw),n] )

names = { row[-1] for row in rowsd}
res ={n:{'sl':{'max':max([r[0] for r in rowsd if r[-1]== n])}} for n in names}
>>> res
{'Iris-setosa': {'sl': {'max': 5.8}}, 'Iris-versicolor': {'sl': {'max': 7.0}}, 'Iris-virginica': {'sl': {'max': 7.9}}}

res = {}
for n in names:
    d = {'sl': {'max':[]}}
    for r in rowsd :
        if r[-1]== n:
            d['sl']['max'].append(r[0])
    d['sl']['max'] = max(d['sl']['max'])
    res[n] = d 
    
##DB API 
import mysql.connector 
con = mysql.connector.connect(user='root', password='root',
    host='127.0.0.1', database='python')
    
cur = con.cursor()
cur.execute("drop table if exists iris")
cur.execute("""create table iris(sl double, sw double, 
                        pl double, pw double, n varchar(50))""")

for r in rowsd:
    cur.execute("insert into iris values(%s,%s,%s,%s,%s)", r)

con.commit()
cur.execute("""select n, max(sl) from iris group by n order by n""")
result = list(cur.fetchall())
print(result)


##Max 

def maxFile(directory):
    import glob, os.path 
    d = {f: os.path.getsize(f) 
            for f in glob.glob(os.path.join(directory, "*")) 
            if os.path.isfile(f)}
    return sorted(d, key=lambda k: d[k])[-1] 

#json
[ ph['number']  for e in obj  
                for ph in e['details']['phoneNumbers']  
                if ph['type'] == 'office']


















    




















    
