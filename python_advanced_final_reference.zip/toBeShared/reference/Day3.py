   
###*** Web Page & CGI Programming
#Web programming and automation using Python

#Common Gateway Interface 
#A CGI script is invoked by an HTTP server, eg to process <FORM> or <ISINDEX> element
#cgi script - print text to display in browser
#must be under ['/cgi-bin', '/htbin'] for builtin http.server 

#file :  cgi-bin/cgiEx.py

import cgi, os, sys 

#Enables long report if there is some error 
import cgitb
cgitb.enable(logdir="logs")

#form is a dictionary 
#note form contains both GET parsed URL and/or POST form data if present 
form = cgi.FieldStorage()

#to access raw GET QUery 
# the query string, which contains the raw GET data
# (For example, for http://example.com/myscript.py?a=b&c=d&e this is "a=b&c=d&e")
#os.environ["QUERY_STRING"]

# the raw POST data
#sys.stdin.read()

'''
application/x-www-form-urlencoded 
    Default. 
    All characters are encoded before sent 
    (spaces are converted to "+" symbols, and special characters are converted to ASCII HEX values) 
multipart/form-data 
    No characters are encoded. 
    use this if  forms that have a file upload control 
text/plain 
    Spaces are converted to "+" symbols, but no special characters are encoded 
'''

string = """
<form method="post" action="cgiEx.py" >
       <p>Name: <input type="text" name="name"/></p>
	   <p>address1: <input type="text" name="addr"/></p>
	   <p>address2: <input type="text" name="addr"/></p>
	   <input type="submit" value="Submit" />
     </form>  
"""



#headers section
print("Content-Type: text/html")    # HTML is following
print()                             # blank line, end of headers

#content section
print("<HTML>")
print("<TITLE>CGI script output</TITLE>")
print("<BODY>")
print("<H1>This is my first CGI script</H1>")
print("Hello, world!")
print("</br>")

if 'REQUEST_METHOD'  in os.environ and os.environ['REQUEST_METHOD'].upper() == 'POST':
    if "name" not in form or "addr" not in form:
        print("<H1>Error</H1>")
        print("Please fill in the name and addr fields.")
        print("</BODY></HTML>")
        sys.exit(0)
    print(form.getfirst("name","").upper(), ",".join(form.getlist("addr")) )
    #or could be form['name'].value 
else:   #IT IS GET 
    print('QUERY_STRING=', os.environ["QUERY_STRING"], "</br>")
    print('name=', form.getfirst("name", "no name found"),"</br>")
    print(string)
    
print("</BODY></HTML>")





#run http server from outside of this script 
#python3: python -m http.server --bind 127.0.0.1 --cgi 8080
#py2.7: python -m CGIHTTPServer  8080
#in browser http://localhost:8080/cgi-bin/cgiEx.py

#or python -m http.server 8000 --bind 127.0.0.1
#or , to serve a specific dir 
#python -m http.server --directory /tmp/






##Check all input types 
#https://www.w3schools.com/html/html_form_input_types.asp


##for  an uploaded file field 
#http.server has problem with large file > 194KB 
#Lib/http/server.py:1164: 
            if self.command.lower() == "post" and nbytes > 0:                
                data = self.rfile.read(nbytes)
                while len(data) < nbytes:
                    print(length, nbytes, len(data), "call again")
                    data += self.rfile.read(nbytes)


#use action="test.py" to test it 
#test.py 
import cgi 
cgi.test()

#code 
string = """
<form enctype="multipart/form-data"  method="post">
<p>File: <input type="file" name="file"></p>
<p>Name: <input type="text" name="name"/></p>
<p><input type="submit" value="Upload"></p>
</form>
"""
html = """Content-Type: text/html\n
    <html><body>
    <p>%s</p>
    </body></html>
    """

import cgi, os, sys , os.path
import tempfile
#Enables long report if there is some error 
import cgitb
cgitb.enable(logdir="logs")


# Windows needs stdio set for binary mode. THIS IS MUST 
#else Standard input is opened by default in "text" mode

try: 
    import msvcrt
    msvcrt.setmode(sys.stdin.fileno(), os.O_BINARY) # stdin  = 0
    msvcrt.setmode (sys.stdout.fileno(), os.O_BINARY) # stdout = 1
except ImportError:
    pass
    
    

#form is a dictionary 
#note form contains both GET parsed URL and/or POST form data if present 
form = cgi.FieldStorage()

     

if 'REQUEST_METHOD'  in os.environ and os.environ['REQUEST_METHOD'].upper() == 'POST':
    if 'file' not in form:
        #how come it is not there 
        sys.exit(0) 
        
    fileitem = form['file']
    # Test if the file was uploaded
    if fileitem.file:
        # strip leading path from file name
        # to avoid directory traversal attacks
        fn = os.path.basename(fileitem.filename if fileitem.filename else "somedummy.du")
        #curdir is outside cgi-bin  
        # gets truncated         
        with open(os.path.normpath(os.path.join(os.getcwd(), 'uploaded_files' , fn)), 'wb') as f:
            while True:
                chunk = fileitem.file.read(100000)
                if not chunk: break
                f.write(chunk)
        message = 'The file "' + fn + '" was uploaded successfully'
    else:
        message = 'No file was uploaded'

    print( html % (message,))
else:
    print(html % (string,))


##Content-type 
#type/subtype followed by an optional semicolon delimited attribute-value pairs (known as parameters).
#https://www.iana.org/assignments/media-types/media-types.xhtml
text
    This type indicates that the content is plain text and no special software is required to read the contents. 
    The subtype represents more specific details about the content, which can be used by the client for special processing, if any. 
    For instance, Content-Type: text/html indicates that the body content is html, 
    and the client can use this hint to kick rendering engine while displaying the response.
multipart
    As the name indicates, this type consists of multiple parts of the independent data types. 
    For instance, Content-Type: multipart/form-data is used for submitting forms 
    that contain the files, non-ASCII data, and binary data.
image
    This type represents the image data. 
    For instance, Content-Type: image/png indicates that the body content is a .png image.
audio
    This type indicates the audio data. 
    For instance, Content-Type: audio/mpeg indicates that the body content is MP3 or other MPEG audio.
video
    This type indicates the video data. 
    For instance Content-Type:, video/mp4 indicates that the body content is MP4 video.
application
    This type represents the application data or binary data. 
    For instance, Content-Type: application/json; charset=utf-8 designates the content to be in JSON format, encoded with UTF-8 character encoding
    In this case write string of json eg sys.stdout.write(json.dumps(obj))
    For Content-Type: application/xml , Get XML string xml.etree.ElementTree.tostring(element, encoding="us-ascii", method="xml")
    

      
##File Download 
#write file content to stdout 
import cgi 
import cgi, os
import cgitb; cgitb.enable()

try: # Windows needs stdio set for binary mode.
    import msvcrt
    msvcrt.setmode (0, os.O_BINARY) # stdin  = 0
    msvcrt.setmode (1, os.O_BINARY) # stdout = 1
except ImportError:
    pass
    
filename = 'somefile'
print("Content-Type: application/octet-stream")
print("Content-Disposition: attachment; filename=%s" % filename)
print()

#actual  downloading 
fo = open(filename, "rb")
while True:
    buffer = fo.read(4096)
    if buffer:
        sys.stdout.write(buffer)
    else:
        break
fo.close()
    
#OR 
#f.read() could cause a problem if the file is huge. 
#To prevent that, use shutil.copyfileobj:
import os
import shutil
import sys

#no Content-Disposition, hence displayed in browser 
with open(os.path.abspath('test.png'), 'rb') as f:
    sys.stdout.buffer.write("Content-Type: image/png\n\n")
    shutil.copyfileobj(f, sys.stdout.buffer)
    
        
##Other important methods
cgi.print_environ()
    Format the shell environment in HTML.
cgi.print_form(form)  #form is dict of { key:value} which will be formatted
    Format a form in HTML.
cgi.print_directory()
    Format the current directory in HTML.
cgi.print_environ_usage()
    Print a list of useful (used by CGI) environment variables in HTML.

cgi.escape(s, quote=False)
    Convert the characters '&', '<' and '>'  and quotes (if quote=True) in string s to HTML-safe sequences
    Deprecated, Must use quote=True 
    or  Use html.escape(s, quote=True) for escaping and html.unescape(s) for unescaping 

cgi.test()
    Robust test CGI script, usable as main program. 
    Writes minimal HTTP headers and formats all information provided to the script in HTML form

cgi.parse_qs(qs, keep_blank_values=False, strict_parsing=False)
    Use urllib.parse.parse_qs(qs, keep_blank_values=False, strict_parsing=False, encoding='utf-8', errors='replace')
    Parse a query string given as a string argument (data of type application/x-www-form-urlencoded). 
    Data are returned as a dictionary
    
cgi.parse_qsl(qs, keep_blank_values=False, strict_parsing=False)
    Use urllib.parse.parse_qsl(qs, keep_blank_values=False, strict_parsing=False, encoding='utf-8', errors='replace')
    Parse a query string given as a string argument (data of type application/x-www-form-urlencoded). Data are returned as a list of name, value pairs

    
##Reading HTTP headers 
#you can't read the HTTP header directly, 
#but the web server put into environment variables , os.environ 

#Important env variables 
#check Metavariables http://www.ietf.org/rfc/rfc3875.txt
AUTH_TYPE
CONTENT_LENGTH 
CONTENT_TYPE
GATEWAY_INTERFACE
PATH_INFO
PATH_TRANSLATED
QUERY_STRING
REMOTE_ADDR
REMOTE_HOST
REMOTE_IDENT  
REMOTE_USER
REQUEST_METHOD 
SCRIPT_NAME
SERVER_NAME
SERVER_PORT
SERVER_PROTOCOL
SERVER_SOFTWARE

    
    
    
    
    
###*** Django - Chapter-1
 
'''
examplesite from setup to Production deplyoment 
    urls, views and settings, template language 
    Objective- Understanding  Application development
settings, urls, views(inc class based) and deployment steps
'''
#Py3.x
#REF: https://docs.djangoproject.com/en/2.0/

### Install version 
$ pip install Django==2.0.6
#Note The last version to support Python 2.7 is Django 1.11 
$ pip install Django==1.11

###STEP 0: Python 2.7 , it's python.exe must be in PATH
#django-admin is installed in Scripts dir, must be in Path (> django-1.7) 
# < django-1.7 , django-admin.py at Lib\site-packages\django\bin

#check help 
$ django-admin help startproject
$ django-admin help startapp

##Django2.0 changes compared to 1.11 
#django.conf.urls.url() is also named as   django.urls.re_path()
#but use django.urls.path for simplicity 
#urls.py 
from django.urls import include, path, re_path

#django.urls.path() function allows a simpler, more readable URL routing syntax. 
url(r'^articles/(?P<year>[0-9]{4})/$', views.year_archive),
#could be written as:
path('articles/<int:year>/', views.year_archive),



###STEP 1.1: Creating project , Project contains App, App contains MVC
$ django-admin startproject examplesite

###STEP 1.2 : check dir structure 

.   
�   manage.py
+---examplesite
        settings.py       #setting files 
        urls.py           #route file  
        wsgi.py           #Web Server Gateway Interface file  exposing 'application'
        __init__.py
 
###STEP 1.3 : check settings at examplesite\settings.py 
#check https://docs.djangoproject.com/en/2.0/ref/settings/
    
##To get attributes programitically 
#check https://docs.djangoproject.com/en/2.0/topics/settings/, eg how to use Django standalone 
from django.conf import settings #check dir(settings) in python manage.py shell 
STATIC = getattr(settings, "STATIC", None)  #'/static/'   



###File: settings.py 

import os

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
#This is Project DIR
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/2.0/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = '+f$pnly#@8zf-5m4kwpy6*qodji4-6r^0%2@=e5fvmafpbk*pb'
#Used for many hash calculation, must be secret , in production ,use it from env string or from file  
#eg 
#import os
#SECRET_KEY = os.environ['SECRET_KEY']
#or 
#with open('/etc/secret_key.txt') as f:
#    SECRET_KEY = f.read().strip()




# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

#A list of strings representing the host/domain names that this Django site can serve
#could be list of  'www.example.com', '.example.com' or '*' 
#Django uses the Host header provided by the client to construct URLs in certain cases
#this prevent HTTP Host header attacks
ALLOWED_HOSTS = []

#SSL activation 
SECURE_SSL_REDIRECT = True
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True


# Application definition
#app_name/app_label  is from 'startapp' command
#if not 'startapp' command is issued, then  keep the generated ones 

INSTALLED_APPS = [
    "sslserver",                        #for runsslserver , install it at first , pip install django-sslserver
    'django.contrib.admin',             #for admin module 
    'django.contrib.auth',              #authentication module
    'django.contrib.contenttypes',      #track all of the models installed in your Django-powered project, and attach permissions
    'django.contrib.sessions',          #for Session handling  
    'django.contrib.messages',          #for  "flash message"
    'django.contrib.staticfiles',       #static file handling 
    'my_app',                           #my app, order is significant , app means containing model 
    'my_app2',
    
]


#Using session 
#By default, Django stores sessions in your database , Other options are file, cookie etc , 
#Use SESSION_ENGINE  setting
#command: python manage.py migrate #to install the single database table that stores session data.
# each HttpRequest object � the first argument to any Django view function � will have a session attribute, which is a dictionary-like object.
#eg request.session.get('has_commented', False) or request.session['has_commented'] = True


#Middleware: hooks into Django�s request/response processing
#Check bundled middleware at https://docs.djangoproject.com/en/2.0/ref/middleware/
#middleware = a decorator like function given below 
#def simple_middleware(get_response):
#    # One-time configuration and initialization.
#
#    def middleware(request):
#        # Code to be executed for each request before
#        # the view (and later middleware) are called.
#
#        response = get_response(request)
#
#        # Code to be executed for each request/response after
#        # the view is called.
#
#        return response
#
#    return middleware

#Django 2.0 has MIDDLEWARE  instead of MIDDLEWARE_CLASSES
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',         #provides several security enhancements to the request/response cycle. eg SSL
    'django.contrib.sessions.middleware.SessionMiddleware',  #for Session handling  
    'django.middleware.common.CommonMiddleware',             #Adds a few conveniences , check https://docs.djangoproject.com/en/2.0/ref/middleware/#module-django.middleware.common
    'django.middleware.csrf.CsrfViewMiddleware',             #Cross Site Request Forgery protection, in template use <form action="" method="post">{% csrf_token %}, https://docs.djangoproject.com/en/2.0/ref/csrf/
    'django.contrib.auth.middleware.AuthenticationMiddleware', #authentication module
    'django.contrib.messages.middleware.MessageMiddleware',    #for  "flash message", SessionMiddleware must be enabled and appear before MessageMiddleware 
    'django.middleware.clickjacking.XFrameOptionsMiddleware',  #protection against clickjacking, https://docs.djangoproject.com/en/2.0/ref/clickjacking/
]
#Handling flash message 
#adding 
#from django.contrib import messages
#messages.add_message(request, messages.INFO, 'Hello world.') #message.tags is messages.INFO
#displaying in template 
#{% if messages %}
#<ul class="messages">
#    {% for message in messages %}
#    <li{% if message.tags %} class="{{ message.tags }}"{% endif %}>{{ message }}</li>
#    {% endfor %}
#</ul>
#{% endif %}



ROOT_URLCONF = 'examplesite.urls'  #urls.py file 

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',  #other could be 'django.template.backends.jinja2.Jinja2'
        'DIRS': [],                      #Directories where the engine should look for template source files, in search order ,for example to include project\templates, use 'DIRS': [os.path.join(BASE_DIR, 'templates')],
        'APP_DIRS': True,                #Whether the engine should look for my_app/templates/
        'OPTIONS': {                     #depending upon BACKEND , https://docs.djangoproject.com/en/2.0/topics/templates/#module-django.template.backends.django
            'context_processors': [      #a list of dotted Python paths to callables that are used to populate the context when a template is rendered with a request. 
                                         #These callables take a request object as their argument and return a dict of items to be merged into the context.
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',         #for admin module
                'django.contrib.messages.context_processors.messages', #for  "flash message",
            ],
            #loaders to be used for template file loading 
            #by default below is not required and 'APP_DIRS': True means filesystem.Loader and app_directories.Loader are active
            #To use make APP_DIRS as false 
        #    'loaders' : [
        #            'django.template.loaders.cached.Loader'      #for caching below loader 
        #            'django.template.loaders.filesystem.Loader'  #Loads templates from the filesystem, according to DIRS
        #            'django.template.loaders.app_directories.Loader' #For each app in INSTALLED_APPS, the loader looks for a templates subdirectory.
        #                                                             #The order of INSTALLED_APPS is significant, first template found is loaded ignoring same name in other apps
        #    ],                                                       #Hence use namespace eg another subdir as my_app eg my_app/templates/my_app/template.html and always use as my_app/template.html
        },
    },
]
#below would override all settings of TEMPLATES.DIRS, hence deprecated  
TEMPLATE_DIRS = (
    os.path.join(BASE_DIR, 'templates')
)

#For putting the site under WSGI enabled server eg apache httpd
WSGI_APPLICATION = 'examplesite.wsgi.application'


# Database
# https://docs.djangoproject.com/en/2.0/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.path.join(BASE_DIR, 'db.sqlite3'),
    }
}

#DATABASES = {
#    'default': {
#        'ENGINE': 'django.db.backends.mysql',
#        'NAME': 'django',
#        'USER': 'root',
#        'PASSWORD': '',
#        'HOST': '127.0.0.1',
#    }
#}


# Password validation
# https://docs.djangoproject.com/en/2.0/ref/settings/#auth-password-validators
#Validators are class with (OPTIONS are passed to constructor)method: validate(self, password, user=None) method, if error raises ValidationError else return None
#can be also called manually with django.contrib.auth.password_validation.validate_password(password, user=None, password_validators=None)
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
        'OPTIONS': {
            'min_length': 9,
        }
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]



# Internationalization
# https://docs.djangoproject.com/en/2.0/topics/i18n/

#internationalization  Writing code such that it is locale sensitive 
#localization           Writing translation for each locale 
#both are done by below settings 

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'Asia/Kolkata'

USE_I18N = True

USE_L10N = True

USE_TZ = True
#Steps for I/L 
#Use django.utils.translation.ugettext("string_tobe_localized") in any py file 
#or in template , {% trans "string_tobe_localised" %}
#create 'locale' subdir in each my_app (MUST)
#Use command: django-admin makemessages -l locale_code  #must have  GNU gettext utilities installed,
#for example 'en-us' is language code, 'en_US' is locale name/code
#Above generates .po file eg in my_app/locale/<locale_code>/LC_MESSAGES/django.po
#contains 

#: path/to/python/module.py:23
#msgid "string_tobe_localised"
#msgstr ""    #<-- here you put translated version of "string_tobe_localised"
#To reexamine , Use django-admin makemessages -a
#Then , compile as  (create .mo file from .po file) 
#django-admin compilemessages





# Absolute filesystem path to the directory that will hold user-uploaded files.
# Example: "/home/media/media.lawrence.com/media/"
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')

# URL that handles the media served from MEDIA_ROOT. Make sure to use a
# trailing slash. so below URLs are actually  from above MEDIA_ROOT
# Examples: "http://media.lawrence.com/media/", "http://example.com/media/"
MEDIA_URL = '/media/'


# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/2.0/howto/static-files/

STATIC_URL = '/static/'         #prefix to access static file in URL  it is under my_app/static/
                                #Preferred to have another my_app subdir as a namespace as first file found is loaded across all installed apps  
                                # my_app/static/my_app/file.ext and is used as my_app/file.ext

#For any other user defined static files
STATICFILES_DIRS = [
    os.path.join(BASE_DIR, "static"),
    '/var/www/static/',
]

#in template , handle as 
#{% load static %}
#<img src="{% static "my_app/example.jpg" %}" alt="My image"/>
#when file is my_app/static/my_app/example.jpg


#printing to console 
#check other Backend at https://docs.djangoproject.com/en/2.0/topics/email/
EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_HOST_USER = 'ndas1971@gmail.com'
EMAIL_HOST_PASSWORD = 'xyzabc'

#Login required 

SESSION_EXPIRE_AT_BROWSER_CLOSE = True    # everytime browser is closed, session is expired, ELSE persistant session 
SESSION_COOKIE_AGE  = 5*60 # in seconds 


##Logging 
#https://docs.djangoproject.com/en/2.1/topics/logging/
LOGGING_CONFIG = None
LOGGING = {
    'version': 1,
    'disable_existing_loggers': True,
    'formatters': {
        'verbose': {
            'format': '%(levelname)s %(asctime)s %(module)s %(process)d %(thread)d %(message)s'
        },
        'simple': {
            'format': '%(levelname)s %(message)s'
        },
    },
    'handlers': {
        'console': {
            'level': 'DEBUG',
            'class': 'logging.StreamHandler',
            'formatter': 'simple'
            },
        'file': {
            'level': 'DEBUG',
            'class': 'logging.FileHandler',
            'filename': 'file.log',
            'formatter': 'simple'
            },
        },
    'loggers': {
        'django': {
            'handlers': ['console'],
            'level': 'DEBUG',
            'propagate': True,
            },
         'examplesite': {                      #Put the root of your module to handle the logging
            'handlers': ['console'],
            'level': 'DEBUG',
            'propagate': True,
            },
        }
    }

#This is required for correct logging 
import logging.config
logging.config.dictConfig(LOGGING)

#usage of log 
#import logging
#log = logging.getLogger(__name__)
#log.debug("GET " + str(request.GET))




###File: urls.py 
"""
The urlpatterns list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include, re_path 

urlpatterns = [
    path('admin/', admin.site.urls),
]

##Other syntax 
from django.conf.urls import url
#OR 
from django.urls import re_path 
from django.contrib import admin

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    #or
    re_path(r'^admin/', admin.site.urls),
]

   
        
###STEP 1.4  : check quickly 
$ cd examplesite
$ python manage.py help runserver
$ python manage.py runserver  8000 #<<port>>

#Open  http://127.0.0.1:8000/




###Step1.5.1 - Add one static file 
#in settings.py 
STATICFILES_DIRS = (
    "static/",    
   )
#examplesite/static/hello.html 
#can contain css, js etc 
<!DOCTYPE html>
<html> 
 <head> 
    <title>  Demo </title>
    
    <style>
        .mainDiv {
                border: 1px solid red;
                padding: 5px;
                min-height: 10px;
            }
    </style>  

    <script >
         function clck(evt){   //click is reserved method
           alert(evt);
         }        
    </script>    
 </head> 
 <body>
 <div class="mainDiv" id="mainDiv"  onclick="clck(event)"> 
 Hello
 </div>  
 </body>   
</html>

#check 
$ python manage.py runserver  8000 #<<port>>
#With URL http://127.0.0.1:8000/static/hello.html

###Step1.5.2 - Add path to urls.py 
1. When Django starts , it check root url file from examplesite\settings.py 
    ROOT_URLCONF = 'examplesite.urls'

2. examplesite\urls.py file is processed , urlpatterns is [path, path, ...] 
    django.conf.urls.url(regex, view, kwargs=None, name=None)
    #or 
    django.urls.re_path(regex, view, kwargs=None, name=None)
    #or for non regex path 
    django.urls.path(path, view, kwargs=None, name=None)
    view : callable object 
    kwargs : allows to pass additional arguments to the view function 
    name: used for performing  URL reversing ie go to view callable from 'name' (name must be unique)
            for example 
            �In templates: Using the {% url 'name' }
            �In Python code: Using the django.urls.reverse('name') function.
                    

3.  Add following in examplesite/urls.py

from . import views
urlpatterns = [                #previously it is patterns('', url...)
    #....
    url(r'^$', views.index, name='index'),      # name is for reverse URL resolve 
    #url(r'^hello2/(?P<id>\d+)', views.index2, kwargs={'url': 'index'}, name = "views_index"), 
    path('hello2/<int:id>', views.index2, kwargs={'url': 'index'}, name = "views_index")
    url(r'hello/$', views.hello) #matches  http://address:port/hello and calls hello method of views module 
   ]

4. Add examplesite/views.py 

from django.http import HttpResponse
def index(request):
    return HttpResponse("Hello, world")

4.2 Update views.py with below 
#render() is a new shortcut for render_to_response  that will automatically use RequestContext 
#Always use render 
#handling Query 
from django.shortcuts import render

def index2(request, id, url):  #path('hello2/<int:id>', views.index2, kwargs={'url': 'index'}, name = "views_index")
    query = request.GET.dict()
    #log.debug("GET " + str(request.GET))
    return render(request, 'index.html', {'id': id, 'queries':query})

    
# templates/index.html 
#contains reverse url etc 
#'if' tag may use the operators and, or, not, ==, !=, <, >, <=, >=, in, not in, is, and is not 

# Filter is used after | , 
#REF: https://docs.djangoproject.com/en/2.0/ref/templates/builtins/ 
#Arithmetic operation on value 
#Generally it is recommended you do this calculation in your view. 
#or use  'add' filter(builtin) or use pip django-mathfilters and then {% load mathfilters %}   <li>13 - 17 = {{ 13|sub:17 }}</li>

<h1> List of Queries for id {{ id }} </h1>

{% if queries.items %}
    Number of Queries: {{ queries.items | length }}       
{% else %}
    No Queries.
{% endif %}

<br />
<a href="{% url 'views_index' id|add:100 %}" > Refresh </a>



#check 
$ python manage.py runserver  8000 #<<port>>
#With URL http://127.0.0.1:8000/hello2/23?size=20


##Understand the error as templates are not found  
#Solution - update settings.py 
TEMPLATES = [
    {
        ...
        'DIRS': [os.path.join(BASE_DIR, 'templates')],
        ...
    }...]
    

4.3 Update views.py with below to handle redirect

from django.http import HttpResponseRedirect  
from django.urls  import reverse
def hello(request):
    return HttpResponseRedirect(reverse('index'))


5.  Add following in examplesite/urls.py

from django.conf.urls import include 

urlpatterns = [                #previously it is patterns('', url...)
    #....  
    url(r'^dummy/', include('dummy.urls')), #match .../dummy/ and pass the remaining strings to urls.py of module dummy 
]

5.1 Create dummy module with __init__.py 
5.2 , Update dummy/views.py 
from django.http import HttpResponse
def index(request, name):           #comes from url's (\w+), this positional args 
    return HttpResponse("Hello " + name)


5.3 Update dummy/urls.py 
from django.conf.urls import url, include 
from . import views

#after dummy/
urlpatterns = [    
    url(r'^(\w+)/$',  views.index),    #views 's index method has 2nd arg as (\w+)
]                                                           



6. Add following in examplesite/urls.py - Using class based view 
from django.views.generic import TemplateView

urlpatterns = [
    ...
    url(r'^about/$', TemplateView.as_view(template_name="about.html")),
]
6.1 Create templates/about.html
<h1> This is new Project </h1>


6.2 - Lets Create userdefined MyView 
#check attributes in https://ccbv.co.uk/projects/Django/2.0/django.views.generic.base/TemplateView/
#Template context data is created in get_context_data
#examplesite/views.py 

from django.views.generic.base import TemplateView
import os 

class MyView(TemplateView):

    template_name = "environ.html"

    def get_context_data(self, **kwargs):
        context = super(MyView, self).get_context_data(**kwargs)
        context['objects'] = os.environ
        return context
        
6.3 Update urls.py 
from .views import MyView

urlpatterns = [
    ...
    url(r'^environ/$', MyView.as_view()),
]


6.3 Update templates/environ.html to include template language 
#check all builtin tags and filters - https://docs.djangoproject.com/en/2.0/ref/templates/builtins/

#Note template 'for' is for list only. 
#To access dictionary or list of list, use with .items  
#Can not access dictionary like {{ objects[k] }} as {{ }} contains only variable name like in 'for' in object.items (Note without end ())
#Variable names consist of any combination of alphanumeric characters and the underscore ("_"). 

#The dot (".")  appears in variable sections and interpreted as either(in order)
#Dictionary lookup ie dicts["key"] for dicts.key
#Attribute or method lookup for any python class  
    #If the resulting value is callable, it is called with no arguments. 
    #The result of the call becomes the template value.
#Numeric index lookup
#After ., string must be literal not any var 

{# single line comment #}

{% comment %} 
The for loop sets a number of variables available within the loop
forloop.counter         The current iteration of the loop (1-indexed) 
forloop.counter0        The current iteration of the loop (0-indexed) 
forloop.revcounter      The number of iterations from the end of the loop (1-indexed) 
forloop.revcounter0     The number of iterations from the end of the loop (0-indexed) 
forloop.first           True if this is the first time through the loop 
forloop.last            True if this is the last time through the loop 
forloop.parentloop      For nested loops, this is the loop surrounding the current one 
{% endcomment %}

<h1> List of environ variables </h1>

<table border="1">
  <tr>
    <th>Variable</th>
    <th >Value</th>
  </tr>  
 {% for k,v in objects.items %}
    <tr >
        <td >{{ k }}</td>
        <td> {{ v }}</td>
        
    </tr>
{% endfor %}

</table>

#check 
$ python manage.py runserver  8000 #<<port>>
#With URL http://127.0.0.1:8000/environ


###Step1.6 Deploy 
##Under apache httpd with mod_wsgi - enable mod_wsgi in http.conf 
#below mod_wsgi is valid only for python 2.7 
#copy examplesite to C:/indigoampp/apache-2.2.15/wsgi-bin/django/
LoadModule wsgi_module modules/mod_wsgi.so

WSGIScriptAlias  /first "C:/indigoampp/apache-2.2.15/wsgi-bin/django/examplesite/examplesite/wsgi.py"
WSGIPythonPath   "C:/indigoampp/apache-2.2.15/wsgi-bin/django/examplesite/"

<Directory "C:/indigoampp/apache-2.2.15/wsgi-bin/django/examplesite/examplesite">
	Order allow,deny
   Allow from all
</Directory>

# Then check 
http://localhost/first/hello

#NOTE:
#If multiple Django sites are run in a single mod_wsgi process, 
#all of them will use the settings of whichever one happens to run first. 
#This can be solved by changing:
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "{{ project_name }}.settings")
#in wsgi.py, to:
os.environ["DJANGO_SETTINGS_MODULE"] = "{{ project_name }}.settings"


##Other deployment options 
#gunicorn(linux)/Waitress(windows)Or oracle virtualbox with linux - very fast  , or uwsgi(unix)- another fast 
#https://docs.djangoproject.com/en/2.0/howto/deployment/wsgi/gunicorn/
#Or can use gevent which is asynchronous server (very fast) or tornado etc 

'''
$ pip install gevent 

'''

from gevent.pywsgi import WSGIServer
from examplesite.wsgi import application as app

http_server = WSGIServer(('127.0.0.1', 8000), app)
http_server.serve_forever()


###Serving Static files 
#During Development , it is OK as Django automatically takes care of that with above settings 
#but production through wsgi.py application, 
#as Django doesn�t serve files itself
#it leaves that job to whichever deployement Web server(as it is scalable)

1.Set the STATIC_ROOT setting to the directory from which you�d like to serve these files, 
STATIC_ROOT = "/var/www/example.com/static/"

2.Run the collectstatic management command:
  This will copy all files from your static folders into the STATIC_ROOT directory
$ python manage.py collectstatic

3. configure in webserver, for example, in http with mod_wsgi 
#This example sets up Django at the site root, 
#but serves robots.txt, favicon.ico, and anything in the /static/ and /media/ URL space as a static file. 
#All other URLs will be served using mod_wsgi:

Alias /robots.txt /path/to/mysite.com/static/robots.txt
Alias /favicon.ico /path/to/mysite.com/static/favicon.ico

Alias /media/ /path/to/mysite.com/media/
Alias /static/ /path/to/mysite.com/static/

<Directory /path/to/mysite.com/static>
    Require all granted
</Directory>

<Directory /path/to/mysite.com/media>
    Require all granted
</Directory>

WSGIScriptAlias / /path/to/mysite.com/mysite/wsgi.py

<Directory /path/to/mysite.com/mysite>
    <Files wsgi.py>
        Require all granted
    </Files>
</Directory>


##To serve static file under gevent , add below in urls.py 
##If using with GEVENT as wsgi automatically shuts off static file serving 
#but static only works with Debug=False 

from django.conf import settings 
import os
from django.conf.urls.static import static

if os.environ['GEVENT']:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATICFILES_DIRS[0])

##OR using django-gevent-deploy
pip install django-gevent-deploy

#Then 
$ python manage.py rungevent [[addr]:port] [pool_size]



##STEP-3.0 : Using bootstrap 
#base.html 
{% load static %}
<!DOCTYPE html>
<html>
<head>
  <title>Django</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="{% static "css/bootstrap.min.css" %}">
  <script src="{% static "js/jquery.min.js" %}"></script>
  <script src="{% static "js/bootstrap.min.js" %}"></script>
    <body>

        <div class="jumbotron jumbotron-fluid  text-center">
          <h1>Django  site</h1>
          <p>OK, this is my first project </p>
        </div>


        <div class="container">
        {% block container %}
        {% endblock container%}
        </div>

    </body>
</html>

#environ.html 
{% extends "base.html" %}

{% block container %}
{{block.super}}
<div class="table-responsive">
<table class="table">       <!- "table table-dark table-striped table-bordered table-condensed table-hover" ->
  <caption>List of Environment variables</caption>
  <thead class="thead-dark">    <!- thead-light ->
    <tr>
      <th scope="col">Key</th>
      <th scope="col" colspan="3">Value</th>
    </tr>
  </thead>
  <tbody>
    {% for k,v in objects.items %}
    <tr>
      <th scope="row">{{k}}</th>
      <td colspan="3">{{v}}</td>
    </tr>
    {% endfor %}
  </tbody>
</table>
</div>
{% endblock %}



### Quick URlConf 

##What the URLconf searches against
#This does not include GET or POST parameters, or the domain name.
#For example, in a request to https://www.example.com/myapp/, the URLconf will look for myapp/.
#In a request to https://www.example.com/myapp/?page=3, the URLconf will look for myapp/.

##Path converters for django.urls.path 
str 
    Matches any non-empty string, excluding the path separator, '/'. 
    This is the default if a converter isn�t included in the expression.
int 
    Matches zero or any positive integer. Returns an int.
    eg path('hello2/<int:id>'..), then view function would have one arg 'id' 
slug 
    Matches any slug string consisting of ASCII letters or numbers, plus the hyphen and underscore characters. 
    For example, building-your-1st-django-site.
uuid 
    Matches a formatted UUID. 
    To prevent multiple URLs from mapping to the same page, dashes must be included and letters must be lowercase. 
    For example, 075194d3-6885-417e-a8a8-6c931e272f00. Returns a UUID instance.
path 
    Matches any non-empty string, including the path separator, '/'. 
    This allows you to match against a complete URL path rather than just a segment of a URL path as with str.
    
##Custom Converters 
#A converter is a class that includes the following:
    A regex class attribute, as a string.
    A to_python(self, value) method, 
        which handles converting the matched string into the type that should be passed to the view function. 
        It should raise ValueError if it can�t convert the given value.
    A to_url(self, value) method, 
        which handles converting the Python type into a string to be used in the URL.
#Example 
#converts.py 
class FourDigitYearConverter:
    regex = '[0-9]{4}'

    def to_python(self, value):
        return int(value)

    def to_url(self, value):
        return '%04d' % value

#Usage 
from django.urls import path, register_converter

from . import converters, views

register_converter(converters.FourDigitYearConverter, 'yyyy')

urlpatterns = [
    path('articles/2003/', views.special_case_2003),
    path('articles/<yyyy:year>/', views.year_archive),  #def year_archive(request, year):
    ...
]

##Regex Match using re_path 
from django.urls import path, re_path #re_path is same as django.conf.urls.url
from . import views

urlpatterns = [
    path('articles/2003/', views.special_case_2003),
    re_path(r'^articles/(?P<year>[0-9]{4})/$', views.year_archive),
    re_path(r'^articles/(?P<year>[0-9]{4})/(?P<month>[0-9]{2})/$', views.month_archive),
    re_path(r'^articles/(?P<year>[0-9]{4})/(?P<month>[0-9]{2})/(?P<slug>[\w-]+)/$', views.article_detail),
]
#Equivalent to 
urlpatterns = [
    path('articles/2003/', views.special_case_2003),
    path('articles/<int:year>/', views.year_archive),
    path('articles/<int:year>/<int:month>/', views.month_archive),
    path('articles/<int:year>/<int:month>/<slug:slug>/', views.article_detail),
]
#Note 
    There�s no need to add a leading slash, because every URL has that. 
    For example, it�s articles, not /articles.
    A request to /articles/2005/03/ would match the third entry in the list. 
        Django would call the function views.month_archive(request, year=2005, month=3).
    /articles/2003/ would match the first pattern in the list, not the second one,
        because the patterns are tested in order, and the first one is the first test to pass. 
        Here, Django would call the function views.special_case_2003(request)
    /articles/2003 would not match any of these patterns, 
        because each pattern requires that the URL end with a slash.
    /articles/2003/03/building-a-django-site/ would match the final pattern. 
        Django would call the function views.article_detail(request, year=2003, month=3, slug="building-a-django-site").

##Nested arguments
from django.urls import re_path

urlpatterns = [
    re_path(r'^blog/(page-(\d+)/)?$', blog_articles),                  # bad
    re_path(r'^comments/(?:page-(?P<page_number>\d+)/)?$', comments),  # good
]
#for example, blog/page-2/ will result in a match to blog_articles with two positional arguments: page-2/ and 2. 
#The second pattern for comments will match comments/page-2/ with keyword argument page_number set to 2. 
#The outer argument in this case is a non-capturing argument (?:...).


##Specifying defaults for view arguments

# URLconf
from django.urls import path

from . import views

urlpatterns = [
    path('blog/', views.page),
    path('blog/page<int:num>/', views.page),
]

# View (in blog/views.py)
def page(request, num=1):
    # Output the appropriate page of blog entries, according to num.

##Captured parameters
#An included URLconf receives any captured parameters from parent URLconfs, 
# In settings/urls/main.py
from django.urls import include, path

urlpatterns = [
    path('<username>/blog/', include('foo.urls.blog')),
]
#the captured "username" variable is passed to the included URLconf,
#eg, views.blog.index and views.blog.archive gets one keyword arg username 
# In foo/urls/blog.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.blog.index),
    path('archive/', views.blog.archive),
]


##Including other URLconfs
#Whenever Django encounters include(), it chops off whatever part of the URL matched up to that point 
#and sends the remaining string to the included URLconf for further processing. 
from django.urls import include, path

urlpatterns = [
    path('community/', include('aggregator.urls')),
    path('contact/', include('contact.urls')),
]
#Another way 
# the /credit/reports/ URL will be handled by the credit_views.report() Django view.
from django.urls import include, path

from apps.main import views as main_views
from credit import views as credit_views

extra_patterns = [
    path('reports/', credit_views.report),
    path('reports/<int:id>/', credit_views.report),
    path('charge/', credit_views.charge),
]

urlpatterns = [
    path('', main_views.homepage),
    path('help/', include('apps.help.urls')),
    path('credit/', include(extra_patterns)),
]
#OR views.history gets(and others) two keyword arg page_slug, page_id
from django.urls import include, path
from . import views

urlpatterns = [
    path('<page_slug>-<page_id>/', include([
        path('history/', views.history),
        path('edit/', views.edit),
        path('discuss/', views.discuss),
        path('permissions/', views.permissions),
    ])),
]




##Passing extra options to view functions
from django.urls import path
from . import views

urlpatterns = [
    path('blog/<int:year>/', views.year_archive, {'foo': 'bar'}),
]
#for a request to /blog/2005/, Django will call 
views.year_archive(request, year=2005, foo='bar')
#In case of conflicts ,  the arguments in the dictionary will be used instead of the arguments captured in the URL.

##Passing extra options to include()
# main.py
from django.urls import include, path

urlpatterns = [
    path('blog/', include('inner'), {'blog_id': 3}),
]

# inner.py
from django.urls import path
from mysite import views

urlpatterns = [
    path('archive/', views.archive),  #views.archive would get keyword arg blog_id 
    path('about/', views.about),
]

#OR , is equivalent to 

# main.py
from django.urls import include, path
from mysite import views

urlpatterns = [
    path('blog/', include('inner')),
]

# inner.py
from django.urls import path

urlpatterns = [
    path('archive/', views.archive, {'blog_id': 3}),
    path('about/', views.about, {'blog_id': 3}),
]


##Reverse resolution of URLs
#The string used for the URL name can contain any characters , 
#use some prefix to decrease clashes 
from django.urls import path

from . import views

urlpatterns = [
    #...
    path('articles/<int:year>/', views.year_archive, name='news-year-archive'),
    #...
]
#in template code by using:

<a href="{% url 'news-year-archive' 2012 %}">2012 Archive</a>
{# Or with the year in a template context variable: #}
<ul>
{% for yearvar in year_list %}
<li><a href="{% url 'news-year-archive' yearvar %}">{{ yearvar }} Archive</a></li>
{% endfor %}
</ul>

#Or in Python code:
from django.http import HttpResponseRedirect
from django.urls import reverse

def redirect_to_year(request):
    # ...
    year = 2006
    # ...
    return HttpResponseRedirect(reverse('news-year-archive', args=(year,)))

    
    
    
##URL namespaces
#URL namespaces allow to uniquely reverse named URL patterns even if different applications use the same URL names. 
    
#Namespaced syntax  
'namespace(application or instance):view_name'
#Example 
'admin:index'. 
    This indicates a namespace of 'admin', and a named URL of 'index'.
# Namespaces can also be nested. 
'sports:polls:index' 
    look for a pattern named 'index' in the namespace 'polls' 
    that is itself defined within the top-level namespace 'sports'.
    
    
##Defining application namespace 
#This describes the name of the application that is being deployed(ie startapp myapp, then app_name=myapp)
#Every instance of a single application will have the same application namespace

#OR Use app_name attribute and include()  like below 
#polls/urls.py

from django.urls import path

from . import views

app_name = 'polls' #The URLs defined in polls.urls will have an application namespace polls.
urlpatterns = [
    path('', views.IndexView.as_view(), name='index'),
    path('<int:pk>/', views.DetailView.as_view(), name='detail'),
    ...
]

#urls.py

from django.urls import include, path

urlpatterns = [
    path('polls/', include('polls.urls')),
]


    
##Defining instance  namespace 
#This identifies a specific instance of an application. 
#Instance namespaces should be unique across entire project. 

#If the instance namespace is not specified, it will default to the included URLconf�s application namespace. 
#ie it will also be the default instance for that namespace.

#OR Use  namespace argument to include(). 
#Example - two instances of the polls application 
#one called 'author-polls' and one called 'publisher-polls'. 
#urls.py
from django.urls import include, path

urlpatterns = [
    path('author-polls/', include('polls.urls', namespace='author-polls')),
    path('publisher-polls/', include('polls.urls', namespace='publisher-polls')),
]

#polls/urls.py

from django.urls import path

from . import views

app_name = 'polls'
urlpatterns = [
    path('', views.IndexView.as_view(), name='index'),
    path('<int:pk>/', views.DetailView.as_view(), name='detail'),
    
]

    
##Lookup - Reversing namespaced URLs

#For given a namespaced URL (e.g. 'polls:index') to resolve, 
1.First, Django looks for a matching application namespace (ie 'polls'). 
  This will yield a list of instances of that application eg 'author-polls' and  'publisher-polls'
  
2.If there is a current application defined, Django finds and returns the URL resolver for that instance. 
  For example , Given 
        reverse('polls:index', current_app=self.request.resolver_match.namespace)
    and in the template:
        {% url 'polls:index' %}
    and Inside 'detail' view of  'author-polls' instance, both above would resolve to "/author-polls/"
    Note in 'url' tag , by default current application resolves to currently activated urlpatterns
    Override this default by setting the current application on the request.current_app attribute.
    
4.If there is no current application. Django looks for a default application instance. 
  The default application instance is with instance namespace matching the application namespace 
  (in this example, an instance of polls called 'polls', but not existing as only two instances 'author-polls' and  'publisher-polls').

5.If there is no default application instance, Django will pick the last deployed instance of the application, 
  whatever its instance name may be(in this example , 'publisher-polls' instance)
  For example ,if we were rendering a page somewhere else on the site 
  'polls:index' will resolve to the last registered instance of polls. ie 'publisher-polls' index view 
  
6.If the provided namespace doesn�t match an application namespace in step 1, 
  Django will attempt a direct lookup of the namespace as an instance namespace.
  For example, 'author-polls:index' will always resolve to the index page of the instance 'author-polls'
  
7.If there are nested namespaces, these steps are repeated for each part of the namespace 
   until only the view name is unresolved. 
   
   
   
   
   
   
### Quick View Functions 

from django.http import HttpResponse
import datetime

def current_datetime(request):
    now = datetime.datetime.now()
    html = "<html><body>It is now %s.</body></html>" % now
    return HttpResponse(html)
    
## More Usages of HttpResponse
from django.http import HttpResponse
response = HttpResponse("Here's the text of the Web page.")
response = HttpResponse("Text only, please.", content_type="text/plain")

#to add content incrementally, you can use response as a file-like object:
response = HttpResponse()
response.write("<p>Here's the text of the Web page.</p>")
response.write("<p>Here's another paragraph.</p>")

#Setting/removing  header fields
response = HttpResponse()
response['Age'] = 120
del response['Age']

#Redirect 
return  HttpResponseRedirect(url='absolute or relative path')

#Telling the browser to treat the response as a file attachment
#mydata is iterator of the data eg like file, generator etc 
data = open(file_full_path, 'rb')
response = HttpResponse(open(file_full_path, 'rb'), content_type='application/vnd.ms-excel')
response['Content-Disposition'] = 'attachment; filename="foo.xls"'
data.close()

#Download a file using StreamingResponse (eg for large text file)
import mimetypes 
def download(request, document_file_name):
    # Handle file download
    file_full_path = os.path.join(settings.MEDIA_ROOT, document_file_name)
    filename = os.path.basename(file_full_path)
    #wud autoclose 
    response = StreamingHttpResponse(open(file_full_path, 'rb'), content_type=mimetypes.guess_type(file_full_path)[0]) 
    response['Content-Disposition'] = "attachment; filename={0}".format(filename)
    response['Content-Length'] = os.path.getsize(file_full_path) 
    return response

#Or using FileResponse(subclass of HttpResponse) for binary file download 
    from django.http import FileResponse
    response = FileResponse(open('myfile.png', 'rb')) #it would autoclose 
    response['Content-Disposition'] = "attachment; filename=myfile.png"
    response['Content-Length'] = os.path.getsize(myfile.png) 
    return response 

#To send json response 
class JsonResponse(data, encoder=DjangoJSONEncoder, safe=True, json_dumps_params=None, **kwargs)
    The json_dumps_params parameter is a dictionary of keyword arguments to pass to the json.dumps() call used to generate the response.

#Safe=True, if root object is a dict   
from django.http import JsonResponse
response = JsonResponse({'foo': 'bar'}, content_type='application/json')

#In order to serialize objects other than dict, set the safe parameter to False:
response = JsonResponse([1, 2, 3], safe=False, content_type='application/json')




###django-jsonview: Note to have view returning JSON always, use 
$ pip install django-jsonview



from jsonview.decorators import json_view

@json_view
def my_view(request):
    return {
        'foo': 'bar',
    }


#Class-based views (CBVs) can inherit from JsonView

from jsonview.views import JsonView


class MyView(JsonView):
    def get_context_data(self, **kwargs):
        context = super(MyView, self).get_context_data(**kwargs)
        context['my_key'] = 'some value'
        return context

# or, method decorator
from django.utils.decorators import method_decorator
from jsonview.decorators import json_view


class MyView(View):
    @method_decorator(json_view)
    def dispatch(self, *args, **kwargs):
        return super(MyView, self).dispatch(*args, **kwargs)

# or, in URLconf
patterns = [
    url(r'^/my-view/$', json_view(MyView.as_view())),
]

 
##Content Types
#To return a content type other than the standard application/json
from jsonview.decorators import json_view

@json_view(content_type='application/vnd.github+json')
def myview(request):
    return {'foo': 'bar'}

##Status Codes
#Tto return a different HTTP status code, just return two values instead of one. 
@json_view
def myview(request):
    if not request.user.is_subscribed():
        # Send a 402 Payment Required status.
        return {'subscribed': False}, 402
    # Send a 200 OK.
    return {'subscribed': True}

 
##Extra Headers
@json_view
def myview(request):
    return {}, 200, {'X-Server': 'myserver'}


##Raw Return Values
#Eg to return cached json string 

from django import http
from jsonview.decorators import JSON

@json_view
def caching_view(request):
    kached = cache.get('cache-key')
    if kached:
        return http.HttpResponse(kached, content_type=JSON)
    # Assuming something else populates this cache.
    return {'complicated': 'object'}

    
##Alternative JSON Implementations -instead of stdlib json 
JSON_MODULE = 'ujson'


##Configuring JSON Output
#update settings.py 
JSON_OPTIONS = {
    'indent': 4,
}


#Or to compactify it:
JSON_OPTIONS = {
    'separators': (',', ':'),
}


#jsonview uses DjangoJSONEncoder by default.
# To use a different JSON encoder, use the cls option:
JSON_OPTIONS = {
    'cls': 'path.to.MyJSONEncoder',
}

#If you are using a JSON module that does not support the ``cls`` kwarg, such as ujson
JSON_OPTIONS = {
    'cls': None,
}

#Default value of content-type is 'application/json' OR set as 
JSON_DEFAULT_CONTENT_TYPE = 'application/json; charset=utf-8'

 
##Atomic Requests
#Because @json_view catches exceptions, 
#the normal Django setting ATOMIC_REQUESTS does not correctly cause a rollback. 
#USe as below 
@json_view
@transaction.atomic
def my_func(request):
    # ...





###Returning errors
#There are subclasses of HttpResponse for a number of common HTTP status codes other than 200 (which means �OK�).

from django.http import HttpResponse, HttpResponseNotFound

def my_view(request):
    # ...
    if foo:
        return HttpResponseNotFound('<h1>Page not found</h1>')
    else:
        return HttpResponse('<h1>Page was found</h1>')
#OR 
from django.http import HttpResponse

def my_view(request):
    # ...

    # Return a "created" (201) response code.
    return HttpResponse(status=201)       
        
##The Http404 exception
#When you return an error such as HttpResponseNotFound, 
#you�re responsible for defining the HTML of the resulting error page:

return HttpResponseNotFound('<h1>Page not found</h1>')

#to have a consistent 404 error page across your site, 
#Django provides an Http404 exception
#Django will catch it and return the standard error page for  application, along with an HTTP error code 404.

from django.http import Http404
from django.shortcuts import render
from polls.models import Poll

def detail(request, poll_id):
    try:
        p = Poll.objects.get(pk=poll_id)
    except Poll.DoesNotExist:
        raise Http404("Poll does not exist")
    return render(request, 'polls/detail.html', {'poll': p})

#to show customized HTML when Django returns a 404, 
#create an HTML template named 404.html and place it in the top level of template tree. 
#(eg Create project level templates /project/templates, and use with DIRS=[] in settings.py and put 404.html there)
#This template will then be served when DEBUG is set to False.

#When DEBUG is True,  provide a message to Http404 
#and it will appear in the standard 404 debug template. 


##Customizing error views
#specify the handlers as seen below in URLconf (setting them anywhere else will have no effect).

#The page_not_found() view is overridden by handler404:
handler404 = 'mysite.views.my_custom_page_not_found_view'

#The server_error() view is overridden by handler500:
handler500 = 'mysite.views.my_custom_error_view'

#The permission_denied() view is overridden by handler403:
handler403 = 'mysite.views.my_custom_permission_denied_view'

#The bad_request() view is overridden by handler400:
handler400 = 'mysite.views.my_custom_bad_request_view'

 

##Important attributes of django.http.HttpRequest 
#https://docs.djangoproject.com/en/2.0/ref/request-response/#ref-httpresponse-subclasses
HttpRequest.body        raw HTTP request body as a byte string
HttpRequest.path        example: /music/bands/the_beatles/
HttpRequest.get_full_path()  example: "/music/bands/the_beatles/?print=true"
HttpRequest.method      'GET' or 'POST' or others 
HttpRequest.content_type
HttpRequest.GET          QueryDict ,  dictionary-like object , access param as ['param']
HttpRequest.POST         QueryDict ,  dictionary-like object 
HttpRequest.FILES       {'name':  UploadedFile_instance}  ,
                        Must be : enctype="multipart/form-data" and <form> contains <input type="file" name="" />
                        Each value in FILES is an UploadedFile
HttpRequest.META        All HHTP headers in dictionary-like object, Note '-' is transformed to '_'
HttpRequest.COOKIES     A dictionary containing all cookies. Keys and values are strings.
HttpRequest.resolver_match    An instance of ResolverMatch representing the resolved URL

#Attributes set by middleware
HttpRequest.session     From the SessionMiddleware: A readable and writable, dictionary-like object that represents the current session.
HttpRequest.site        From the CurrentSiteMiddleware: An instance of Site or RequestSite as returned by get_current_site() representing the current site.
HttpRequest.user        From the AuthenticationMiddleware: An instance of AUTH_USER_MODEL representing the currently logged-in user. 
                        If the user isn�t currently logged in, user will be set to an instance of AnonymousUser. 
                        #to test 
                        if request.user.is_authenticated:
                            ... # Do something for logged-in users.
                        else:
                            ... # Do something for anonymous users.

##Quick Upload 
#for example for <input type="file" name="file">
#request.FILES['file'] would be UploadedFile and used as handle_uploaded_file(request.FILES['file'])
#request.FILES will only contain data if the request method was POST ie request.method == 'POST'
#and the <form> has the attribute enctype="multipart/form-data". 

#UploadedFile.name, UploadedFile.size (in bytes)
def handle_uploaded_file(f):
    with open('some/file/name.txt', 'wb+') as destination:
        for chunk in f.chunks():
            destination.write(chunk)



##Where uploaded data is stored
#By default, if an uploaded file is smaller than 2.5 megabytes, 
#Django will hold the entire contents of the upload in memory. 

#if an uploaded file is too large, Django will write the uploaded file to a temporary file stored in  system�s temporary directory.



##Important Attributes of HttpResponse        
HttpResponse.__init__(content='', content_type=None, status=200, reason=None, charset=None)
HttpResponse.set_cookie(key, value='', max_age=None, expires=None, path='/', domain=None, secure=None, httponly=False)
    Sets a cookie. 
        max_age should be a number of seconds, or None (default) if the cookie should last only as long as the client�s browser session. If expires is not specified, it will be calculated.
        expires should either be a string in the format "Wdy, DD-Mon-YY HH:MM:SS GMT" or a datetime.datetime object in UTC. If expires is a datetime object, the max_age will be calculated.
        Use domain if you want to set a cross-domain cookie. For example, domain="example.com" will set a cookie that is readable by the domains www.example.com, blog.example.com, etc. Otherwise, a cookie will only be readable by the domain that set it.
        Use httponly=True if you want to prevent client-side JavaScript from having access to the cookie.
HttpResponse.set_signed_cookie(key, value, salt='', max_age=None, expires=None, path='/', domain=None, secure=None, httponly=False)
    Like set_cookie(), but cryptographic signing the cookie before setting it. 
    Use in conjunction with HttpRequest.get_signed_cookie(). 
    You can use the optional salt argument for added key strength, but you will need to remember 
    to pass it to the corresponding HttpRequest.get_signed_cookie() call.
HttpResponse.delete_cookie(key, path='/', domain=None)
    Deletes the cookie with the given key. Fails silently if the key doesn�t exist.
HttpResponse.writelines(lines)
    Writes a list of lines to the response. 
    Line separators are not added. 
    This method makes an HttpResponse instance a stream-like object.

    
##django.http.request.QueryDict 
#in general immutable or use mutable=True in ctor
#create a shell 
$ python manage.py shell 
from django.http.request import QueryDict
q = QueryDict('a=1&a=2&c=3')  #<QueryDict: {'a': ['1', '2'], 'c': ['3']}>
q['a']          # u'2'  #last item 
q.getlist('a')  #[u'1', u'2']  #all items as list 
q.lists()       #[(u'a', [u'1', u'2']), (u'c', [u'3'])]
'a' in q        # True
q.urlencode()   # u'a=1&a=2&c=3'

#urldecode is automatic  
q = QueryDict('a=1+3&a=2&c=3') #<QueryDict: {u'a': [u'1 3', u'2'], u'c': [u'3']}>
q = QueryDict('a=1%203&a=2&c=3') #<QueryDict: {u'a': [u'1 3', u'2'], u'c': [u'3']}>


##Django shortcut functions
django.shortcuts.render(request, template_name, context=None, content_type=None, status=None, using=None)
    from django.shortcuts import render
    def my_view(request):
        # View code here...
        return render(request, 'myapp/index.html', {
            'foo': 'bar',
        }, content_type='application/xhtml+xml')
    #This example is equivalent to:
    from django.http import HttpResponse
    from django.template import loader
    def my_view(request):
        # View code here...
        t = loader.get_template('myapp/index.html')
        c = {'foo': 'bar'}
        return HttpResponse(t.render(c, request), content_type='application/xhtml+xml')
django.shortcuts.render_to_response(template_name, context=None, content_type=None, status=None, using=None)
    Deprecated since version 2.0., Use 'render'
    Note there is no 'request' 
django.shortcuts.redirect(to, permanent=False, *args, **kwargs)
    The arguments could be:
        A model: the model�s get_absolute_url() function will be called.
        A view name, possibly with arguments: reverse() will be used to reverse-resolve the name.
        An absolute or relative URL, which will be used as-is for the redirect location.
    By default issues a temporary redirect; pass permanent=True to issue a permanent redirect.
    #By passing some object; that object�s get_absolute_url() method will be called to figure out the redirect URL:
    from django.shortcuts import redirect
    def my_view(request):
        object = MyModel.objects.get(...)
        return redirect(object)
    #By passing the name of a view and optionally some positional or keyword arguments; 
    #the URL will be reverse resolved using the reverse() method:
    def my_view(request):
        return redirect('some-view-name', foo='bar')

    #By passing a hardcoded URL to redirect to:
    def my_view(request):
        return redirect('/some/url/')

    #This also works with full URLs:
    def my_view(request):
        return redirect('https://example.com/')

        
##Allowed HTTP methods
#check other decorators - https://docs.djangoproject.com/en/2.0/topics/http/decorators/
from django.views.decorators.http import require_http_methods

@require_http_methods(["GET", "POST"]) #request methods should be in uppercase.
def my_view(request):
    # I can assume now that only GET or POST requests make it this far
    # ...
    pass
        
        
###Quick Django Debug 

##Using Debug  tag  with django.template.context_processors.debug
#If this processor is enabled, every RequestContext will contain debug 
#and and sql_queries variables � but only if your DEBUG setting is set to True 
#and the request�s IP address (request.META['REMOTE_ADDR']) is in the INTERNAL_IPS setting
<div id="django-debug"><pre>{% debug|escape %}</pre></div>


##OR install https://github.com/jazzband/django-debug-toolbar
$ pip install django-debug-toolbar

#then in settings.py 
INTERNAL_IPS = ('127.0.0.1',)

INSTALLED_APPS = [
    # ...
    'django.contrib.staticfiles',
    # ...
    'debug_toolbar',
]

STATIC_URL = '/static/'

MIDDLEWARE = [
    # ...
    'debug_toolbar.middleware.DebugToolbarMiddleware',
    # ...
]


#in urls.py , end 
if settings.DEBUG:
    import debug_toolbar
    urlpatterns = [
        path('__debug__/', include(debug_toolbar.urls)),

        # For django versions before 2.0:
        # url(r'^__debug__/', include(debug_toolbar.urls)),

    ] + urlpatterns

#then check http://127.0.0.1:8000/environ/, debug toolbar is displayed 
#for example to check all variables available to above template 
#select Templates -> environ.html -> toggle context to see all context objects in that view 
#context objects are displayed directly eg for objects , use objects directly 


     
        
        
###Quick Django Template 
#https://docs.djangoproject.com/en/2.0/ref/templates/language/
#https://docs.djangoproject.com/en/2.0/ref/templates/builtins/


##Automatic HTML escaping
#By default in Django, every template automatically escapes the output of every variable tag. 
    < is converted to &lt;
    > is converted to &gt;
    ' (single quote) is converted to &#39;
    " (double quote) is converted to &quot;
    & is converted to &amp;

#To turn it off For individual variables
#use the safe filter:
This will be escaped: {{ data }}
This will not be escaped: {{ data|safe }}

#To turn it off  For template blocks
#Auto-escaping is on by default.
#The auto-escaping tag passes its effect onto templates that extend the current one 
#as well as templates included via the include tag

Hello {{ name }}

{% autoescape off %}
    This will not be auto-escaped: {{ data }}.

    Nor this: {{ other_data }}
    {% autoescape on %}
        Auto-escaping applies again: {{ name }}
    {% endautoescape %}
{% endautoescape %}


##Include tag 
#Loads a template(called template fragment) and renders it with the current context. 

{% include "foo/bar.html" %}

#template_name is variable 
{% include template_name %}


#An included template is rendered within the context of the template that includes it. 
#Example if Context has 'person' is set to "John" and 'greeting' is set to "Hello".

{% include "name_snippet.html" %}

#name_snippet.html 
{{ greeting }}, {{ person|default:"friend" }}!


#OR pass additional context to the template 
{% include "name_snippet.html" with person="Jane" greeting="Hello" %}


#OR To render the context only with the variables provided 
{% include "name_snippet.html" with greeting="Hi" only %}


  
### Custom template tags and filters
#When a Django app is added to INSTALLED_APPS, any tags it defines in the templatetags directory would be loaded 
#Check default tags and filters in django/template/defaultfilters.py and django/template/defaulttags.py
#For example, if  custom tags/filters are in a file called poll_extras.py in app 'polls'
polls/
    __init__.py
    models.py
    templatetags/
        __init__.py
        poll_extras.py
    views.py

#Usage , Note use with module name 
{% load poll_extras %}

#For example, in the filter {{ var|foo:"bar" }}, 
#the filter foo would be passed the variable var and the argument "bar".

#poll_extras.py
#get Register instance 
from django import template
register = template.Library()

def cut(value, arg):
    """Removes all values of arg from the given string"""
    return value.replace(arg, '')

def lower(value): # Only one argument.
    """Converts a string into all lowercase"""
    return value.lower()

register.filter('cut', cut)
register.filter('lower', lower)

#OR using as decorator 
@register.filter(name='cut')
def cut(value, arg):
    return value.replace(arg, '')

@register.filter
def lower(value):
    return value.lower()
    
#Usage 
{{ somevariable|cut:"0" }}
{{ somevariable|lower }}

#OR use with OPTIONS of django.template.backends.django.DjangoTemplates
OPTIONS={
    'libraries': {
        'myapp_tags': 'path.to.myapp.tags',
        'admin.urls': 'django.contrib.admin.templatetags.admin_urls',
    },
}
#Usage 
{% load myapp_tags %}


##Writing custom template tags - Simple tags - django.template.Library.simple_tag()
#This function takes a function that accepts any number of arguments, wraps it in a render function 
#and registers it with the template system.

import datetime
from django import template

register = template.Library()

@register.simple_tag
def current_time(format_string):
    return datetime.datetime.now().strftime(format_string)


#If template tag needs to access the current context, use the takes_context 
#Note that the first argument must be called context.
@register.simple_tag(takes_context=True)
def current_time(context, format_string):
    timezone = context['timezone']
    return your_get_current_time_method(timezone, format_string)

#to rename your tag, provide a custom name for it:
register.simple_tag(lambda x: x - 1, name='minusone')

@register.simple_tag(name='minustwo')
def some_function(value):
    return value - 2

#simple_tag functions may accept any number of positional or keyword arguments. For example:
@register.simple_tag
def my_tag(a, b, *args, **kwargs):
    warning = kwargs['warning']
    profile = kwargs['profile']
    ...
    return ...

#Usage like python, keyword is used with = 
{% my_tag 123 "abcd" book.title warning=message|lower profile=user.profile %}
#to store the tag results in a template variable 
{% current_time "%Y-%m-%d %I:%M %p" as the_time %}
<p>The time is {{ the_time }}.</p>





### Session handling 
#https://docs.djangoproject.com/en/2.1/topics/http/sessions/
##Enabling sessions
1.Edit the MIDDLEWARE setting to contain 'django.contrib.sessions.middleware.SessionMiddleware'. 
2.Add 'django.contrib.sessions' in INSTALLED_APPS
  By default, Django stores sessions in database (using the model django.contrib.sessions.models.Session). 
3.Install the single database table that stores session data
  $ python manage.py migrate 

##Using file-based sessions
1.set the SESSION_ENGINE setting to "django.contrib.sessions.backends.file".
2.set the SESSION_FILE_PATH setting (which defaults to output from tempfile.gettempdir(), most likely /tmp) 
  to control where Django stores session files. 
  Be sure to check that  Web server has permissions to read and write to this location.

##Using cookie-based sessions
1.set the SESSION_ENGINE setting to "django.contrib.sessions.backends.signed_cookies".
  The session data will be stored using  cryptographic signing with SECRET_KEY setting.

##Using sessions in views
#When SessionMiddleware is activated, each HttpRequest object has  session attribute - SessionBase, dict like object 
#Access by request.session in view function and in template 

#in view 
def post_comment(request, new_comment):
    if request.session.get('has_commented', False):  #default return False 
        return HttpResponse("You've already commented.")
    c = comments.Comment(comment=new_comment)
    c.save()
    request.session['has_commented'] = True
    return HttpResponse('Thanks for your comment!')

    
#in template 
{{ request.session.has_commented }}



###Using Cookies 
#Better use Session based handling which give extra security 

#Example 
response = rrender(request, 'rango/index.html', context_dict)
visits = int(request.COOKIES.get('visits', '0'))

# Does the cookie last_visit exist?
if 'last_visit' in request.COOKIES:
    # Yes it does! Get the cookie's value.
    last_visit = request.COOKIES['last_visit']
    # Cast the value to a Python date/time object.
    last_visit_time = datetime.strptime(last_visit[:-7], "%Y-%m-%d %H:%M:%S")

    # If it's been more than a day since the last visit...
    if (datetime.now() - last_visit_time).days > 0:
        # ...reassign the value of the cookie to +1 of what it was before...
        response.set_cookie('visits', visits+1)
        # ...and update the last visit cookie, too.
        response.set_cookie('last_visit', datetime.now())
else:
    # Cookie last_visit doesn't exist, so create it to the current date/time.
    response.set_cookie('last_visit', datetime.now())

# Return response back to the user, updating any cookies that need changed.
return response


##Setting test cookies
#When you set a cookie, you can�t actually tell whether a browser accepted it until the browser�s next request.

from django.http import HttpResponse
from django.shortcuts import render

def login(request):
    if request.method == 'POST':
        if request.session.test_cookie_worked():
            request.session.delete_test_cookie()
            return HttpResponse("You're logged in.")
        else:
            return HttpResponse("Please enable cookies and try again.")
    request.session.set_test_cookie()
    return render(request, 'foo/login_form.html')


    
    

###Django Flash messages 
#Every message is tagged with a specific level that determines its priority (e.g., info, warning, or error).
#The messages framework allows to temporarily store messages in one request and retrieve them for display in a subsequent request (usually the next one). 

##Setup 
1.Add 'django.contrib.messages' is in INSTALLED_APPS.
2.MIDDLEWARE contains 'django.contrib.sessions.middleware.SessionMiddleware' 
  and 'django.contrib.messages.middleware.MessageMiddleware'.
  The default storage backend relies on sessions. 
3.The 'context_processors' option of the DjangoTemplates backend 
  defined in TEMPLATES setting contains 'django.contrib.messages.context_processors.messages'.

##Storage backends
storage.session.SessionStorage
storage.cookie.CookieStorage
(default)storage.fallback.FallbackStorage
    first uses CookieStorage, and falls back to using SessionStorage 
    for the messages that could not fit in a single cookie.
#Explicit settings 
MESSAGE_STORAGE = 'django.contrib.messages.storage.cookie.CookieStorage'


##Levels 
#Tag         Level 
debug       DEBUG       Development-related messages that will be ignored (or removed) in a production deployment 
info        INFO        Informational messages for the user 
success     SUCCESS     An action was successful, e.g. �Your profile was updated successfully� 
warning     WARNING     A failure did not occur but may be imminent 
error       ERROR       An action was not successful or some other failure occurred 


##Adding a message

from django.contrib import messages
messages.add_message(request, messages.INFO, 'Hello world.')

messages.debug(request, '%s SQL statements were executed.' % count)
messages.info(request, 'Three credits remain in your account.')
messages.success(request, 'Profile details updated.')
messages.warning(request, 'Your account expires in three days.')
messages.error(request, 'Document deleted.')

##Failing silently when the message framework is disabled
messages.add_message(
    request, messages.SUCCESS, 'Profile details updated.',
    fail_silently=True,
)
messages.info(request, 'Hello world.', fail_silently=True)



##Displaying messages
{% if messages %}
<ul class="messages">
    {% for message in messages %}
    <li{% if message.tags %} class="{{ message.tags }}"{% endif %}>{{ message }}</li>
    {% endfor %}
</ul>
{% endif %}

#Outside of templates,  get_messages():
from django.contrib.messages import get_messages

storage = get_messages(request)
for message in storage:
    do_something_with_the_message(message)


    
    
    
    
    
    
    
    
    
    
    
    
    
    

###*** Django - chapter-2 

''' basic - book
        model layer 
        admin module               
        ListView as standard view 
        
Objectives- Basic Model 
Generic display views, Query Performance, Migration concepts
'''
###STEP 1: Then create a application, inside examplesite
$ cd examplesite
$ python manage.py startapp books   #note books is the name of app or app_name or app_label 

#check settings.py has below 
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.path.join(BASE_DIR, 'db.sqlite3'),
    }
}


###STEP2.0: MVC or MVT 
#Update books/models.py, books/view.py and html template file (books/templates/books) for  site in books

###STEP2.1: MVC- Model - the database tables
#REF: https://docs.djangoproject.com/en/2.0/ref/models/fields/
#books/models.py
# models.py (the database tables)
from django.db import models

class Book(models.Model):                   #two field  
	name = models.CharField(max_length=50)
	pub_date = models.DateField()
	
	def __str__(self):              # __str__ on Python 3, __unicode__ in Python2
		return self.name

###STEP2.2: MVC - Views - (the business logic)
#books/views.py
from django.shortcuts import render

# Create  views here.

from .models import Book

def latest_books(request):
	book_list = Book.objects.order_by('-pub_date')
	return render(request, 'books/latest_books.html', {'book_list': book_list})

    
###STEP2.3: MVC - view template 

#books/templates/books/latest_books.html : {% %} for template code, {{ }} for var name 
{% load static %}
<!DOCTYPE>
<html>
    <head>
        <title>DJANGO</title>
        <link rel="stylesheet" type="text/css" href="{% static 'books/style.css' %}" />
    </head>
    <body>
        {% for book in book_list %} 
            <h1>{{ book.name }}  {{ book.pub_date}}</h1>
        {% endfor %} 
    </body>
</html>

###STEP2.4: MVC - view -  Addition of Static files 

#books/static/books/style.css
body {
    background: white url("images/background.gif") no-repeat right bottom;
}

h1 {
    color: red;
}
#books/static/books/images/background.gif
#note the location because of href="{% static 'books/style.css' %}" in style.css

###STEP3.6: MVC - test  Adding testing of Models 
#books/tests.py
from django.test import TestCase
# Create  tests here.
import datetime
from django.test import Client
from books.models import Book

class BookTests(TestCase):

    def setUp(self):
        # django uses separate table test_books in DB  and removes after test
        # hence populate few data in that else test would fail
        Book.objects.create(name="first book", pub_date=datetime.date.today())
        Book.objects.create(name="first book 12", pub_date=datetime.date.today())
        self.c =  Client()

		
    def test_sample(self):
        """First test case"""
        response = self.c.get('http://127.0.0.1:8000/latest/')
        # we can call unittest methods
        self.assertRegexpMatches(response.content.decode('ascii'), "first book") #for py2, decode is not required
        

    def test_not_empty(self):
        """Second Test case"""
        book_list = Book.objects.order_by('-pub_date')  #order_by is action 
        # we can call unittest methods
        self.assertTrue(book_list)






###STEP4.1:Update examplesite/urls.py to include url to be handled

import books.views

urlpatterns = [
    url(r'latest/$', books.views.latest_books),
    #...
]


###STEP4.2: Modify INSTALLED_APPS in examplesite/settings.py to include books application
##Note order is significant , first means apps' template file would override all below's
INSTALLED_APPS = {
...
'books',
}

###STEP5.0: Activating models

#Notify django that models is changed 
#Must when you change model ***
$ python manage.py makemigrations books

#(creates migrations/0001_initial.py) and create migration code. 
$ cat books/migrations/0001_initial.py

###STEP5.1: Check the db creation command by  
#(0001 is parameter which denotes which migration point to display)

$ python manage.py sqlmigrate books 0001


#Note- check DB tablename, must be in lowercase. eg books_book , appName_modelName 
#If you would like to change DB table name use Meta options
#REF: https://docs.djangoproject.com/en/2.0/ref/models/options/
#eg: in models.py/Book class

class Book(models.Model):
	name = models.CharField(max_length=50)
	pub_date = models.DateField()
	class Meta:
		db_table = 'books'
		


###STEP 5.2:Create the Databse tables now
$ python manage.py migrate

#Check from SQL , note many auth_* and django_* tables are created along with books_book
$ python manage.py dbshell
show tables;		# for sqllite SELECT * FROM sqlite_master WHERE type='table';
DROP TABLE appname_modelname;
exit; 			# for sqlite, .exit

#DBShell for sqllite3 
$ python manage.py dbshell 

sqllite> .tables 
sqllite> .schema finance_stock


### STEP 5.3:Check everything is OK
$ python manage.py shell


from books.models import Book  

Book.objects.all() # []

# Create New
# for DateTimeField use  timezone.now() from django.utils import timezone
import datetime
b1 = Book(name="first book", pub_date=datetime.date.today())
# Save the object into the database. You have to call save() explicitly.
b1.save()

#Get object
#REF: https://docs.djangoproject.com/en/2.0/ref/models/querysets/
Book.objects.all()
Book.objects.filter(id=1)
Book.objects.filter(name__startswith='first')
Book.objects.filter(name__endswith='12') #[]





###STEP 6.1:Testing
# Django uses test DB , hence  populate test DB at first (during setUp phase)
#-v is verbose level 
$ python manage.py test -v 3  books

###STEP 6.2 : Run the server by
$ python manage.py runserver

#If below error
Error: [Errno 10013] An attempt was made to access a socket in a way forbidden b
#change port
python manage.py runserver 8080
#check  http://127.0.0.1:8000/latest





###STEP 6.2:AppConfig
#Django contains a registry of installed applications that stores configuration 
#and provides introspection. It also maintains a list of available models.

#This registry is simply called apps and it�s available in django.apps:

>>> from django.apps import apps
>>> apps.get_app_config('admin').verbose_name
'Admin'
#This file is created to help the user include any application configuration for the app
#REF: https://docs.djangoproject.com/en/2.0/ref/applications/




###STEP7.1: MVC - Admin module - you can create user, groups and books
1. check required settings in settings.py , 
   TEMPLATES::OPTIONS::context_processors , MIDDLEWARE_CLASSES and INSTALLED_APPS
2. create ModelAdmin and register, check examplesite\books\admin.py 
3. Hook to <<project>>\urls.py, by url(r'^admin/', admin.site.urls) (default), (note <Django-1.9, url(r'^admin/', include(admin.site.urls)) )

#file books\admin.py :
from django.contrib import admin

from books.models import Book       #note import is always from root, hence .\books\models.py


class BookAdmin(admin.ModelAdmin):
	fields = ['pub_date', 'name']  # reorder

#Now you can create Book instance via admin 
admin.site.register(Book, BookAdmin)  # register  models and ModelAdmin instances with instance of django.contrib.admin.sites.AdminSite created by django.contrib.admin.site 
                                      #Customize the AdminSite for custom behaviour 

#By default following would do if there is no customization of BookAdmin
admin.site.register(Book)

##Discovery of admin files
#When you put 'django.contrib.admin' in  INSTALLED_APPS setting, 
#Django automatically looks for an admin module in each application and imports it.

##ModelAdmin options
#Chek full list https://docs.djangoproject.com/en/2.0/ref/contrib/admin/#modeladmin-options


#To override an admin template for a specific app, 
#copy and edit the template from the django/contrib/admin/templates/admin directory, 
#and save it to <<project>>\templates\ (DIRS in setting.py must be set to check this)
#Note  app must come before 'django.contrib.admin' in settings.INSTALLED_APPS



#Note you have to create superuser to use the admin module 
#Note: must create superuser 
#Create  superuser eg  admin/adminadminadmin
$ python manage.py createsuperuser 

#change passowrd
$ python manage.py changepassword <user_name>

#To give a normal user privileges, open a shell with python manage.py shell and try:
from django.contrib.auth.models import User
user = User.objects.get(username='normaluser')
user.is_superuser = True
user.save()

#Iterate users/superusers
from django.contrib.auth.models import User
User.objects.filter(is_superuser=True)

#then change password
usr = User.objects.get(username=' username')
usr.set_password('raw password')
usr.save()


#Then check at   http://127.0.0.1:8000/admin  (admin/adminadminadmin)
#Some Errors are displayed in DEBUG level , CHange it to INFO to suppress that (settings.py)
'loggers': {
        'django': {
            'handlers': ['console'],
            'level': 'INFO',   
            'propagate': True,
            },
            
#Add Books , delete and update 




###STEP7.2: Migration 
#REF: https://docs.djangoproject.com/en/2.0/topics/migrations/
migrate
    which is responsible for applying and unapplying migrations.
makemigrations
    which is responsible for creating new migrations based on the changes you have made to  models.
sqlmigrate
    which displays the SQL statements for a migration.
showmigrations
    which lists a project�s migrations and their status.


#Change model files and admin file to include email
#books/models.py 
class Book(models.Model):                   #two field  
    name = models.CharField(max_length=50)
    pub_date = models.DateField()	
    email = models.EmailField(null=True, blank=True)
    def __str__(self):             
        return self.name

#Note null is used here else migration would ask for values for older rows 
#which could be other option if this field is non-nullable 

#Avoid using null on string-based fields such as CharField and TextField because empty string values will always be stored as empty strings, not as NULL. 
#If a string-based field has null=True, that means it has two possible values for �no data�: NULL, and the empty string
#Note that blank is different than null. null is purely database-related, whereas blank is validation-related. 
#If a field has blank=True, form validation will allow entry of an empty value. 
#If a field has blank=False, the field will be required.


#Then execute 
$ python manage.py makemigrations books
$ python manage.py sqlmigrate books 0002
$ python manage.py migrate



###STEP 8: Usage of generic display view 

#for example ListView - Displays model.objects.all() (to change, update queryset=WITHQUERY)
#or DetailView for rendering one object of the Model
#REF: https://docs.djangoproject.com/en/2.0/ref/class-based-views/generic-display/
#check all attributes - https://ccbv.co.uk/projects/Django/2.0/django.views.generic.list/ListView/


##Class-based generic views - flattened index 
#All generic view derive from View and has TemplateMixin(attributes similar to TemplateView)
Simple generic views 
    View
    TemplateView
    RedirectView
Detail Views 
    DetailView
List Views 
    ListView
Editing views 
    FormView
    CreateView
    UpdateView
    DeleteView
Date-based views 
    ArchiveIndexView
    YearArchiveView
    MonthArchiveView
    WeekArchiveView
    DayArchiveView
    TodayArchiveView
    DateDetailView


##Each request served by a class-based view has an independent state;
##therefore, it is safe to store state variables on the instance (i.e., self.size = 3 is a thread-safe operation).

urlpatterns = [
    path('view/', MyView.as_view(size=42)), #calls MyView(size=42)
]


class django.views.generic.base.View
    All other class-based views inherit from this base class. 
    It isn�t strictly a generic view and thus can also be imported from django.views.
    Note View.as_view(**initargs) has populated below 
    initargs are keyword based initialization parameters of UserDefinedListViewClass 
    Inside class, can access below 
        self.request = request 
        self.args = args     #all positional args in the path
        self.kwargs = kwargs  #all keywords arg in the path
    Attributes
        http_method_names
            The list of HTTP method names that this view will accept.
            Calls same named method on the View, eg get(request, *args, **kwargs) for GET
            Default:  ['get', 'post', 'put', 'patch', 'delete', 'head', 'options', 'trace']
       
    #Example views.py:
    from django.http import HttpResponse
    from django.views import View

    class MyView(View):
        def get(self, request, *args, **kwargs):
            return HttpResponse('Hello, World!')
            
    #Example urls.py:
    from django.urls import path

    from myapp.views import MyView

    urlpatterns = [
        path('mine/', MyView.as_view(), name='my-view'),
    ]

class django.views.generic.base.TemplateView
    Renders a given template, with the context containing parameters captured in the URL.
    Ancestors (MRO)
        �django.views.generic.base.TemplateResponseMixin
        �django.views.generic.base.ContextMixin
        �django.views.generic.base.View
    Attributes  and defined in 
        content_type = None     
        extra_context = None     
        http_method_names = ['get', 'post', 'put', 'patch', 'delete', 'head', 'options', 'trace']     
        response_class = <class 'django.template.response.TemplateResponse'>     
        template_engine = None     
        template_name = None    
    


##Example 
#Update views.py 
from django.views.generic.list import ListView
from django.views.generic import DetailView
from django.utils import timezone

from .models import Book

#Template file : ListView.template_name or by default , <<appName>>/templates/<<appName>>/<<modelName>>_list.html
#Containing a context containing a variable called 'object_list' that contains all the publisher objects. 
#While this view is executing, self.object_list will contain the list of objects 
class BookListView(ListView):
    model = Book
    template_name = "books/booklist.html"  #under <<appName>>/template
    #context_object_name = 'books'         #rename 'object_list'
    def get_context_data(self, **kwargs):
        context = super(BookListView, self).get_context_data(**kwargs)
        context['now'] = timezone.now()
        return context
        
#Use DetailView.get_object() is the method that retrieves the object 
#Note default template name is <<appName>>/templates/<<appName>>/<<modelName>>_detail.html
#in template, context variable name is 'object'
#Note if 'DetailView.get_object()' is not overridden, then URL must contain pk_keyword as determined by 'pk_url_kwarg = 'pk''
#eg  book/<int:pk>/, then DetailView would display that object 
class BookDetailView(DetailView):
    model = Book
    extra_context = {'now': datetime.date.today()}
    template_name = "books/book.html"
    #add another extra context 
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['book_list'] = Book.objects.all()
        return context       
        
#Create and Update view , If any class attribute is missing, check error and update 
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy


import logging
log = logging.getLogger(__name__)


class BookCreateView(CreateView):
    model = Book
    extra_context = {'now': datetime.date.today()}
    template_name = "books/book_create.html"
    success_url = reverse_lazy('author-list')
    fields = ['name', 'pub_date']
    initial = {'name':"Book Name", 'pub_date': datetime.date.today()}
    def form_valid(self, form):
        #do some activity
        #then call super 
        log.info("Valid form Saving.., can update cleaned_data.")
        log.info(str(form.cleaned_data))
        return super().form_valid(form)
        #raise IndentationError("simulated")  #for checking all values 
        
    
        
class BookUpdateView(UpdateView):
    model = Book
    fields = ['name', 'pub_date']
    extra_context = {'now': datetime.date.today()}
    template_name = "books/book_update.html"
    success_url = reverse_lazy('author-list')
    


class BookDeleteView(DeleteView):
    model = Book
    success_url = reverse_lazy('author-list')
    template_name = "books/book_delete.html"
    fields = ['name', 'pub_date']      
 

   
#books/urls.py     
from django.urls import path, include 
from . import views 

urlpatterns = [
    path('latest/', views.latest_books),
    path('books/', views.BookListView.as_view(), name="author-list"),
    path('book/', views.BookCreateView.as_view()),
    path('book/<int:pk>/update/', views.BookUpdateView.as_view()),
    path('book/<int:pk>/delete/', views.BookDeleteView.as_view()),
    path('book/<int:pk>/', views.BookDetailView.as_view(), name='author-detail'),
]
#django_total/urls.py 
urlpatterns = [
   #...
    path('books/', include('books.urls')),
]

#Lets use template inheritance 
#books/static/base.html 
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css" />
    <title>{% block title %}My amazing site{% endblock %}</title>
</head>

<body>
    <div id="sidebar">
        {% block sidebar %}
        <ul>            
            <li><a href="/latest/">Latest</a></li>
        </ul>
        {% endblock %}
    </div>

    <div id="content">
        {% block content %}{% endblock %}
    </div>
</body>
</html>

#books/template/books/booklist.html 
{% extends "base.html" %}

{% block title %}Books at {{ now }}{% endblock %}

{% block content %}
    <ul>
    {% for book in object_list %}
        <li>{{ book.pub_date|date }} - {{ book.name }}</li>
    {% empty %}
        <li>No articles yet.</li>
    {% endfor %}
    </ul>
{% endblock %}

#books/template/books/book.html 
{% extends "base.html" %}

{% block title %}Books at {{ now }}{% endblock %}

{% block content %}
    <ul>
        <li>{{ object.pub_date|date }} - {{ object.name }}</li>
    </ul>
{% endblock %}




#books/book_create.html 
<form method="post">
    {% csrf_token %}
    {{ form.as_p }}
    <input type="submit" value="Save">
</form>

#books/book_delete.html 
<form method="post">
    {% csrf_token %}
    <p>Are you sure you want to delete "{{ object }}"?</p>
    <input type="submit" value="Confirm">
</form>

#books/book_update.html 
<form method="post">
    {% csrf_token %}
    {{ form.as_p }}
    <input type="submit" value="Update">
</form>

#check
python manage.py runserver 8080
# with http://127.0.0.1:8000/books/








###Model - Few important concepts 
    
##Overriding predefined model methods
#Overridden model methods are not called on bulk operations        

#A classic use-case for overriding the built-in methods is 
#if you want something to happen whenever you save an object. 
from django.db import models

class Blog(models.Model):
    name = models.CharField(max_length=100)
    tagline = models.TextField()

    def save(self, *args, **kwargs):
        do_something()
        super().save(*args, **kwargs)  # Call the "real" save() method.
        do_something_else()

#You can also prevent saving:
from django.db import models

class Blog(models.Model):
    name = models.CharField(max_length=100)
    tagline = models.TextField()

    def save(self, *args, **kwargs):
        if self.name == "Yoko Ono's blog":
            return # Yoko shall never have her own blog!
        else:
            super().save(*args, **kwargs)  # Call the "real" save() method.



    
            
##Validating Models 
Model.full_clean(exclude=None, validate_unique=True)
    The optional exclude argument lets you provide a list of field names to exclude from validation
    All three steps are performed when Model.full_clean() is called 
        1.Validate the model fields - Model.clean_fields(exclude=None)
        2.Validate the model as a whole, Customize this  - Model.clean()
        3.Validate the field uniqueness - Model.validate_unique() 
    ModelForm.is_valid() will perform these validation steps for all the fields that are included on the form
    Note that full_clean() will not be called automatically when Model.save() is called 
    Call seperately 

    from django.core.exceptions import NON_FIELD_ERRORS, ValidationError
    try:
        article.full_clean()
    except ValidationError as e:
        # Do something based on the errors contained in e.message_dict.
        # NON_FIELD_ERRORS  for errors not related to any field 
        #message_dict[field] for field related error 
        non_field_errors = e.message_dict[NON_FIELD_ERRORS]
        pub_date_field_errors = e.message_dict["pub_date"]
        

Model.clean_fields(exclude=None)
    This method will validate all fields on  model
    You can�t raise validation errors in Model.clean() for fields that don�t appear in a model form 
    (a form may limit its fields using Meta.fields or Meta.exclude). 
    Instead override Model.clean_fields() as it receives the list of fields that are excluded from validation. 
    #Example 
    class Article(models.Model):
        ...
        #Model.clean() is better place to put custom validation 
        def clean_fields(self, exclude=None):
            super().clean_fields(exclude=exclude)
            if self.status == 'draft' and self.pub_date is not None:
                if exclude and 'status' in exclude:
                    raise ValidationError(
                        _('Draft entries may not have a publication date.')
                    )
                else:
                    raise ValidationError({
                        'status': _(
                            'Set status to draft if there is not a '
                            'publication date.'
                         ),
                    })

       

 
Model.clean()
    This method should be used to provide custom model validation
    #Example 
    import datetime
    from django.core.exceptions import ValidationError
    from django.db import models
    from django.utils.translation import gettext_lazy as _

    class Article(models.Model):
        ...
        def clean(self):
            # Don't allow draft entries to have a pub_date.
            if self.status == 'draft' and self.pub_date is not None:
                raise ValidationError(_('Draft entries may not have a publication date.'))
            # Set the pub_date for published items if it hasn't been set already.
            if self.status == 'published' and self.pub_date is None:
                self.pub_date = datetime.date.today()
    ValidationError exception raised by Model.clean() was instantiated with a string, 
    so it will be stored in a special error dictionary key, NON_FIELD_ERRORS. 
    This key is used for errors that are tied to the entire model instead of to a specific field: 
    To assign exceptions to a specific field, instantiate the ValidationError with a dictionary, 
    where the keys are the field names
    class Article(models.Model):
        ...
        def clean(self):
            # Don't allow draft entries to have a pub_date.
            if self.status == 'draft' and self.pub_date is not None:
                raise ValidationError({'pub_date': _('Draft entries may not have a publication date.')})
            ...
            #OR with multiple fields 
            raise ValidationError({
                'title': ValidationError(_('Missing title.'), code='required'),
                'pub_date': ValidationError(_('Invalid date.'), code='invalid'),
            })

                        
        
Field.validators
    A list of validators to run for this field
    #Example 
    from django.core.exceptions import ValidationError
    from django.utils.translation import gettext_lazy as _

    def validate_even(value):
        if value % 2 != 0:
            raise ValidationError(
                _('%(value)s is not an even number'),
                params={'value': value},
            )
    #usage 
    from django.db import models
    class MyModel(models.Model):
        even_field = models.IntegerField(validators=[validate_even])

    #Can be used with Form as well 
    from django import forms
    class MyForm(forms.Form):
        even_field = forms.IntegerField(validators=[validate_even])
    #Standard Validator ,django.core.validators , each has __call__(self, value), so can be used as instance
    class RegexValidator(regex=None, message=None, code=None, inverse_match=None, flags=0)
    class EmailValidator(message=None, code=None, whitelist=None)
    class URLValidator(schemes=None, regex=None, message=None, code=None)
    class MaxValueValidator(max_value, message=None)
        Raises a ValidationError with a code of 'max_value' if value is greater than max_value.
    class MinValueValidator(min_value, message=None)
        Raises a ValidationError with a code of 'min_value' if value is less than min_value.
    class MaxLengthValidator(max_length, message=None)
        Raises a ValidationError with a code of 'max_length' if the length of value is greater than max_length.
    class MinLengthValidator(min_length, message=None)
        Raises a ValidationError with a code of 'min_length' if the length of value is less than min_length.
    class DecimalValidator(max_digits, decimal_places)
    class FileExtensionValidator(allowed_extensions, message, code)
    class ProhibitNullCharactersValidator(message=None, code=None)

    

##List of Fields
#https://docs.djangoproject.com/en/2.0/ref/models/fields/
django.db.models.fields.Field(verbose_name=None, name=None, primary_key=False,
                 max_length=None, unique=False, blank=False, null=False,
                 db_index=False, rel=None, default=NOT_PROVIDED, editable=True,
                 serialize=True, unique_for_date=None, unique_for_month=None,
                 unique_for_year=None, choices=None, help_text='', db_column=None,
                 db_tablespace=None, auto_created=False, validators=(),
                 error_messages=None)

class BigIntegerField(**options)
class BinaryField(**options)
class BooleanField(**options)
class CharField(max_length=None, **options)
class DateField(auto_now=False, auto_now_add=False, **options)
class DateTimeField(auto_now=False, auto_now_add=False, **options)
class DecimalField(max_digits=None, decimal_places=None, **options)
class DurationField(**options)
class EmailField(max_length=254, **options)
  
class FilePathField(path=None, match=None, recursive=False, max_length=100, **options)
class FloatField(**options)
class GenericIPAddressField(protocol='both', unpack_ipv4=False, **options)
class IntegerField(**options)
class NullBooleanField(**options)
class PositiveIntegerField(**options)
class PositiveSmallIntegerField(**options)
class SlugField(max_length=50, **options)
class SmallIntegerField(**options)
class TextField(**options)
class TimeField(auto_now=False, auto_now_add=False, **options)
class URLField(max_length=200, **options)
class UUIDField(**options)

class ImageField(upload_to=None, height_field=None, width_field=None, max_length=100, **options)
class FileField(upload_to=None, max_length=100, **options)


    
        
###*** Django - Chapter-3 
'''
ManytoOne , ManyToMany and Making Queries 
Objectives- Understanding Associations, Models, Queries
'''


###STEP 1: create a application, inside examplesite

$ python manage.py startapp baeapp 

#Update settings.INSTALLED_APPS to include 'baeapp'

#Update baeapp/models.py 
#Note *_set is renamed by attribute 'related_name' and reverse filter by 'related_query_name'


from django.db import models

class Blog(models.Model):                     #Many(Entry) to One(Blog), blog.entry_set and reverse filter= entry__*
    name = models.CharField(max_length=100)   #ForeignKey on Many side 
    tagline = models.TextField()   

    def __str__(self):              # __unicode__ on Python 2
        return self.name

class Author(models.Model):                     #Many(entry) to Many(Author), author.entry_set, reverse filter= entry__*
    name = models.CharField(max_length=200)     #ManyToManyField could be on any side 
    email = models.EmailField()

    def __str__(self):              # __unicode__ on Python 2
        return self.name

class Entry(models.Model):          
    blog = models.ForeignKey(Blog,on_delete=models.CASCADE)     #Many(Entry) to One(Blog), entry.blog, , reverse filter = blog__* 
    headline = models.CharField(max_length=255)
    body_text = models.TextField()
    pub_date = models.DateField()
    mod_date = models.DateField()
    authors = models.ManyToManyField(Author) #Many(entry) to Many(Author), entry.authors, filter= author__*
    n_comments = models.IntegerField()
    n_pingbacks = models.IntegerField()
    rating = models.IntegerField()

    def __str__(self):              # __unicode__ on Python 2
        return self.headline
        
    class Meta:
            ordering = ('headline',)


##Many-to-one relationships
#Many - Entry, One - Blog, use django.db.models.ForeignKey(Blog) on Entry ie Many side 
#Many side table would have one foreign key, eg blog (default db_column = blog_id)
#hence One blog id can be  linked across many Entry rows 

#all Blog objects ,  Blog.objects. (has add, get, filter, all methods)
#('objects' is default manager, Blog._default_manager)

#filter from Blog to Entry(reverse filter), entry__ENTRYATTRIBUTES
#all entries of a Blog instance , b.entry_set. (this has add, get, filter, all methods)
#instance of below class has create, save, delete methods and field names as attributes 
class Blog(models.Model):
       .

#All Entry objects , Entry.objects. (this has add, get, filter, all methods)
#Entry instance has one blog, e.blog.  (this has add, get, filter, all methods)
#filter from Entry to Blog, blog__BLOGATTRIBUTES
# instance of below class has create, save, delete methods and field names as attributes
class Entry(models.Model):
       .


##Many-to-many relationships- use ManyToManyField on either of side (not both)
#Generally, ManyToManyField instances should go in the object that�s going to be edited on a form
#Django implements through one intermideate table , Entry.authors.through

#Many - Entry, Many - Author, use django.db.models.ManyToManyField(Author) on Entry ie any one side 


#all Author objects ,  Author.objects.  (this has add,  get, filter, all methods)
#all entries of a Author instance , a.entry_set.  (this has add, get, filter, all methods)
#filter from Author to Entry(reverse filter), entry__
#Note entry_set is created by Django, nothing is explicitly mentioned
#instance of below class has create, save, delete methods and field names as attributes
class Author(models.Model): 
       
            
            
#All Entry objects , entry.objects.  (this has add,  get, filter, all methods)
#authors of an Entry, e.authors (from field name) (this has add, get, filter, all methods)
#filter from Entry to Author, author__



###STEP 2:Create the Database tables now
$ python manage.py makemigrations baeapp
$ python manage.py migrate


### STEP 3:Query 
#https://docs.djangoproject.com/en/1.10/ref/models/querysets
$ python manage.py shell


from baeapp.models import Blog, Author, Entry 


#To display SQL queries, use Debugtoolbar , http://django-debug-toolbar.readthedocs.io/en/stable/installation.html
#And then python manage.py  debugsqlshell, , then each ORM call that results in a database query will be output in the shell.
#OR use , connection.queries includes all SQL statements � INSERTs, UPDATES, SELECTs, etc. Each time your app hits the database, the query will be recorded.

>>> from django.db import connection
>>> connection.queries
[{'sql': 'SELECT polls_polls.id, polls_polls.question, polls_polls.pub_date FROM polls_polls',
'time': '0.002'}]

#For multiple databases, you can use the same interface on each member of the connections dictionary:
>>> from django.db import connections
>>> connections['my_db_alias'].queries

#to clear the query list manually at any point in your functions, just call reset_queries(), like this:
from django.db import reset_queries
reset_queries()


###When QuerySets(lazy) are evaluated
1.Iteration. 
    for e in Entry.objects.all():
        print(e.headline)

2.Slicing
3.Pickling/Caching
4.repr()
5.len()
6.list()
    entry_list = list(Entry.objects.all())
7.bool()
    if Entry.objects.filter(headline="Test"):
       print("There is at least one Entry with the headline Test")

###Comparing objects
#always based on primary key 
some_entry == other_entry
some_entry.id == other_entry.id

              
###Creating and Saving 
b = Blog(name='Beatles Blog', tagline='All the latest Beatles news.')
b.save()        #performs an INSERT SQL statement ,Django doesn�t hit the database until you explicitly call save().

#Entry - Many 
import datetime
e = Entry(blog=b, headline='Any headline', body_text='body', pub_date=datetime.date.today(),
            mod_date=datetime.date.today(), n_comments=2, n_pingbacks=3, rating=10)
e.save()

###Updating changes to objects
b.name = 'Cheddar Talk'
b.save()

###Updating ForeignKey 
entry = Entry.objects.get(pk=1)
cheese_blog = Blog.objects.get(name="Cheddar Talk")
entry.blog = cheese_blog
entry.save()
entry       #from __str__ , <Entry: Any headline>

###Updating a ManyToManyField � use the add() method on the field to add a record to the relation. 
joe = Author.objects.create(name="Joe")
entry.authors.add(joe)


#To add multiple records to a ManyToManyField in one go, 
john = Author.objects.create(name="John")
paul = Author.objects.create(name="Paul")
george = Author.objects.create(name="George")
ringo = Author.objects.create(name="Ringo")
entry.authors.add(john, paul, george, ringo)
entry.save()

###Retrieving objects
#construct a QuerySet via a Manager on  model class
#It can have zero, one or many filters. 
#In SQL terms, a QuerySet equates to a SELECT statement, and a filter is a limiting clause such as WHERE or LIMIT.
#Each model has at least one Manager, and it�s called 'objects' by default

Blog.objects  #<django.db.models.manager.Manager object at 0x03CE1610>

#Retrieving all objects
all_entries = Entry.objects.all()
      
      
      
##Basic lookups keyword arguments take the form 
field__lookuptype=value 

##For reverse relation, by default, related_query_name is reverse Model name in lowercase 
#or defined on ManyToManyField or ForeignKey
<<related_query_name>>__field__lookuptype=value 

##The pk lookup shortcut
#stands for'primary key'

#these three statements are equivalent:
Blog.objects.get(id__exact=14) # Explicit form
Blog.objects.get(id=14) # __exact is implied
Blog.objects.get(pk=14) # pk implies id__exact

# Get blogs entries with id 1, 4 and 7
>>> Blog.objects.filter(pk__in=[1,4,7])

# Get all blog entries with id > 14
>>> Blog.objects.filter(pk__gt=14)


#these three statements are equivalent:
Entry.objects.filter(blog__id__exact=3) # Explicit form
Entry.objects.filter(blog__id=3)        # __exact is implied
Entry.objects.filter(blog__pk=3)        # __pk implies __id__exact


###QuerySet reference 
#https://docs.djangoproject.com/en/2.0/ref/models/querysets/

The lookup parameters (**kwargs) should be in the format described in Field lookups below. 
Multiple parameters are joined via AND in the underlying SQL statement
For queries with OR statements, use Q objects
    exact
        Entry.objects.get(id__exact=14)
        Entry.objects.get(id__exact=None)
        Entry.objects.get(id=14)
    iexact
        Case-insensitive exact match
        Blog.objects.get(name__iexact='beatles blog')
        Blog.objects.get(name__iexact=None)
    contains
        Case-sensitive containment test.
        Entry.objects.get(headline__contains='Lennon')
    icontains
        Case-insensitive containment test.
        Entry.objects.get(headline__icontains='Lennon')
    in
        Entry.objects.filter(id__in=[1, 3, 4])
        inner_qs = Blog.objects.filter(name__contains='Cheddar')
        entries = Entry.objects.filter(blog__in=inner_qs)
        #Ensure only one field is returned to be used with in 
        inner_qs = Blog.objects.filter(name__contains='Ch').values('name')
        entries = Entry.objects.filter(blog__name__in=inner_qs)
    gt
        Entry.objects.filter(id__gt=4)
    gte
    lt
    lte
    startswith
    istartswith
        Entry.objects.filter(headline__istartswith='Lennon')
    endswith
        Entry.objects.filter(headline__endswith='Lennon')
    iendswith
    range
        import datetime
        start_date = datetime.date(2005, 1, 1)
        end_date = datetime.date(2005, 3, 31)
        Entry.objects.filter(pub_date__range=(start_date, end_date))
    date
        Entry.objects.filter(pub_date__date=datetime.date(2005, 1, 1))
        Entry.objects.filter(pub_date__date__gt=datetime.date(2005, 1, 1))
    year
        Entry.objects.filter(pub_date__year=2005)
        Entry.objects.filter(pub_date__year__gte=2005)
    month
    day
    week
    week_day
        Entry.objects.filter(pub_date__week_day=2)
        Entry.objects.filter(pub_date__week_day__gte=2)
    quarter
    time
        Entry.objects.filter(pub_date__time=datetime.time(14, 30))
        Entry.objects.filter(pub_date__time__range=(datetime.time(8), datetime.time(17)))
    hour
    minute
    second
    isnull
    regex
        Case-sensitive regular expression match.
        Entry.objects.get(title__regex=r'^(An?|The) +')
    iregex
        Entry.objects.get(title__iregex=r'^(an?|the) +')



Methods that return new QuerySets 
    filter(**kwargs)
    exclude(**kwargs)
        Entry.objects.exclude(pub_date__gt=datetime.date(2005, 1, 3), headline='Hello')
    annotate()
        from django.db.models import Count
        #annotate is aggregation 
        q = Blog.objects.annotate(Count('entry'))
        # The name of the first blog
        q[0].name               #        'Blogasaurus'
        # The number of entries on the first blog
        q[0].entry__count       #  42
        #OR
        q = Blog.objects.annotate(number_of_entries=Count('entry'))
        # The number of entries on the first blog, using the name provided
        q[0].number_of_entries      #42
    order_by(*fields)
        Entry.objects.filter(pub_date__year=2005).order_by('-pub_date', 'headline') # '-' means descending 
        Entry.objects.order_by('?')         #Random 
        Entry.objects.order_by('blog__name', 'headline')  #order entry based on blog_name 
        Entry.objects.order_by(Lower('headline').desc())
        Entry.objects.order_by('headline').order_by('pub_date') #note this only orders by pub_date, order by headline is cleared 
    reverse()
        my_queryset.reverse()[:5]  #last five 
    distinct(*fields)
        *fields only works on PostgreSQL only
        Author.objects.distinct()
        Entry.objects.order_by('pub_date').distinct('pub_date')
    values(*fields, **expressions)
        Returns a QuerySet that returns dictionaries, rather than model instances, when used as an iterable.
        #Examples 
        >>> Blog.objects.filter(name__startswith='Beatles')
        <QuerySet [<Blog: Beatles Blog>]>
        # This list contains a dictionary.
        >>> Blog.objects.filter(name__startswith='Beatles').values()
        <QuerySet [{'id': 1, 'name': 'Beatles Blog', 'tagline': 'All the latest Beatles news.'}]>
        #All fields 
        >>> Blog.objects.values()
        <QuerySet [{'id': 1, 'name': 'Beatles Blog', 'tagline': 'All the latest Beatles news.'}]>
        #only few 
        >>> Blog.objects.values('id', 'name')
        <QuerySet [{'id': 1, 'name': 'Beatles Blog'}]>
        #and with annonate in expressions
        >>> from django.db.models.functions import Lower
        >>> Blog.objects.values(lower_name=Lower('name'))
        <QuerySet [{'lower_name': 'beatles blog'}]>
        #Note expressions is applied first 
        #An aggregate/expressions within a values() clause is applied before other arguments 
        #within the same values() clause. 
        #If you need to group by another value, add it to an earlier values() clause instead
        >>> from django.db.models import Count
        >>> Blog.objects.values('entry__authors', entries=Count('entry'))
        <QuerySet [{'entry__authors': 1, 'entries': 20}, {'entry__authors': 1, 'entries': 13}]>
        >>> Blog.objects.values('entry__authors').annotate(entries=Count('entry'))
        <QuerySet [{'entry__authors': 1, 'entries': 33}]>
    values_list(*fields, flat=False, named=False)
        it returns tuples when iterated over
        #Examples 
        >>> Entry.objects.values_list('id', 'headline')
        <QuerySet [(1, 'First entry'), ...]>
        >>> from django.db.models.functions import Lower
        >>> Entry.objects.values_list('id', Lower('headline'))
        <QuerySet [(1, 'first entry'), ...]>
    dates(field, kind, order='ASC')
        Returns dates based on kind 
        #Examples 
        >>> Entry.objects.dates('pub_date', 'year')
        [datetime.date(2005, 1, 1)]
        >>> Entry.objects.dates('pub_date', 'month')
        [datetime.date(2005, 2, 1), datetime.date(2005, 3, 1)]
        >>> Entry.objects.filter(headline__contains='Lennon').dates('pub_date', 'day')
        [datetime.date(2005, 3, 20)]
    datetimes(field_name, kind, order='ASC', tzinfo=None)
        Returns datetimes based on kind 
    none()
        Calling none() will create a queryset that never returns any objects and no query will be executed 
        Entry.objects.none()#<QuerySet []>
    all()
        Returns a copy of the current QuerySet (or QuerySet subclass)
        When a QuerySet is evaluated, it typically caches its results
        OR to get new dataset, call .all() again on old queryset 
    union(*other_qs, all=False)
        Uses SQL�s UNION operator to combine the results of two or more QuerySets
        qs1.union(qs2, qs3)
        qs1 = Author.objects.values_list('name')
        qs2 = Entry.objects.values_list('headline')
        qs1.union(qs2).order_by('name')
    intersection(*other_qs)
        qs1.intersection(qs2, qs3)
    difference(*other_qs)
        qs1.difference(qs2, qs3)
    select_related(*fields)
        Returns a QuerySet that will 'follow' foreign-key relationships, 
        selecting additional related-object data when it executes its query. 
        You can use select_related() with any queryset of objects:
        #Examples 
        from django.utils import timezone
        # Find all the blogs with entries scheduled to be published in the future.
        blogs = set()
        for e in Entry.objects.filter(pub_date__gt=timezone.now()).select_related('blog'):
            # Without select_related(), this would make a database query for each
            # loop iteration in order to fetch the related blog for each entry.
            blogs.add(e.blog)
        #to clear the list of related fields added by past calls of select_related on a QuerySet
        without_relations = queryset.select_related(None)
    prefetch_related(*lookups)
        Returns a QuerySet that will automatically retrieve, in a single batch, related objects 
        for each of the specified lookups.
        select_related works by creating an SQL join and including the fields of the related object in the SELECT statement
        select_related is limited to single-valued relationships - foreign key and one-to-one.
        prefetch_related, on the other hand, does a separate lookup for each relationship, and does the �joining� in Python. 
        This allows it to prefetch many-to-many and many-to-one objects
        #Example 
        Pizza.objects.all().prefetch_related('toppings') #where in Pizza, toppings = models.ManyToManyField(Topping)
        #Exmaple 
        class Restaurant(models.Model):
            pizzas = models.ManyToManyField(Pizza, related_name='restaurants')
            best_pizza = models.ForeignKey(Pizza, related_name='championed_by', on_delete=models.CASCADE)
        #Usage 
        Restaurant.objects.prefetch_related('pizzas__toppings')
        Restaurant.objects.prefetch_related('best_pizza__toppings')
        Restaurant.objects.select_related('best_pizza').prefetch_related('best_pizza__toppings')
        #To clear 
        non_prefetched = qs.prefetch_related(None)
    extra(select=None, where=None, params=None, tables=None, order_by=None, select_params=None)
        a hook for injecting specific clauses into the SQL generated by a QuerySet.
        Specify one or more of params, select, where or tables. 
        None of the arguments is required, but you should use at least one of them.
        select 
            Entry.objects.extra(select={'is_recent': "pub_date > '2006-01-01'"})
            Blog.objects.extra(
                    select={
                        'entry_count': 'SELECT COUNT(*) FROM blog_entry WHERE blog_entry.blog_id = blog_blog.id'
                    },
                )
            Blog.objects.extra(
                select=OrderedDict([('a', '%s'), ('b', '%s')]),
                select_params=('one', 'two'))
        where / tables
            Entry.objects.extra(where=["foo='a' OR bar = 'a'", "baz = 'a'"])
        order_by 
            q = Entry.objects.extra(select={'is_recent': "pub_date > '2006-01-01'"})
            q = q.extra(order_by = ['-is_recent'])
        params 
            Entry.objects.extra(where=['headline=%s'], params=['Lennon']) #Good, avoids SQL injection 
    defer(*fields)
        To tell Django not to retrieve them from the database initially because it contains lot of data 
        Entry.objects.defer("headline", "body")
        # Defers both the body and headline fields.
        Entry.objects.defer("body").filter(rating=5).defer("headline")
        #defer select_related fields 
        Blog.objects.select_related().defer("entry__headline", "entry__body")
        # Load all fields immediately.
        my_queryset.defer(None)
    only(*fields)
        The only() method is more or less the opposite of defer(). 
        #Examples 
        Person.objects.defer("age", "biography")
        Person.objects.only("name")
        # This will defer all fields except the headline.
        Entry.objects.only("body", "rating").only("headline")
        # Final result is that everything except "headline" is deferred.
        Entry.objects.only("headline", "body").defer("body")
        # Final result loads headline and body immediately (only() replaces any
        # existing set of fields).
        Entry.objects.defer("body").only("headline", "body")
    using(alias)
        This method is for controlling which database the QuerySet will be evaluated against if you are using more than one database
        # queries the database with the 'default' alias.
        >>> Entry.objects.all()
        # queries the database with the 'backup' alias
        >>> Entry.objects.using('backup')
    select_for_update(nowait=False, skip_locked=False, of=())
        Returns a queryset that will lock rows until the end of the transaction, generating a SELECT ... FOR UPDATE SQL statement on supported databases.
        entries = Entry.objects.select_for_update().filter(author=request.user)
    raw(raw_query, params=None, translations=None)
        Raw sql query 
        for p in Person.objects.raw('SELECT * FROM myapp_person'):
            print(p)
        #The order of fields in your query doesn�t matte
        Person.objects.raw('SELECT id, first_name, last_name, birth_date FROM myapp_person')
        Person.objects.raw('SELECT last_name, birth_date, first_name, id FROM myapp_person')
        #Matching is done by name OR Use AS 
        Person.objects.raw('''SELECT first AS first_name,
                                     last AS last_name,
                                     bd AS birth_date,
                                     pk AS id,
                              FROM some_other_table''')
        #Index lookup 
        first_person = Person.objects.raw('SELECT * FROM myapp_person')[0]
        first_person = Person.objects.raw('SELECT * FROM myapp_person LIMIT 1')[0]
        #Fields may also be left out
        for p in Person.objects.raw('SELECT id, first_name FROM myapp_person'):
            print(p.first_name, # This will be retrieved by the original query
                  p.last_name) # This will be retrieved on demand
        #Adding annotations
        people = Person.objects.raw('SELECT *, age(birth_date) AS age FROM myapp_person')
        for p in people:
            print("%s is %s." % (p.first_name, p.age))
        #Passing parameters into raw()
        lname = 'Doe'
        Person.objects.raw('SELECT * FROM myapp_person WHERE last_name = %s', [lname])
        #Executing custom SQL directly
        #To protect against SQL injection, you must not include quotes around the %s placeholders in the SQL string.
        from django.db import connection
        def my_custom_sql(self):
            with connection.cursor() as cursor:
                cursor.execute("UPDATE bar SET foo = 1 WHERE baz = %s", [self.baz])
                cursor.execute("SELECT foo FROM bar WHERE baz = %s", [self.baz])
                row = cursor.fetchone()
            return row



Methods that do not return QuerySets 
    get(**kwargs)
        Entry.objects.get(id='foo')
        If you expect a queryset to return one row, you can use get() without any arguments to return the object for that row:
            entry = Entry.objects.filter(...).exclude(...).get()
    create(**kwargs)
        p = Person.objects.create(first_name="Bruce", last_name="Springsteen")
        #equivalent 
        p = Person(first_name="Bruce", last_name="Springsteen")
        p.save(force_insert=True)
    get_or_create(defaults=None, **kwargs)
        obj, created = Person.objects.get_or_create( #created is a boolean specifying whether a new object was created.
            first_name='John',
            last_name='Lennon',
            defaults={'birthday': date(1940, 10, 9)},
        )
    update_or_create(defaults=None, **kwargs)
        obj, created = Person.objects.update_or_create(
            first_name='John', last_name='Lennon',
            defaults={'first_name': 'Bob'},
        )
    bulk_create(objs, batch_size=None)
        Note The model�s save() method will not be called, and the pre_save and post_save signals will not be sent.
        Entry.objects.bulk_create([
            Entry(headline='This is a test'),
            Entry(headline='This is only a test'),
        ])
    count()
        # Returns the total number of entries in the database.
        Entry.objects.count()
        # Returns the number of entries whose headline contains 'Lennon'
        Entry.objects.filter(headline__contains='Lennon').count()
    in_bulk(id_list=None, field_name='pk')
        >>> Blog.objects.in_bulk([1])
        {1: <Blog: Beatles Blog>}
        >>> Blog.objects.in_bulk([1, 2])
        {1: <Blog: Beatles Blog>, 2: <Blog: Cheddar Talk>}
        >>> Blog.objects.in_bulk([])
        {}
        >>> Blog.objects.in_bulk()
        {1: <Blog: Beatles Blog>, 2: <Blog: Cheddar Talk>, 3: <Blog: Django Weblog>}
        >>> Blog.objects.in_bulk(['beatles_blog'], field_name='slug')
        {'beatles_blog': <Blog: Beatles Blog>}
    iterator(chunk_size=2000)
        A QuerySet typically caches its results internally so that repeated evaluations do not result in additional queries. 
        In contrast, iterator() will read results directly, without doing any caching at the QuerySet level 
    latest(*fields)
        Entry.objects.latest('pub_date')
        Entry.objects.latest('pub_date', '-expire_date')
    earliest(*fields)
    first()
        p = Article.objects.order_by('title', 'pub_date').first() # None if there is no matching object.
    last()
    aggregate(*args, **kwargs)
        Returns a dictionary of aggregate values (averages, sums, etc.) calculated over the QuerySet
        #Examples 
        from django.db.models import Count
        q = Blog.objects.aggregate(Count('entry')) #{'entry__count': 16}
        q = Blog.objects.aggregate(number_of_entries=Count('entry')) #{'number_of_entries': 16}
        #Examples 
        # Total number of books.
        >>> Book.objects.count()
        2452
        # Total number of books with publisher=BaloneyPress
        >>> Book.objects.filter(publisher__name='BaloneyPress').count()
        73
        # Average price across all books.
        >>> from django.db.models import Avg
        >>> Book.objects.all().aggregate(Avg('price'))
        {'price__avg': 34.35}
        # Max price across all books.
        >>> from django.db.models import Max
        >>> Book.objects.all().aggregate(Max('price'))
        {'price__max': Decimal('81.20')}
        # Difference between the highest priced book and the average price of all books.
        >>> from django.db.models import FloatField
        >>> Book.objects.aggregate(price_diff=Max('price', output_field=FloatField()) - Avg('price'))
        {'price_diff': 46.85}
        # All the following queries involve traversing the Book<->Publisher foreign key relationship backwards.
        # Each publisher, each with a count of books as a "num_books" attribute.
        from django.db.models import Count
        pubs = Publisher.objects.annotate(num_books=Count('book'))
        >>> pubs
        <QuerySet [<Publisher: BaloneyPress>, <Publisher: SalamiPress>, ...]>
        >>> pubs[0].num_books
        73
        # Each publisher, with a separate count of books with a rating above and below 5
        from django.db.models import Q
        above_5 = Count('book', filter=Q(book__rating__gt=5))
        below_5 = Count('book', filter=Q(book__rating__lte=5))
        pubs = Publisher.objects.annotate(below_5=below_5).annotate(above_5=above_5)
        >>> pubs[0].above_5
        23
        >>> pubs[0].below_5
        12
        # The top 5 publishers, in order by number of books.
        pubs = Publisher.objects.annotate(num_books=Count('book')).order_by('-num_books')[:5]
        >>> pubs[0].num_books
        1323

    exists()
        if some_queryset.exists():
            print("There is at least one object in some_queryset")

    update(**kwargs)
        Entry.objects.filter(pub_date__year=2010).update(comments_on=False) #returns the number of affected rows
        #it can only update columns in the model�s main table, not on related models. 
        Entry.objects.update(blog__name='foo') # Won't work!
        #Filtering based on related fields is still possible, though:
        Entry.objects.filter(blog__id=1).update(comments_on=True)
        #You cannot call update() on a QuerySet that has had a slice taken or can otherwise no longer be filtered.

    delete()
        The delete() is applied instantly. 
        You cannot call delete() on a QuerySet that has had a slice taken or can otherwise no longer be filtered.
        #Examples 
        b = Blog.objects.get(pk=1)
        # Delete all the entries belonging to this Blog.
        >>> Entry.objects.filter(blog=b).delete()
        (4, {'weblog.Entry': 2, 'weblog.Entry_authors': 2})


    as_manager()
        Class method that returns an instance of Manager with a copy of the QuerySet�s methods
        Manager names 
            Person.objects will generate an AttributeError exception, 
            but Person.people.all() will provide a list of all Person objects.
            #Example 
            from django.db import models
            class Person(models.Model):
                #...
                people = models.Manager()
        Adding extra manager methods
            OpinionPoll.objects.with_counts() to return that list of OpinionPoll objects with num_responses attributes.
            #Example 
            from django.db import models
            class PollManager(models.Manager):
                def with_counts(self):
                    from django.db import connection
                    with connection.cursor() as cursor:
                        cursor.execute("""
                            SELECT p.id, p.question, p.poll_date, COUNT(*)
                            FROM polls_opinionpoll p, polls_response r
                            WHERE p.id = r.poll_id
                            GROUP BY p.id, p.question, p.poll_date
                            ORDER BY p.poll_date DESC""")
                        result_list = []
                        for row in cursor.fetchall():
                            p = self.model(id=row[0], question=row[1], poll_date=row[2])
                            p.num_responses = row[3]
                            result_list.append(p)
                    return result_list
            class OpinionPoll(models.Model):
                question = models.CharField(max_length=200)
                poll_date = models.DateField()
                objects = PollManager()
            class Response(models.Model):
                poll = models.ForeignKey(OpinionPoll, on_delete=models.CASCADE)
                person_name = models.CharField(max_length=50)
                response = models.TextField()
        Modifying a manager�s initial QuerySet
            #Example 
            class DahlBookManager(models.Manager):
                def get_queryset(self):
                    #can use filter(), exclude() and all the other QuerySet methods on it
                    return super().get_queryset().filter(author='Roald Dahl')
            # Then hook it into the Book model explicitly.
            class Book(models.Model):
                title = models.CharField(max_length=100)
                author = models.CharField(max_length=50)

                objects = models.Manager() # The default manager.
                dahl_objects = DahlBookManager() # The Dahl-specific manager.
            #Usge 
            Book.dahl_objects.all()
            Book.dahl_objects.filter(title='Matilda')
            Book.dahl_objects.count()
        Calling custom QuerySet methods from the manager
            To call both authors() and editors() directly from the manager Person.people.
                class PersonQuerySet(models.QuerySet):
                    def authors(self):
                        return self.filter(role='A')
                    def editors(self):
                        return self.filter(role='E')
                class PersonManager(models.Manager):
                    def get_queryset(self):
                        return PersonQuerySet(self.model, using=self._db)
                    def authors(self):
                        return self.get_queryset().authors()
                    def editors(self):
                        return self.get_queryset().editors()
                class Person(models.Model):
                    first_name = models.CharField(max_length=50)
                    last_name = models.CharField(max_length=50)
                    role = models.CharField(max_length=1, choices=(('A', _('Author')), ('E', _('Editor'))))
                    people = PersonManager()
        Creating a manager with QuerySet methods
            In lieu of the above approach which requires duplicating methods on both the QuerySet and the Manager,
            QuerySet.as_manager() can be used to create an instance of Manager with a copy of a custom QuerySet�s methods:
            #Examples 
            class Person(models.Model):
                people = PersonQuerySet.as_manager()
            #Which methods get replicated 
            class CustomQuerySet(models.QuerySet):
                # Available on both Manager and QuerySet.
                def public_method(self):
                    return
                # Available only on QuerySet.
                def _private_method(self):
                    return
                # Available only on QuerySet.
                def opted_out_public_method(self):
                    return
                opted_out_public_method.queryset_only = True
                # Available on both Manager and QuerySet.
                def _opted_in_private_method(self):
                    return
                _opted_in_private_method.queryset_only = False
        classmethod from_queryset(queryset_class)
            To get both a custom Manager and a custom QuerySet. 
            You can do that by calling Manager.from_queryset() which returns a subclass of your base Manager 
            with a copy of the custom QuerySet methods:
            #Examples 
            class BaseManager(models.Manager):
                def manager_only_method(self):
                    return
            class CustomQuerySet(models.QuerySet):
                def manager_and_queryset_method(self):
                    return
            class MyModel(models.Model):
                objects = BaseManager.from_queryset(CustomQuerySet)()

            #You may also store the generated class into a variable:
            CustomManager = BaseManager.from_queryset(CustomQuerySet)
            class MyModel(models.Model):
                objects = CustomManager()

 
    

Q() objects
    Complex Query, using | (OR) and & (AND) operators
    #Examples 
    from django.db.models import Q
    Q(question__startswith='What')
    Q(question__startswith='Who') | Q(question__startswith='What')
    Q(question__startswith='Who') | ~Q(pub_date__year=2005)
    #individual arg is ANDed together 
    Poll.objects.get(
        Q(question__startswith='Who'),
        Q(pub_date=date(2005, 5, 2)) | Q(pub_date=date(2005, 5, 6))
    )
    #non Q arg must be last 
    Poll.objects.get(
        Q(pub_date=date(2005, 5, 2)) | Q(pub_date=date(2005, 5, 6)),
        question__startswith='Who',
    )

F() expressions 
    Useful to create an expression based on another field in same expression 
    #Examples 
    from django.db.models import DateTimeField, ExpressionWrapper, F
    reporter = Reporters.objects.get(name='Tintin')
    reporter.stories_filed = F('stories_filed') + 1
    reporter.save()
    #or 
    reporter = Reporters.objects.filter(name='Tintin')
    reporter.update(stories_filed=F('stories_filed') + 1)
    #or 
    Reporter.objects.all().update(stories_filed=F('stories_filed') + 1)
    #Creating dynamic fields 
    company = Company.objects.annotate(chairs_needed=F('num_employees') - F('num_chairs'))
    #if F() expression returning different output filed type 
    Ticket.objects.annotate( expires=ExpressionWrapper(
                                F('active_at') + F('duration'), output_field=DateTimeField())
                            )
    #to sort null values 
    Company.object.order_by(F('last_contacted').desc(nulls_last=True))


Func() expressions
    base type of all expressions that involve database functions like COALESCE and LOWER, or aggregates like SUM.
    They can be used directly
    from django.db.models import F, Func
    queryset.annotate(field_lower=Func(F('field'), function='LOWER'))
    #or custom function 
    class Lower(Func):
        function = 'LOWER'
    queryset.annotate(field_lower=Lower('field'))

Value() expressions
    Value(value, output_field=None)
        To represent the value of literal - an integer, boolean, or string within an expression, 
        wrap that value within a Value().

Subquery() expressions
    Subquery(queryset, output_field=None)
        To add an explicit subquery to a QuerySet using the Subquery expression
        #Examples 
        from django.db.models import OuterRef, Subquery
        newest = Comment.objects.filter(post=OuterRef('pk')).order_by('-created_at')
        Post.objects.annotate(newest_commenter_email=Subquery(newest.values('email')[:1]))
    Referencing columns from the outer queryset
        class OuterRef(field)
            Book.objects.filter(author=OuterRef(OuterRef('pk')))
    Limiting a subquery to a single column
        Use values 
        #Examples 
        from datetime import timedelta
        from django.utils import timezone
        one_day_ago = timezone.now() - timedelta(days=1)
        posts = Post.objects.filter(published_at__gte=one_day_ago)
        Comment.objects.filter(post__in=Subquery(posts.values('pk')))
    Limiting the subquery to a single row
        Use slice 
        #Examples 
        subquery = Subquery(newest.values('email')[:1])
        Post.objects.annotate(newest_commenter_email=subquery)
    Exists() subqueries
        class Exists(queryset)
            from django.db.models import Exists, OuterRef
            from datetime import timedelta
            from django.utils import timezone
            one_day_ago = timezone.now() - timedelta(days=1)
            recent_comments = Comment.objects.filter(
                post=OuterRef('pk'),
                created_at__gte=one_day_ago,
            )
            Post.objects.annotate(recent_comment=Exists(recent_comments))
    Filtering on a Subquery expression
        It�s not possible to filter directly using Subquery and Exists, e.g.:
            >>> Post.objects.filter(Exists(recent_comments))
            ...
            TypeError: 'Exists' object is not iterable
        Use filter on a subquery expression by first annotating the queryset and then filtering based on that annotation:
            Post.objects.annotate(
                recent_comment=Exists(recent_comments),
            ).filter(recent_comment=True)
    Using aggregates within a Subquery expression
        Aggregates may be used within a Subquery, but they require a specific combination of filter(), values(), and annotate() 
        to get the subquery grouping correct.
        #Examples 
        from django.db.models import OuterRef, Subquery, Sum
        comments = Comment.objects.filter(post=OuterRef('pk')).order_by().values('post')
        total_comments = comments.annotate(total=Sum('length')).values('total')
        Post.objects.filter(length__gt=Subquery(total_comments))



Raw SQL expressions
    class RawSQL(sql, params, output_field=None)
        from django.db.models.expressions import RawSQL
        queryset.annotate(val=RawSQL("select col from sometable where othercol = %s", (someparam,)))


Aggregation functions
    #note all below create result field as <field>__<function_name> eg <field>__avg, <field>__count etc 
    Avg(expression, output_field=FloatField(), filter=None, **extra)
        expression
            A string that references a field on the model, or a query expression
        filter 
            An optional Q object that's used to filter the rows that are aggregated
    Count(expression, distinct=False, filter=None, **extra)
    Max(expression, output_field=None, filter=None, **extra)
    Min(expression, output_field=None, filter=None, **extra)
    StdDev(expression, sample=False, filter=None, **extra)
    Sum(expression, output_field=None, filter=None, **extra)
    Variance(expression, sample=False, filter=None, **extra)

Aggregate() expressions
    Special case of a Func() expression 
    #Example  
    from django.db.models import Count
    Company.objects.annotate( managers_required=(Count('num_employees') / 4) + Count('num_managers'))
    #Custom Aggregate 
    from django.db.models import Aggregate
    class MyCount(Aggregate):
        # supports COUNT(distinct field)
        function = 'COUNT'
        template = '%(function)s(%(distinct)s%(expressions)s)' #SQL that is generated for this aggregate. Defaults to '%(function)s( %(expressions)s )'.
        def __init__(self, expression, distinct=False, **extra):
            super().__init__(
                expression,
                distinct='DISTINCT ' if distinct else '',
                output_field=IntegerField(),
                **extra
            )

Conditional expressions
    Django natively supports SQL CASE expressions    
    When(condition=None, then=None, **lookups)
        from django.db.models import F, Q, When
        # String arguments refer to fields; the following two examples are equivalent:
        When(account_type=Client.GOLD, then='name')
        When(account_type=Client.GOLD, then=F('name'))
        # You can use field lookups in the condition
        from datetime import date
        When(registered_on__gt=date(2014, 1, 1),
             registered_on__lt=date(2015, 1, 1),
             then='account_type')
        # Complex conditions can be created using Q objects
        When(Q(name__startswith="John") | Q(name__startswith="Paul"), then='name')
    Case(*cases, **extra)
        if � elif � else statement in Python
        #Examples 
        Client.objects.annotate(
            discount=Case(
                When(account_type=Client.GOLD, then=Value('5%')),
                When(account_type=Client.PLATINUM, then=Value('10%')),
                default=Value('0%'),
                output_field=CharField(),
            ),
        ).values_list('name', 'discount')
        #output 
        <QuerySet [('Jane Doe', '0%'), ('James Smith', '5%'), ('Jack Black', '10%')]>
    Conditional update
        a_month_ago = date.today() - timedelta(days=30)
        a_year_ago = date.today() - timedelta(days=365)
        # Update the account_type for each Client from the registration date
        Client.objects.update(
            account_type=Case(
                When(registered_on__lte=a_year_ago,
                     then=Value(Client.PLATINUM)),
                When(registered_on__lte=a_month_ago,
                     then=Value(Client.GOLD)),
                default=Value(Client.REGULAR)
            ),
        )
        Client.objects.values_list('name', 'account_type')
    Conditional aggregation
        from django.db.models import Count
        Client.objects.aggregate(
            regular=Count('pk', filter=Q(account_type=Client.REGULAR)),
            gold=Count('pk', filter=Q(account_type=Client.GOLD)),
            platinum=Count('pk', filter=Q(account_type=Client.PLATINUM)),
        )
        #output 
        {'regular': 2, 'gold': 1, 'platinum': 3}


Database Functions
    Comparison and conversion functions 
        Cast(expression, output_field)
            from django.db.models import FloatField
            from django.db.models.functions import Cast
            value = Value.objects.annotate(as_float=Cast('integer', FloatField())).get()
            >>> print(value.as_float)
            4.0
        Coalesce(*expressions, **extra)
            Accepts a list of at least two field names or expressions and returns the first non-null value 
            # Get a screen name from least to most public
            from django.db.models import Sum, Value as V
            from django.db.models.functions import Coalesce
            Author.objects.create(name='Margaret Smith', goes_by='Maggie')
            author = Author.objects.annotate(
               screen_name=Coalesce('alias', 'goes_by', 'name')).get()
            >>> print(author.screen_name)
            Maggie
            # Prevent an aggregate Sum() from returning None
            aggregated = Author.objects.aggregate(
               combined_age=Coalesce(Sum('age'), V(0)),
               combined_age_default=Sum('age'))
            >>> print(aggregated['combined_age'])
            0
            >>> print(aggregated['combined_age_default'])
            None
        Greatest(*expressions, **extra)
            Accepts a list of at least two field names or expressions and returns the greatest value
        Least(*expressions, **extra)[

    Date functions 
        Extract(expression, lookup_name=None, tzinfo=None, **extra)
            lookup_name 
                year,quarter,month,day,week,week_day,hour,minute,second
            #Examples 
            # Add the experiment start year as a field in the QuerySet.
            experiment = Experiment.objects.annotate(
               start_year=Extract('start_datetime', 'year')).get()
            >>> experiment.start_year
            2015
            # How many experiments completed in the same year in which they started?
            Experiment.objects.filter( start_datetime__year=Extract('end_datetime', 'year')).count()

        DateField extracts
            short-cut to Extract with appropriate lookup_name 
                class ExtractYear(expression, tzinfo=None, **extra)[source]
                class ExtractMonth(expression, tzinfo=None, **extra)[source]
                class ExtractDay(expression, tzinfo=None, **extra)[source]
                class ExtractWeekDay(expression, tzinfo=None, **extra)[source]
                class ExtractWeek(expression, tzinfo=None, **extra)[source]�
                class ExtractQuarter(expression, tzinfo=None, **extra)
        DateTimeField extracts
            short-cut to Extract with appropriate lookup_name 
                class ExtractHour(expression, tzinfo=None, **extra)
                class ExtractMinute(expression, tzinfo=None, **extra)
                class ExtractSecond(expression, tzinfo=None, **extra)
        Now
            from django.db.models.functions import Now
            Article.objects.filter(published__lte=Now())

        Trunc(expression, kind, output_field=None, tzinfo=None, **extra)
            Truncates a date up to a significant component.
            #Examples 
            experiments_per_day = Experiment.objects.annotate(
               start_day=Trunc('start_datetime', 'day', output_field=DateTimeField())
            ).values('start_day').annotate(experiments=Count('id'))
            for exp in experiments_per_day:
                print(exp['start_day'], exp['experiments'])
            #output 
            2015-06-15 00:00:00 2
            2015-12-25 00:00:00 1
            experiments = Experiment.objects.annotate(
               start_day=Trunc('start_datetime', 'day', output_field=DateTimeField())
            ).filter(start_day=datetime(2015, 6, 15))
            for exp in experiments:
                print(exp.start_datetime)
            #output 
            2015-06-15 14:30:50.000321
            2015-06-15 14:40:02.000123
 
        DateField truncation
            short-cut to Trunc with appropriate kind 
                class TruncYear(expression, output_field=None, tzinfo=None, **extra)
                class TruncMonth(expression, output_field=None, tzinfo=None, **extra)
                class TruncQuarter(expression, output_field=None, tzinfo=None, **extra)
        DateTimeField truncation
            class TruncDate(expression, **extra)
            class TruncTime(expression, **extra)[source]�
            class TruncDay(expression, output_field=None, tzinfo=None, **extra)
            class TruncHour(expression, output_field=None, tzinfo=None, **extra)
            class TruncMinute(expression, output_field=None, tzinfo=None, **extra)
            class TruncSecond(expression, output_field=None, tzinfo=None, **extra)
            class TruncHour(expression, output_field=None, tzinfo=None, **extra)
            class TruncMinute(expression, output_field=None, tzinfo=None, **extra)
            class TruncSecond(expression, output_field=None, tzinfo=None, **extra)

    Text functions 
        Concat(*expressions, **extra)
            Accepts a list of at least two text fields or expressions and returns the concatenated text
            #Examples 
            from django.db.models import CharField, Value as V
            from django.db.models.functions import Concat
            Author.objects.create(name='Margaret Smith', goes_by='Maggie')
            author = Author.objects.annotate(
                screen_name=Concat(
                    'name', V(' ('), 'goes_by', V(')'),
                    output_field=CharField()
                )
            ).get()
            >>> print(author.screen_name)
            Margaret Smith (Maggie)

        Length(expression, **extra)        
            author = Author.objects.annotate(
               name_length=Length('name'),
               goes_by_length=Length('goes_by')).get()
            print(author.name_length, author.goes_by_length) #(14, None)

        Lower(expression, **extra)[
        StrIndex(string, substring, **extra)
            Author.objects.filter(name='Margaret Jackson').annotate(
                 smith_index=StrIndex('name', V('Smith'))
               ).get().smith_index
        Substr(expression, pos, length=None, **extra)
        Upper(expression, **extra)

    Window functions 
        Window(expression, partition_by=None, order_by=None, frame=None, output_field=None)
            Window functions provide a way to apply functions on partitions. 
            Unlike a normal aggregation function which computes a final result for each set defined by the group by, 
            window functions operate on frames and partitions, and compute the result for each row.
            expression argument is either a window function, an aggregate function,
            Partitioning(ie groupby in windowing) narrows which rows are used to compute the result set.
            The frame parameter specifies which other rows that should be used in the computation
                 ValueRange(start=None, end=None)
                 RowRange(start=None, end=None)
            #Examples 
            from django.db.models import Avg, F, Window
            from django.db.models.functions import ExtractYear
            Movie.objects.annotate(
                avg_rating=Window(
                    expression=Avg('rating'),
                    partition_by=[F('studio'), F('genre')],
                    order_by=ExtractYear('released').asc(),
                ),
            )
            #OR 
            from django.db.models import Avg, F, RowRange, Window
            from django.db.models.functions import ExtractYear
            Movie.objects.annotate(
                avg_rating=Window(
                    expression=Avg('rating'),
                    partition_by=[F('studio'), F('genre')],
                    order_by=ExtractYear('released').asc(),
                    frame=RowRange(start=-2, end=2),
                ),
            )
        CumeDist(*expressions, **extra)
        DenseRank(*expressions, **extra)
        FirstValue(expression, **extra)
        Lag(expression, offset=1, default=None, **extra)
        LastValue(expression, **extra)
        Lead(expression, offset=1, default=None, **extra)
        NthValue(expression, nth=1, **extra)
        Ntile(num_buckets=1, **extra)
        PercentRank(*expressions, **extra)
        Rank(*expressions, **extra)
        RowNumber(*expressions, **extra)












###*** Django - Chapter-4
'''
Forms     
    Show ModelForm handling     
    Objectives - Handiing forms, Form class and Edit  views
Seccurity features
'''

###Note there are three ways to create a form to update Database 
1. Use view eg CreateView, DeleteView, UpdateView 
2. Or manually code all these updates after inheriting from ModelForm
3. Or Use admin module
#Both forms are demonstrated here 
#Note above are used to create a Form based on Model 
#for Simply creating html form, inherit from Form (infact ModelForm inherits Form)

###STEP 1: Then create a application, inside examplesite

$ python manage.py startapp modelform 


#modelform/urls.py 
from django.conf.urls import url, include 

from . import views


urlpatterns = [        
    url(r'^book-create/',  views.create_book, name="modelex-book-create"),  
    url(r'^author-create/',  views.AuthorCreate.as_view(), name="modelex-author-create"),
    url(r'^books/',  views.latest_books , name="modelex-books-list"),
    url(r'^authors/',  views.latest_authors , name="modelex-authors-list"),
]

#modelform/models.py 
from django.db import models
TITLE_CHOICES = (
    ('MR', 'Mr.'),
    ('MRS', 'Mrs.'),
    ('MS', 'Ms.'),
)


class Author(models.Model):    #.book_set, reverse relation = book__
    name = models.CharField(max_length=100)
    title = models.CharField(max_length=3, choices=TITLE_CHOICES)
    birth_date = models.DateField(blank=True, null=True)
    def __str__(self):              # __unicode__ on Python 2
        return self.name


class Book(models.Model):
    name = models.CharField(max_length=100)
    authors = models.ManyToManyField(Author)  # .authors, forward relation = author__
    def __str__(self):              # __unicode__ on Python 2
        return self.name
 

    
  
#modelform/forms.py 
from django.forms import ModelForm
from .models import *
from django import forms

'''
#Not required as we have used CreateView which directly creates a form from model 
class AuthorForm(ModelForm):    
    class Meta:
        model = Author
        fields = ['name', 'title', 'birth_date']
        widgets = {
            'name': forms.Textarea(attrs={'cols': 80, 'rows': 20}),
        }
''' 

class BookForm(ModelForm):
    def clean(self):      
        '''additional validation'''
        cleaned_data = super(BookForm, self).clean()
        name = cleaned_data.get("name")      #it is a dict    
        if len(name) < 2:            
                raise forms.ValidationError("Name Length Error")
    class Meta:
        model = Book
        fields = ['name', 'authors']
        widgets = {
            'name': forms.Textarea(attrs={'cols': 80, 'rows':2}), #can update  class, id comes from string of variable name  
        }
        

#modelform/views.py 

from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render
from  django.urls import *


from .forms import BookForm
from .models import *

'''
def create_author(request):   

    # if this is a POST request we need to process the form data
    if request.method == 'POST':      
        # create a form instance and populate it with data from the request:
        form = AuthorForm(request.POST)
        log.debug("POST " + str(request.POST))
        # check whether it's valid:
        if form.is_valid():            
            form.save(commit=True)           
            return HttpResponseRedirect(reverse('modelex-authors-list'))
    # if a GET (or any other method) we'll create a blank form
    else:
        form = AuthorForm()
    return render(request, 'create.html', {'form': form, 'create_string': 'modelex-author-create'})
'''   

#check attributes https://ccbv.co.uk/projects/Django/2.0/django.views.generic.edit/CreateView/
#default value: template_name_suffix =  '_form' , 
#default template_name to be '<<app>>/templates/<<app>>/<<model>>_form.html'.
from django.views.generic.edit import CreateView
from django.utils import timezone
class AuthorCreate(CreateView):
    model = Author   
    success_url = reverse_lazy('modelex-authors-list')  # _lazy is must else ImproperlyConfigured error 
    fields = ['name', 'title', 'birth_date']    
    #Put any extra context here 
    def get_context_data(self, **kwargs):
        ''' Any context var for form '''
        context = super(AuthorCreate, self).get_context_data(**kwargs)
        context['now'] = timezone.now()
        return context    
    def form_valid(self, form):
        # This method is called when valid form data has been POSTed.
        # It should return an HttpResponse.
        #Do some addl activity, super class saves it in database 
        return super(AuthorCreate, self).form_valid(form)

       
#Instead of hardcoding below, we can use general editng view as given above 
#REF: https://docs.djangoproject.com/en/2.0/ref/class-based-views/generic-editing/
#       
def create_book(request):  
    # if this is a POST request we need to process the form data
    if request.method == 'POST':      
        # create a form instance and populate it with data from the request:
        form = BookForm(request.POST)        
        # check whether it's valid:
        if form.is_valid():        #calls form validation as well as model validation    
            #now form.cleaned_data (a dict of all fields) are available 
            #form.data is uncleaned ones
            form.save(commit=True)           
            return HttpResponseRedirect(reverse('modelex-books-list'))
    # if a GET (or any other method) we'll create a blank form
    else:
        form = BookForm()
    return render(request, 'create.html', {'form': form, 'create_string': 'modelex-book-create'})
  
    
def latest_books(request):    
    book_list = Book.objects.prefetch_related('authors').all()
    return render(request, 'list.html', {'book_list': book_list})

def latest_authors(request):   
    a_list = Author.objects.prefetch_related('book_set').all()
    return render(request, 'list_a.html', {'a_list': a_list})
    


#modelform/templates/list.html 
{% load staticfiles %}
<!DOCTYPE>
<html>
    <head>
        <title>Books</title>       
    </head>
    <body>
        {% for book in book_list %} 
            <h1>{{ book.name }}  </h1>
            {% for author in book.authors.all %} 
              <h2>  {{ author.name}}</h2>
            {% endfor %} 
        {% endfor %} 
    </body>
</html>

#modelform/templates/list_a.html  
{% load staticfiles %}
<!DOCTYPE>
<html>
    <head>
        <title>Authors</title>       
    </head>
    <body>
        {% for author in a_list %} 
            <h1>{{ author.name }}  </h1>
            {% for book in author.book_set.all %} 
              <h2>  {{ book.name}}</h2>
            {% endfor %} 
        {% endfor %} 
    </body>
</html>

#modelform/templates/create.html
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Contact form</title>	
        <style type="text/css">
            table.gridtable {
                font-family: verdana,arial,sans-serif;
                font-size:11px;
                color:#333333;
                border-width: 1px;
                border-color: #666666;
                border-collapse: collapse;
            }
            table.gridtable th {
                border-width: 1px;
                padding: 8px;
                border-style: solid;
                border-color: #666666;
                background-color: #dedede;
            }
            table.gridtable td {
                border-width: 1px;
                padding: 8px;
                border-style: solid;
                border-color: #666666;
                background-color: #ffffff;
            }
        </style>   
	</head>

	<body>
        <form action="{% url create_string %}" method="post">
            {% csrf_token %}
            <table class="gridtable">
                {{ form.as_table }}
            </table >
            <input type="submit" value="Submit" />
        </form>
	</body>

</html>  

#modelform/templates/modelform/author_form.html 
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Author Create form</title>	
        <style type="text/css">
            table.gridtable {
                font-family: verdana,arial,sans-serif;
                font-size:11px;
                color:#333333;
                border-width: 1px;
                border-color: #666666;
                border-collapse: collapse;
            }
            table.gridtable th {
                border-width: 1px;
                padding: 8px;
                border-style: solid;
                border-color: #666666;
                background-color: #dedede;
            }
            table.gridtable td {
                border-width: 1px;
                padding: 8px;
                border-style: solid;
                border-color: #666666;
                background-color: #ffffff;
            }
        </style>   
	</head>

	<body>
        <form action="" method="post">
            {% csrf_token %}
            <table class="gridtable">
                {{ form.as_table }}
            </table >
            <input type="submit" value="Save" />
        </form>
	</body>

</html> 




###STEP 2:Create the Database tables now
$ python manage.py makemigrations modelform
$ python manage.py migrate

#examplesite/urls.py 
urlpatterns = [   
    url(r'^modelform/' , include('modelform.urls')),
]

#modelform/admin.py 

# Register your models here.
from .models import Author, Book 

admin.site.register(Author)
admin.site.register(Book)

#Create  superuser eg  admin/adminadminadmin
$ python manage.py createsuperuser 


#check
python manage.py runserver 8080
# http://127.0.0.1:8080/modelform/author-create
# http://127.0.0.1:8080/modelform/book-create
# http://127.0.0.1:8080/modelform/books
# http://127.0.0.1:8080/modelform/authors





###Crispy Forms - based on bootstrap 
#https://django-crispy-forms.readthedocs.io/en/d-0/tags.html

$ pip install django-crispy-forms

#Update settings.py
#In production environments, always activate Django template cache loader. 
INSTALLED_APPS = (
    ...
    'crispy_forms',
)



#django-crispy-forms has built-in support for different CSS frameworks, known as template packs 
#crispy-forms no longer includes static files. , include proper urls 
bootstrap 
    Bootstrap is crispy-forms�s default template pack, 
    version 2 
bootstrap3 
    Twitter Bootstrap version 3.
bootstrap4 
    Alpha support for Twitter Bootstrap version 4, which is still in Alpha.
uni-form 
    Uni-form is a nice looking, well structured, highly customizable, 
    accessible and usable forms.
foundation 
    Foundation FrameWork 
    
#Update settings.py
CRISPY_TEMPLATE_PACK = 'uni_form'


###crispy filter
#render a form or formset using django-crispy-forms div based fields
# class="uniForm" is only for uni_form template pack

{% load crispy_forms_tags %}

<form method="post" class="uniForm">
    {{ my_formset|crispy }}
</form>


###Complete Example 
#forms.py 
# -*- coding: utf-8 -*-
from django import forms

from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Div, Submit, HTML, Button, Row, Field
from crispy_forms.bootstrap import AppendedText, PrependedText, FormActions


class MessageForm(forms.Form):
    text_input = forms.CharField()

    textarea = forms.CharField(
        widget = forms.Textarea(),
    )

    radio_buttons = forms.ChoiceField(
        choices = (
            ('option_one', "Option one is this and that be sure to include why it's great"), 
            ('option_two', "Option two can is something else and selecting it will deselect option one")
        ),
        widget = forms.RadioSelect,
        initial = 'option_two',
    )

    checkboxes = forms.MultipleChoiceField(
        choices = (
            ('option_one', "Option one is this and that be sure to include why it's great"), 
            ('option_two', 'Option two can also be checked and included in form results'),
            ('option_three', 'Option three can yes, you guessed it also be checked and included in form results')
        ),
        initial = 'option_one',
        widget = forms.CheckboxSelectMultiple,
        help_text = "<strong>Note:</strong> Labels surround all the options for much larger click areas and a more usable form.",
    )

    appended_text = forms.CharField(
        help_text = "Here's more help text"
    )

    prepended_text = forms.CharField()

    prepended_text_two = forms.CharField()

    multicolon_select = forms.MultipleChoiceField(
        choices = (('1', '1'), ('2', '2'), ('3', '3'), ('4', '4'), ('5', '5')),
    )

    # Uni-form
    helper = FormHelper()
    helper.form_class = 'form-horizontal'
    helper.layout = Layout(
        Field('text_input', css_class='input-xlarge'),
        Field('textarea', rows="3", css_class='input-xlarge'),
        'radio_buttons',
        Field('checkboxes', style="background: #FAFAFA; padding: 10px;"),
        AppendedText('appended_text', '.00'),
        PrependedText('prepended_text', '<input type="checkbox" checked="checked" value="" id="" name="">', active=True),
        PrependedText('prepended_text_two', '@'),
        'multicolon_select',
        FormActions(
            Submit('save_changes', 'Save changes', css_class="btn-primary"),
            HTML('<a class="btn btn-default" href="/">Cancel</a>'),
        )
    )
          
#settings.py 
CRISPY_TEMPLATE_PACK = 'bootstrap3'

INSTALLED_APPS = (
    ...
    'crispy_forms',
)

#views.py 
from django.shortcuts import render
from .forms import MessageForm
from django.http import JsonResponse


import logging
log = logging.getLogger(__name__)

    
def index(request):
    # if this is a POST request we need to process the form data
    if request.method == 'POST':      
        # create a form instance and populate it with data from the request:
        form = MessageForm(request.POST)
        log.debug("POST " + str(request.POST))
        # check whether it's valid:
        if form.is_valid():            
            #form.save(commit=True)           
            return JsonResponse(form.cleaned_data)
    # if a GET (or any other method) we'll create a blank form
    else:
        form = MessageForm()
    return render(request, 'index.html', {'form': form, 'cancel': 'index'})
    
    
#base.html 
{% load crispy_forms_tags %}
<!DOCTYPE html>
<html>
  <head>
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" />
  </head>
  <body>
    <div class="container">
      <div class="row">
        {% block content %}{% endblock %}
      </div>
    </div>
  </body>
</html>

#index.html
{% extends 'base.html' %}
{% load crispy_forms_tags %}

{% block content %}
   {% crispy form %}
{% endblock %}



###With model form 
class ExampleModelForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(ExampleModelForm, self).__init__(*args, **kwargs)

        # If you pass FormHelper constructor a form instance
        # It builds a default layout with all its fields
        self.helper = FormHelper(self)

        # You can dynamically adjust your layout
        self.helper.layout.append(Submit('save', 'save'))

    class Meta:
        model = ExampleModel
        
#in  view:
form = ExampleModelForm()
return render(request, 'index.html', {'form': ExampleModelForm()})

#In  template:
{% load crispy_forms_tags %}
{% crispy form %}





###Quick Django Forms 
#REF:  https://docs.djangoproject.com/en/2.0/ref/forms/fields/

forms.Field(required=True, widget=None, label=None, initial=None,
                 help_text='', error_messages=None, show_hidden_initial=False,
                 validators=(), localize=False, disabled=False, label_suffix=None)
#fields 
class CharField(max_length=None, min_length=None, strip=True, empty_value='', **kwargs)
class IntegerField(max_value=None, min_value=None, **kwargs)
class FloatField(max_value=None, min_value=None, **kwargs) #Super IntegerField
class DecimalField(max_value=None, min_value=None, max_digits=None, decimal_places=None, **kwargs)#Super IntegerField
class BaseTemporalField(input_formats=None, **kwargs)
class DateField(BaseTemporalField)
class TimeField(BaseTemporalField)
class DateTimeField(BaseTemporalField)
class DurationField(Field)
class RegexField(max_length=None, min_length=None, strip=True, empty_value='',regex, **kwargs)#Super CharField
class EmailField(CharField)
class FileField(max_length=None, allow_empty_file=False, **kwargs)
class ImageField(FileField)
class URLField(CharField)
class BooleanField(Field):
class NullBooleanField(BooleanField)
class ChoiceField(choices=(), **kwargs)
class TypedChoiceField(coerce=lambda val: val, empty_value='', **kwargs)#Super ChoiceField
class MultipleChoiceField(ChoiceField):
class TypedMultipleChoiceField(coerce=lambda val: val, **kwargs): #Super MultipleChoiceField
class ComboField(fields, **kwargs)
class MultiValueField(fields, *, require_all_fields=True, **kwargs)
class FilePathField(path, *, match=None, recursive=False, allow_files=True,allow_folders=False, **kwargs)
class SplitDateTimeField(input_date_formats=None, input_time_formats=None, **kwargs) #Super MultiValueField
class GenericIPAddressField(protocol='both', unpack_ipv4=False, **kwargs) #Super CharField
class SlugField(allow_unicode=False, **kwargs):
class UUIDField(CharField)#Super CharField       
        
        
        
#Create a form from forms.XyzField, XyzField takes many parameters
#further attributes can be given by 'attrs' and Each field has one default Widget to display in html form
#Example 
from django import forms

class NameForm(forms.Form):
    your_name = forms.CharField(label='Your name', max_length=100, attrs={'class': 'myClass'})

#is equivalent to below , note no <form> tags, or a submit button
#Note automatic id and 'name' is created from variable name 
    <label for="your_name">Your name: </label>
    <input id="your_name" type="text" name="your_name" maxlength="100" required />


##Bound and unbound form instances - Field.is_bound attribute
� An unbound form has no data associated with it. 
  When rendered to the user, it will be empty or will contain default values.
  #Example 
  form = BookForm() #unbound 
� A bound form has submitted data , (eg from POST data)
  and hence can be used to tell if that data is valid. 
  If an invalid bound form is rendered, it can include inline error messages 
  check with form.is_bound 
  Note form.initial, used  to declare the initial value of form fields at runtime, where no validation is triggered 
  Form.has_changed() shows whether any form data is changed or not and Form.changed_data gives the changed data   
  Form.fields gives all Fields in the form 
  #example 
  form = BookForm(request.POST)       #create bound form 

  
  
##Form rendering options - other than {{form}}
#provide the surrounding <table> or <ul>
�{{ form.as_table }}    will render them as table cells wrapped in <tr> tags
�{{ form.as_p }}        will render them wrapped in <p> tags
�{{ form.as_ul }}       will render them wrapped in <li> tags


##Rendering fields manually
#Each field is available as an attribute of the form using {{ form.name_of_field }}
#label ID is available as {{ form.name_of_field.id_for_label }}
#Any error in field is available as {{ form.name_of_field.errors }}
#{{ form.non_field_errors }} contains all nonfield form error 

#Example with four fields with var name = subject, message, sender, cc_myself 
{{ form.non_field_errors }}
<div class="fieldWrapper">
    {{ form.subject.errors }}
    <label for="{{ form.subject.id_for_label }}">Email subject:</label>
    {{ form.subject }}
</div>
<div class="fieldWrapper">
    {{ form.message.errors }}
    <label for="{{ form.message.id_for_label }}">Your message:</label>
    {{ form.message }}
</div>
<div class="fieldWrapper">
    {{ form.sender.errors }}
    <label for="{{ form.sender.id_for_label }}">Your email address:</label>
    {{ form.sender }}
</div>
<div class="fieldWrapper">
    {{ form.cc_myself.errors }}
    <label for="{{ form.cc_myself.id_for_label }}">CC yourself?</label>
    {{ form.cc_myself }}
</div>


#Or  <label> elements can also be generated using the label_tag()
<div class="fieldWrapper">
    {{ form.subject.errors }}
    {{ form.subject.label_tag }}
    {{ form.subject }}
</div>


#Rendering form error messages
#{{ form.sender.errors }} would look as below 
<ul class="errorlist">
    <li>Sender is required.</li>
</ul>

#Or iterate manually
{% if form.sender.errors %}
    <ol>
    {% for error in form.sender.errors %}
        <li><strong>{{ error|escape }}</strong></li>
    {% endfor %}
    </ol>
{% endif %}


#{{ form.non_field_errors }} would look like:
<ul class="errorlist nonfield">
    <li>Generic validation error</li>
</ul>


##Looping over the form�s fields - {% for %} loop
{% for field in form %}
    <div class="fieldWrapper">
        {{ field.errors }}
        {{ field.label_tag }} {{ field }}
        {% if field.help_text %}
        <p class="help">{{ field.help_text|safe }}</p>
        {% endif %}
    </div>
{% endfor %}


##Useful attributes on {{ field }} 
{{ field.label }}           The label of the field, e.g. forms.CharField(label='Your name')
{{ field.label_tag }}       The field�s label wrapped in the appropriate HTML <label> tag. 

{{ field.id_for_label }}    The ID that will be used for this field (id_email , <label for="id_email">Email address:</label>). 
{{ field.value }}           The value of the field. e.g someone@example.com.
{{ field.html_name }}       The name of the field that will be used in the input element�s name field. 
                            This takes the form prefix into account, if it has been set.
{{ field.help_text }}       Any help text that has been associated with the field.
{{ field.errors }}          Outputs a <ul class="errorlist"> containing any validation errors corresponding to this field. You can customize the presentation of the errors with a {% for error in field.errors %} loop. In this case, each object in the loop is a simple string containing the error message.
{{field.as_hidden }}        Outputs as hidden 
{{ field.is_hidden }}       This attribute is True if the form field is a hidden field and False otherwise.
                             {% if field.is_hidden %}
                               {# Do something special #}
                             {% endif %}
{{ field.field }}           The Field instance from the form class that this BoundField wraps. 
                            You can use it to access Field attributes, 
                            e.g. {{ char_field.field.max_length }}.


##Note to create hidden input 
forms.CharField(widget = forms.HiddenInput(), required = False)
#or make 
show_hidden_initial=True

#For normal form 
class MyForm(forms.Form):
    slug = forms.CharField(widget=forms.HiddenInput())

class Myform(forms.Form):
    def __init__(self, *args, **kwargs):
        super(Myform, self).__init__(*args, **kwargs)
        self.fields['slug'].widget = forms.HiddenInput()    
#or 
class MyModelForm(forms.ModelForm):
    class Meta:
        model = TagStatus
        fields = ('slug', 'ext')
        widgets = {'slug': forms.HiddenInput()}



                        
                            
##Looping over hidden and visible fields- hidden_fields() and visible_fields(). 
{# Include the hidden fields #}
{% for hidden in form.hidden_fields %}
{{ hidden }}
{% endfor %}
{# Include the visible fields #}
{% for field in form.visible_fields %}
    <div class="fieldWrapper">
        {{ field.errors }}
        {{ field.label_tag }} {{ field }}
    </div>
{% endfor %}




##Forms - Using validators   
#Django�s form (and model) fields support use of simple utility functions and classes known as validators. 
#A validator is  a callable object or function that takes a value and  returns nothing if the value is valid 
#or raises a ValidationError if not.
from django.core import validators
from django.forms import CharField

class SlugField(CharField):
    default_validators = [validators.validate_slug]


slug = forms.SlugField()
#is equivalent to:
slug = forms.CharField(validators=[validators.validate_slug])

#Userdefined 
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _

def validate_even(value):
    if value % 2 != 0:
        raise ValidationError(
            _('%(value)s is not an even number'),
            params={'value': value},
        )

#usage 
from django.db import models

class MyModel(models.Model):
    even_field = models.IntegerField(validators=[validate_even])

from django import forms

class MyForm(forms.Form):
    even_field = forms.IntegerField(validators=[validate_even])



#Standard Validator ,django.core.validators , each has __call__(self, value), so can be used as instance
class RegexValidator(regex=None, message=None, code=None, inverse_match=None, flags=0)
    message   
        The error message used by ValidationError if validation fails. Defaults to "Enter a valid value".
    code   
        The error code used by ValidationError if validation fails. Defaults to "invalid".
    inverse_match   
        The match mode for regex. Defaults to False.
    flags   
        The flags used when compiling the regular expression string regex. If regex is a pre-compiled regular expression, and flags is overridden, TypeError is raised. Defaults to 0.
class EmailValidator(message=None, code=None, whitelist=None)
class URLValidator(schemes=None, regex=None, message=None, code=None)
class MaxValueValidator(max_value, message=None)
    Raises a ValidationError with a code of 'max_value' if value is greater than max_value.
class MinValueValidator(min_value, message=None)
    Raises a ValidationError with a code of 'min_value' if value is less than min_value.
class MaxLengthValidator(max_length, message=None)
    Raises a ValidationError with a code of 'max_length' if the length of value is greater than max_length.
class MinLengthValidator(min_length, message=None)
    Raises a ValidationError with a code of 'min_length' if the length of value is less than min_length.
class DecimalValidator(max_digits, decimal_places)
class FileExtensionValidator(allowed_extensions, message, code)
class ProhibitNullCharactersValidator(message=None, code=None)
#Methods 
validate_email   
    An EmailValidator instance without any customizations.
validate_slug   
    A RegexValidator instance that ensures a value consists of only letters, numbers, underscores or hyphens.
validate_unicode_slug   
    A RegexValidator instance that ensures a value consists of only Unicode letters, numbers, underscores, or hyphens.
validate_ipv4_address      
    A RegexValidator instance that ensures a value looks like an IPv4 address.
validate_ipv6_address      
    Uses django.utils.ipv6 to check the validity of an IPv6 address.
validate_ipv46_address      
    Uses both validate_ipv4_address and validate_ipv6_address to ensure a value is either a valid IPv4 or IPv6 address.
validate_comma_separated_integer_list   
    A RegexValidator instance that ensures a value is a comma-separated list of integers.
int_list_validator(sep=', ', message=None, code='invalid', allow_negative=False)      
    Returns a RegexValidator instance that ensures a string consists of integers separated by sep. It allows negative integers when allow_negative is True.
validate_image_file_extension   
    Uses Pillow to ensure that value.name (value is a File) has a valid image extension.



           
           
###ModelForm - form created directly from model fields 

#Example 
from django.db import models
from django.forms import ModelForm

TITLE_CHOICES = (
    ('MR', 'Mr.'),
    ('MRS', 'Mrs.'),
    ('MS', 'Ms.'),
)

class Author(models.Model):
    name = models.CharField(max_length=100)
    title = models.CharField(max_length=3, choices=TITLE_CHOICES)
    birth_date = models.DateField(blank=True, null=True)

    def __str__(self):
        return self.name

class Book(models.Model):
    name = models.CharField(max_length=100)
    authors = models.ManyToManyField(Author)

class AuthorForm(ModelForm):
    class Meta:
        model = Author
        fields = ['name', 'title', 'birth_date']

class BookForm(ModelForm):
    class Meta:
        model = Book
        fields = ['name', 'authors']

#Usage 
>>> form = AuthorForm()

# Note forms.Form has 'data' variable, where as ModelForm has 'instance' variable 
#Otherwise, ModelForm has all varaibles of forms.Form eg .errors, .cleaned_data, etc 
>>> author = Author.objects.get(pk=1)
>>> form = AuthorForm(instance=author)

#Based on above AuthorForm, BookForm, Django created below autogenerated forms 

from django import forms

class AuthorForm(forms.Form):
    name = forms.CharField(max_length=100)
    title = forms.CharField(
        max_length=3,
        widget=forms.Select(choices=TITLE_CHOICES),
    )
    birth_date = forms.DateField(required=False)

class BookForm(forms.Form):
    name = forms.CharField(max_length=100)
    authors = forms.ModelMultipleChoiceField(queryset=Author.objects.all())


##Model field,models.       Form field, forms.
AutoField                   Not represented in the form 
BigAutoField                Not represented in the form 
BigIntegerField             IntegerField with min_value set to -9223372036854775808 and max_value set to 9223372036854775807. 
BooleanField                BooleanField 
CharField                   CharField with max_length set to the model field�s max_length and empty_value set to None if null=True. 
DateField                   DateField 
DateTimeField               DateTimeField 
DecimalField                DecimalField 
EmailField                  EmailField 
FileField                   FileField 
FilePathField               FilePathField 
FloatField                  FloatField 
ForeignKey                  ModelChoiceField 
ImageField                  ImageField 
IntegerField                IntegerField 
IPAddressField              IPAddressField 
GenericIPAddressField       GenericIPAddressField 
ManyToManyField             ModelMultipleChoiceField 
NullBooleanField            NullBooleanField 
PositiveIntegerField        IntegerField 
PositiveSmallIntegerField   IntegerField 
SlugField                   SlugField 
SmallIntegerField           IntegerField 
TextField                   CharField with widget=forms.Textarea 
TimeField                   TimeField 
URLField                    URLField 

#Note ForeignKey and ManyToManyField model field types are special cases:
1.ForeignKey is represented by django.forms.ModelChoiceField, 
  which is a ChoiceField whose choices are a model QuerySet.
2.ManyToManyField is represented by django.forms.ModelMultipleChoiceField, 
  which is a MultipleChoiceField whose choices are a model QuerySet.

#In addition, each generated form field has attributes set as follows:
1.If the model field has blank=True, then required=False on the form field. Otherwise, required=True.
2.The form field�s label is set to the verbose_name of the model field, with the first character capitalized.
3.The form field�s help_text is set to the help_text of the model field.
4.If the model field has choices set, then the form field�s widget will be set to Select, 
  with choices coming from the model field�s choices. 
  The choices will normally include the blank choice which is selected by default. 
  If the field is required, this forces the user to make a selection. 
  The blank choice will not be included if the model field has blank=False and an explicit default value (the default value will be initially selected instead).
     
        
        
##Validation on a ModelForm
#There are two main steps involved in validating a ModelForm
#form.is_valid() would call below methods and then form.cleaned_data dict is available 
1.Validating the form
  Triggered by form.is_valid() or accessing form.errors 
  Does form level validation , calls below methods just like model validation 
  After this form.cleaned_data would contains all validated data 
  where form.data contains data before validation 
    Form.clean_fields(exclude=None)
        calls each field.clean()
    Form.clean()
        Override this to handle any custom validation 
2.Validating the model instance
  Once step1 is done, Django calls Model.Model.full_clean(exclude=None, validate_unique=True)
  This method calls sequentially and raises a ValidationError 
  that has a message_dict attribute containing errors from all three stages.
    Model.clean_fields(exclude=None)
        This method will validate all fields on your model
        Calls each field's 
            Field.clean(value, model_instance)
                """Convert the value's type and run validation. Validation errors
                from to_python() and validate() are propagated. Return the correct
                value if no error is raised.
                """
                value = self.to_python(value)
                self.validate(value, model_instance)
                self.run_validators(value)
                return value
    Model.clean()
        This method should be used to provide custom model validation, 
        and to modify attributes if required 
    Model.validate_unique(exclude=None)
        This method is similar to clean_fields(), 
        but validates all uniqueness constraints on model instead of individual field values
        
3.Note: Error messages defined at the form field level(django.forms.Field.error_messages) 
  or at the form Meta level always take precedence over the error messages defined at the model field level(django.db.models.Field.error_messages)
  Error messages defined on model fields are only used when the ValidationError is raised 
  during the model validation step and no corresponding error messages are defined at the form level.
  To override the error messages from NON_FIELD_ERRORS raised by model validation 
  by adding the NON_FIELD_ERRORS key to the error_messages dictionary of the ModelForm�s inner Meta class:
    from django.core.exceptions import NON_FIELD_ERRORS
    from django.forms import ModelForm

    class ArticleForm(ModelForm):
        class Meta:
            error_messages = {
                NON_FIELD_ERRORS: {
                    'unique_together': "%(model_name)s's %(field_labels)s are not unique.",
                }
            }



  
##ModelForm - ModelForm.save() 
#ModelForm works exactly the same way as any other forms form. 
#For example, the is_valid() method is used to check for validity, 
#the is_multipart() method is used to determine whether a form requires multipart file upload 
#(and hence whether request.FILES must be passed to the form), 

#Difference of ModelForm.save(commit=True) compared to Form.save()
#This method creates and saves a database object from the data bound to the form. 
#Note that if the form hasn�t been validated, calling save() would check form.errors, if False=, raises ValidationError 
#A subclass of ModelForm can accept an existing model instance as the keyword argument 'instance'; 
#if this is supplied, save() will update that instance.
#If it�s not supplied, save() will create a new instance of the specified model:


from myapp.models import Article
from myapp.forms import ArticleForm

# Create a form instance from POST data.
f = ArticleForm(request.POST)

# Save a new Article object from the form's data.
>>> new_article = f.save()

# Create a form to edit an existing Article, but use
# POST data to populate the form.
a = Article.objects.get(pk=1)
f = ArticleForm(request.POST, instance=a)
f.save()



###Form handling with class-based views
#takes Form class while creating 
#REF: https://docs.djangoproject.com/en/2.0/ref/class-based-views/generic-editing/

#Reference of class based Views     
#Check attributes - https://ccbv.co.uk/projects/Django/2.0/django.views.generic.edit/FormView/

#By default , template name is <<app_name>>/templates/<<app_name>>/<<model>>_<<template_name_suffix>>.html 
#or value given in 'template_name' 
#In template , access if single object by 'object' or list of object by 'object_list'
#Populate more context by overriding 'get_context_data(...)' with calling super inside that 
#or populating 'extra_context' by a dict of context objects 
#Customize query by overriding 'get_queryset(...)' or by defining 'queryset'

#Date based views use paginator exactly like ListView, use page_obj as Paginator object and object_list/date_list for queryset 

Editing views 
   FormView
   CreateView
   UpdateView
   DeleteView

Date-based views
   ArchiveIndexView
   YearArchiveView
   MonthArchiveView
   WeekArchiveView
   DayArchiveView
   TodayArchiveView
   DateDetailView


class django.views.generic.edit.FormView   
    A view that displays a form. On error, redisplays the form with validation errors; 
    on success, redirects to a new URL, given by success_url
    Ancestors (MRO)
        �django.views.generic.base.TemplateResponseMixin
        �django.views.generic.edit.BaseFormView
        �django.views.generic.edit.FormMixin
        �django.views.generic.edit.ProcessFormView
        �django.views.generic.base.View
    Attributes  Defined in
        content_type = None   TemplateResponseMixin  
        extra_context = None   ContextMixin  
        form_class = None   FormMixin  
        http_method_names = ['get', 'post', 'put', 'patch', 'delete', 'head', 'options', 'trace']   View  
        initial = {}   FormMixin  
        prefix = None   FormMixin  
        response_class = <class 'django.template.response.TemplateResponse'>   TemplateResponseMixin  
        success_url = None   FormMixin  
        template_engine = None   TemplateResponseMixin  
        template_name = None   TemplateResponseMixin  
    #Various Data 
    View creation extra init params 
        Use     def as_view(cls, **initkwargs)
        initkwargs is key=value keyword arg and are available as self.key=value 
    Request Data 
        self.request
    context data 
        by default from def get_context_data(self, **kwargs)
            kwargs['form'] = self.get_form()
            kwargs['view'] = self
            kwargs.update(self.extra_context)
    Form creation extra init params 
        Override def get_form_kwargs(self)
        default is given below 
        def get_form_kwargs(self):
            """Return the keyword arguments for instantiating the form."""
            kwargs = {
                'initial': self.get_initial(),
                'prefix': self.get_prefix(),
            }
            if self.request.method in ('POST', 'PUT'):
                kwargs.update({
                    'data': self.request.POST,
                    'files': self.request.FILES,
                })
            return kwargs
    Extra work if form is valid or form is invalid 
        override below     
            def form_invalid(self, form):
                """If the form is invalid, render the invalid form."""
                return self.render_to_response(self.get_context_data(form=form))
            def form_valid(self, form):
                """If the form is valid, redirect to the supplied URL."""
                return HttpResponseRedirect(self.get_success_url())
        These are called in POST method 
        def post(self, request, *args, **kwargs):
            """
            Handle POST requests: instantiate a form instance with the passed
            POST variables and then check if it's valid.
            """
            form = self.get_form()
            if form.is_valid():
                return self.form_valid(form)
            else:
                return self.form_invalid(form)
     


#Form processing generally has 3 paths:
1.Initial GET (blank or prepopulated form)
2.POST with invalid data (typically redisplay form with errors)
3.POST with valid data (process the data and typically redirect)

#forms.py

from django import forms

class ContactForm(forms.Form):
    name = forms.CharField()
    message = forms.CharField(widget=forms.Textarea)

    def send_email(self):
        # send email using the self.cleaned_data dictionary
        pass


#Check attributes - https://ccbv.co.uk/projects/Django/2.0/django.views.generic.edit/FormView/
#FormView inherits TemplateResponseMixin so template_name can be used here.
#The default implementation for form_valid() simply redirects to the success_url.
#views.py
from myapp.forms import ContactForm
from django.views.generic.edit import FormView

class ContactView(FormView):
    template_name = 'contact.html'
    form_class = ContactForm
    success_url = '/thanks/'

    def form_valid(self, form):
        # This method is called when valid form data has been POSTed.
        # It should return an HttpResponse.
        form.send_email()
        return super().form_valid(form)
        
#Example myapp/contact.html:
{% load crispy_forms_tags %}
<form method="post">
    {% csrf_token %}
    {{ form.as_p }}
    {{ form | crispy }}
    <input type="submit" value="Send message" />
</form>
#Urls.py 
path('form/', views.ContactView.as_view(), name='index'),


##Model forms 
CreateView
    Creating new instance of model 
DeleteView
    Deleting an existing instance, either int:pk in URL or get_object() is required 
UpdateView
    Deleting an existing instance, either int:pk in URL or get_object() is required 
#Check attributes - https://ccbv.co.uk/projects/Django/2.0/django.views.generic.edit/FormView/
#These generic views will automatically create a ModelForm
1.If the model attribute is given, that model class will be used.
2.If get_object() returns an object, the class of that object and that instance will be used further 
3.If a queryset is given, the model for that queryset will be used.
4.If URL has int:pk field, that pk is taken as the object 
5.Modelform views provide a form_valid(self, form) implementation that saves the model automatically. 
  Override this if any custom work is needed 
  Inside this function, access model object from 'form.instance'
6.No need to provide a success_url for CreateView or UpdateView 
  they will use get_absolute_url() on the model object if available.
7.To use a custom ModelForm (for instance to add extra validation) set form_class on view.
  and specify the model
8.These views inherit SingleObjectTemplateResponseMixin which uses template_name_suffix to construct the template_name based on the model.
  For Example, 
    CreateView and UpdateView use myapp/author_form.html
    DeleteView uses myapp/author_confirm_delete.html  
#models.py  
from django.db import models
from django.urls import reverse

class Author(models.Model):
    name = models.CharField(max_length=200)

    def get_absolute_url(self):
        return reverse('author-detail', kwargs={'pk': self.pk})

#views.py
from django.urls import reverse_lazy
from django.views.generic.edit import CreateView, DeleteView, UpdateView
from myapp.models import Author

class AuthorCreate(CreateView):
    model = Author
    fields = ['name']

class AuthorUpdate(UpdateView):
    model = Author
    fields = ['name']

class AuthorDelete(DeleteView):
    model = Author
    success_url = reverse_lazy('author-list') #use reverse_lazy() here, not just reverse() as the urls are not loaded when the file is imported
#urls.py
from django.urls import path
from myapp.views import AuthorCreate, AuthorDelete, AuthorUpdate

urlpatterns = [
    # ...
    path('author/add/', AuthorCreate.as_view(), name='author-add'),
    path('author/<int:pk>/', AuthorUpdate.as_view(), name='author-update'),
    path('author/<int:pk>/delete/', AuthorDelete.as_view(), name='author-delete'),
]

##Models and request.user   
#To track the user that created an object using a CreateView, use a custom ModelForm to do this. 
#First, add the foreign key relation to the model:
#models.py

from django.contrib.auth.models import User
from django.db import models

class Author(models.Model):
    name = models.CharField(max_length=200)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)

    # ...

#don�t include created_by in the list of fields to edit, and override form_valid() to add the user:
#views.py

from django.views.generic.edit import CreateView
from myapp.models import Author

#@login_required() is generally required to restrict this usages 
class AuthorCreate(CreateView):
    model = Author
    fields = ['name']

    def form_valid(self, form):
        form.instance.created_by = self.request.user
        return super().form_valid(form)

  
  
  
  
  
    
###*** Django -chapter-5 
'''
    Django authetication
    how to handle signup form and handle users 
    upload a file 
    download a file 
    send a mail 
'''

###STEP 1: Then create a application, inside examplesite

$ python manage.py startapp advanced 

#examplesite/urls.py 
urlpatterns = [
   #...
    url(r'^advanced/' , include('advanced.urls')), 
]


###STEP 2: Sending mail 
#Turn on less secure APPs
# https://www.google.com/settings/security/lesssecureapps
#Or use OAuth separately 
#http://stackoverflow.com/questions/11445523/python-smtplib-is-sending-mail-via-gmail-using-oauth2-possible
#https://developers.google.com/api-client-library/python/guide/aaa_oauth

django.core.mail.send_mail(subject, message, from_email, recipient_list, fail_silently=False, 
        auth_user=None, auth_password=None, connection=None, html_message=None)

django.core.mail.send_mass_mail(datatuple, fail_silently=False, auth_user=None, auth_password=None, connection=None)[source]�
    send_mass_mail() is intended to handle mass emailing.
    datatuple is a tuple in which each element is in this format:
        (subject, message, from_email, recipient_list)
    The return value will be the number of successfully delivered messages.

django.core.mail.mail_admins(subject, message, fail_silently=False, connection=None, html_message=None)[source]�
    django.core.mail.mail_admins() is a shortcut for sending an email to the site admins, 
    as defined in the ADMINS setting.
    mail_admins() prefixes the subject with the value of the EMAIL_SUBJECT_PREFIX setting, 
    which is "[Django] " by default.
    The �From:� header of the email will be the value of the SERVER_EMAIL setting.
    If html_message is provided, the resulting email will be a multipart/alternative email with message as the text/plain content type and html_message as the text/html content type.
django.core.mail.mail_managers(subject, message, fail_silently=False, connection=None, html_message=None)[source]�
    django.core.mail.mail_managers() is just like mail_admins(), 
    except it sends an email to the site managers, as defined in the MANAGERS setting.


#examplesite/settings.py 
#for gmail server 
#EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
#for console output 
EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_HOST_USER = 'ndas1971@gmail.com'
EMAIL_HOST_PASSWORD = 'abczxy'  #give correct password
EMAIL_USE_TLS = True

#advanced/urls.py 
from . import views
urlpatterns = [        
    url(r'^contact/',  views.contact, name="contact"),  
    url(r'^thanks/',  views.thanks, name='thanks'),   
    ]
    
#advanced/forms.py 
from django import forms

class ContactForm(forms.Form):
    subject = forms.CharField(max_length=100)
    message = forms.CharField(widget=forms.Textarea)
    sender = forms.EmailField()
    cc_myself = forms.BooleanField(required=False)
    
    
#advanced/views.py 
from django.shortcuts import render
from django.core.mail import send_mail
from django.core.urlresolvers import reverse
from django.http import HttpResponseRedirect


from .forms import *

#This can be simplified via FormView
def contact(request):    
    # if this is a POST request we need to process the form data
    if request.method == 'POST':        
        # create a form instance and populate it with data from the request:
        form = ContactForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:            
            subject = form.cleaned_data['subject']
            message = form.cleaned_data['message']
            sender = form.cleaned_data['sender']
            cc_myself = form.cleaned_data['cc_myself']

            recipients = ['ndas1971@gmail.com']
            if cc_myself:
                recipients.append(sender)            
            send_mail(subject, message, sender, recipients )
            return HttpResponseRedirect(reverse('thanks'))
    # if a GET (or any other method) we'll create a blank form
    else:
        form = ContactForm()
    return render(request, 'contact.html', {'form': form})
    
def thanks(request):
    return HttpResponse("email sent")

#advanced/templates/contact.html 
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Contact form</title>	
        <style type="text/css">
        </style>   
	</head>

	<body>
        <form action="{% url 'contact' %}" method="post">
            {% csrf_token %}
            <table class="gridtable">
                {{ form.as_table }}
            </table >
            <input type="submit" value="Submit" />
        </form>
	</body>

</html>     


###STEP 3:Create the Database tables now
$ python manage.py makemigrations advanced
$ python manage.py migrate

#check
python manage.py runserver 8080
# http://127.0.0.1:8080/advanced/contact







###Django - Password Management 
#The password attribute of a User object is a string in this format:
<algorithm>$<iterations>$<salt>$<hash>
#Django chooses the algorithm to use by using PASSWORD_HASHERS[0] 
#Default 
PASSWORD_HASHERS = [
    'django.contrib.auth.hashers.PBKDF2PasswordHasher',
    'django.contrib.auth.hashers.PBKDF2SHA1PasswordHasher',
    'django.contrib.auth.hashers.Argon2PasswordHasher',
    'django.contrib.auth.hashers.BCryptSHA256PasswordHasher',
    'django.contrib.auth.hashers.BCryptPasswordHasher',
]
#Argon2 is the winner of the 2015 Password Hashing Competition
#django.contrib.auth.hashers.Argon2PasswordHasher make this first entry to use this 
$ pip install django[argon2]

##Password validation
#Validation is controlled by the AUTH_PASSWORD_VALIDATORS setting
UTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
        'OPTIONS': {
            'min_length': 9,
        }
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]
# django.contrib.auth.password_validation
class MinimumLengthValidator(min_length=8)
    Validates whether the password meets a minimum length. 
    The minimum length can be customized with the min_length parameter.

class UserAttributeSimilarityValidator(user_attributes=DEFAULT_USER_ATTRIBUTES, max_similarity=0.7)
    Validates whether the password is sufficiently different from certain attributes of the user.
    The user_attributes parameter should be an iterable of names of user attributes to compare to. 
    If this argument is not provided, the default is used: 'username', 'first_name', 'last_name', 'email'. 
    Attributes that don�t exist are ignored.
    The minimum similarity of a rejected password can be set on a scale of 0 to 1 
    with the max_similarity parameter. 
    A setting of 0 rejects all passwords, 
    whereas a setting of 1 rejects only passwords that are identical to an attribute�s value.
class CommonPasswordValidator(password_list_path=DEFAULT_PASSWORD_LIST_PATH)
    Validates whether the password is not a common password. 
    This converts the password to lowercase (to do a case-insensitive comparison) 
    and checks it against a list of 1000 common password created by Mark Burnett.
    The password_list_path can be set to the path of a custom file of common passwords. 
    This file should contain one lowercase password per line and may be plain text or gzipped.
class NumericPasswordValidator
    Validates whether the password is not entirely numeric.
#methods 
validate_password(password, user=None, password_validators=None)
    Validates a password. If all validators find the password valid, returns None. 
    If one or more validators reject the password, raises a ValidationError with all the error messages from the validators.
    The user object is optional: if it�s not provided, some validators may not be able to perform any validation and will accept any password.

password_changed(password, user=None, password_validators=None)
    Informs all validators that the password has been changed. 
    This can be used by validators such as one that prevents password reuse. 
    This should be called once the password has been successfully changed.
    For subclasses of AbstractBaseUser, the password field will be marked as �dirty� when calling set_password() which triggers a call to password_changed() after the user is saved.

password_validators_help_texts(password_validators=None)
    Returns a list of the help texts of all validators. These explain the password requirements to the user.

password_validators_help_text_html(password_validators=None)
    Returns an HTML string with all help texts in an <ul>. 
    This is helpful when adding password validation to forms, as you can pass the output directly to the help_text parameter of a form field.

get_password_validators(validator_config)
    Get all Password 
    

###STEP 4:Upload/download, with User authentication 

#examplesite/settings.py 

#Session based login, hence set below to expire 
SESSION_EXPIRE_AT_BROWSER_CLOSE = True    # everytime browser is closed, session is expired, ELSE persistant session 
SESSION_COOKIE_AGE  = 5*60 # in seconds 


# Absolute filesystem path to the directory that will hold user-uploaded files.
# Example: "/home/media/media.lawrence.com/media/"
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')

# URL that handles the media served from MEDIA_ROOT. Make sure to use a
# trailing slash. so below URLs are actually  from above MEDIA_ROOT
# Examples: "http://media.lawrence.com/media/", "http://example.com/media/"
MEDIA_URL = '/media/'

#advanced/urls.py 
#Using auth_views
from django.contrib.auth import views as auth_views
from . import views
urlpatterns = [            
    url(r'^signup/',  views.signup, name = 'signup'),  
    url(r'^login/',  auth_views.login,  {'template_name': 'registration/login.html'}, name = 'login'),  
    url(r'^logout/',  auth_views.logout,{'template_name': 'registration/logout.html'}, name = 'logout'), 
    
    url(r'^list/$', views.document_list, name='document-lists'), #this contains upload 
    url(r'^documents/(?P<pk>\d+)/$', views.download , name = 'documents-download'),
  ] 
  
#advanced/models.py 
from django.db import models

class Document(models.Model):
    docfile = models.FileField(upload_to='documents/%Y/%m/%d')   #auto Uploaded to MEDIA_ROOT
    
    
#advanced/forms.py 
from django import forms
from django.contrib.auth.models import User

#Used for model 
class DocumentForm(forms.Form):
    docfile = forms.FileField( label='Select a file' )  #<input type="file" name="docfile">
    
    
##Signup form
from django.contrib.auth.password_validation  import password_validators_help_text_html, validate_password

class SignupForm(forms.Form):
    user = forms.CharField(max_length=20)
    email = forms.EmailField()
    password = forms.CharField(widget=forms.PasswordInput, help_text= password_validators_help_text_html())
    again_password = forms.CharField(widget=forms.PasswordInput)
    def clean(self):
        cleaned_data = super(SignupForm, self).clean()
        user = cleaned_data.get("user")
        email = cleaned_data.get("email")
        password = cleaned_data.get("password")
        user_obj = User(username=user, password=password, email=email)
        validate_password(password, user_obj)
        if self.user_exists(user): 
            self.add_error('user', "User exists!!")
        
    def user_exists(self, username):
        user_count = User.objects.filter(username=username).count()
        if user_count == 0:
            return False
        return True
        
#advanced/views.py 
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render

from django.core.urlresolvers import reverse
from django.conf import settings
from django.http import StreamingHttpResponse 


from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User


import mimetypes 
import os.path

from .forms import *
from .models import * 

    
@login_required(login_url='/advanced/login/')  # beginning / is must, reverse('login') -> gives error!! 
def document_list(request):
    # Handle file upload
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            newdoc = Document(docfile = form.cleaned_data['docfile'])  #OR docfile=request.FILES['docfile'])
            newdoc.save()
            # Redirect to the document list after POST
            return HttpResponseRedirect(reverse('document-lists'))
    else:
        form = DocumentForm() # A empty, unbound form

    # Load documents for the list page
    documents = Document.objects.all()
    # Render list page with the documents and the form
    return render(request, 'upload_list.html',  {'documents': documents, 'form': form}  )


    
def download(request, pk=1):
    # Handle file download
    document    = Document.objects.get(pk = pk)    
    file_full_path = os.path.join(settings.MEDIA_ROOT, document.docfile.name)
    filename = os.path.basename(file_full_path)
    response = StreamingHttpResponse(document.docfile, content_type=mimetypes.guess_type(file_full_path)[0]) 
    response['Content-Disposition'] = "attachment; filename={0}".format(filename)
    response['Content-Length'] = os.path.getsize(file_full_path) 
    return response
    
    
    
    
def signup(request):
    # Handle file upload
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            user = create_user(username=form.cleaned_data['user'], email=form.cleaned_data['email'], password=form.cleaned_data['password'])
            # Redirect to login page 
            return HttpResponseRedirect('%s?next=%s' % (reverse('login'), reverse('document-lists')) )
    else:
        form = SignupForm() # A empty, unbound form    
    # Render list page with the documents and the form
    return render(request, 'registration/signup.html',  {'form': form} )


 

    
def create_user(username, email, password):
    user = User(username=username, email=email) #or use User.objects.create_user()
    user.set_password(password)
    user.save()
    return user
 
#advanced/templates/base.html 
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css" />
    <title>{% block title %}My amazing site{% endblock %}</title>
    <script type="text/javascript" > {% block head_script %} {% endblock %}  </script>
</head>

<body> 
    <div id="content">
        {% block content %}{% endblock %}
    </div>
</body>
</html>
 
#advanced/templates/registration/signup.html 
{% extends "base.html" %}

{% block title %}Create an account{% endblock %}

{% block head_script %} 
        function validateForm() { 
            if(document.frm.again_password.value != document.frm.password.value) { 
                alert("Both password must be same "); 
                document.frm.password.value = "";
                document.frm.again_password.value = "";
                document.frm.password.focus(); 
                return false; 
                }             
            return true;
        }

{% endblock %}

{% block content %}
  <h1>Create an account</h1>
  <form action="{% url 'signup' %}" method="post" name="frm" onsubmit="return validateForm()">
      {% csrf_token %}
      <table border="1">      {{ form.as_table }}  </table>
      <input type="submit" value="Create the account">
      
  </form>
{% endblock %}

#advanced/templates/registration/login.html 
{% extends "base.html" %}

{% block title %}Login form{% endblock %}


{% block content %}

{% if form.errors %}
<p>Your username and password didn't match. Please try again.</p>
{% endif %}

<form method="post" action="{% url 'login' %}">
{% csrf_token %}
<table>
<tr>
    <td>{{ form.username.label_tag }}</td>
    <td>{{ form.username }}</td>
</tr>
<tr>
    <td>{{ form.password.label_tag }}</td>
    <td>{{ form.password }}</td>
</tr>
</table>

<input type="submit" value="login" />
<p> <a href="{% url 'signup' %}">First time user? Please SignUp</a><p>
<input type="hidden" name="next" value="{{ next }}" />
</form>
{% endblock %}

#advanced/templates/registration/logout.html 
{% extends "base.html" %}

{% block title %}{{title}}{% endblock %}

{% block content %}
{{title}}
<br/>
<p> <a href="{% url 'login' %}?next={% url 'document-lists' %}">Login Again</a><p>  {# next is must else going to profile #}
{% endblock %}

#advanced/templates/upload_list.html 
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Django File Upload Example</title>	
	</head>

	<body>
		<!-- List of uploaded documents -->
		{% if documents %}
			<ul>
			{% for document in documents %}
				<li><a href='{% url "documents-download" document.id %}'>{{ document.docfile.name }}</a></li>
			{% endfor %}
			</ul>  
		{% else %}
			<p>No documents.</p>
		{% endif %}

		<!-- Upload form. Note enctype attribute! -->
		<form action="{% url 'document-lists' %}" method="post" enctype="multipart/form-data">
			{% csrf_token %}
			<table>
                {{ form.as_table }}
            </table>
			<p><input type="submit" value="Upload" /></p>
		</form>
        <br/>
		<p> <a href="{% url 'logout' %}">Logout</a><p>
	</body>

</html> 


###STEP 6:Create the Database tables now
$ python manage.py makemigrations advanced
$ python manage.py migrate

#check
python manage.py runserver 8080
# http://127.0.0.1:8080/advanced/list 



###Alternate 
###Forms - basic - Upload/download, with User authentication 

$ python manage.py startapp advanced 

#create director 'media'

#django_total/settings.py 

#Session based login, hence set below to expire 
SESSION_EXPIRE_AT_BROWSER_CLOSE = True    # everytime browser is closed, session is expired, ELSE persistant session 
SESSION_COOKIE_AGE  = 5*60 # in seconds 


# Absolute filesystem path to the directory that will hold user-uploaded files.
# Example: "/home/media/media.lawrence.com/media/"
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')

# URL that handles the media served from MEDIA_ROOT. Make sure to use a
# trailing slash. so below URLs are actually  from above MEDIA_ROOT
# Examples: "http://media.lawrence.com/media/", "http://example.com/media/"
MEDIA_URL = '/media/'

#LOGGING 
'advanced': {                      #Put the root of your module to handle the logging
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': True,
            },
            
#INSTALLED_APPS
'advanced'
#to use crispy 
$ pip install django-crispy-forms

#Update settings.py
#In production environments, always activate Django template cache loader. 
INSTALLED_APPS = (
    ...
    'crispy_forms',
)




#advanced/urls.py 
#Using auth_views
from django.contrib.auth import views as auth_views
from django.urls import path, include
from . import views

urlpatterns = [            
    path('login/',  auth_views.login,  {'template_name': 'registration/login.html'}, name = 'login'),  
    path('upload/', views.upload, name='document-upload'), 
    path('documents/', views.document_list , name = 'documents-list'),
  ] 
  
#django_total/urls.py 
urlpatterns = [
    #...
    path('advanced/', include('advanced.urls')),
]

#advanced/forms.py 
from django import forms


class DocumentForm(forms.Form):
    docfile = forms.FileField( label='Select a file' )  #<input type="file" name="docfile">
    name = forms.CharField(label='short name', max_length=100)
    description = forms.CharField(
             widget=forms.Textarea(attrs={'cols': 80, 'rows': 20}),
        )

        
#advanced/views.py 
from django.shortcuts import render
from django.http import HttpResponseRedirect  

from django.urls  import reverse

from django.contrib.auth.decorators import login_required

import glob, os.path
from .forms import *
from django.conf import settings

import logging 
log = logging.getLogger(__name__)
    
  
def document_list(request):
    MEDIA_ROOT = settings.MEDIA_ROOT
    documents = glob.glob(os.path.join(MEDIA_ROOT, "*"))
    return render(request, 'advanced/doc_list.html',  {'documents': list(map(os.path.basename,documents))}  )


@login_required(login_url='/advanced/login/')   # beginning / is must, reverse('login') -> gives error!! 
def upload(request):
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            log.info("all form data:", form.cleaned_data)
            handle_uploaded_file(request.FILES['docfile'])
            return HttpResponseRedirect(reverse("documents-list"))
    else:
        form = DocumentForm()
    return render(request, 'advanced/upload.html', {'form': form})


    
def handle_uploaded_file(f):  #f = UploadedFile, #UploadedFile.name, UploadedFile.size (in bytes)
    MEDIA_ROOT = settings.MEDIA_ROOT
    file = os.path.join(MEDIA_ROOT, f.name)
    with open(file, 'wb+') as destination:
        for chunk in f.chunks():
            destination.write(chunk)


   
 
#advanced/templates/advanced/base.html 
{% load static %}

<!DOCTYPE html>
<html>
<head>
  <title>{% block title %}{% endblock %} </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="{% static "css/bootstrap.min.css" %}">
  <script src="{% static "js/jquery.min.js" %}"></script>
  <script src="{% static "js/bootstrap.min.js" %}"></script>
  </head>
    <body>
        <div class="container">
          <div class="row">
            {% block content %}{% endblock %}
          </div>
        </div>
    </body>
</html>
 
#advanced/templates/advanced/upload.html
{% extends "advanced/base.html" %}
{% load crispy_forms_tags %}
{% block title %}Upload File{% endblock title %}

{% block content %}
  <h1>Upload File </h1>
  <form action="{% url 'document-upload' %}" method="post" name="frm" enctype="multipart/form-data">
      {% csrf_token %}
      {{ form |crispy }}
      <input type="submit" value="Upload">
  </form>
{% endblock %}


#advanced/templates/registration/login.html 
{% extends "advanced/base.html" %}
{% load crispy_forms_tags %}

{% block title %}Login form{% endblock %}

{% block content %}

{% if form.errors %}
    <p>Your username and password didn't match. Please try again.</p>
{% endif %}

<form method="post" action="{% url 'login' %}">
    <input type="hidden" name="next" value="{{ next }}" />
    {% csrf_token %}
    {{ form |crispy }}
    <input type="submit" value="Login" />
</form>
{% endblock %}

#advanced/templates/advanced/doc_list.html
{% extends "advanced/base.html" %}
{% load crispy_forms_tags %}

{% block title %}doc list{% endblock %}

{% block content %}
    <h1> Uploaded Docs </h1>
 {% for doc in documents %} 
            <b>{{ doc}} </b>
 {% endfor %} 
{% endblock %}

##If crispy is not there 
<table>
    {{ form.as_table }}
</table>



###STEP 6:Create the Database tables now
$ python manage.py makemigrations advanced
$ python manage.py migrate

#check
python manage.py runserver 8080
# http://127.0.0.1:8080/advanced/documents 


##With ModelForm 

#models.py 
from django.db import models

# Create your models here.
class Document(models.Model):
    docfile = models.FileField(upload_to='documents/%Y/%m/%d')   #auto Uploaded to MEDIA_ROOT, time.strftime("documents/%Y/%m/%d/%H")
    name = models.CharField(verbose_name='short name', max_length=100) #The form field label is set to the verbose_name 
    description = models.TextField()
             
'''
To give unique file name 
import uuid, os.path, time 
def get_file_path(instance, filename, format):
    ext = filename.split('.')[-1]
    filename = "%s.%s" % (uuid.uuid4(), ext)
    return os.path.join(time.strftime(format), filename)

file = models.FileField(upload_to= lambda i,f: get_file_path(i,f,'documents/%Y/%m/%d'), verbose_name= 'doc list')
'''

#forms.py 
from django import forms
from .models import Document 

class DocumentForm(forms.ModelForm):
    class Meta:
        model = Document
        fields = ('docfile', 'name', 'description')
        #specify any unique widgets else default widget for each field would be used 
        widgets = {
            'description': forms.Textarea(attrs={'cols': 80, 'rows': 20}),
        }




#Views.py 
#note the difference 
def document_list(request):
    documents = Document.objects.all()
    #d.docfile is FieldFile
    return render(request, 'advanced/doc_list.html',  {'documents': list(map(lambda d: (d.name, d.docfile.name) ,documents))}  )


@login_required(login_url='/advanced/login/')   # beginning / is must, reverse('login') -> gives error!! 
def upload(request):
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            log.info("all form data:", form.cleaned_data)
            form.save() #physically saves to media **diff 
            return HttpResponseRedirect(reverse("documents-list"))
    else:
        form = DocumentForm()
    return render(request, 'advanced/upload.html', {'form': form})


###STEP 6:Create the Database tables now
$ python manage.py makemigrations advanced
$ python manage.py migrate















### Reference to forms.FileField and forms.ImageField
class FileField(**kwargs)
    Default widget: ClearableFileInput
    Has two optional arguments for validation, max_length and allow_empty_file. 
    If provided, these ensure that the file name is at most the given length, 
    and that validation will succeed even if the file content is empty
    Creates An UploadedFile object that wraps the file content and file name into a single object.
    Bind usig form = UploadFileForm(request.POST, request.FILES)
    Note one form.is_valid() is called, request.FILES['form_field_name'](UploadedFile) can be directly used 
    OR above UploadedFile can be diretcly assigned to Field.FileField of Model 
    or if ModelForm with Model's FileField is used, then form.save() would save the file 
    #methods 
    UploadedFile.read()
        Read the entire uploaded data from the file. 
    UploadedFile.multiple_chunks(chunk_size=None)
        Returns True if the uploaded file is big enough to require reading in multiple chunks. 
    UploadedFile.chunks(chunk_size=None)
        A generator returning chunks of the file
    UploadedFile.name
    UploadedFile.size
    UploadedFile.content_type
        The content-type header uploaded with the file (e.g. text/plain or application/pdf). 
    UploadedFile.content_type_extra
    UploadedFile.charset
    #Example 
    handle_uploaded_file(request.FILES['file'])
    def handle_uploaded_file(f):
        with open('some/file/name.txt', 'wb+') as destination:
            for chunk in f.chunks():
                destination.write(chunk)
    
class ImageField(**kwargs)
    Default widget: ClearableFileInput
    Using an ImageField requires that Pillow is installed with support for the image formats you use.
    Usage is same as FileField


###Reference to Field.FileField and Field.ImageField from Model 
class ImageField(upload_to=None, height_field=None, width_field=None, max_length=100, **options)
class FileField(upload_to=None, max_length=100, **options)

#Example 
class MyModel(models.Model):
    # file will be uploaded to MEDIA_ROOT/uploads
    upload = models.FileField(upload_to='uploads/')
    # or...
    # file will be saved to MEDIA_ROOT/uploads/2015/01/30
    upload = models.FileField(upload_to='uploads/%Y/%m/%d/')
#OR 
def user_directory_path(instance, filename):
    # file will be uploaded to MEDIA_ROOT/user_<id>/<filename>
    return 'user_{0}/{1}'.format(instance.user.id, filename)
class MyModel(models.Model):
    upload = models.FileField(upload_to=user_directory_path)
    
#Usage 
1.define MEDIA_ROOT as the full path to a directory to store uploaded files. 
  Define MEDIA_URL as the base public URL of that directory. 
  Make sure that this directory is writable by the Web server�s user account.
  eg  MEDIA_ROOT is set to '/home/media', and upload_to is set to 'photos/%Y/%m/%d'.
2.Add the FileField or ImageField to  model, defining the upload_to option to specify 
  a subdirectory of MEDIA_ROOT to use for uploaded files.
3.All that will be stored in  database is a path to the file (relative to MEDIA_ROOT). 
  For example, if  ImageField is called mug_shot, get the absolute path to image in a template with 
  {{ object.mug_shot.url }}.
#When you access a FileField on a model, you get an instance of FieldFile as a proxy for django.core.files.File
FieldFile.name
FieldFile.size
FieldFile.url
FieldFile.open(mode='rb')
    Unlike the standard Python open() method, it doesn�t return a file descriptor.
    Since the underlying file is opened implicitly when accessing it, it may be unnecessary to call this method 
    except to reset the pointer to the underlying file or to change the mode.
FieldFile.close()
FieldFile.save(name, content, save=True)
    This method takes a filename and file contents(django.core.files.File) 
    and passes them to the storage class for the field, then associates the stored file 
    with the model field. 
    from django.core.files import File
    # Open an existing file using Python's built-in open()
    f = open('/path/to/hello.world')
    myfile = File(f)

FieldFile.delete(save=True)
    Deletes the file associated with this instance and clears all attributes on the field. 
    Note that when a model is deleted, related files are not deleted. 

##Example 
from django.db import models
class Car(models.Model):
    name = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=5, decimal_places=2)
    photo = models.ImageField(upload_to='cars')

>>> car = Car.objects.get(name="57 Chevy")
>>> car.photo # proxy of File object
<ImageFieldFile: chevy.jpg>
>>> car.photo.name
'cars/chevy.jpg'
>>> car.photo.path
'/media/cars/chevy.jpg'
>>> car.photo.url
'http://media.example.com/cars/chevy.jpg'
#The file is saved as part of saving the model in the database, 
#so the actual file name used on disk cannot be relied on until after the model has been saved.


##File storage
#Django�s default file storage is given by the DEFAULT_FILE_STORAGE setting; 
#if you don�t explicitly provide a storage system, this is the one that will be used.

#Using default storage 
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage

path = default_storage.save('/path/to/file', ContentFile('new content'))
>>> path
'/path/to/file'

>>> default_storage.size(path)
11
>>> default_storage.open(path).read()
'new content'

>>> default_storage.delete(path)
>>> default_storage.exists(path)
False

#For example, To store uploaded files under /media/photos regardless of what MEDIA_ROOT setting is:
from django.core.files.storage import FileSystemStorage
from django.db import models
fs = FileSystemStorage(location='/media/photos')
class Car(models.Model):
    photo = models.ImageField(storage=fs)


    
###Django User Model - Creating User programatically 
from django.contrib.auth.models import User

# Create user and save to the database
user = User.objects.create_user('myusername', 'myemail@crazymail.com', 'mypassword')

# Update fields and then save again
user.first_name = 'John'
user.last_name = 'Citizen'
user.save()

##Manager methods User model has a custom manager , access by User.objects.
create_user(username, email=None, password=None, **extra_fields)        
    Creates, saves and returns a User.
create_superuser(username, email, password, **extra_fields)
    Creates superuser 
    #OR 
    $ python manage.py createsuperuser --username=joe --email=joe@example.com

#To change a user�s password, 
$ python manage.py manage.py changepassword *username
#OR 
>>> from django.contrib.auth.models import User
>>> u = User.objects.get(username='john')
>>> u.set_password('new password')
>>> u.save()



##Few Imp attributes of User
first_name
last_name
email
password
groups                  
    Many-to-many relationship to Group
    Group has 'permisions' and user_set 
user_permissions        
    Many-to-many relationship to Permission
    Permission has 'user_set' and 'group_set' 
is_staff                
    Boolean. 
    Designates whether this user can access the admin site.
is_active               
    Boolean. 
    Designates whether this user account should be considered active.
is_superuser            
    Boolean. 
    Designates that this user has all permissions without explicitly assigning them.
last_login
date_joined
set_password(raw_password)
check_password(raw_password)
set_unusable_password()             
    Marks the user as having no password set
has_usable_password()
get_group_permissions(obj=None)
    Returns a set of permission strings that the user has, through their groups.
    If obj is passed in, only returns the group permissions for this specific object.
get_all_permissions(obj=None)
    Returns a set of permission strings that the user has, both through group and user permissions.
    If obj is passed in, only returns the permissions for this specific object.
has_perm(perm, obj=None)
    Returns True if the user has the specified permission, 
    where perm is in the format "<app label>.<permission codename>". . 
    If the user is inactive, this method will always return False.
    If obj is passed in, this method won�t check for a permission for the model, but for this specific object.
has_perms(perm_list, obj=None)
    Returns True if the user has each of the specified permissions, 
    where each perm is in the format "<app label>.<permission codename>". 
    If the user is inactive, this method will always return False.
    If obj is passed in, this method won�t check for permissions for the model, but for the specific object.
has_module_perms(package_name)
    Returns True if the user has any permissions in the given package (the Django app label). 
    If the user is inactive, this method will always return False.
email_user(subject, message, from_email=None, **kwargs)
    Sends an email to the user. If from_email is None, Django uses the DEFAULT_FROM_EMAIL. 
    Any **kwargs are passed to the underlying send_mail() call.
class models.Group
    name
        Required. 80 characters or fewer. 
        Any characters are permitted. Example: 'Awesome Users'.
    permissions
        Many-to-many field to Permission:
        group.permissions.set([permission_list])
        group.permissions.add(permission, permission, ...)
        group.permissions.remove(permission, permission, ...)
        group.permissions.clear()



##Login and logout signals
user_logged_in()            
    Sent when a user logs in successfully.
    Args are sender, request, user 
user_logged_out()           
    Args are sender, request, user 
user_login_failed()         
    Args are sender, credentials, request
    
#Example 
from django.contrib.auth.signals import user_logged_in

def do_stuff(sender, user, request, **kwargs):
    whatever...

user_logged_in.connect(do_stuff)
    
##How to use Signals 
#https://docs.djangoproject.com/en/2.1/topics/signals/  
#https://docs.djangoproject.com/en/2.1/ref/signals/
#Option-1
from django.core.signals import request_finished

request_finished.connect(my_callback)

#OR Option-2 
from django.core.signals import request_finished
from django.dispatch import receiver

@receiver(request_finished)
def my_callback(sender, **kwargs):
    print("Request finished!")

#Connecting to signals sent by specific senders
from django.db.models.signals import pre_save
from django.dispatch import receiver
from myapp.models import MyModel


@receiver(pre_save, sender=MyModel)
def my_handler(sender, **kwargs):



###Permissions and Authorization 
#superuser is authenticated and has all permissions
#permission is a string of the form "<app label>.<permission codename>" and can have anything there 
#In general, Admin user(admin console) creates any permission string, group , 
#assigns that to group/user and code checks that permission for an logged in user 


#Django comes with a simple permissions system. 
#It provides a way to assign permissions to specific users and groups of users.
1.Access to see/view the "add" form and add an object 
    is limited to users with the "add" permission for that type of object.
2.Access to see/view the change list, view the "change" form and change an object 
    is limited to users with the "change" permission for that type of object.
3.Access to delete an object 
    is limited to users with the "delete" permission for that type of object.
    
#Permissions can be set not only per type of object, but also per specific object instance. 
#permissions are "<app label>.<permission codename>", app_level is defined in 'python manage.py createapp app_nameORapp_label' 
#permission codename can be any string and created vi Model's Meta OPTIONS or by programatically
#And checked by User.has_parm()

##Default permissions
#When django.contrib.auth is listed in INSTALLED_APPS setting, 
#it will ensure that three default permissions 
#add, change and delete � are created for each Django model defined in one of installed applications.
#when below is executed  
$ python manage.py migrate


#For example - for app_label 'foo' and a model named 'Bar', 
#to test for basic permissions you should use:
1.add: user.has_perm('foo.add_bar')
2.change: user.has_perm('foo.change_bar')
3.delete: user.has_perm('foo.delete_bar')
#Note app_label comes from Model, Meta OPTIONS 
Options.app_label
    If a model is defined outside of an application in INSTALLED_APPS, 
    it must declare which app it belongs to:
    Else, app_lable comes from manage.py startapp 'myapp', then   app_label = 'myapp'
    If you want to represent a model with the format app_label.object_name or app_label.model_name 
    you can use model._meta.label or model._meta.label_lower respectively.

#These permissions can be added/deleted from admin consoles for each User, for User group 



##django.contrib.auth.models.Group
#A generic way of categorizing users so you can apply permissions, or some other label, to those users. 
#A user can belong to any number of groups.

#A user in a group automatically has the permissions granted to that group. 
#For example, if the group Site editors has the permission 'can_edit_home_page', 
#any user in that group will have that permission.


##Programmatically creating permissions
#While custom permissions can be defined within a model�s Meta class, you can also create permissions directly. 
#Note permissions are "<app label>.<permission codename>"
Options.permissions
    Extra permissions to enter into the permissions table when creating this object. 
    Add, delete and change permissions are automatically created for each model. 
    This example specifies an extra permission, can_deliver_pizzas:
    permissions = (("can_deliver_pizzas", "Can deliver pizzas"),)
    This is a list or tuple of 2-tuples in the format (permission_code, human_readable_permission_name).
Options.default_permissions
    Defaults to ('add', 'change', 'delete'). 
    You may customize this list, for example, by setting this to an empty list 
    if your app doesn�t require any of the default permissions. 
    It must be specified on the model before the model is created by migrate in order 
    to prevent any omitted permissions from being created.


#OR,for example, create the 'can_publish' permission for a BlogPost model in myapp:
from myapp.models import BlogPost
from django.contrib.auth.models import Permission
from django.contrib.contenttypes.models import ContentType #django.contrib.contenttypes in INSTALLED_APPS

content_type = ContentType.objects.get_for_model(BlogPost)  #content_type is a Model  
permission = Permission.objects.create(
    codename='can_publish',
    name='Can Publish Posts',
    content_type=content_type,
)

#The permission can then be assigned to a User via its user_permissions attribute 
#or to a Group via its 'permissions' attribute.
#User objects have two many-to-many fields: 
#groups and user_permissions. 
#User objects can access their related objects in the same way as any other Django model:
myuser.groups.set([group_list])
myuser.groups.add(group, group, ...)
myuser.groups.remove(group, group, ...)
myuser.groups.clear()
myuser.user_permissions.set([permission_list])
myuser.user_permissions.add(permission, permission, ...)
myuser.user_permissions.remove(permission, permission, ...)
myuser.user_permissions.clear()
#OR via group 
group.permissions.set([permission_list])
group.permissions.add(permission, permission, ...)
group.permissions.remove(permission, permission, ...)
group.permissions.clear()
        
#And then check via User 
myuser.has_perm(perm, obj=None)
myuser.has_perms(perm_list, obj=None)

##Permission caching
#The ModelBackend caches permissions on the user object after the first time they need to be fetched for a permissions check. 
#If you are adding permissions and checking them immediately afterward, in a test or view for example, 
#the easiest solution is to re-fetch the user from the database

from django.contrib.auth.models import Permission, User
from django.contrib.contenttypes.models import ContentType
from django.shortcuts import get_object_or_404
from myapp.models import BlogPost
def user_gains_perms(request, user_id):
    user = get_object_or_404(User, pk=user_id)
    # any permission check will cache the current set of permissions
    user.has_perm('myapp.change_blogpost')
    content_type = ContentType.objects.get_for_model(BlogPost)
    permission = Permission.objects.get(
        codename='change_blogpost',
        content_type=content_type,
    )
    user.user_permissions.add(permission)
    # Checking the cached permission set
    user.has_perm('myapp.change_blogpost')  # False
    # Request new instance of User
    # Be aware that user.refresh_from_db() won't clear the cache.
    user = get_object_or_404(User, pk=user_id)
    # Permission cache is repopulated from the database
    user.has_perm('myapp.change_blogpost')  # True
    ...




###Authenticating users
#checks username, password against each authentication backend, 
#and returns a User object if the credentials are valid for a backend. 
#if a backend raises PermissionDenied, it returns None. 

from django.contrib.auth import authenticate, login
from django.contrib.auth import logout

def my_view(request):
    username = request.POST['username']
    password = request.POST['password']
    user = authenticate(request, username=username, password=password)
    if user is not None:
        login(request, user)
        # Redirect to a success page.
        ...
    else:
        # Return an 'invalid login' error message.



def logout_view(request):
    logout(request)
    # Redirect to a success page.

 

##Limiting access to logged-in users
from django.conf import settings
from django.shortcuts import redirect
def my_view(request):
    if not request.user.is_authenticated:
        return redirect('%s?next=%s' % (settings.LOGIN_URL, request.path))
    # ...
#or display an error message:
from django.shortcuts import render
def my_view(request):
    if not request.user.is_authenticated:
        return render(request, 'myapp/login_error.html')
    # ...
    
#OR , use The login_required decorator
#use django.contrib.admin.views.decorators.staff_member_required() if STAFF(superuser) is required 
login_required(redirect_field_name='next', login_url=None)
    login_required() does the following:
    1.If the user isn�t logged in, redirect to settings.LOGIN_URL, 
      passing the current absolute path in the query string . Example: /accounts/login/?next=/polls/3/.
    2.If the user is logged in, execute the view normally. 
      The view code is free to assume the user is logged in.

#Example 
from django.contrib.auth.decorators import login_required
@login_required
def my_view(request):
    #request.user is now logged in 
    

#By default, the path that the user should be redirected to upon successful authentication 
#is stored in a query string parameter called "next" or use  redirect_field_name parameter in login_required
#And customize login template as well, since the template context variable would also use redirect_field_name as its key rather than "next" (the default).

@login_required(redirect_field_name='my_redirect_field')
def my_view(request):
    ...
    
#login_required() also takes an optional login_url parameter for redirecting to login view (instead of settings.LOGIN_URL
@login_required(login_url='/accounts/login/')
def my_view(request):
    ...
    
#then urls.py:  Note path should be equal to login_url or settings.LOGIN_URL    
from django.contrib.auth import views as auth_views
path('accounts/login/', auth_views.LoginView.as_view()),



##Class based Access control 
#https://ccbv.co.uk/projects/Django/1.9/django.contrib.auth.mixins/UserPassesTestMixin/
class django.contrib.auth.mixins import AccessMixin
    Abstract CBV mixin that gives access mixins the same customizable functionality.
    Attributes 
        login_url = None 	AccessMixin
        permission_denied_message = '' 	AccessMixin
        raise_exception = False 	AccessMixin
        redirect_field_name = 'next' 	AccessMixin 


class django.contrib.auth.mixins.LoginRequiredMixin
    CBV mixin which verifies that the current user is authenticated.
    Ancestors (MRO)
        LoginRequiredMixin
        AccessMixin
    Attributes 
        login_url = None 	AccessMixin
        permission_denied_message = '' 	AccessMixin
        raise_exception = False 	AccessMixin
        redirect_field_name = 'next' 	AccessMixin


class django.contrib.auth.mixins.PermissionRequiredMixin
    CBV mixin which verifies that the current user has all specified permissions.
    Ancestors (MRO)
        PermissionRequiredMixin
        AccessMixin
    Attributes
        login_url = None 	
        permission_denied_message = '' 	
        permission_required = None 	 #String name of permssions or tuple pf permission strings 
        raise_exception = False 	
        redirect_field_name = 'next' 	
    Methods 
        def get_permission_required(self):
            """
            Override this method to override the permission_required attribute.
            Must return an iterable.
            """
            if self.permission_required is None:
                raise ImproperlyConfigured(
                    '{0} is missing the permission_required attribute. Define {0}.permission_required, or override '
                    '{0}.get_permission_required().'.format(self.__class__.__name__)
                )
            if isinstance(self.permission_required, six.string_types):
                perms = (self.permission_required, )
            else:
                perms = self.permission_required
            return perms
        def has_permission(self):
            """
            Override this method to customize the way permissions are checked.
            """
            perms = self.get_permission_required()
            return self.request.user.has_perms(perms)    
            
            

class django.contrib.auth.mixins.UserPassesTestMixin
    CBV Mixin that allows you to define a test function which must return True
    if the current user can access the view.
    Ancestors (MRO)
        UserPassesTestMixin
        AccessMixin
    Attributes
        login_url = None 	            AccessMixin
        permission_denied_message = '' 	AccessMixin
        raise_exception = False 	    AccessMixin
        redirect_field_name = 'next' 	AccessMixin
    Methods
        def test_func(self):
            raise NotImplementedError(
                '{0} is missing the implementation of the test_func() method.'.format(self.__class__.__name__)
            )
            
            
##LoginRequiredMixin
#If a view is using this mixin, all requests by non-authenticated users will be redirected to the login page 
#or shown an HTTP 403 Forbidden error, depending on the raise_exception parameter.

from django.contrib.auth.mixins import LoginRequiredMixin
class MyView(LoginRequiredMixin, View):
    login_url = '/login/'
    redirect_field_name = 'redirect_to'
    #implement get(self, request, *args, **kwargs) etc if any HTTP is required 
    #
    
    
##Limiting access to logged-in users that pass a test
#Option-1 
from django.shortcuts import redirect
def my_view(request):
    if not request.user.email.endswith('@example.com'):
        return redirect('/login/?next=%s' % request.path)
    # ...
    
#OR use 'user_passes_test' which redirects to login_url or settings.LOGIN_URL when test_func returns True 
#user_passes_test() takes a required argument: a callable that takes a User object and returns True if the user is allowed to view the page. 
#Note that user_passes_test() does not automatically check that the User is not anonymous( call user.is_authenticated to know that)

def email_check(user):
    return user.email.endswith('@example.com')
    
@user_passes_test(email_check)
def my_view(request):
    ...

#With login_url
@user_passes_test(email_check, login_url='/login/')
def my_view(request):
    ...
    
#OR use UserPassesTestMixin
from django.contrib.auth.mixins import UserPassesTestMixin
class MyView(UserPassesTestMixin, View):
    def test_func(self):
        return self.request.user.email.endswith('@example.com')
        
        
        
##Stacking UserPassesTestMixin
#Due to the way UserPassesTestMixin is implemented, you cannot stack them in inheritance list. 
#The following does NOT work:
#If TestMixin1 calls super() and take that result into account, TestMixin1 wouldn�t work standalone anymore.
class TestMixin1(UserPassesTestMixin):
    def test_func(self):
        return self.request.user.email.endswith('@example.com')
class TestMixin2(UserPassesTestMixin):
    def test_func(self):
        return self.request.user.username.startswith('django')
class MyView(TestMixin1, TestMixin2, View):
    ...
    
    


##The permission_required decorator
permission_required(perm, login_url=None, raise_exception=False)
#permission names take the form "<app label>.<permission codename>" (i.e. polls.can_vote for a permission on a model in the polls application).
#login_url defaults to settings.LOGIN_URL
#If the raise_exception parameter is given, the decorator will raise PermissionDenied, prompting the 403 (HTTP Forbidden) view instead of redirecting to the login page.

#Example 
from django.contrib.auth.decorators import permission_required
@permission_required('polls.can_vote')
def my_view(request):
    ...

#OR 
from django.contrib.auth.decorators import permission_required
@permission_required('polls.can_vote', login_url='/loginpage/')
def my_view(request):
    ...
    
    
#can be stacked with login_required, reccomended 
from django.contrib.auth.decorators import login_required, permission_required
@login_required
@permission_required('polls.can_vote', raise_exception=True)
def my_view(request):
    ...


#Or USe The PermissionRequiredMixin mixin
#can override get_permission_required():list_of_perms and or has_permission():Trie/False

from django.contrib.auth.mixins import PermissionRequiredMixin
class MyView(PermissionRequiredMixin, View):
    permission_required = 'polls.can_vote'
    # Or multiple of permissions:
    permission_required = ('polls.can_open', 'polls.can_edit')
    




###*** Example - Django blog using Django packages 

#Better to create virtualenv and virtualenvwrapper
#virtualenv is a tool to create isolated Python environments
    
$ pip install virtualenv

##Then use virtualenvwrapper (easy usage of virtualenv in windows) to provide a dedicated environment for each Django project 
#https://pypi.org/project/virtualenvwrapper-win/

$ pip install virtualenvwrapper  #unix 
$ pip install virtualenvwrapper-win

#create a virtual environment for your project:
$ mkvirtualenv simpleblog   --no-site-packages 
#stored in %USERPROFILE%\Envs
#or set WORKON_HOME=some_loacation where it would be stored 

#The virtual environment will be activated automatically 
#or in new command prompt 
$ workon simpleblog

#other commands 
lsvirtualenv
    List all of the enviornments stored in WORKON_HOME.
rmvirtualenv <name>
    Remove the environment <name>.
deactivate
    Deactivate the working virtualenv and switch back to the default system Python.
add2virtualenv <full or relative path>
    If a virtualenv environment is active, appends <path> to virtualenv_path_extensions.pth inside the environment�s site-packages, 
    which effectively adds <path> to the environment�s PYTHONPATH
cdproject
    If a virtualenv environment is active and a projectdir has been defined, 
    change the current working directory to active virtualenv�s project directory
cdsitepackages
    If a virtualenv environment is active, change the current working directory to the active virtualenv�s site-packages directory
cdvirtualenv
    If a virtualenv environment is active, change the current working directory to the active virtualenv base directory.
lssitepackages
    If a virtualenv environment is active, list that environment�s site-packages
mkproject
    If the environment variable PROJECT_HOME is set, 
    create a new project directory in PROJECT_HOME and a virtualenv in WORKON_HOME. 
    The project path will automatically be associated with the virtualenv on creation.
setprojectdir <full or relative path>
    If a virtualenv environment is active, define <path> as project directory containing the source code
toggleglobalsitepackages
    If a virtualenv environment is active, toggle between having the global site-packages in the PYTHONPATH or just the virtualenv�s site-packages.
whereis <file>
    Returns the locations (on %PATH%) that contain an executable file. 
virtualenvwrapper
    Print a list of commands and their descriptions as basic help output


#To create requirements.txt from existng environment 
$ pip freeze > requirements.txt

#Install requirements.txt in new dir 
$ cd <<DIR>>/MyProject/
$ workon simpleblog
$ pip install -r requirements.txt 




###Simple blog usin zinnia
#https://djangopackages.org/packages/p/django-plugins/

$ mkvirtualenv simpleblog   --no-site-packages 

#Creating other file 
$ mkdir simpleblog 
$ cd simpleblog 
$ workon simpleblog 
$ pip install Django==2.0.6
#https://github.com/drager/django-simple-blog
$ pip install django-blog-zinnia
#start project 
$ django-admin startproject myblog 

#compact the dir structure such that it measures below 
#create static and templates dir under this 
#dir structure 
.
+-- simpleblog
    +-- manage.py
    +-- myblog
        +-- __init__.py
        +-- settings.py
        +-- urls.py
        +-- wsgi.py
        
        
        
##Update Settings.py 

#additional locations the staticfiles app will traverse
STATICFILES_DIRS = (
   os.path.join(BASE_DIR, "static/"),   
   )
   
#my_own_stuff 
TEMPLATES[0]['DIRS'].append(os.path.join(BASE_DIR, 'templates'))

   
#for register zinnia module 
INSTALLED_APPS += [ 'django.contrib.humanize', 'django.contrib.sites', 'django_comments',
  'mptt',
  'tagging',
  'zinnia',
]
SITE_ID = 1
TEMPLATES[0]['OPTIONS']['context_processors']+= [
    'django.template.context_processors.i18n',
    'zinnia.context_processors.version',  # Optional
]


##Update urls.py 

from django.conf.urls import url

urlpatterns += [
    url(r'^weblog/', include('zinnia.urls')),
    url(r'^comments/', include('django_comments.urls')),
 ]


#then 
$ python manage.py migrate
$ python manage.py createsuperuser
$ python manage.py runserver 8000 
#http://127.0.0.1:8000/weblog    

#Change domain from www.example.com to new from http://127.0.0.1:8000/admin/sites/site/
#Change Heading from Zinnia;s weblog to Myweblog 
#copy zinnia module/templates/zinnia/skeleton.html to myblog/templates/zinnia/skeleton.html 
#update 

#check api  http://docs.django-blog-zinnia.com/en/develop/getting-started/overview.html




##Updating wsgi.py using this virtualenv 
import os
import sys
import site

#site:This module is automatically imported during initialization
#addsitedir: Add a directory to sys.path and process its .pth files.
# Add the site-packages of the chosen virtualenv to work with
#$WORKON_HOME/simpleblog/Lib/site-packages
#find out exact dir 
sitedir = os.path.expanduser("~/Envs/simpleblog/Lib/site-packages")
site.addsitedir(sitedir)  #C:\Users\das\Envs\simpleblog\Lib\site-packages

# Add the app's directory to the PYTHONPATH
app_dir = r"D:\Desktop\PPT\python\OtherPython\Django\code\recent\simpleblog\myblog"
sys.path.append(app_dir)
sys.path.append(os.path.join(app_dir, 'myblog'))  #where settings.py exists 

# Activate your virtual env
activate_env = os.path.expanduser("~/Envs/simpleblog/Scripts/activate_this.py") #C:\Users\das\Envs\simpleblog\Scripts

#python2.7 
#execfile(activate_env, dict(__file__=activate_env))
#python3 
with open(activate_env) as f:
    code = compile(f.read(), activate_env, 'exec')
    exec(code, dict(__file__=activate_env))


from django.core.wsgi import get_wsgi_application
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "myblog.settings")
application = get_wsgi_application()

