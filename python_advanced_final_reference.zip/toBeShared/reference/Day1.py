Day1
Modules and Packages
   Definition and Creating a User Module
   Byte compilation of Module
   Invoking Modules - import statement
   Calling attributes and functions of a Module � prefixing modulename
   Calling specific functions/attributes � from .. import statement
   Creating alias names for methods in import statement
   Getting the attributs/methods of a module � dir()
   Help on a method � help()
   Reloading a module � reload()
   Knowing the list of installed modules � help('modules')
   Running modules individually as a program - __name__=='__main__'
   What is a package and Use of a package
   __init__.py file and its use
   Relation between packages and modules
  Installing modules and packages using pip
Database Connectivity
   MySQL Database
   Connection to a database server
   Drivers for MySQL and other databases
   The basic principles of databases
   Using MySQL from Python
   Executing SQL statements � DDL and DML
   Using SQL select
   Retrieving the data from SQL table to Python for display
   Executing Stored Procedures
Python Standard Library
  os and os.path
  sys
  math, cmath
  zlib
  glob
  datetime, dateutil,time
  __builtin__
  string
  random
  timeit
  unittest
Regex in Python
  Regular expressions in Python � the re module
  Elements of a Python-style regular expression
  Anchors (Assertions)
  Literal characters
  Character groups
  Counts
  Alternation
  Grouping
  Modifiers
  re methods - re.match, re.search, res.sub, re.compile, re.purge
  More examples on regular expressions
  Some popular regular expressions
  
#_________________________________________________________________



###*** Relative import 
#A single leading dot indicates a relative import, 
#starting with the current package. 

#Two or more leading dots give a relative import to the parent(s) of the current package,

#Example 
package/
    __init__.py
    subpackage1/
        __init__.py
        moduleX.py
        moduleY.py
    subpackage2/
        __init__.py
        moduleZ.py
    moduleA.py


#Current file is moduleX.py :
 
from .moduleY import spam
from .moduleY import spam as ham
from . import moduleY
from ..subpackage1 import moduleY
from ..subpackage2.moduleZ import eggs
from ..moduleA import foo
from ...package import bar  ##package\__init__.py must have bar 



###*** __init__.py 's use 

#Ex:
package/
    __init__.py
    file.py
    file2.py



##USAGE-1: Normally, use import like
from package.file import File

#if package/__init__.py contains below 
from file import File

#Can use like below in user file
from package import File

##USAGE-2: when you do below

from package import *

#default behaviour of import * in module file 
#is to import all symbols that do not begin with an underscore, from the given namespace

#default behaviour of import * for package if there is no __all__ or not code , not to import anything 

# __all__ is a list of strings defining what symbols in a module(module name, function, object) will be exported 

#if  package/__init__.py contains below 
from file import func, var, Myclass 

__all__ = ['func', 'file2', 'var', 'Myclass']


#it imports all modules from __all__




##USAGE-3:Any class, methods defined in __init__.py would be automatically available 
#when user import the package 
#An example
database/
    __init__.py
    schema.py
   ...

#__init__.py
import os

from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine

engine = create_engine(os.environ['DATABASE_URL'])
Session = sessionmaker(bind=engine)

def method():
    pass
    
class C:
    pass

#User can do below
from database import Session, method, C
session = Session()



#Usage-4:__init__.py can  contain anything as it itself is a py file, 
#But below are generally used for special purpose(not so standardised)
__version__ = '0.1'
__author__ = 'Cardinal Biggles'

>>> import email
>>> email.__version__
'5.1.0'


###*** Reloading modules in Python 
#Dont do it, restart the script as it might fail if dependencies or circular dependencies 
#for dependencies, do it for all 
import sys 
sys.modules 

#For Python2.x
reload(module)

#For above 2.x and <=Python3.3
import imp
imp.reload(module)


#For >=Python3.4
import importlib
importlib.reload(module)

#from X import Y case ie __import__('X', fromlist='Y')
def importOrReload(module_name, *names):
    import sys
    if module_name in sys.modules:
        reload(sys.modules[module_name])
    else:
        __import__(module_name, fromlist=names)
    for name in names:
        globals()[name] = getattr(sys.modules[module_name], name)

# use instead of: from dfly_parser import parseMessages
importOrReload("dfly_parser", "parseMessages")


###*** Building and Distributing Packages with Setuptools
#Setuptools is a collection of enhancements to the Python distutils

#setup.py  at root directory of a package 

from setuptools import setup, find_packages
setup(
    name="HelloWorld",
    version="0.1",
    packages=find_packages(),
)
#OR complex one 
#https://setuptools.readthedocs.io/en/latest/setuptools.html
from setuptools import setup, find_packages
setup(
    name="HelloWorld",
    version="0.1",
    packages=find_packages(),
    scripts=['say_hello.py'],

    # Project uses reStructuredText, so ensure that the docutils get
    # installed or upgraded on the target machine
    install_requires=['docutils>=0.3'],

    package_data={
        # If any package contains *.txt or *.rst files, include them:
        '': ['*.txt', '*.rst'],
        # And include any *.msg files found in the 'hello' package, too:
        'hello': ['*.msg'],
    },

    # metadata to display on PyPI
    author="Me",
    author_email="me@example.com",
    description="This is an Example Package",
    license="PSF",
    keywords="hello world example examples",
    url="http://example.com/HelloWorld/",   # project home page, if any
    project_urls={
        "Bug Tracker": "https://bugs.example.com/HelloWorld/",
        "Documentation": "https://docs.example.com/HelloWorld/",
        "Source Code": "https://code.example.com/HelloWorld/",
    }

    # could also include long_description, download_url, classifiers, etc.
)



#command 
#https://setuptools.readthedocs.io/en/latest/setuptools.html#command-reference
$ python setup.py sdist --formats=zip      #create a source distribution (tarball, zip file, etc.)
$ python setup.py --help-commands

#To update to pypi , check 
#https://pythonhosted.org/an_example_pypi_project/setuptools.html#intermezzo-pypirc-file-and-gpg

##Reference 
setup()
    https://setuptools.readthedocs.io/en/latest/setuptools.html#new-and-changed-setup-keywords
    
find_packages(where='.', exclude=(), include=('*',))
    takes a source directory and two lists of package name patterns to exclude and include
    Some projects use a src or lib directory as the root of their source tree,
    and those projects would use "src" or "lib" as the first argument to find_packages(). 
    (And such projects also need package_dir={'':'src'} in their setup() arguments)
    
    'where' is the root directory which will be searched for packages.  It
    should be supplied as a "cross-platform" (i.e. URL-style) path; it will
    be converted to the appropriate local path syntax.

    'exclude' is a sequence of package names to exclude; '*' can be used
    as a wildcard in the names, such that 'foo.*' will exclude all
    subpackages of 'foo' (but not 'foo' itself).

    'include' is a sequence of package names to include.  If it's
    specified, only the named packages will be included.  If it's not
    specified, all found packages will be included.  'include' can contain
    shell style wildcard patterns just like 'exclude'.


    
###*** Virtualenv 
#virtualenv is a tool to create isolated Python environments
    
$ pip install virtualenv

##Then use virtualenvwrapper (easy usage of virtualenv in windows) to provide a dedicated environment for each Django project 
#https://pypi.org/project/virtualenvwrapper-win/

$ pip install virtualenvwrapper  #unix 
$ pip install virtualenvwrapper-win

#create a virtual environment for your project:
$ mkvirtualenv simpleblog   --no-site-packages 
#stored in %USERPROFILE%\Envs
#or set WORKON_HOME=some_loacation where it would be stored 

#The virtual environment will be activated automatically 
#or in new command prompt 
$ workon simpleblog

#other commands 
lsvirtualenv
    List all of the enviornments stored in WORKON_HOME.
rmvirtualenv <name>
    Remove the environment <name>.
deactivate
    Deactivate the working virtualenv and switch back to the default system Python.
add2virtualenv <full or relative path>
    If a virtualenv environment is active, appends <path> to virtualenv_path_extensions.pth inside the environment�s site-packages, 
    which effectively adds <path> to the environment�s PYTHONPATH
cdproject
    If a virtualenv environment is active and a projectdir has been defined, 
    change the current working directory to active virtualenv�s project directory
cdsitepackages
    If a virtualenv environment is active, change the current working directory to the active virtualenv�s site-packages directory
cdvirtualenv
    If a virtualenv environment is active, change the current working directory to the active virtualenv base directory.
lssitepackages
    If a virtualenv environment is active, list that environment�s site-packages
mkproject
    If the environment variable PROJECT_HOME is set, 
    create a new project directory in PROJECT_HOME and a virtualenv in WORKON_HOME. 
    The project path will automatically be associated with the virtualenv on creation.
setprojectdir <full or relative path>
    If a virtualenv environment is active, define <path> as project directory containing the source code
toggleglobalsitepackages
    If a virtualenv environment is active, toggle between having the global site-packages in the PYTHONPATH or just the virtualenv�s site-packages.
whereis <file>
    Returns the locations (on %PATH%) that contain an executable file. 
virtualenvwrapper
    Print a list of commands and their descriptions as basic help output


#To create requirements.txt from existng environment 
$ pip freeze > requirements.txt

#Install requirements.txt in new dir 
$ cd <<DIR>>/MyProject/
$ workon simpleblog
$ pip install -r requirements.txt 




###*** Regex 
#https://docs.python.org/3/library/re.html


\n \t   escape pattern
.       An char
\w      Alphanumeric 
\W      inverse of \w
\d      digit
\D      inverse of digit 
\s      white space 
\S      inverse of white space 
+       >=1
*       >=0
?       0, 1
{m,n}   max n , min m 
{m}     only m
{,n}
{m,}
\1      Back reference 
$1      Group reference **not available
^       Begining
$       End
()      Grouping 
|       Alternate 



##Advanced Pattern 
(?aiLmsux)(One or more letters from the set 'a', 'i', 'L', 'm', 's', 'u', 'x'.)
    The group matches the empty string; 
    The letters set the corresponding flags for the entire regular expression
        re.A (ASCII-only matching), 
        re.I (ignore case), 
        re.L (locale dependent), 
        re.M (multi-line), 
        re.S (dot matches all), 
        re.U (Unicode matching), 
        re.X (verbose)
        
(?aiLmsux-imsx:...)(Zero or more letters from the set 'a', 'i', 'L', 'm', 's', 'u', 'x', optionally followed by '-' followed by one or more letters from the 'i', 'm', 's', 'x'.) 
    The letters set or remove(with -) the above  flags

(?P<name>...)
    Named group with name 'name' 
(?P=name)
    A backreference to a named group;
    #Context of reference to group �quote�                   Ways to reference it
    in the same pattern itself                              (?P=quote) 
                                                            \1 
    when processing match object m                          m.group('quote')
                                                            m.end('quote') (etc.) 
    in a string passed to the repl argument of re.sub()     \g<quote>
                                                            \g<1>
                                                            \1
 
(?#...)
    A comment
(?=...)
    Matches if ... matches next, but doesn�t consume any of the string. 
    This is called a lookahead assertion. 
    For example, Isaac (?=Asimov) will match 'Isaac ' only if it�s followed by 'Asimov'
(?!...)
    Matches if ... doesn�t match next. 
    This is a negative lookahead assertion. 
    For example, Isaac (?!Asimov) will match 'Isaac ' only if it�s not followed by 'Asimov'.
(?<=...)
    Matches if the current position in the string is preceded by a match for ... that ends at the current position. 
    This is called a positive lookbehind assertion. 
    (?<=abc)def will find a match in 'abcdef', since the lookbehind will back up 3 characters and check if the contained pattern matches. 
    The contained pattern must only match strings of some fixed length, meaning that abc or a|b are allowed, 
    but a* and a{3,4} are not. 
    Note that patterns which start with positive lookbehind assertions will not match at the beginning of the string being searched; 
    you will most likely want to use the search() function rather than the match() function
(?<!...)
    Matches if the current position in the string is not preceded by a match for .... 
    This is called a negative lookbehind assertion. 
    the contained pattern must only match strings of some fixed length. 
    Patterns which start with negative lookbehind assertions may match at the beginning of the string being searched.
    
(?(id/name)yes-pattern|no-pattern)
    Will try to match with yes-pattern if the group with given id or name exists, 
    and with no-pattern if it doesn�t. 
    no-pattern is optional and can be omitted. 
    For example, (<)?(\w+@\w+(?:\.\w+)+)(?(1)>|$) is a poor email matching pattern, 
    which will match with '<user@host.com>' as well as 'user@host.com', 
    but not with '<user@host.com' nor 'user@host.com>'.



##Flags 
re.A
re.ASCII
    Make \w, \W, \b, \B, \d, \D, \s and \S perform ASCII-only matching instead of full Unicode matching. 
re.DEBUG
    Display debug information about compiled expression. No corresponding inline flag.
re.I
re.IGNORECASE
    Perform case-insensitive matching; expressions like [A-Z] will also match lowercase letters
re.L
re.LOCALE
    Make \w, \W, \b, \B and case-insensitive matching dependent on the current locale.
re.M
re.MULTILINE
    When specified, the pattern character '^' matches at the beginning of the string 
    and at the beginning of each line (immediately following each newline); 
    and the pattern character '$' matches at the end of the string and at the end of each line (immediately preceding each newline). 
    By default, '^' matches only at the beginning of the string, and '$' only at the end of the string and immediately before the newline (if any) at the end of the string. 
    Corresponds to the inline flag (?m).
re.S
re.DOTALL
    Make the '.' special character match any character at all, including a newline; 
    without this flag, '.' will match anything except a newline. 
    Corresponds to the inline flag (?s).
re.X
re.VERBOSE
    This flag allows you to write regular expressions that look nicer and are more readable 
    by allowing you to visually separate logical sections of the pattern and add comments.
    Corresponds to the inline flag (?x).    
    a = re.compile(r"""\d +  # the integral part
                       \.    # the decimal point
                       \d *  # some fractional digits""", re.X)
    #same as 
    b = re.compile(r"\d+\.\d*")




##COmmon Examples of Regex 

Anchors�^ and $
    ^The        matches any string that starts with The 
    end$        matches a string that ends with end
    ^The end$   exact string match (starts and ends with The end)
    roar        matches any string that has the text roar in it

Quantifiers�* + ? and {}
    abc*        matches a string that has ab followed by zero or more c 
    abc+        matches a string that has ab followed by one or more c
    abc?        matches a string that has ab followed by zero or one c
    abc{2}      matches a string that has ab followed by 2 c
    abc{2,}     matches a string that has ab followed by 2 or more c
    abc{2,5}    matches a string that has ab followed by 2 up to 5 c
    a(bc)*      matches a string that has a followed by zero or more copies of the sequence bc
    a(bc){2,5}  matches a string that has a followed by 2 up to 5 copies of the sequence bc

OR operator�| or []
    a(b|c)     matches a string that has a followed by b or c 
    a[bc]      same as previous

Character classes?�?\d \w \s and .
    \d         matches a single character that is a digit 
    \w         matches a word character (alphanumeric character plus underscore) 
    \s         matches a whitespace character (includes tabs and line breaks)
    .          matches any character 
    
Grouping and capturing�()
    a(bc)           parentheses create a capturing group with value bc 
    a(?:bc)*        using ?: we disable the capturing group 
    a(?P<foo>bc)     using ?<foo> we put a name to the group 
    
Bracket expressions�[]
    [abc]            matches a string that has either an a or a b or a c -> is the same as a|b|c 
    [a-c]            same as previous
    [a-fA-F0-9]      a string that represents a single hexadecimal digit, case insensitively 
    [0-9]%           a string that has a character from 0 to 9 before a % sign
    [^a-zA-Z]        a string that has not a letter from a to z or from A to Z. In this case the ^ is used as negation of the expression -> 
    <.+?>            matches any character one or more times included inside < and >, expanding as needed 
    <[^<>]+>         matches any character except < or > one or more times included inside < and > 
    
    
Boundaries�\b and \B
    \babc\b          performs a "whole words only" search 
    \Babc\B          matches only if the pattern is fully surrounded by word characters 

Back-references�\1
    ([abc])\1              using \1 it matches the same text that was matched by the first capturing group 
    ([abc])([de])\2\1      we can use \2 (\3, \4, etc.) to identify the same text that was matched by the second (third, fourth, etc.) capturing group 
    (?<foo>[abc])\k<foo>   we put the name foo to the group and we reference it later (\k<foo>). The result is the same of the first regex 

Look-ahead and Look-behind�(?=) and (?<=)
    d(?=r)       matches a d only if is followed by r, but r will not be part of the overall regex match 
    (?<=r)d      matches a d only if is preceded by an r, but r will not be part of the overall regex match 
    d(?!r)       matches a d only if is not followed by r, but r will not be part of the overall regex match 
    (?<!r)d      matches a d only if is not preceded by an r, but r will not be part of the overall regex match 



##More examples 
Decimals input
    Positive Integers ^\d+$
    Negative Integers ^-\d+$
    Integer ^-?\d+$
    Positive Number ^\d*\.?\d+$
    Negative Number ^-\d*\.?\d+$
    Positive Number or Negative Number ^-?\d*\.?\d+$
    Phone number ^\+?[\d\s]{3,}$
    Phone with code ^\+?[\d\s]+\(?[\d\s]{10,}$
    Year 1900-2099 ^(19|20)\d{2}$
    Date (dd mm yyyy, d/m/yyyy, etc.) 
        ^([1-9]|0[1-9]|[12][0-9]|3[01])\D([1-9]|0[1-9]|1[012])\D(19[0-9][0-9]|20[0-9][0-9])$
    IP v4
        ^(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]){3}$

Alphabetic input
    Personal Name ^[\w.']{2,}(\s[\w.']{2,})+$
    Username ^[\w\d_.]{4,}$
    Password at least 6 symbols ^.{6,}$
    Password or empty input ^.{6,}$|^$
    email ^[_]*([a-z0-9]+(\.|_*)?)+@([a-z][a-z0-9-]+(\.|-*\.))+[a-z]{2,6}$
    domain ^([a-z][a-z0-9-]+(\.|-*\.))+[a-z]{2,6}$

Other regular expressions
    Match no input ^$ 
    Match blank input ^\s\t*$ 
    Match New line [\r\n]|$ 
    Match white Space ^\s+$ 
    Match Url = ^http\:\/\/[a-zA-Z0-9.-]+\.[a-zA-Z]{2,3}$


##More examples with explanations 
Date in format dd/mm/yyyy
    Will match dates with dashes, slashes or with spaces (e.g. dd-mm-yyyy dd/mm/yyyy dd mm yyyy), and optional time separated by a space or a dash (e.g. dd-mm-yyyy-hh:mm:ss or dd/mm/yyyy hh:mm:ss).
    ^(0?[1-9]|[12][0-9]|3[01])([ /\-])(0?[1-9]|1[012])\2([0-9][0-9][0-9][0-9])(([ -])([0-1]?[0-9]|2[0-3]):[0-5]?[0-9]:[0-5]?[0-9])?$

Time in 24-hour format
    Match times in 24 hour format
    ([01]?[0-9]|2[0-3]):[0-5][0-9]$
    
Date and time in ISO-8601 format
    Will match a valid date and times in the ISO-8601 format, excludes durations.
    ^(?![+-]?\d{4,5}-?(?:\d{2}|W\d{2})T)(?:|(\d{4}|[+-]\d{5})-?(?:|(0\d|1[0-2])(?:|-?([0-2]\d|3[0-1]))|([0-2]\d{2}|3[0-5]\d|36[0-6])|W([0-4]\d|5[0-3])(?:|-?([1-7])))(?:(?!\d)|T(?=\d)))(?:|([01]\d|2[0-4])(?:|:?([0-5]\d)(?:|:?([0-5]\d)(?:|\.(\d{3})))(?:|[zZ]|([+-](?:[01]\d|2[0-4]))(?:|:?([0-5]\d)))))$

HTML tags
    Match opening and closing HTML tags with content between
    ^<([a-z1-6]+)([^<]+)*(?:>(.*)<\/\1>| *\/>)$

Username
    A string between 3 and 16 characters, allowing alphanumeric characters and hyphens and underscores
	^[a-zA-Z0-9_-]{3,16}$

Hex Color Value
    RGB hex colors
    ^#?([a-fA-F0-9]{6}|[a-fA-F0-9]{3})$

URL Slug
    Match valid URL slugs
    ^[a-z0-9-]+$


Email
    Verify that there is an @ symbol with something before it
    ^.+@.+$

SRC of image tag
    Match the src attribute of an HTML image tag
    ^<\s*img[^>]+src\s*=\s*(["'])(.*?)\1[^>]*>$

URL
    Match URL with optional protocol
	^((https?|ftp|file):\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$

IPv4 Address
    Match IP v4 addresses
    ^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$

IPv6 Address
    Match IP v6 addresses
    ^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$

Positive or negative number
    Match integers or floats that are positive or negative
    ^-?\d*\.?\d+$

Phone number
    Match phone numbers at least 3 digits long
    ^\+?(\d.*){3,}$
    
New line
    [\r\n]|$

ID of Youtube video
    https?:\/\/(?:youtu\.be\/|(?:[a-z]{2,3}\.)?youtube\.com\/watch(?:\?|#\!)v=)([\w-]{11}).*

ID of Youtube Channel
    https?:\/\/(www\.)?youtube.com\/channel\/UC([-_a-z0-9]{22})
    
CSS comment
    \/\*[^*]*\*+([^/*][^*]*\*+)*\/
	description:"Match standard CSS comments",

UK Postal Code
    Matches all UK postcodes
    ^(([gG][iI][rR] {0,}0[aA]{2})|(([aA][sS][cC][nN]|[sS][tT][hH][lL]|[tT][dD][cC][uU]|[bB][bB][nN][dD]|[bB][iI][qQ][qQ]|[fF][iI][qQ][qQ]|[pP][cC][rR][nN]|[sS][iI][qQ][qQ]|[iT][kK][cC][aA]) {0,}1[zZ]{2})|((([a-pr-uwyzA-PR-UWYZ][a-hk-yxA-HK-XY]?[0-9][0-9]?)|(([a-pr-uwyzA-PR-UWYZ][0-9][a-hjkstuwA-HJKSTUW])|([a-pr-uwyzA-PR-UWYZ][a-hk-yA-HK-Y][0-9][abehmnprv-yABEHMNPRV-Y]))) {0,}[0-9][abd-hjlnp-uw-zABD-HJLNP-UW-Z]{2}))$

Morse Code",
    ^[.-]{1,5}(?:[ \t]+[.-]{1,5})*(?:[ \t]+[.-]{1,5}(?:[ \t]+[.-]{1,5})*)*$
    
Image shortcode
    Matches the content in between [img][/img]. Useful for making dynamic WYSIWYG editors
    \[img\](.*?)\[\/img\]


    
    
###*** Python DB API 

#https://dev.mysql.com/doc/refman/8.0/en/create-table.html
DDL, Data Definition Language
    deals with database schemas and descriptions, of how the data should reside in the database.
        �CREATE � to create database and its objects like (table, index, views, store procedure, function and triggers)
        �ALTER � alters the structure of the existing database
        �DROP � delete objects from the database
        �TRUNCATE � remove all records from a table, including all spaces allocated for the records are removed
        �COMMENT � add comments to the data dictionary
        �RENAME � rename an object
DML, Data Manipulation Language
    deals with data manipulation, 
        �SELECT � retrieve data from the a database
        �INSERT � insert data into a table
        �UPDATE � updates existing data within a table
        �DELETE � Delete all records from a database table
        �MERGE � UPSERT operation (insert or update)
        �CALL � call a PL/SQL or Java subprogram
        �EXPLAIN PLAN � interpretation of the data access path
        �LOCK TABLE � concurrency Control
DCL, Data Control Language
    includes commands such as GRANT, and mostly concerned with rights, permissions and other controls of the database system.
        �GRANT � allow users access privileges to database
        �REVOKE � withdraw users access privileges given by using the GRANT command

TCL, Transaction Control Language
    deals with transaction within a database.
        �COMMIT � commits a Transaction
        �ROLLBACK � rollback a transaction in case of any error occurs
        �SAVEPOINT � to rollback the transaction making points within groups
        �SET TRANSACTION � specify characteristics for the transaction


###Module-sqllit , standard package
from sqlite3 import connect

conn = connect(r'D:/temp.db')
curs = conn.cursor()
curs.execute('create table if not exists emp (who, job, pay)')

prefix = 'insert into emp values '
curs.execute(prefix + "('Bob', 'dev', 100)")
curs.execute(prefix + "('Sue', 'dev', 120)")
conn.commit()
curs.execute("select * from emp where pay > 100")
for (who, job, pay) in curs.fetchall():
		print(who, job, pay)

result = curs.execute("select who, pay from emp")
result.fetchone()

query = "select * from emp where job = ?"
curs.execute(query, ('dev',)).fetchall()
conn.close()

#bulk insert 
import sqlite3
conn = connect(r'D:/temp.db')
c = conn.cursor()

# Create table
c.execute('''CREATE TABLE stocks
             (date text, trans text, symbol text, qty real, price real)''')

# Insert a row of data
c.execute("INSERT INTO stocks VALUES ('2006-01-05','BUY','RHAT',100,35.14)")

# Larger example that inserts many records at a time
purchases = [('2006-03-28', 'BUY', 'IBM', 1000, 45.00),
             ('2006-04-05', 'BUY', 'MSFT', 1000, 72.00),
             ('2006-04-06', 'SELL', 'IBM', 500, 53.00),
            ]
curs.executemany('INSERT INTO stocks VALUES (?,?,?,?,?)', purchases)

conn.commit()
conn.close()

#Few other usages - check below 
#http://pythoncentral.io/advanced-sqlite-usage-in-python/




$ sqlite3 sample.db
SQLite version 3.19.1 2017-05-24 13:08:33
Enter ".help" for usage hints.
sqlite> .tables
emp
sqlite> .schema emp
sqlite> select * from emp;






###Mysql 
#download from 
#https://dev.mysql.com/downloads/connector/python/

#start sqld eg in cygwin 
#mysql -running daemon in cygwin
/usr/bin/mysqld_safe &
#shutting down
mysqladmin.exe -h 127.0.0.1 -u root   --connect-timeout=5 shutdown
#mysql admin #  default port 3306, 
mysql -u root    -h 127.0.0.1 -p 
#few commands
show databases;
create database python;
use python;
show tables;
create table employes ( id INT, first_name VARCHAR(20), last_name VARCHAR(20), hire_date  DATE);
desc employes;
insert into employes values (3, "das", "das", '1999-03-30');
select * from employes; 
drop table employes;

#Quick 
from mysql.connector import connect 
conn = connect(user='root', password='root',host='127.0.0.1',database='python')
curs = conn.cursor()

curs.execute("select * from employes")
for all in curs.fetchall():
		print(all)


conn.close()



##Detailed example - Creation 
import mysql.connector
from mysql.connector import errorcode

DB_NAME = 'employees'

TABLES = {}
TABLES['employees'] = (
    "CREATE TABLE `employees` ("
    "  `emp_no` int(11) NOT NULL AUTO_INCREMENT,"
    "  `birth_date` date NOT NULL,"
    "  `first_name` varchar(14) NOT NULL,"
    "  `last_name` varchar(16) NOT NULL,"
    "  `gender` enum('M','F') NOT NULL,"
    "  `hire_date` date NOT NULL,"
    "  PRIMARY KEY (`emp_no`)"
    ") ENGINE=InnoDB")

TABLES['departments'] = (
    "CREATE TABLE `departments` ("
    "  `dept_no` char(4) NOT NULL,"
    "  `dept_name` varchar(40) NOT NULL,"
    "  PRIMARY KEY (`dept_no`), UNIQUE KEY `dept_name` (`dept_name`)"
    ") ENGINE=InnoDB")

TABLES['salaries'] = (
    "CREATE TABLE `salaries` ("
    "  `emp_no` int(11) NOT NULL,"
    "  `salary` int(11) NOT NULL,"
    "  `from_date` date NOT NULL,"
    "  `to_date` date NOT NULL,"
    "  PRIMARY KEY (`emp_no`,`from_date`), KEY `emp_no` (`emp_no`),"
    "  CONSTRAINT `salaries_ibfk_1` FOREIGN KEY (`emp_no`) "
    "     REFERENCES `employees` (`emp_no`) ON DELETE CASCADE"
    ") ENGINE=InnoDB")

TABLES['dept_emp'] = (
    "CREATE TABLE `dept_emp` ("
    "  `emp_no` int(11) NOT NULL,"
    "  `dept_no` char(4) NOT NULL,"
    "  `from_date` date NOT NULL,"
    "  `to_date` date NOT NULL,"
    "  PRIMARY KEY (`emp_no`,`dept_no`), KEY `emp_no` (`emp_no`),"
    "  KEY `dept_no` (`dept_no`),"
    "  CONSTRAINT `dept_emp_ibfk_1` FOREIGN KEY (`emp_no`) "
    "     REFERENCES `employees` (`emp_no`) ON DELETE CASCADE,"
    "  CONSTRAINT `dept_emp_ibfk_2` FOREIGN KEY (`dept_no`) "
    "     REFERENCES `departments` (`dept_no`) ON DELETE CASCADE"
    ") ENGINE=InnoDB")

TABLES['dept_manager'] = (
    "  CREATE TABLE `dept_manager` ("
    "  `dept_no` char(4) NOT NULL,"
    "  `emp_no` int(11) NOT NULL,"
    "  `from_date` date NOT NULL,"
    "  `to_date` date NOT NULL,"
    "  PRIMARY KEY (`emp_no`,`dept_no`),"
    "  KEY `emp_no` (`emp_no`),"
    "  KEY `dept_no` (`dept_no`),"
    "  CONSTRAINT `dept_manager_ibfk_1` FOREIGN KEY (`emp_no`) "
    "     REFERENCES `employees` (`emp_no`) ON DELETE CASCADE,"
    "  CONSTRAINT `dept_manager_ibfk_2` FOREIGN KEY (`dept_no`) "
    "     REFERENCES `departments` (`dept_no`) ON DELETE CASCADE"
    ") ENGINE=InnoDB")

TABLES['titles'] = (
    "CREATE TABLE `titles` ("
    "  `emp_no` int(11) NOT NULL,"
    "  `title` varchar(50) NOT NULL,"
    "  `from_date` date NOT NULL,"
    "  `to_date` date DEFAULT NULL,"
    "  PRIMARY KEY (`emp_no`,`title`,`from_date`), KEY `emp_no` (`emp_no`),"
    "  CONSTRAINT `titles_ibfk_1` FOREIGN KEY (`emp_no`)"
    "     REFERENCES `employees` (`emp_no`) ON DELETE CASCADE"
    ") ENGINE=InnoDB")
    


cnx = mysql.connector.connect(user='root', password='root',host='127.0.0.1',database='python')
                              
cursor = cnx.cursor()




try:
    cursor.execute(
        "CREATE DATABASE IF NOT EXISTS {} DEFAULT CHARACTER SET 'utf8'".format(DB_NAME))
except mysql.connector.Error as err:
    print("Failed creating database: {}".format(err))
    exit(1)

try:
    cursor.execute("USE {}".format(DB_NAME))
except mysql.connector.Error as err:
    print("Database {} does not exists.".format(DB_NAME))
    if err.errno == errorcode.ER_BAD_DB_ERROR:
        create_database(cursor)
        print("Database {} created successfully.".format(DB_NAME))
        cnx.database = DB_NAME
    else:
        print(err)
        exit(1)

#Drop Earlier table 
cursor.execute("DROP TABLE IF EXISTS  titles, dept_manager, dept_emp, salaries, departments, employees") #auto commit 
        
#create table 
for table_name in TABLES:
    table_description = TABLES[table_name]
    try:
        print("Creating table {}: ".format(table_name), end='')
        cursor.execute(table_description)
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("already exists.")
        else:
            print(err.msg)
    else:
        print("OK")

        
from datetime import date, datetime, timedelta

tomorrow = datetime.date(1999, 1, 1) + timedelta(days=1)
#datetime.now().date() + timedelta(days=1)

add_employee = ("INSERT INTO employees "
               "(first_name, last_name, hire_date, gender, birth_date) "
               "VALUES (%s, %s, %s, %s, %s)")
add_salary = ("INSERT INTO salaries "
              "(emp_no, salary, from_date, to_date) "
              "VALUES (%(emp_no)s, %(salary)s, %(from_date)s, %(to_date)s)")

data_employee = ('Geert', 'Vanderkelen', tomorrow, 'M', date(1977, 6, 14))

# Insert new employee
cursor.execute(add_employee, data_employee)
emp_no = cursor.lastrowid

# Insert salary information
data_salary = {
  'emp_no': emp_no,
  'salary': 50000,
  'from_date': tomorrow,
  'to_date': date(9999, 1, 1),
}
cursor.execute(add_salary, data_salary)

# Make sure data is committed to the database
cnx.commit()
        
import datetime        
query = ("SELECT first_name, last_name, hire_date FROM employees "
         "WHERE hire_date BETWEEN %s AND %s")

hire_start = datetime.date(1999, 1, 1)
hire_end = datetime.date(1999, 12, 31)

cursor.execute(query, (hire_start, hire_end))

for (first_name, last_name, hire_date) in cursor:
    print("{}, {} was hired on {:%d %b %Y}".format(last_name, first_name, hire_date))
        
cursor.close()



# Get two buffered cursors
curA = cnx.cursor(buffered=True)
curB = cnx.cursor(buffered=True)

# Query to get employees who joined in a period defined by two dates
query = (
  "SELECT s.emp_no, salary, from_date, to_date FROM employees AS e "
  "LEFT JOIN salaries AS s USING (emp_no) "
  "WHERE to_date = DATE('9999-01-01')"
  "AND e.hire_date BETWEEN DATE(%s) AND DATE(%s)")

# UPDATE and INSERT statements for the old and new salary
update_old_salary = (
  "UPDATE salaries SET to_date = %s "
  "WHERE emp_no = %s AND from_date = %s")
insert_new_salary = (
  "INSERT INTO salaries (emp_no, from_date, to_date, salary) "
  "VALUES (%s, %s, %s, %s)")

# Select the employees getting a raise
curA.execute(query, (date(2000, 1, 1), date(2000, 12, 31)))

# Iterate through the result of curA
for (emp_no, salary, from_date, to_date) in curA:
  # Update the old and insert the new salary
  new_salary = int(round(salary * Decimal('1.15')))
  curB.execute(update_old_salary, (tomorrow, emp_no, from_date))
  curB.execute(insert_new_salary,(emp_no, tomorrow, date(9999, 1, 1,), new_salary))
  # Commit the changes
  cnx.commit()


cnx.close()
    
  
    
###Executing stored proceedure - mysql 
result_args = cursor.callproc(proc_name, args=())

#Result sets produced by the stored procedure are automatically fetched 
#and stored as MySQLCursorBuffered instances. 

#simple 
mysql> 
DROP PROCEDURE IF EXISTS simpleproc;

delimiter //

CREATE PROCEDURE simpleproc (OUT param1 INT)
BEGIN
    SELECT COUNT(*) INTO param1 FROM DUAL;
END//


delimiter ;
CALL simpleproc(@a);
SELECT @a;

#python 
args = (0,) # 0 is to hold value of the OUT parameter 
cursor.callproc('simpleproc', args)


#Example 
DROP PROCEDURE IF EXISTS multiply;

delimiter //

CREATE PROCEDURE multiply(IN pFac1 INT, IN pFac2 INT, OUT pProd INT)
BEGIN
  SET pProd := pFac1 * pFac2;
END//

delimiter ;
CALL multiply(1,2, @a);
SELECT @a;

#python code 
args = (5, 6, 0) # 0 is to hold value of the OUT parameter pProd
>>> cursor.callproc('multiply', args)
('5', '6', 30L)

#OR  with parameter types to be specified. 
#specify a parameter as a two-item tuple consisting of the parameter value and type.
DROP PROCEDURE IF EXISTS sp1;

delimiter //

CREATE PROCEDURE sp1(IN pStr1 VARCHAR(20), IN pStr2 VARCHAR(20), OUT pConCat VARCHAR(100))
BEGIN
  SET pConCat := CONCAT(pStr1, pStr2);
END//
delimiter ;

#code 
args = ('ham', 'eggs', (0, 'CHAR'))
cursor.callproc('sp1', args) #('ham', 'eggs', 'hameggs')


#If you are using sqlalchemy, then 
def call_procedure(function_name, params):
    from sqlalchemy import create_engine
    engine = create_engine('mysql+mysqlconnector://root:root@localhost/employees')
    connection = engine.raw_connection()
    try:
        cursor = connection.cursor()
        results = cursor.callproc(function_name, params)
        cursor.close()
        return results
    finally:
        connection.close()
       
#usage 
call_procedure("sp1", ['x','y','z'])





###*** SQLAlchemy (Py3.x and Py2.7)
$ pip install sqlalchemy



##SQLAlchemy - Quick Tutorial 
https://www.bytefish.de/blog/first_steps_with_sqlalchemy/


##Without any Model class 
#Database Urls - dialect+driver://username:password@host:port/database

#http://docs.sqlalchemy.org/en/latest/core/engines.html#engine-creation-api
from sqlalchemy import create_engine

# sqlite://<nohostname>/<path>
# where <path> is relative:
engine = create_engine('sqlite:///foo.db')
#for an absolute file path
#Unix/Mac - 4 initial slashes in total
engine = create_engine('sqlite:////absolute/path/to/foo.db')
#Windows
engine = create_engine('sqlite:///C:\\path\\to\\foo.db')
#Windows alternative using raw string
engine = create_engine(r'sqlite:///C:\path\to\foo.db')
#To use a SQLite :memory: database, specify an empty URL:
engine = create_engine('sqlite://')

#MySQL
# default
engine = create_engine('mysql://scott:tiger@localhost/foo')
# mysql-python
engine = create_engine('mysql+mysqldb://scott:tiger@localhost/foo')
# MySQL-connector-python
engine = create_engine('mysql+mysqlconnector://scott:tiger@localhost/foo')
# OurSQL
engine = create_engine('mysql+oursql://scott:tiger@localhost/foo')

#Few importants  methods 
engine.scalar(statement, *multiparams, **params)
    Executes and returns the first column of the first row.
engine.execute(statement, *multiparams, **params)
    Executes the given construct and returns a ResultProxy.
engine.has_table(table_name, schema=None)
    Return True if the given backend has a table of the given name.
engine.table_names(schema=None, connection=None)
    Return a list of all table names available in the database.
engine.run_callable(callable_, *args, **kwargs)
    Given a callable object or function, execute it, 
    passing a Connection as the first argument
engine.raw_connection(_connection=None)
    Return a 'raw' DBAPI connection from the connection pool.



#execution 
from sqlalchemy import create_engine
engine = create_engine('mysql+mysqlconnector://root:root@localhost/employees')

###Option-1 : Transaction based commit 
engine.execute("create table if not exists dummy  (id int, value varchar(20))") #autocommited 

with engine.begin() as conn:
    conn.execute("insert into dummy (id, value) values (1, '23')")
    
    
#OR directly - autocomitted 
#multiple , note for mysqlconnector, the parameter marker is %s , for many others, the parameter marker is ?(check reference manual)
#There is not relation between %s as parameter marker and %s as string formatting 
#Irrespective of data types, the parameter marker is %s 

engine.execute("INSERT INTO dummy (id, value) VALUES (%s, %s)", (1, "v1"), (2, "v2"))
#single 
engine.execute("INSERT INTO dummy (id, value) VALUES (%s, %s)",  1, "v1")

#with trx boundary 
def do_something(conn, x, y):
    conn.execute("INSERT INTO dummy (id, value) VALUES (%(x)s, %(y)s)", {'x':x, 'y':y})  #no :x, :y syntax 
   
engine.transaction(do_something, 5, '10')

#then result 
result = engine.execute("select * from dummy")
for row in result:
    print(row) #a tuple 
result.close() 


    
    
    
    
###Option-2: Get connection and execute 
conn = engine.connect()
#multiple 
conn.execute("INSERT INTO dummy (id, value) VALUES (%s, %s)", (1, "v1"), (2, "v2"))
#single 
conn.execute("INSERT INTO dummy (id, value) VALUES (%s, %s)",  1, "v1")

#with trx boundary call trans.rollback() or trans2.commit()
trans = conn.begin()   # transaction
conn.execute("insert into dummy values (1, 2)")
trans.commit()         # actually commits
#or 
with conn.begin():
    conn.execute("insert into dummy values (1, 2)")

#check below 
conn.begin_nested() 
    use a SAVEPOINT
conn.begin_twophase() 
    use a two phase /XID transaction


#result 
result = conn.execute("select * from dummy")
for row in result:
    print(row) #tuple 
    
conn.close()
    





###OPTION-3: DBAPI-agnostic way( without using ? or %s) 
from sqlalchemy import text
from sqlalchemy import Table, Column, Integer, String, MetaData, ForeignKey, DateTime

connection = engine.connect()

t = text("SELECT * FROM dummy")
result = connection.execute(t)

#For SQL statements where a colon is required verbatim
t = text("SELECT * FROM dummy WHERE id='\:id'")
#with elaborate binding 
t = text("SELECT * FROM dummy WHERE id=:user_id").bindparams(user_id=1).\
        columns(id=Integer, value=String)
#or 
from sqlalchemy.sql import column
t = text("SELECT * FROM dummy WHERE id=:user_id").bindparams(user_id=1).columns(
                      column('id', Integer),
                      column('value', String)
                  )
for id, name in connection.execute(t):
    print(id, name)
    
#multiple bindparams 
t = text("SELECT id, name FROM user WHERE name=:name AND timestamp=:timestamp")\
        .bindparams(name='jack', timestamp=datetime.datetime(2012, 10, 8, 15, 12, 5))
#or 
from sqlalchemy import bindparam
t=text("SELECT id, name FROM user WHERE name=:name AND timestamp=:timestamp").bindparams(
                bindparam('name', value='jack', type_=String),
                bindparam('timestamp', type_=DateTime)
            )    

#with Proc 
t = text("EXEC my_procedural_thing()").execution_options(autocommit=True)
result = connection.execute(t)
conn.close()   
   
   
###Option-4:Using SQlAlchemy core 

from sqlalchemy import Table, Column, Integer, String, MetaData, ForeignKey
#check other types - https://docs.sqlalchemy.org/en/latest/core/types.html

metadata = MetaData()
users = Table('users', metadata,
    Column('id', Integer, primary_key=True),
    Column('name', String(50)),
    Column('fullname', String(50)),
)

addresses = Table('addresses', metadata,
  Column('id', Integer, primary_key=True),
  Column('user_id', None, ForeignKey('users.id')),
  Column('email_address', String(50), nullable=False)
 )

#This will check for the presence of each table first before creating, so it�s safe to call multiple times:
metadata.create_all(engine)

conn = engine.connect()
#conn.close()

#Insert Expressions
ins = users.insert()
>>> str(ins)
'INSERT INTO users (id, name, fullname) VALUES (:id, :name, :fullname)'


#Notice above that the INSERT statement names every column in the users table. 
#This can be limited by using the values() method
ins = users.insert().values(name='jack', fullname='Jack Jones')
>>> str(ins)
'INSERT INTO users (name, fullname) VALUES (:name, :fullname)'


#Executing
>>> result = conn.execute(ins)
INSERT INTO users (name, fullname) VALUES (?, ?)
('jack', 'Jack Jones')
COMMIT


#Executing Multiple Statements - autocommit 
>>> ins = users.insert()
>>> conn.execute(ins, id=2, name='wendy', fullname='Wendy Williams')
INSERT INTO users (id, name, fullname) VALUES (?, ?, ?)
(2, 'wendy', 'Wendy Williams')
COMMIT

conn.execute(addresses.insert(), [
   {'user_id': 1, 'email_address' : 'jack@yahoo.com'},
   {'user_id': 1, 'email_address' : 'jack@msn.com'},
   {'user_id': 2, 'email_address' : 'www@www.org'},
   {'user_id': 2, 'email_address' : 'wendy@aol.com'},
])


#Selecting

from sqlalchemy.sql import select
s = select([users])
result = conn.execute(s)

#tuple like 
for row in result:
    print(row)

#or dictionary 
result = conn.execute(s)
row = result.fetchone()
print("name:", row['name'], "; fullname:", row['fullname'])

#OR Integer 
row = result.fetchone()
print("name:", row[1], "; fullname:", row[2])

#OR use the Column objects directly as keys:
for row in conn.execute(s):
    print("name:", row[users.c.name], "; fullname:", row[users.c.fullname])

result.close()

#OR projection
s = select([users.c.name, users.c.fullname])
result = conn.execute(s)
#tuple 
for row in result:
    print(row)


#OR multiple tables 
for row in conn.execute(select([users, addresses])):
    print(row)

#OR join 
 s = select([users, addresses]).where(users.c.id == addresses.c.user_id)
for row in conn.execute(s):
    print(row)


##Operators

>>> print(users.c.id == addresses.c.user_id)
users.id = addresses.user_id

# bind parameter:
>>> print(users.c.id == 7)
users.id = :id_1

#Most Python operators produce a SQL expression here, like equals, not equals, etc.:
>>> print(users.c.id != 7)
users.id != :id_1

# None converts to IS NULL
>>> print(users.c.name == None)
users.name IS NULL

# reverse works too
>>> print('fred' > users.c.name)
users.name < :name_1

#addition expression:
>>> print(users.c.id + addresses.c.id)
users.id + addresses.id

#the type of the Column is important - below is string concate , correctly handles all engine 
>>> print(users.c.name + users.c.fullname)
users.name || users.fullname

>>> print((users.c.name + users.c.fullname).compile(bind=create_engine('mysql://'))) 
concat(users.name, users.fullname)

#If a opertaor does not exists in sqlalchemy, use op 
>>> print(users.c.name.op('NEW_OP')('foo'))
users.name NEW_OP :name_1

#bitwise operators explicit
somecolumn.op('&')(0xff)

#When using Operators.op(), the return type of the expression may be important, 
#especialy when the operator is used in an expression that will be sent as a result column. 

from sqlalchemy import type_coerce
expr = type_coerce(somecolumn.op('-%>')('foo'), MySpecialType())
stmt = select([expr])

#For boolean operators, use the Operators.bool_op() method
somecolumn.bool_op('-->')('some value')


##Conjunctions

from sqlalchemy.sql import and_, or_, not_
print(and_(
        users.c.name.like('j%'),
        users.c.id == addresses.c.user_id,
        or_(
             addresses.c.email_address == 'wendy@aol.com',
             addresses.c.email_address == 'jack@yahoo.com'
        ),
        not_(users.c.id > 5)
      )
 )
#equivalent 
users.name LIKE :name_1 AND users.id = addresses.user_id AND
(addresses.email_address = :email_address_1
   OR addresses.email_address = :email_address_2)
AND users.id <= :id_1

#or use &, | ~, but use with parenthesis

print(users.c.name.like('j%') & (users.c.id == addresses.c.user_id) &
    (
      (addresses.c.email_address == 'wendy@aol.com') | \
      (addresses.c.email_address == 'jack@yahoo.com')
    ) \
    & ~(users.c.id>5)
)
#equivalent 
users.name LIKE :name_1 AND users.id = addresses.user_id AND
(addresses.email_address = :email_address_1
    OR addresses.email_address = :email_address_2)
AND users.id <= :id_1

#using between 
s = select([(users.c.fullname +
              ", " + addresses.c.email_address).
               label('title')]).\
       where(
          and_(
              users.c.id == addresses.c.user_id,
              users.c.name.between('m', 'z'),
              or_(
                 addresses.c.email_address.like('%@aol.com'),
                 addresses.c.email_address.like('%@msn.com')
              )
          )
       )
conn.execute(s).fetchall()
#A shortcut to using and_() is to chain together multiple where() clauses
s = select([(users.c.fullname +
              ", " + addresses.c.email_address).
               label('title')]).\
       where(users.c.id == addresses.c.user_id).\
       where(users.c.name.between('m', 'z')).\
       where(
              or_(
                 addresses.c.email_address.like('%@aol.com'),
                 addresses.c.email_address.like('%@msn.com')
              )
       )
conn.execute(s).fetchall()
#OR , use sql directly 
from sqlalchemy.sql import text
s = text(
    "SELECT users.fullname || ', ' || addresses.email_address AS title "
        "FROM users, addresses "
        "WHERE users.id = addresses.user_id "
        "AND users.name BETWEEN :x AND :y "
        "AND (addresses.email_address LIKE :e1 "
            "OR addresses.email_address LIKE :e2)")
            
conn.execute(s, x='m', y='z', e1='%@aol.com', e2='%@msn.com').fetchall()


##Specifying Bound Parameter Behaviors

stmt = text("SELECT * FROM users WHERE users.name BETWEEN :x AND :y")
stmt = stmt.bindparams(x="m", y="z")

#OR 
stmt = stmt.bindparams(bindparam("x", type_=String), bindparam("y", type_=String))
result = conn.execute(stmt, {"x": "m", "y": "z"})

##Specifying Result-Column Behaviors
stmt = stmt.columns(id=Integer, name=String)

#or
stmt = text("SELECT id, name FROM users")
stmt = stmt.columns(users.c.id, users.c.name)

#or using complex 
j = stmt.join(addresses, stmt.c.id == addresses.c.user_id)

new_stmt = select([stmt.c.id, addresses.c.id]).\
    select_from(j).where(stmt.c.name == 'x')

#OR 
stmt = text("SELECT users.id, addresses.id, users.id, "
    "users.name, addresses.email_address AS email "
    "FROM users JOIN addresses ON users.id=addresses.user_id "
    "WHERE users.id = 1").columns(
       users.c.id,
       addresses.c.id,
       addresses.c.user_id,
       users.c.name,
       addresses.c.email_address
    )
result = conn.execute(stmt)
row = result.fetchone()
>>> row[addresses.c.email_address]
'jack@yahoo.com'


##Using text() fragments inside bigger statements
s = select([
       text("users.fullname || ', ' || addresses.email_address AS title")
    ]).\
        where(
            and_(
                text("users.id = addresses.user_id"),
                text("users.name BETWEEN 'm' AND 'z'"),
                text(
                    "(addresses.email_address LIKE :x "
                    "OR addresses.email_address LIKE :y)")
            )
        ).select_from(text('users, addresses'))
conn.execute(s, x='%@aol.com', y='%@msn.com').fetchall()

##Using More Specific Text with table(), literal_column(), and column()
from sqlalchemy import select, and_, text, String
from sqlalchemy.sql import table, literal_column
s = select([
   literal_column("users.fullname", String) +
   ', ' +
   literal_column("addresses.email_address").label("title")
]).\
   where(
       and_(
           literal_column("users.id") == literal_column("addresses.user_id"),
           text("users.name BETWEEN 'm' AND 'z'"),
           text(
               "(addresses.email_address LIKE :x OR "
               "addresses.email_address LIKE :y)")
       )
   ).select_from(table('users')).select_from(table('addresses'))

conn.execute(s, x='%@aol.com', y='%@msn.com').fetchall()

##Ordering or Grouping by a Label
from sqlalchemy import func
stmt = select([
        addresses.c.user_id,
        func.count(addresses.c.id).label('num_addresses')]).\
        order_by("num_addresses")

conn.execute(stmt).fetchall()
[(2, 4)]

#asc() or desc() 
from sqlalchemy import func, desc
stmt = select([
        addresses.c.user_id,
        func.count(addresses.c.id).label('num_addresses')]).\
        order_by(desc("num_addresses"))

conn.execute(stmt).fetchall()


#to order by a column name that appears more than once:
u1a, u1b = users.alias(), users.alias()
stmt = select([u1a, u1b]).\
            where(u1a.c.name > u1b.c.name).\
            order_by(u1a.c.name)  # using "name" here would be ambiguous

conn.execute(stmt).fetchall()

##Using Aliases
a1 = addresses.alias()
a2 = addresses.alias()
s = select([users]).\
       where(and_(
           users.c.id == a1.c.user_id,
           users.c.id == a2.c.user_id,
           a1.c.email_address == 'jack@msn.com',
           a2.c.email_address == 'jack@yahoo.com'
       ))
conn.execute(s).fetchall()


##Using Joins
>>> print(users.join(addresses))
users JOIN addresses ON users.id = addresses.user_id

>>> print(users.join(addresses,addresses.c.email_address.like(users.c.name + '%')   )  )
users JOIN addresses ON addresses.email_address LIKE users.name || :name_1

#use  select_from() method instead of select 
s = select([users.c.fullname]).select_from(
   users.join(addresses,
            addresses.c.email_address.like(users.c.name + '%'))
   )
conn.execute(s).fetchall()

[(u'Jack Jones',), (u'Jack Jones',), (u'Wendy Williams',)]

#The outerjoin() method creates LEFT OUTER JOIN constructs
s = select([users.c.fullname]).select_from(users.outerjoin(addresses))
>>> print(s)
SELECT users.fullname
    FROM users
    LEFT OUTER JOIN addresses ON users.id = addresses.user_id

#eg  Oracle-specific SQL:
from sqlalchemy.dialects.oracle import dialect as OracleDialect
>>> print(s.compile(dialect=OracleDialect(use_ansi=False)))
SELECT users.fullname
FROM users, addresses
WHERE users.id = addresses.user_id(+)

##Bind Parameter Objects
from sqlalchemy.sql import bindparam
s = users.select(users.c.name == bindparam('username'))
conn.execute(s, username='wendy').fetchall()

#or with type 
s = users.select(users.c.name.like(bindparam('username', type_=String) + text("'%'")))
conn.execute(s, username='wendy').fetchall()

[(2, u'wendy', u'Wendy Williams')]

#bindparam() constructs of the same name can also be used multiple times
s = select([users, addresses]).\
    where(
       or_(
         users.c.name.like(
                bindparam('name', type_=String) + text("'%'")),
         addresses.c.email_address.like(
                bindparam('name', type_=String) + text("'@%'"))
       )
    ).\
    select_from(users.outerjoin(addresses)).\
    order_by(addresses.c.id)
conn.execute(s, name='jack').fetchall()


##Functions
from sqlalchemy.sql import func
>>> print(func.now())
now()

>>> print(func.concat('x', 'y'))
concat(:concat_1, :concat_2)

#any SQL function is created based on the word you choose:
>>> print(func.xyz_my_goofy_function())
xyz_my_goofy_function()

#Certain function names are known by SQLAlchemy, 
#Some for example are �ANSI� functions, which mean they don�t get the parenthesis added after them, such as CURRENT_TIMESTAMP:

>>> print(func.current_timestamp())
CURRENT_TIMESTAMP

#Functions are most typically used in the columns clause of a select statement
conn.execute(
    select([
           func.max(addresses.c.email_address, type_=String).
               label('maxemail')
          ])
    ).scalar()

u'www@www.org'

#Databases such as PostgreSQL and Oracle which support functions that return whole result sets
#eg  a database function calculate() which takes the parameters x and y, and returns three columns 
#which we�d like to name q, z and r

from sqlalchemy.sql import column
calculate = select([column('q'), column('z'), column('r')]).\
       select_from(
            func.calculate(
                   bindparam('x'),
                   bindparam('y')
               )
            )
calc = calculate.alias()
print(select([users]).where(users.c.id > calc.c.z))


#to use our calculate statement twice with different bind parameters, use unique_params()
calc1 = calculate.alias('c1').unique_params(x=17, y=45)
calc2 = calculate.alias('c2').unique_params(x=5, y=12)
s = select([users]). where(users.c.id.between(calc1.c.z, calc2.c.z))
>>> print(s)
SELECT users.id, users.name, users.fullname
FROM users,
    (SELECT q, z, r FROM calculate(:x_1, :y_1)) AS c1,
    (SELECT q, z, r FROM calculate(:x_2, :y_2)) AS c2
WHERE users.id BETWEEN c1.z AND c2.z

>>> s.compile().params 
{u'x_2': 5, u'y_2': 12, u'y_1': 45, u'x_1': 17}


##Window Functions
s = select([
        users.c.id,
        func.row_number().over(order_by=users.c.name)
    ])
>>> print(s)
SELECT users.id, row_number() OVER (ORDER BY users.name) AS anon_1
FROM users

#range specification 
s = select([
        users.c.id,
        func.row_number().over(
                order_by=users.c.name,
                rows=(-2, None))
    ])
>>> print(s)
SELECT users.id, row_number() OVER
(ORDER BY users.name ROWS BETWEEN :param_1 PRECEDING AND UNBOUNDED FOLLOWING) AS anon_1
FROM users


##Unions UNION and UNION ALL, and Other Set Operations

from sqlalchemy.sql import union
u = union(
    addresses.select().
            where(addresses.c.email_address == 'foo@bar.com'),
   addresses.select().
            where(addresses.c.email_address.like('%@yahoo.com')),
).order_by(addresses.c.email_address)

conn.execute(u).fetchall()


#though not supported on all databases, are intersect(), intersect_all(), except_(), and except_all():
from sqlalchemy.sql import except_
u = except_(
   addresses.select().
            where(addresses.c.email_address.like('%@%.com')),
   addresses.select().
            where(addresses.c.email_address.like('%@msn.com'))
)

conn.execute(u).fetchall()

#A common issue with so-called �compound� selectables arises due to the fact that they nest with parenthesis. 
#SQLite in particular doesn�t like a statement that starts with parenthesis. 
#So when nesting a �compound� inside a �compound�, it�s often necessary to apply .alias().select() to the first element of the outermost compound, if that element is also a compound. 
#For example, to nest a �union� and a �select� inside of �except_�, SQLite will want the �union� to be stated as a subquery:

u = except_(
   union(
        addresses.select().
            where(addresses.c.email_address.like('%@yahoo.com')),
        addresses.select().
            where(addresses.c.email_address.like('%@msn.com'))
    ).alias().select(),   # apply subquery here
   addresses.select(addresses.c.email_address.like('%@msn.com'))
)
conn.execute(u).fetchall()


##Scalar Selects
#A scalar select is a SELECT that returns exactly one row and one column. 
#It can then be used as a column expression.
# A scalar select is often a correlated subquery, which relies upon the enclosing SELECT statement in order to acquire at least one of its FROM clauses.

stmt = select([func.count(addresses.c.id)]).\
            where(users.c.id == addresses.c.user_id).\
            as_scalar()
>>> conn.execute(select([users.c.name, stmt])).fetchall()
[(u'jack', 2), (u'wendy', 2)]

#To apply a non-anonymous column name to our scalar select, use  SelectBase.label() instead:
stmt = select([func.count(addresses.c.id)]).\
            where(users.c.id == addresses.c.user_id).\
            label("address_count")
            
>>> conn.execute(select([users.c.name, stmt])).fetchall()
[(u'jack', 2), (u'wendy', 2)]


##Correlated Subqueries
#SQLAlchemy automatically correlates embedded FROM objects to that of an enclosing query, if present, 
#and if the inner SELECT statement would still have at least one FROM clause of its own

stmt = select([addresses.c.user_id]).\
            where(addresses.c.user_id == users.c.id).\
            where(addresses.c.email_address == 'jack@yahoo.com')
enclosing_stmt = select([users.c.name]).where(users.c.id == stmt)
conn.execute(enclosing_stmt).fetchall()

#For example, if we wanted a statement to correlate only to the addresses table but not the users table, 
#even if both were present in the enclosing SELECT, we use the correlate() method to specify those FROM clauses that may be correlated:
stmt = select([users.c.id]).\
            where(users.c.id == addresses.c.user_id).\
            where(users.c.name == 'jack').\
            correlate(addresses)
enclosing_stmt = select(
        [users.c.name, addresses.c.email_address]).\
    select_from(users.join(addresses)).\
    where(users.c.id == stmt)
conn.execute(enclosing_stmt).fetchall()

#To entirely disable a statement from correlating, we can pass None as the argument:
stmt = select([users.c.id]).\
            where(users.c.name == 'wendy').\
            correlate(None)
enclosing_stmt = select([users.c.name]).\
    where(users.c.id == stmt)
conn.execute(enclosing_stmt).fetchall()


#OR control correlation via exclusion, using the Select.correlate_except() method. 
#Such as, we can write our SELECT for the users table by telling it to correlate all FROM clauses except for users:
stmt = select([users.c.id]).\
            where(users.c.id == addresses.c.user_id).\
            where(users.c.name == 'jack').\
            correlate_except(users)
enclosing_stmt = select(
        [users.c.name, addresses.c.email_address]).\
    select_from(users.join(addresses)).\
    where(users.c.id == stmt)
conn.execute(enclosing_stmt).fetchall()


##Ordering, Grouping, Limiting, Offset�ing�
stmt = select([users.c.name]).order_by(users.c.name)
>>> conn.execute(stmt).fetchall()
[(u'jack',), (u'wendy',)]

stmt = select([users.c.name]).order_by(users.c.name.desc())
>>> conn.execute(stmt).fetchall()
[(u'wendy',), (u'jack',)]

#Grouping
stmt = select([users.c.name, func.count(addresses.c.id)]).\
            select_from(users.join(addresses)).\
            group_by(users.c.name)
conn.execute(stmt).fetchall()


#HAVING can be used to filter results on an aggregate value, after GROUP BY has been applied. 
stmt = select([users.c.name, func.count(addresses.c.id)]).\
            select_from(users.join(addresses)).\
            group_by(users.c.name).\
            having(func.length(users.c.name) > 4)
conn.execute(stmt).fetchall()


#DISTINCT modifier
stmt = select([users.c.name]).\
            where(addresses.c.email_address.
                   contains(users.c.name)).\
            distinct()
conn.execute(stmt).fetchall()

#limiting 
stmt = select([users.c.name, addresses.c.email_address]).\
            select_from(users.join(addresses)).\
            limit(1).offset(1)
conn.execute(stmt).fetchall()


##Inserts, Updates and Deletes
stmt = users.update().values(fullname="Fullname: " + users.c.name)
>>> conn.execute(stmt)
UPDATE users SET fullname=(? || users.name)
('Fullname: ',)
COMMIT

#with bindparam
stmt = users.insert().values(name=bindparam('_name') + " .. name")
conn.execute(stmt, [
       {'id':4, '_name':'name1'},
       {'id':5, '_name':'name2'},
       {'id':6, '_name':'name3'},
    ])


#With Update additional WHERE clause that can be specified:
stmt = users.update().\
            where(users.c.name == 'jack').\
            values(name='ed')

conn.execute(stmt)

#with bindparam 
stmt = users.update().\
            where(users.c.name == bindparam('oldname')).\
            values(name=bindparam('newname'))
conn.execute(stmt, [
    {'oldname':'jack', 'newname':'ed'},
    {'oldname':'wendy', 'newname':'mary'},
    {'oldname':'jim', 'newname':'jake'},
    ])


##Correlated Updates
#A correlated update lets you update a table using selection from another table, or the same table:
stmt = select([addresses.c.email_address]).\
            where(addresses.c.user_id == users.c.id).\
            limit(1)
>>> conn.execute(users.update().values(fullname=stmt))
UPDATE users SET fullname=(SELECT addresses.email_address
    FROM addresses
    WHERE addresses.user_id = users.id
    LIMIT ? OFFSET ?)
(1, 0)
COMMIT

<sqlalchemy.engine.result.ResultProxy object at 0x...>


##Multiple Table Updates
#The PostgreSQL, Microsoft SQL Server, and MySQL backends all support UPDATE statements that refer to multiple tables. 
stmt = users.update().\
        values(name='ed wood').\
        where(users.c.id == addresses.c.id).\
        where(addresses.c.email_address.startswith('ed%'))
conn.execute(stmt)

#The resulting SQL from the above statement would render as:
UPDATE users SET name=:name FROM addresses
WHERE users.id = addresses.id AND
addresses.email_address LIKE :email_address_1 || '%'

#When using MySQL, columns from each table can be assigned to in the SET clause directly, 
#using the dictionary form passed to Update.values():
stmt = users.update().\
        values({
            users.c.name:'ed wood',
            addresses.c.email_address:'ed.wood@foo.com'
        }).\
        where(users.c.id == addresses.c.id).\
        where(addresses.c.email_address.startswith('ed%'))

#The tables are referenced explicitly in the SET clause:
UPDATE users, addresses SET addresses.email_address=%s,
        users.name=%s WHERE users.id = addresses.id
        AND addresses.email_address LIKE concat(%s, '%')


##Deletes
>>> conn.execute(addresses.delete())
DELETE FROM addresses
()
COMMIT


>>> conn.execute(users.delete().where(users.c.name > 'm'))
DELETE FROM users WHERE users.name > ?
('m',)
COMMIT

##Multiple Table Deletes
#The PostgreSQL, Microsoft SQL Server, and MySQL backends all support DELETE statements that refer to multiple tables within the WHERE criteria. For PG and MySQL, this is the �DELETE USING� syntax, and for SQL Server, it�s a �DELETE FROM� that refers to more than one table. The SQLAlchemy delete() construct supports both of these modes implicitly, by specifying multiple tables in the WHERE clause:
stmt = users.delete().\
        where(users.c.id == addresses.c.id).\
        where(addresses.c.email_address.startswith('ed%'))
conn.execute(stmt)



##Matched Row Counts
#Both of update() and delete() are associated with matched row counts
result = conn.execute(users.delete())
>>> result.rowcount
1

   
   
   
   
   
###Option-5: Using  AutomapBase  to create automatically all classes and relationships 
#NOte: SQLAlchemy Automap does not create class for tables without primary key

from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session
from sqlalchemy import create_engine

Base = automap_base()

# engine, suppose it has two tables 'user' and 'addresses' set up
#engine = create_engine("sqlite:///mydatabase.db")
auto_engine = create_engine('mysql+mysqlconnector://root:root@localhost/employees')

# reflect the tables
Base.prepare(auto_engine, reflect=True)

>>> Base.classes.keys()
['addresses', 'users']

# mapped classes are now created with names by default matching that of the table name.
User = Base.classes.users
Address = Base.classes.addresses

session = Session(auto_engine)

# rudimentary relationships are produced
session.add(Address(email_address="foo@bar.com", user_id=2))
session.commit()



# collection-based relationships are by default named "<classname>_collection"
#session.add(Address(email_address="foo@bar.com", user=User(name="foo", fullname="foofull")))
#print (u1.address_collection)


session.query(User).count()

a = session.query(User) \
    .filter(User.id < 3) \
    .all()

for user in a:
    print(user.name, user.fullname, user.id)
    for add in user.addresses_collection:
        print(add.email_address, add.user_id)
        

##OR with explicit schema 
from sqlalchemy import create_engine, MetaData, Table, Column, ForeignKey

# produce our own MetaData object
metadata = MetaData()

# we can reflect it ourselves from a database, using options such as 'only' to limit what tables we look at...
metadata.reflect(engine, only=['user', 'address'])

# ... or just define our own Table objects with it (or combine both)
Table('user_order', metadata,
                Column('id', Integer, primary_key=True),
                Column('user_id', ForeignKey('user.id'))
            )

# we can then produce a set of mappings from this MetaData.
Base = automap_base(metadata=metadata)

# calling prepare() just sets up mapped classes and relationships.
Base.prepare()

# mapped classes are ready
User, Address, Order = Base.classes.user, Base.classes.address, Base.classes.user_order








###SQLAlchemy - With Model and associations 
#uses the declarative extensions of SQLAlchemy. 
#declarative_base is a factory function, that returns a base class (actually a metaclass), 
#and the entities are going to inherit from it. 

#Once the definition of the class is done, 
#the Table and mapper will be generated automatically. 
#Only define explicitly table name, primary keys and relationships.

#create the Base class:

from sqlalchemy.ext.declarative import declarative_base
Base = declarative_base()

'''
A one to many relationship places a foreign key on the child table(Child class) 
referencing the parent(Parent). 
relationship() is then specified on the parent(Parent class), 
as referencing a collection of items represented by the child:

class Parent(Base):
    __tablename__ = 'parent'
    id = Column(Integer, primary_key=True)
    children = relationship("Child")

class Child(Base):
    __tablename__ = 'child'
    id = Column(Integer, primary_key=True)
    parent_id = Column(Integer, ForeignKey('parent.id'))
    
To establish a bidirectional relationship in one-to-many, 
where the 'reverse' side is a many to one, 
use  backref option on a Parent relationship() eg 
Child.parent would created on Child to access parent 
children = relationship("Child", backref="parent")


'''

'''
Many to Many adds an association table between two classes. 
There is no need to delete from this table manually, it is handled automatically
The association table is indicated by the secondary argument to relationship() of Parent class . 

association_table = Table('association', Base.metadata,
    Column('left_id', Integer, ForeignKey('left.id')),
    Column('right_id', Integer, ForeignKey('right.id'))
)

class Parent(Base):
    __tablename__ = 'left'
    id = Column(Integer, primary_key=True)
    children = relationship("Child",secondary=association_table)

class Child(Base):
    __tablename__ = 'right'
    id = Column(Integer, primary_key=True)
    
For a bidirectional relationship, 
both sides of the relationship contain a collection, Use backref on Parent realtionship()
Child.parents would created on Child to access parents 
children = relationship("Child",secondary=association_table, backref="parents")

'''

'''
sqlalchemy.orm.relationship(argument, secondary=None, primaryjoin=None, 
        secondaryjoin=None, foreign_keys=None, uselist=None, order_by=False, 
        backref=None, back_populates=None, post_update=False, cascade=False, 
        extension=None, viewonly=False, lazy='select', collection_class=None, 
        passive_deletes=False, passive_updates=True, remote_side=None, 
        enable_typechecks=True, join_depth=None, comparator_factory=None, 
        single_parent=False, innerjoin=False, distinct_target_key=None, 
        doc=None, active_history=False, cascade_backrefs=True, 
        load_on_pending=False, bake_queries=True, _local_remote_pairs=None, 
        query_class=None, info=None)
    Provide a relationship between two mapped classes
sqlalchemy.orm.backref(name, **kwargs)
    Create a back reference with explicit keyword arguments, 
    which are the same arguments one can send to relationship().
    Note name attribute would be created Other objects 

lazy types 
    lazy='dynamic' 
        Valid for a one-to-many or many-to-many relationship, 
        as 'children' would be Python collection for these relations 
        However with this, 'children' is a Query object in place of a collection 
        and filter() criterion may be applied as well as limits and offsets, either explicitly or via array slices
    lazy='noload'   
        A 'noload' relationship never loads from the database
        children would be empty          
    lazy='select'
        By default, all inter-object relationships are lazy loading ie load upon attribute access
    lazy='raise'
        lazy='select' causes  N plus one problem
        for any  N objects loaded, accessing their lazy-loaded attributes means 
        there will be N+1 SELECT statements emitted
        This options would make children empty and if somebody accesses children, would raise Exception
    lazy="joined"
        Eager loading in the ORM
        This form of loading applies a JOIN to the given SELECT statement 
        so that related rows are loaded in the same result set. 
    lazy='subquery' 
        Emits a second SELECT statement for each relationship to be loaded, 
        across all result objects at once
        Advantages compared to 'joined'
        it allows the original query to proceed without changing it at all
        it allows for many collections to be eagerly loaded without producing a single query that has many JOINs in it, which can be even less efficient
    lazy='selectin' 
        Emits a second (or more) SELECT statement 
        which assembles the primary key identifiers of the parent objects 
        into an IN clause, so that all members of related collections / scalar references are loaded at once by primary key
        In general, 'selectin' loading is probably superior to 'subquery' eager loading in most ways
        
'''


from datetime import datetime, timedelta
from sqlalchemy import Table, Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship, backref



#Bidirectional One to Many : One Image, Many Comment 
#Here Parent = Image , Child = Comment , 
#Parent gets 'children=relationship('Child', backref='parent'), children is Python collection
#Child gets foreign key 'parent_id = Column(Integer, ForeignKey('parent.id'))'


#Bidirectional Many to Many relation with association table 
#Here Parent = Image , Child = Tag , association table = tags 
#Parent gets 'children = relationship("Child",secondary=association_table, backref='parent'), children is Python collection
#Child gets nothing 



tags = Table('tag_image', Base.metadata,
    Column('tag_id', Integer, ForeignKey('tags.id')),    #tags = table name of Tag 
    Column('image_id', Integer, ForeignKey('images.id')) #images = Table name of Image 
)

class Image(Base):  
    __tablename__ = 'images'
    id          =   Column(Integer, primary_key=True)
    uuid        =   Column(String(36), unique=True, nullable=False)
    likes       =   Column(Integer, default=0)
    created_at  =   Column(DateTime, default=datetime.utcnow)
    #has .tags  and each tag has .images 
    tags        =   relationship('Tag', secondary=tags, backref = backref('images', lazy='dynamic'))
    #has .comments and each comment has .image 
    comments    =   relationship('Comment', backref='image', lazy='dynamic')
    def __repr__(self):
        str_created_at = self.created_at.strftime("%Y-%m-%d %H:%M:%S")
        return "<Image (uuid='%s', likes='%d', created_at=%s)>" % (self.uuid, self.likes, str_created_at)

class Tag(Base):
    __tablename__ = 'tags'
    id      =   Column(Integer, primary_key=True)
    name    =   Column(String(255), unique=True, nullable=False)
    def __repr__(self):
        return "<Tag (name='%s')>" % (self.name)

class Comment(Base):
    __tablename__ = 'comments'
    id          =   Column(Integer, primary_key=True)
    text        =   Column(String(2000))
    image_id    =   Column(Integer, ForeignKey('images.id'))
    def __repr__(self):
        return "<Comment (text='%s')>" % (self.text)


##Connecting and Creating the Schema

from sqlalchemy import create_engine

#for sqlite hack 
from sqlalchemy import event
@event.listens_for(Engine, "connect")
def set_sqlite_pragma(dbapi_connection, connection_record):
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.close()
    

engine = create_engine('sqlite:///:memory:', echo=True)
#generates the Schema:
Base.metadata.create_all(engine)


#With echo=True for the engine, below SQL would be generated :
CREATE TABLE tags (
        id INTEGER NOT NULL,
        name VARCHAR(255) NOT NULL,
        PRIMARY KEY (id),
        UNIQUE (name)
)
COMMIT

CREATE TABLE images (
        id INTEGER NOT NULL,
        uuid VARCHAR(36) NOT NULL,
        likes INTEGER,
        created_at DATETIME,
        PRIMARY KEY (id),
        UNIQUE (uuid)
)
COMMIT

CREATE TABLE tag_image (
        tag_id INTEGER,
        image_id INTEGER,
        FOREIGN KEY(tag_id) REFERENCES tags (id),
        FOREIGN KEY(image_id) REFERENCES images (id)
)
COMMIT

CREATE TABLE comments (
        id INTEGER NOT NULL,
        text VARCHAR(2000),
        image_id INTEGER,
        PRIMARY KEY (id),
        FOREIGN KEY(image_id) REFERENCES images (id)
)
COMMIT


##Handling Sessions to DB 

from sqlalchemy.orm import sessionmaker

Session = sessionmaker(bind=engine)
session = Session()

#Note attributes are accessed as Class.attribute_var 
#Instance is created like Class(attribute_var=value,...)
#.id are automatically created 
#On to Many, Image to comments , comments  is python collection 
#Many to Many , Image to tags, tags is python collection 

##Insert
tag_cool = Tag(name='cool')
tag_car = Tag(name='car')
tag_animal = Tag(name='animal')

comment_rhino = Comment(text='Rhinoceros, often abbreviated as rhino, is a group of five extant species of odd-toed ungulates in the family Rhinocerotidae.')

image_car = Image(uuid='uuid_car', tags=[tag_car, tag_cool],created_at=(datetime.utcnow() - timedelta(days=1)))
image_another_car = Image(uuid='uuid_anothercar', tags=[tag_car])
image_rhino = Image(uuid='uuid_rhino', tags=[tag_animal], comments=[comment_rhino])


#add the records and commit the work:
session.add(tag_cool)
session.add(tag_car)
session.add(tag_animal)
session.add(comment_rhino)
session.add(image_car)
session.add(image_another_car)
session.add(image_rhino)
session.commit()


#The generated SQL appears in the command prompt:
BEGIN
INSERT INTO tags (name) VALUES (?)('cool',)
INSERT INTO tags (name) VALUES (?)('car',)
INSERT INTO tags (name) VALUES (?)('animal',)
INSERT INTO images (uuid, likes, created_at) VALUES (?, ?, ?)('uuid_car', 0, '2014-12-20 19:16:19.822000')
INSERT INTO images (uuid, likes, created_at) VALUES (?, ?, ?)('uuid_anothercar', 0, '2014-12-21 19:16:19.828000')
INSERT INTO images (uuid, likes, created_at) VALUES (?, ?, ?)('uuid_rhino', 0, '2014-12-21 19:16:19.829000')
INSERT INTO tag_image (tag_id, image_id) VALUES (?, ?)((2, 1), (1, 1), (3, 3), (2, 2))
INSERT INTO comments (text, image_id) VALUES (?, ?)('Rhinoceros, often abbreviated as rhino, is a group of five extant species of odd-toed ungulates in the family Rhinocerotidae.', 3)
COMMIT


##Update
# Find the image with the given uuid:
image_to_update = session.query(Image).filter(Image.uuid == 'uuid_rhino').first()
# Increase the number of upvotes:
image_to_update.likes = image_to_update.likes + 1
# And commit the work:
session.commit()


#The generated SQL appears in the command prompt:
SELECT images.id AS images_id, images.uuid AS images_uuid, images.likes AS images_likes, images.created_at AS images_created_at
        FROM imagesWHERE images.uuid = ? LIMIT ? OFFSET ? ('uuid_rhino', 1, 0)
UPDATE images SET likes=? WHERE images.id = ? (1, 3)
COMMIT


##Delete
session.delete(image_rhino)
session.commit()

#The generated SQL appears in the command prompt:
#comments of an image do not get deleted once the image is deleted. 
#orphaned tags are not deleted
SELECT images.id AS images_id, images.uuid AS images_uuid, images.likes AS images_likes, images.created_at AS images_created_at
    FROM images WHERE images.id = ? (3,)
SELECT comments.id AS comments_id, comments.text AS comments_text, comments.image_id AS comments_image_id
    FROM comments WHERE ? = comments.image_id (3,)
sqlalchemy.engine.base.Engine SELECT tags.id AS tags_id, tags.name AS tags_name 
    FROM tags, tag_image WHERE ? = tag_image.image_id AND tags.id = tag_image.tag_id (3,)
DELETE FROM tag_image WHERE tag_image.tag_id = ? AND tag_image.image_id = ? (3, 3)
UPDATE comments SET image_id=? WHERE comments.id = ? (None, 1)
DELETE FROM images WHERE images.id = ? (3,)
COMMIT (1,)


#If you want the comments to be deleted, 
#when the parent image is deleted, then add a cascade = "all,delete" to the relationship declaration:
comments = relationship('Comment', cascade = "all,delete", backref='image', lazy='dynamic')



##Queries
#http://docs.sqlalchemy.org/en/latest/orm/query.html
#To force query, use .all(), .count(), .one() etc actions 
#.filter() etc returns another query 

#Note attributes are accessed as Class.attribute_var 
#One to Many, Image to comments , comments  is python collection 
#Many to Many , Image to tags, tags is python collection 


# Get a list of tags:
for name in session.query(Tag.name).order_by(Tag.name):
    print(name)

# How many tags do we have?
session.query(Tag).count()

# Get all images created yesterday:
session.query(Image) \
    .filter(Image.created_at < datetime.utcnow().date()) \
    .all()

# Get all images, that belong to the tag 'car' or 'animal', using a subselect:
session.query(Image) \
    .filter(Image.tags.any(Tag.name.in_(['car', 'animal']))) \
    .all()

# This can also be expressed with a join:
session.query(Image) \
    .join(Tag, Image.tags) \
    .filter(Tag.name.in_(['car', 'animal'])) \
    .all()

# Play around with functions:
from sqlalchemy.sql import func, desc

max_date = session.query(func.max(Image.created_at))
session.query(Image).filter(Image.created_at == max_date).first()

# Get a list of tags with the number of images:
q = session.query(Tag, func.count(Tag.name)) \
    .outerjoin(Image, Tag.images) \
    .group_by(Tag.name) \
    .order_by(desc(func.count(Tag.name))) \
    .all()

for tag, count in q:
    print 'Tag "%s" has %d images.' % (tag.name, count) 

# Get images created in the last two hours and zero likes so far:
session.query(Image) \
    .join(Tag, Image.tags) \
    .filter(Image.created_at > (datetime.utcnow() - timedelta(hours=2))) \
    .filter(Image.likes == 0) \
    .all()



    
    
    
###*** Python Logging 

#Logging from multiple threads requires no special effort as logging is threadsafe 
#logging from multiple process to same file not supported, use SocketHandler(host, port) 
#or DatagramHandler(host, port)or HTTPHandler(host, url, method='GET') 
#to send to server and let server handle as it sees fit 
#or use advanced multiprocessing module with Lock as locking mechanism


#you can pass contextual information to be output along with logging event information- use the LoggerAdapter class
#you can use filtering mechanisms using using a user-defined Filter


##Logger hierarchy 
#Child loggers propagate messages up to the handlers associated with their ancestor loggers(till root looger)
#For example, given a logger with a name of foo, loggers with names of foo.bar, foo.bar.baz, and foo.bam are all descendants of foo

#Root level Logger - any configuration on this would be used if child logger is not configured 
#default level is WARNING 
rootLogger = logging.getLogger()

#child logger - eg Module level logger 
logger = logging.getLogger(__name__)





##Logging 
Logger.info(msg, *args, **kwargs)
    Logs a message with level INFO on this logger. The arguments are interpreted as for debug().
Logger.warning(msg, *args, **kwargs)
    Logs a message with level WARNING on this logger. The arguments are interpreted as for debug().
Logger.error(msg, *args, **kwargs)
    Logs a message with level ERROR on this logger. The arguments are interpreted as for debug().
Logger.critical(msg, *args, **kwargs)
    Logs a message with level CRITICAL on this logger. The arguments are interpreted as for debug().
Logger.log(lvl, msg, *args, **kwargs)
    Logs a message with integer level lvl on this logger. The other arguments are interpreted as for debug().
Logger.setLevel(level)
    Sets the threshold for this logger to level.

    
    
##basic usages 

import logging

# create logger
logger = logging.getLogger('simple_example')
logger.setLevel(logging.DEBUG)

# create console handler and set level to debug
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to ch
ch.setFormatter(formatter)

# add ch to logger
logger.addHandler(ch)

# 'application' code
logger.debug('debug message')
logger.info('info message')
logger.warn('warn message')
logger.error('error message')
logger.critical('critical message')

##OR with config file 

import logging
import logging.config

#disable any existing loggers 
logging.config.fileConfig('logging.conf', disable_existing_loggers=True)

# create logger
logger = logging.getLogger('simpleExample')

# 'application' code
logger.debug('debug message')
logger.info('info message')
logger.warn('warn message')
logger.error('error message')
logger.critical('critical message')


#logging.conf file:
[loggers]
keys=root,simpleExample

[handlers]
keys=consoleHandler

[formatters]
keys=simpleFormatter

[logger_root]
level=DEBUG
handlers=consoleHandler

[logger_simpleExample]
level=DEBUG
handlers=consoleHandler
qualname=simpleExample
propagate=0

[handler_consoleHandler]
class=StreamHandler
level=DEBUG
formatter=simpleFormatter
args=(sys.stdout,)

[formatter_simpleFormatter]
format=%(asctime)s - %(name)s - %(levelname)s - %(message)s
datefmt=






##Multiple logging destinations 
#-D.Ds  for formatting info for string 
#'-' The converted value is left adjusted
#first D, Minimum field width , second D= precision 
#check https://pyformat.info/
import logging
logFormatter = logging.Formatter("%(asctime)s [%(threadName)-12.12s] [%(levelname)-5.5s]  %(message)s")
rootLogger = logging.getLogger()

fileHandler = logging.FileHandler("{0}/{1}.log".format(logPath, fileName))
fileHandler.setFormatter(logFormatter)
rootLogger.addHandler(fileHandler)

consoleHandler = logging.StreamHandler()
consoleHandler.setFormatter(logFormatter)
rootLogger.addHandler(consoleHandler)

#Then usage 
rootLogger.warning('%s before you %s', 'Look', 'leap!')

#Prints to the format of:
2012-12-05 16:58:26,618 [MainThread  ] [INFO ]  my message



##Meaning of special syntax 
%(name)s 
    Name of the logger used to log the call. 
%(pathname)s 
    Full pathname of the source file where the logging call was issued (if available). 
%(process)d 
    Process ID (if available). 
%(processName)s 
    Process name 
%(thread)d 
    Thread ID (if available). 
%(threadName)s 
    Thread name (if available). 
%(asctime)s
    Human-readable time when the LogRecord was created. By default this is of the form �2003-07-08 16:49:45,896� (the numbers after the comma are millisecond portion of the time). 
%(filename)s 
    Filename portion of pathname. 
%(funcName)s 
    Name of function containing the logging call. 
%(levelname)s 
    Text logging level for the message ('DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'). 
%(levelno)s 
    Numeric logging level for the message (DEBUG, INFO, WARNING, ERROR, CRITICAL). 
%(lineno)d 
    Source line number where the logging call was issued (if available). 
%(module)s 
    Module (name portion of filename). 
%(msecs)d 
    Millisecond portion of the time when the LogRecord was created. 
%(message)s 
    The logged message, computed as msg % args. 
    
##Handler Support
#Support is included in the package for writing log messages to files, 
#HTTP GET/POST locations, email via SMTP, generic sockets, 
#or OS-specific logging mechanisms such as syslog or the Windows NT event log

#https://docs.python.org/2/library/logging.handlers.html#module-logging.handlers
#under module logging.handlers for all except StreamHandler, FileHandler, NullHandler(under logging)
1.logging.StreamHandler(stream=None) (default stream is sys.stderr) 
    instances send messages to streams (file-like objects).
2.logging.FileHandler(filename, mode='a', encoding=None, delay=False) 
    instances send messages to disk files.
    By default, the file grows indefinitely.
3.BaseRotatingHandler 
    is the base class for handlers that rotate log files at a certain point. It is not meant to be instantiated directly. Instead, use RotatingFileHandler or TimedRotatingFileHandler.
4.logging.handlers.RotatingFileHandler(filename, mode='a', maxBytes=0, backupCount=0, encoding=None, delay=0) 
    instances send messages to disk files, with support for maximum log file sizes and log file rotation.
5.logging.handlers.TimedRotatingFileHandler(filename, when='h', interval=1, backupCount=0, encoding=None, delay=False, utc=False) 
    instances send messages to disk files, rotating the log file at certain timed intervals.
6.logging.handlers.SocketHandler(host, port) 
    instances send messages to TCP/IP sockets.
    don't bother with a formatter, since a socket handler sends the event as an unformatted pickle
7.logging.handlers.DatagramHandler(host, port) 
    instances send messages to UDP sockets.
8.logging.handlers.SMTPHandler(mailhost, fromaddr, toaddrs, subject, credentials=None, secure=None) 
    instances send messages to a designated email address.
9.logging.handlers.SysLogHandler(address=('localhost', SYSLOG_UDP_PORT), facility=LOG_USER, socktype=socket.SOCK_DGRAM) 
    instances send messages to a Unix syslog daemon, possibly on a remote machine.
10.logging.handlers.NTEventLogHandler(appname, dllname=None, logtype='Application') 
    instances send messages to a Windows NT/2000/XP event log.
11.logging.handlers.MemoryHandler(capacity, flushLevel=ERROR, target=None)� 
    instances send messages to a buffer in memory, which is flushed 
    whenever specific criteria are met.
12.logging.handlers.HTTPHandler(host, url, method='GET') 
    instances send messages to an HTTP server using either GET or POST semantics.
    host is host:port
    Note it sends data as URL key for GET and application/x-www-form-urlencoded for POST 
13.logging.handlers.WatchedFileHandler(filename[, mode[, encoding[, delay]]]) 
    instances watch the file they are logging to. 
    If the file changes, it is closed and reopened using the file name. 
    This handler is only useful on Unix-like systems; Windows does not support the underlying mechanism used.
14.logging.NullHandler 
    instances do nothing with error messages. They are used by library developers who want to use logging, but want to avoid the �No handlers could be found for logger XXX� message which can be displayed if the library user has not configured logging. See Configuring Logging for a Library for more information.

##Quick SocketHandler
#https://docs.python.org/2/howto/logging-cookbook.html#sending-and-receiving-logging-events-across-a-network



##Quick HTTPHandler Pattern using Flask 
#server.py:
#request.args is dict for URL KEY for GET 
#for POST and application/x-www-form-urlencoded, use request.form as dict 
#for post and 'application/json'  , use request.json or request.get_json() which json coverted to py obj 
#for post and 'text/plain', use request.data

from flask import Flask, request

app = Flask(__name__)

@app.route("/", methods=['POST', 'GET'])
def index():
    for key, value in request.args.items():
        print(key,value)
    return 'GET log' # it has to return something
    
    
@app.route('/json-post', methods = ['POST'])
def json_log():
    if request.headers['Content-Type'] == 'application/json':
        print(json.dumps(request.json))
    return "JSON log"
        
if __name__ == "__main__":
    app.run(debug=True)


#Usage: send_log.py:

import logging
import logging.handlers

logger = logging.getLogger(__name__)

server = '127.0.0.1:5000'
path = '/'
method = 'GET'

sh = logging.handlers.HTTPHandler(server, path, method=method)

logger.addHandler(sh)
logger.setLevel(logging.DEBUG)

logger.debug("Test message.")


##Custom Handler and Formatter eg to send json data to Flask server handling Json 
import requests, json 
class RequestsHandler(logging.Handler):
    def emit(self, record):
        log_entry = self.format(record)
        return requests.post('http://localhost:8080/json-post',log_entry, headers={"Content-type": "application/json"}).content

class JsonFormatter(logging.Formatter):
    def __init__(self, task_name=None):
        self.task_name = task_name
        super(LogstashFormatter, self).__init__()
    def format(self, record):  #LogRecord attributes : https://docs.python.org/2/library/logging.html#logrecord-attributes
        res = super(JsonFormatter, self).format(record)
        data = {'message': res,
                'timestamp': datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%fZ')}
        if self.task_name:
            data['task_name'] = self.task_name
        return json.dumps(data)
#Usage 
class SomeClass:
    def __init__(self, llogging_level,ogger_name="SomeModule.SomeClass"):
        self.logger = logging.getLogger(logger_name.upper())
        self.logger.setLevel(logging_level)
        handler = RequestsHandler()
        formatter = JsonFormatter(logger_name.upper())
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)
    
##Usage of passing extra info in each call to logging 
#Option-1:LoggerAdapter

import logging
extra = {'app_name':'Super App'}

logger = logging.getLogger(__name__)
syslog = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s %(app_name)s : %(message)s')
syslog.setFormatter(formatter)
logger.setLevel(logging.INFO)
logger.addHandler(syslog)
logger = logging.LoggerAdapter(logger, extra)


logger.info('The sky is so blue')

#Output 
2013-07-09 17:39:33,596 Super App : The sky is so blue


#Option-2: using Filters 
import logging

class AppFilter(logging.Filter):
    def filter(self, record):
        record.app_name = 'Super App'
        return True

logger = logging.getLogger(__name__)
logger.addFilter(AppFilter())
syslog = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s %(app_name)s : %(message)s')
syslog.setFormatter(formatter)
logger.setLevel(logging.INFO)
logger.addHandler(syslog)

logger.info('The sky is so blue')



    

###*** Python Argument Parsing 

#Example 
import argparse

parser = argparse.ArgumentParser(description='sha_install')
parser.add_argument('-t', dest="INST_METHOD", action="store", help='<<give help text here>>')

args = parser.parse_args()
INST_METHOD = args.INST_METHOD.strip().upper()
print(args)


#Example 
import argparse

parser = argparse.ArgumentParser(description='Process some integers.')

#nargs = how many positional args to consume , + means atleast one and consume all 
#metavar would display in help 
#intergers would be destination by default 
parser.add_argument('integers', metavar='N', type=int, nargs='+',
                    help='an integer for the accumulator')
                    
#'store_const' - store 'const' in 'dest' ie accumulate 
#by default(if no --sum provided) 'accumulate' would 'default' ie max      
parser.add_argument('--sum', dest='accumulate', action='store_const',
                    const=sum, default=max,
                    help='sum the integers (default: find the max)')

args = parser.parse_args()
print(args.accumulate(args.integers))


$ python prog.py -h
usage: prog.py [-h] [--sum] N [N ...]

Process some integers.

positional arguments:
 N           an integer for the accumulator

optional arguments:
 -h, --help  show this help message and exit
 --sum       sum the integers (default: find the max)


$ python prog.py 1 2 3 4
4

$ python prog.py 1 2 3 4 --sum
10


##Reference 
ArgumentParser.add_argument(name or flags...[, action][, nargs][, const][, default][, type][, choices][, required][, help][, metavar][, dest])

name or flags
    an optional argument, like -f or --foo, 
        >> parser.add_argument('-f', '--foo')
    while a positional argument c
        >>> parser.add_argument('bar')
    When parse_args() is called
        >>> parser.parse_args(['BAR'])
        Namespace(bar='BAR', foo=None)
        >>> parser.parse_args(['BAR', '--foo', 'FOO'])
        Namespace(bar='BAR', foo='FOO')
        >>> parser.parse_args(['--foo', 'FOO'])
        usage: PROG [-h] [-f FOO] bar
        PROG: error: the following arguments are required: bar
action
    'store' - This just stores the argument�s value. This is the default action. For example:
        >>> parser = argparse.ArgumentParser()
        >>> parser.add_argument('--foo')
        >>> parser.parse_args('--foo 1'.split())
        Namespace(foo='1')
    'store_const' - This stores the value specified by the const keyword argument. 
        >>> parser = argparse.ArgumentParser()
        >>> parser.add_argument('--foo', action='store_const', const=42)
        >>> parser.parse_args(['--foo'])
        Namespace(foo=42)
    'store_true' and 'store_false' -for storing the values True and False respectively. 
        >>> parser = argparse.ArgumentParser()
        >>> parser.add_argument('--foo', action='store_true')
        >>> parser.add_argument('--bar', action='store_false')
        >>> parser.add_argument('--baz', action='store_false')
        >>> parser.parse_args('--foo --bar'.split())
        Namespace(foo=True, bar=False, baz=True)
    'append' - This stores a list, and appends each argument value to the list. 
        >>> parser = argparse.ArgumentParser()
        >>> parser.add_argument('--foo', action='append')
        >>> parser.parse_args('--foo 1 --foo 2'.split())
        Namespace(foo=['1', '2'])
    'append_const' - This stores a list, and appends the value specified by the const keyword argument to the list. 
        >>> parser = argparse.ArgumentParser()
        >>> parser.add_argument('--str', dest='types', action='append_const', const=str)
        >>> parser.add_argument('--int', dest='types', action='append_const', const=int)
        >>> parser.parse_args('--str --int'.split())
        Namespace(types=[<class 'str'>, <class 'int'>])
    'count' - This counts the number of times a keyword argument occurs. 
        >>> parser = argparse.ArgumentParser()
        >>> parser.add_argument('--verbose', '-v', action='count')
        >>> parser.parse_args(['-vvv'])
        Namespace(verbose=3)
    'help' - This prints a complete help message for all the options in the current parser and then exits.
    'version' - This expects a version= keyword argument in the add_argument() call, 
        and prints version information and exits when invoked:
        >>> import argparse
        >>> parser = argparse.ArgumentParser(prog='PROG')
        >>> parser.add_argument('--version', action='version', version='%(prog)s 2.0')
        >>> parser.parse_args(['--version'])
        PROG 2.0
nargs
    N (an integer). N arguments from the command line will be gathered together into a list. 
    Note that nargs=1 produces a list of one item
        >>> parser = argparse.ArgumentParser()
        >>> parser.add_argument('--foo', nargs=2)
        >>> parser.add_argument('bar', nargs=1)
        >>> parser.parse_args('c --foo a b'.split())
        Namespace(bar=['c'], foo=['a', 'b'])
    '?'. One argument will be consumed from the command line if possible, and produced as a single item. 
    One of the more common uses of nargs='?' is to allow optional input and output files:
        >>> parser = argparse.ArgumentParser()
        >>> parser.add_argument('infile', nargs='?', type=argparse.FileType('r'),
                            default=sys.stdin)
        >>> parser.add_argument('outfile', nargs='?', type=argparse.FileType('w'),
                            default=sys.stdout)
        >>> parser.parse_args(['input.txt', 'output.txt'])
        Namespace(infile=<_io.TextIOWrapper name='input.txt' encoding='UTF-8'>,
                  outfile=<_io.TextIOWrapper name='output.txt' encoding='UTF-8'>)
        >>> parser.parse_args([])
        Namespace(infile=<_io.TextIOWrapper name='<stdin>' encoding='UTF-8'>,
                  outfile=<_io.TextIOWrapper name='<stdout>' encoding='UTF-8'>)
    '*'. All command-line arguments present are gathered into a list. 
    Note that it generally doesn�t make much sense to have more than one positional argument with nargs='*', 
    but multiple optional arguments with nargs='*' is possible. For example:
        >>> parser = argparse.ArgumentParser()
        >>> parser.add_argument('--foo', nargs='*')
        >>> parser.add_argument('--bar', nargs='*')
        >>> parser.add_argument('baz', nargs='*')
        >>> parser.parse_args('a b --foo x y --bar 1 2'.split())
        Namespace(bar=['1', '2'], baz=['a', 'b'], foo=['x', 'y'])
    '+'. Just like '*', all command-line args present are gathered into a list.
        >>> parser = argparse.ArgumentParser(prog='PROG')
        >>> parser.add_argument('foo', nargs='+')
        >>> parser.parse_args(['a', 'b'])
        Namespace(foo=['a', 'b'])
        >>> parser.parse_args([])
        usage: PROG [-h] foo [foo ...]
        PROG: error: the following arguments are required: foo
    argparse.REMAINDER. All the remaining command-line arguments are gathered into a list. 
        >>> parser = argparse.ArgumentParser(prog='PROG')
        >>> parser.add_argument('--foo')
        >>> parser.add_argument('command')
        >>> parser.add_argument('args', nargs=argparse.REMAINDER)
        >>> print(parser.parse_args('--foo B cmd --arg1 XX ZZ'.split()))
        Namespace(args=['--arg1', 'XX', 'ZZ'], command='cmd', foo='B')
const
    The const argument of add_argument() is used to hold constant values 
    that are not read from the command line 
default
    All optional arguments and some positional arguments may be omitted at the command line. 
    The default keyword argument of add_argument(), whose value defaults to None, 
    specifies what value should be used if the command-line argument is not present. 
    Providing default=argparse.SUPPRESS causes no attribute to be added 
    if the command-line argument was not present:
        >>> parser = argparse.ArgumentParser()
        >>> parser.add_argument('--foo', default=argparse.SUPPRESS)
        >>> parser.parse_args([])
        Namespace()
        >>> parser.parse_args(['--foo', '1'])
        Namespace(foo='1')
type
    By default, ArgumentParser objects read command-line arguments in as simple strings.
    type= can take any callable that takes a single string argument and returns the converted value
        >>> parser = argparse.ArgumentParser()
        >>> parser.add_argument('foo', type=int)
        >>> parser.add_argument('bar', type=open)
        >>> parser.parse_args('2 temp.txt'.split())
        Namespace(bar=<_io.TextIOWrapper name='temp.txt' encoding='UTF-8'>, foo=2)
        >>> parser = argparse.ArgumentParser()
        >>> parser.add_argument('bar', type=argparse.FileType('w'))
        >>> parser.parse_args(['out.txt'])
        Namespace(bar=<_io.TextIOWrapper name='out.txt' encoding='UTF-8'>)

choices
    Some command-line arguments should be selected from a restricted set of values.
        >>> parser = argparse.ArgumentParser(prog='game.py')
        >>> parser.add_argument('move', choices=['rock', 'paper', 'scissors'])
        >>> parser.parse_args(['rock'])
        Namespace(move='rock')
        >>> parser.parse_args(['fire'])
        usage: game.py [-h] {rock,paper,scissors}
        game.py: error: argument move: invalid choice: 'fire' (choose from 'rock','paper', 'scissors')
required
    In general, the argparse module assumes that flags like -f and --bar indicate optional arguments, 
    which can always be omitted at the command line. 
    To make an option required, True can be specified for the required= keyword argument
help
    The help value is a string containing a brief description of the argument.
metavar
    When ArgumentParser generates help messages, it needs some way to refer to each expected argument. 
    By default, ArgumentParser objects use the dest value as the �name� of each object. 
    By default, for positional argument actions, the dest value is used directly, 
    and for optional argument actions, the dest value is uppercased. 
    So, a single positional argument with dest='bar' will be referred to as bar. 
    A single optional argument --foo that should be followed by a single command-line argument 
    will be referred to as FOO.
    An alternative name can be specified with metavar:
dest
    Most ArgumentParser actions add some value as an attribute of the object returned by parse_args(). 
    The name of this attribute is determined by the dest keyword argument of add_argument(). 
    For positional argument actions, dest is normally supplied as the first argument to add_argument():



###*** Os and os.path module 

1. Create below env vars containing below 
HOST        hostname 
DT          todays date using pattern "%m%d%y%H%M%S" 
SCRIPT      this script name only (without extension)
SCRIPT_PID  this script pid 
OUTDIR      C:/tmp/adm
LOGFIL      $OUTDIR/$SCRIPT.$DT.log (in unix expansion of variable 
2. Then dump in parent and in child these values 
3. write mslog with takes any message and dumps that message to LOGFIL and console 
   with format , message may contain any env var and that should be expanded 
   HOST:DT:message 


#Code 
import os, os.path, sys, subprocess as S, time, datetime as D, shlex
direct_environ = dict(HOST=os.uname()[1], 
                      DT=D.datetime.today().strftime("%m%d%y%H%M%S"),
                      SCRIPT=os.path.splitext(os.path.basename(sys.argv[0]))[0],
                      SCRIPT_PID=str(os.getpid()),
                      OUTDIR=r"/var/adm/aaas",
                      ) 
    

#Update, could have called os.environ.update(direct_environ), ensure all are string 
for k,v in direct_environ.items():
    os.environ[str(k)] = str(v) 
    
    
#Add all environs which are dependent on other environs , must after above 
indirect_environ = dict(LOGFILE=os.path.expandvars(r"$OUTDIR/$SCRIPT.$DT.log"))

for k,v in indirect_environ.items():
    os.environ[str(k)] = str(v)    
  
  

##Dumps all environ variable 
def print_parent_env():
    for k,v in os.environ.items():
        if k in direct_environ or k in indirect_environ:
            print(k,'=',v)        

def print_child_env():
    print("Print in subprocess")
    #both in windows and shell 
    proc = S.Popen("printenv", shell=True, stdout=S.PIPE, stderr=S.STDOUT, universal_newlines=True)
    outs, errs = proc.communicate(timeout=10)
    final_keys = direct_environ.keys() | indirect_environ.keys()
    for line in outs.split():
        k,*v = line.split("=")
        if k in final_keys:
            print("\t",line)


def msglog(text, file=True):
    import os 
    LOGFILE = os.environ["LOGFILE"]
    HOST = os.environ["HOST"]
    DT = os.environ["DT"]
    line = "%s:%s:%s" % (HOST, DT, os.path.expanduser(os.path.expandvars(text)))
    if file :
        with open(LOGFILE, "at") as f :
            f.writelines([line+"\n"])
    print(line)

            
            
            
            
###*** Module -subprocess - replaces os.system and os.spawn

import subprocess

#Arguments meaning
stdin, stdout and stderr 
    specify the executed program's standard input, 
    standard output and standard error file handles, 
    values are PIPE, DEVNULL, an existing file descriptor (a positive integer), 
    an existing file object, and None    
    stderr can be STDOUT    
universal_newlines 
    if it is False the file objects stdin, stdout and stderr will be opened as binary streams,
    and no line ending conversion is done
shell 
    If shell is True, the specified command will be executed through the shell
    accesses to shell pipes, filename wildcards, environment variable expansion
    On POSIX with shell=True, the shell defaults to /bin/sh. 
    Popen(['/bin/sh', '-c', args[0], args[1], ...])
    On windows shell=True to execute is built into the shell (e.g. dir or copy)


#Main Interface -Py3.5
subprocess.run(args, *, stdin=None, input=None, stdout=None, stderr=None, 
        capture_output=False, shell=False, cwd=None, timeout=None, check=False, 
        encoding=None, errors=None, text=None, env=None)
    The Main High level interface 
    Run the command described by args. 
    Wait for command to complete, then return a CompletedProcess instance.
    If capture_output is true, stdout and stderr will be captured
    The input argument is passed to Popen.communicate() and thus to the subprocess�s stdin
    CompletedProcess has below methods 
    args
        The arguments used to launch the process. This may be a list or a string.
    returncode
        Exit status of the child process. 
        Typically, an exit status of 0 indicates that it ran successfully.
        A negative value -N indicates that the child was terminated by signal N (POSIX only).
    stdout
        Captured stdout from the child process. 
        A bytes sequence, or a string if run() was called with an encoding, errors, or text=True. 
        None if stdout was not captured.
        If you ran the process with stderr=subprocess.STDOUT, 
        stdout and stderr will be combined in this attribute, and stderr will be None.
    stderr
        Captured stderr from the child process. 
        A bytes sequence, or a string if run() was called with an encoding, errors, or text=True. 
        None if stderr was not captured.
    check_returncode()
        If returncode is non-zero, raise a CalledProcessError.
        
#Example 
>>> subprocess.run(["ls", "-l"])  # doesn't capture output
CompletedProcess(args=['ls', '-l'], returncode=0)

>>> subprocess.run("exit 1", shell=True, check=True)
Traceback (most recent call last):
  ...
subprocess.CalledProcessError: Command 'exit 1' returned non-zero exit status 1

>>> subprocess.run(["ls", "-l", "/dev/null"], capture_output=True)
CompletedProcess(args=['ls', '-l', '/dev/null'], returncode=0,
stdout=b'crw-rw-rw- 1 root root 1, 3 Jan 23 16:23 /dev/null\n', stderr=b'')

   
#Low level API 
class subprocess.Popen(args, bufsize=-1, executable=None, stdin=None, stdout=None, stderr=None, 
            preexec_fn=None, close_fds=True, shell=False, cwd=None, env=None, universal_newlines=False, 
            startupinfo=None, creationflags=0, restore_signals=True, start_new_session=False, 
            pass_fds=(), *, encoding=None, errors=None, text=None)    
    args should be a sequence of program arguments(RECOMENDED) or else a single string
    buffsize
        0 means unbuffered (read and write are one system call and can return short)
        1 means line buffered (only usable if universal_newlines=True i.e., in a text mode)
        any other positive value means use a buffer of approximately that size
        negative bufsize (the default) means the system default of io.DEFAULT_BUFFER_SIZE will be used.
    here Popen is instance as returned by above call 
    Popen.poll()
        Check if child process has terminated. Set and return returncode attribute.
    Popen.wait(timeout=None)
        Wait for child process to terminate. Set and return returncode attribute.
    Popen.send_signal(signal)
        Sends the signal signal to the child.
    Popen.terminate()
        Stop the child. 
    Popen.kill()
        Kills the child
    Popen.args
    Popen.stdin  
        if stdin argument was PIPE, it is file object, use write()
    Popen.stdout 
        If the stdout argument was PIPE, it is file object, use read()
        Use communicate() rather than .stdin.write, .stdout.read or .stderr.read to avoid deadlocks 
    Popen.stderr
    Popen.pid
        The process ID of the child process.
    Popen.returncode
    (stdoutdata, stderrdata) = Popen.communicate(input=None, timeout=None) 
        Send data to stdin. Read data from stdout and stderr, until end-of-file is reached
        Can only be used if stdin, stdout, stderr are PIPE 
        The data read is buffered in memory, so do not use this method 
        if the data size is large or unlimited.

#Examples 
proc = subprocess.Popen(...)
try:
    outs, errs = proc.communicate(timeout=15)
except TimeoutExpired:
    proc.kill()
    outs, errs = proc.communicate()

#works with with
import subprocess as S
with S.Popen(["ipconfig"], stdout=S.PIPE, universal_newlines =True) as proc:  #ifconfig in unix 
    output = proc.stdout.read() 

	
	
#shlex.split() can be useful when determining the correct tokenization for args, 
#especially in complex cases
import shlex

>>> command_line = input()
/bin/vikings -input eggs.txt -output "spam spam.txt" -cmd "echo '$MONEY'"

>>> args = shlex.split(command_line)
>>> print(args)
['/bin/vikings', '-input', 'eggs.txt', '-output', 'spam spam.txt', '-cmd', "echo '$MONEY'"]



##Subprocess Pattern 

#Replacing /bin/sh shell backquote
output=`mycmd myarg`
# becomes
output = subprocess.run(["mycmd", "myarg"], capture_output=True).stdout

# Replacing shell pipeline
#cat regex.py | grep def

p1 = subprocess.Popen(["cat", "regex.py"], stdout=subprocess.PIPE)
p2 = subprocess.Popen(["grep", "def"], stdin=p1.stdout, stdout=subprocess.PIPE)
p1.stdout.close()  ## Allow p1 to receive a SIGPIPE if p2 exits
output_str = p2.communicate()[0]  # or p2.stdout.read().decode("utf-8") or universal_newlines=True
print(output_str.decode("utf-8"))

#OR
output=`dmesg | grep hda`
# becomes
output = subprocess.run("dmesg | grep hda", shell=True, capture_output=True).stdout

#Replacing os.system()
sts = os.system("mycmd" + " myarg")
# becomes
sts = subprocess.run("mycmd" + " myarg", shell=True).returncode

#or 
try:
    retcode = subprocess.run("mycmd" + " myarg", shell=True).returncode
    if retcode < 0:
        print("Child was terminated by signal", -retcode, file=sys.stderr)
    else:
        print("Child returned", retcode, file=sys.stderr)
except OSError as e:
    print("Execution failed:", e, file=sys.stderr)



#Replacing the os.spawn family
#P_NOWAIT example:
pid = os.spawnlp(os.P_NOWAIT, "/bin/mycmd", "mycmd", "myarg")
#becomes
pid = subprocess.Popen(["/bin/mycmd", "myarg"]).pid


#P_WAIT example:
retcode = os.spawnlp(os.P_WAIT, "/bin/mycmd", "mycmd", "myarg")
#becomes
retcode = subprocess.run(["/bin/mycmd", "myarg"]).returncode

#Environment example:
os.spawnlpe(os.P_NOWAIT, "/bin/mycmd", "mycmd", "myarg", env)
#becomes
subprocess.Popen(["/bin/mycmd", "myarg"], env={"PATH": "/usr/bin"})


#Replacing os.popen(), os.popen2(), os.popen3()
(child_stdin, child_stdout) = os.popen2(cmd, mode, bufsize)
#becomes
p = subprocess.Popen(cmd, shell=True, bufsize=bufsize,
          stdin=subprocess.PIPE, stdout=subprocess.PIPE, close_fds=True)
(child_stdin, child_stdout) = (p.stdin, p.stdout)

#OR 
(child_stdin,
 child_stdout,
 child_stderr) = os.popen3(cmd, mode, bufsize)
#becomes
p = Popen(cmd, shell=True, bufsize=bufsize,
          stdin=PIPE, stdout=PIPE, stderr=PIPE, close_fds=True)
(child_stdin,
 child_stdout,
 child_stderr) = (p.stdin, p.stdout, p.stderr)

#OR 
(child_stdin, child_stdout_and_stderr) = os.popen4(cmd, mode, bufsize)
#becomes
p = Popen(cmd, shell=True, bufsize=bufsize,
          stdin=PIPE, stdout=PIPE, stderr=STDOUT, close_fds=True)
(child_stdin, child_stdout_and_stderr) = (p.stdin, p.stdout)


##few windows commands 
'''
tracert www.google.com
netstat -an
ipconfig /all
powercfg /lastwake
#file compare 
fc /l "C:\Program Files (x86)\example1.doc" "C:\Program Files (x86)\example2.doc"
driverquery -v
nslookup www.google.com 
tasklist -m
'''


##Example - escapiing the pipe by ^, /v means lines other than matching , /c:"" - matching, /r - regex 
#To strip out the top 2 lines pipe the output to findstr /v "Active Proto".
for /f "tokens=2,5" %i  in ('netstat -n -o ^| findstr /v "Active Proto"') do @echo Local Address = %i, PID = %j
#OR 
for /f "tokens=2,5" %i  in ('netstat -n -o ^| findstr /C:"ESTABLISHED"') do @echo Local Address = %i, PID = %j




command = """for /f "tokens=2,5" %i  in ('netstat -n -o ^| findstr /C:"ESTABLISHED"') do @echo Local Address = %i, PID = %j"""
import subprocess as S
bufsize = 2**20
p = S.Popen(command, bufsize =bufsize, shell=True, stdout=S.PIPE, stderr=S.PIPE, universal_newlines=True)
(out,err) = p.communicate()

#Unique Port 
import re 
sp = r":(\d+),"
res = re.findall(sp, out)
unique = {int(e) for e in res }

#details of process 
sp = r"PID = (\d+)\n"
unique = {int(e) for e in re.findall(sp, out) }

command = r"""tasklist /fi "pid eq %d" /nh"""
stat = {}
for pid in unique:
    p = S.Popen(command % pid , shell=True, stdout=S.PIPE, stderr=S.STDOUT, universal_newlines=True)
    stat[pid] = p.communicate()[0]
    

#no header- nh 
D:\Desktop\PPT>tasklist /fi "pid eq 6340"

Image Name                     PID Session Name        Session#    Mem Usage
========================= ======== ================ =========== ============
iexplore.exe                  6340 Console                    7   1,33,468 K
    
    
##Example of only return code 
command = """taskkill -im iexplore.exe"""
#echo %errorlevel% or echo $? , note 0 means success 
import subprocess as S, os , sys 
#Py3.5, S.DEVNULL 
with open(os.devnull, 'w') as DEVNULL:
    exit = S.Popen(command, shell=True, stdout=DEVNULL, stderr=DEVNULL).returncode
#then exit 
sys.exit(exit)
 
 
##Example of pipe 
#dir /B | findstr /r /c:"[mp]"

import subprocess as S, os , sys 
command = 'dir /B | findstr /r /c:"[mp]"'
output = S.check_output(command, shell=True, stderr=S.STDOUT, universal_newlines=True)

#OR 
command1 = 'dir /B' 
command2 = 'findstr /r /c:"[mp]"'
#Py3.5, S.DEVNULL 
with open(os.devnull, 'w') as DEVNULL:
    p1 = S.Popen(command1, shell=True, stdout=S.PIPE, stderr=DEVNULL)
    p2 = S.Popen(command2, shell=True, stdin=p1.stdout, stdout= S.PIPE, stderr=DEVNULL)
    p1.stdout.close()  ## Allow p1 to receive a SIGPIPE if p2 exits
    (out, err) = p2.communicate() 
    


##Example of Redirect 
command = 'tasklist /fi "imagename eq iexplore.exe"' #> test.txt
file = "test.txt"
with open(file , "wt") as f :
    proc = S.Popen(command, shell=True, stdout=f, stderr=S.STDOUT)
    proc.wait()

command = "type %s"
contents = S.Popen(command % file, shell=True, stdout=S.PIPE, stderr=S.STDOUT).stdout.read() 
 
 
 

##Example of timeout 
#py3.5 
def execute_and_watchdog(command, TIMEOUT=15, KILL_TMOUT=60, **kwargs): 
    import errno
    def test_d(pid):
        try:
            os.kill(pid, 0)
        except OSError as err:
            if err.errno == errno.ESRCH:
                return False
        return True 
        
    args = shlex.split(command)    
    proc = S.Popen(args, **kwargs)
    try:
        outs, errs = proc.communicate(timeout=TIMEOUT)
    except S.TimeoutExpired:
        #timeout 
        if test_d(proc.pid):
            proc.terminate()
            time.sleep(KILL_TMOUT)
        if test_d(proc.pid):
            proc.kill()
            time.sleep(KILL_TMOUT)
        outs, errs = proc.communicate()
        if test_d(proc.pid):
            #could not kill 
            pass
        return (9, outs, errs)
    return (proc.returncode, outs, errs)



#Py2.7 
def execute_and_watchdog(command, TIMEOUT=15, KILL_TMOUT=60, **kwargs): 
    import errno
    def test_d(pid):
        try:
            os.kill(pid, 0)
        except OSError as err:
            if err.errno == errno.ESRCH:
                return False
        return True         
    args = shlex.split(command)    
    proc = S.Popen(args, **kwargs)
    timeout = TIMEOUT + 1 
    while proc.poll() is None and timeout > 0 :
        time.sleep(1)
        timeout -= 1         
    if timeout == 0:
        print("INFO:Time out period reached. Killing process %d." % (proc.pid,))
        if test_d(proc.pid):
            proc.terminate()
            time.sleep(KILL_TMOUT)
        if test_d(proc.pid):
            proc.kill()
            time.sleep(KILL_TMOUT)
        outs, errs = proc.communicate()
        if test_d(proc.pid):
            print("INFO:Process %d cound not be kiilled. Please verify manually" % (proc.pid,))
        return (9, outs, errs)
    outs, errs = proc.communicate()
    return (proc.returncode, outs, errs)
    
    
    
## TroubleShooting 
#If subprocess method is hanging  unpredictably
#the problem might be , stdout=PIPE and/or stderr=PIPE and data volumn is large > 64KB 
#in this case, create Popen with bufsize = BIG number and then use Popen.communicate 
#OR, open one tempfile and then use stdout=fileObject 
import tempfile
temp_stdout = tempfile.NamedTemporaryFile(mode="w+t") #open for read, write and text mode 
proc = subprocess.Popen(command, universal_newlines =True, stdout=temp_stdout.file, stderr=subprocess.STDOUT, shell=True)
proc.wait()
#then read the file 
temp_stdout.flush()
temp_stdout.seek(0)
outs = temp_stdout.read()
temp_stdout.close()





###*** File and Directory Access
#https://docs.python.org/3/library/filesys.html      

#For example stat method 

>>> import os
>>> statinfo = os.stat('somefile.txt')
>>> statinfo
os.stat_result(st_mode=33188, st_ino=7876932, st_dev=234881026,
st_nlink=1, st_uid=501, st_gid=501, st_size=264, st_atime=1297230295,
st_mtime=1297230027, st_ctime=1297230027)
>>> statinfo.st_size
264

##To use module stat 's predefined constant 
#check other stat https://docs.python.org/3/library/stat.html

import os, sys
from stat import *

def walktree(top, callback):
    '''recursively descend the directory tree rooted at top,
       calling the callback function for each regular file'''

    for f in os.listdir(top):
        pathname = os.path.join(top, f)
        mode = os.stat(pathname).st_mode
        if S_ISDIR(mode):
            # It's a directory, recurse into it
            walktree(pathname, callback)
        elif S_ISREG(mode):
            # It's a file, call the callback function
            callback(pathname)
        else:
            # Unknown file type, print a message
            print('Skipping %s' % pathname)

def visitfile(file):
    print('visiting', file)

if __name__ == '__main__':
    walktree(sys.argv[1], visitfile)



###*** filecmp � File and Directory Comparisons
from filecmp import dircmp
def print_diff_files(dcmp):
    for name in dcmp.diff_files:
        print("diff_file %s found in %s and %s" % (name, dcmp.left,  dcmp.right))
    for sub_dcmp in dcmp.subdirs.values():
        print_diff_files(sub_dcmp)

dcmp = dircmp('dir1', 'dir2') 
print_diff_files(dcmp) 

##API 
filecmp.cmp(f1, f2, shallow=True)
    Compare the files named f1 and f2, returning True if they seem equal, False otherwise.
    If shallow is true, files with identical os.stat() signatures are taken to be equal.
    Otherwise, the contents of the files are compared.

filecmp.cmpfiles(dir1, dir2, common, shallow=True)
    Compare the files in the two directories dir1 and dir2 whose names are given by common.
    Returns three lists of file names: match, mismatch, errors. 
    
class filecmp.dircmp(a, b, ignore=None, hide=None)
    Construct a new directory comparison object, to compare the directories a and b. 
    ignore is a list of names to ignore, and defaults to filecmp.DEFAULT_IGNORES. 
    hide is a list of names to hide, and defaults to [os.curdir, os.pardir].
    The dircmp class provides the following attributes:
    report()
        Print (to sys.stdout) a comparison between a and b.
    report_partial_closure()
        Print a comparison between a and b and common immediate subdirectories.
    report_full_closure()
        Print a comparison between a and b and common subdirectories (recursively).
    left
        The directory a.
    right
        The directory b.
    left_list
        Files and subdirectories in a, filtered by hide and ignore.
    right_list
        Files and subdirectories in b, filtered by hide and ignore.
    common
        Files and subdirectories in both a and b.
    left_only
        Files and subdirectories only in a.
    right_only
        Files and subdirectories only in b.
    common_dirs
        Subdirectories in both a and b.
    common_files
        Files in both a and b.
    common_funny
        Names in both a and b, such that the type differs between the directories, or names for which os.stat() reports an error.
    same_files
        Files which are identical in both a and b, using the class�s file comparison operator.
    diff_files
        Files which are in both a and b, whose contents differ according to the class�s file comparison operator.
    funny_files
        Files which are in both a and b, but could not be compared.
    subdirs
        A dictionary mapping names in common_dirs to dircmp objects.


###*** fileinput � Iterate over lines from multiple input streams
 
import fileinput
for line in fileinput.input():
    process(line)


#This iterates over the lines of all files listed in sys.argv[1:], 
#defaulting to sys.stdin if the list is empty. 
#If a filename is '-', it is also replaced by sys.stdin. 
#To specify an alternative list of filenames, pass it as the first argument to input(). 
#A single file name is also allowed.

#with predefined list 
#not thread safe , creates global state 
with fileinput.input(files=('spam.txt', 'eggs.txt')) as f:
    for line in f:
        process(line)

#thread safe 
with fileinput.FileInput(files=('spam.txt', 'eggs.txt')) as f:
    for line in f:
        process(line)
        
        
##API 
fileinput.input(files=None, inplace=False, backup='', bufsize=0, mode='r', openhook=None)
    not thread safe , creates global state 
    Create an instance of the FileInput class.

class fileinput.FileInput(files=None, inplace=False, backup='', bufsize=0, mode='r', openhook=None)
    it has a readline() method which returns the next input line, 
    and a __getitem__() method which implements the sequence behavior. 
    The sequence must be accessed in strictly sequential order; 
    random access and readline() cannot be mixed.
    mode must be one of 'r', 'rU', 'U' and 'rb'.
    The openhook, when given, must be a function that takes two arguments, filename and mode, 
    and returns an accordingly opened file-like object. 
    You cannot use inplace and openhook together.
    Return instance has following attributes 
    filename()
        Return the name of the file currently being read. 
        Before the first line has been read, returns None.
    fileno()
        Return the integer �file descriptor� for the current file. 
        When no file is opened (before the first line and between files), returns -1.
    lineno()
        Return the cumulative line number of the line that has just been read. 
        Before the first line has been read, returns 0. 
        After the last line of the last file has been read, returns the line number of that line.
    filelineno()
        Return the line number in the current file.
        Before the first line has been read, returns 0. 
        After the last line of the last file has been read, 
        returns the line number of that line within the file.
    isfirstline()
        Returns true if the line just read is the first line of its file, otherwise returns false.
    isstdin()
        Returns true if the last line was read from sys.stdin, otherwise returns false.
    nextfile()
        Close the current file so that the next iteration will read the first line from the next file (if any); 
        lines not read from the file will not count towards the cumulative line count. 
        The filename is not changed until after the first line of the next file has been read. 
        Before the first line has been read, this function has no effect;
        it cannot be used to skip the first file. 
        After the last line of the last file has been read, this function has no effect.
    close()
        Close the sequence.


###*** Data Compression and Archiving
#https://docs.python.org/3/library/archiving.html


##tarfile Mode and Action 
'r' or 'r:*'        Open for reading with transparent compression (recommended). 
'r:'                Open for reading exclusively without compression. 
'r:gz'              Open for reading with gzip compression. 
'r:bz2'             Open for reading with bzip2 compression. 
'r:xz'              Open for reading with lzma compression. 
'x' or 'x:'         Create a tarfile exclusively without compression. 
'x:gz'              Create a tarfile with gzip compression. 
'x:bz2'             Create a tarfile with bzip2 compression. 
'x:xz'              Create a tarfile with lzma compression.
'a' or 'a:'         Open for appending with no compression. The file is created if it does not exist. 
'w' or 'w:'         Open for uncompressed writing. 
'w:gz'              Open for gzip compressed writing. 
'w:bz2'             Open for bzip2 compressed writing. 
'w:xz'              Open for lzma compressed writing. 


##a TarFile object that processes its data as a stream of blocks
#Use this with sys.stdin, a socket file object or a tape device
#Does not support random access 
#Mode       Action
'r|*'       Open a stream of tar blocks for reading with transparent compression. 
'r|'        Open a stream of uncompressed tar blocks for reading. 
'r|gz'      Open a gzip compressed stream for reading. 
'r|bz2'     Open a bzip2 compressed stream for reading. 
'r|xz'      Open an lzma compressed stream for reading. 
'w|'        Open an uncompressed stream for writing. 
'w|gz'      Open a gzip compressed stream for writing. 
'w|bz2'     Open a bzip2 compressed stream for writing. 
'w|xz'      Open an lzma compressed stream for writing. 


#extract an entire tar archive to the current working directory:

import tarfile
tar = tarfile.open("sample.tar.gz")
tar.extractall()
tar.close()

#extract a subset of a tar archive with TarFile.extractall() 
#using a generator function instead of a list:


import os
import tarfile

def py_files(members):
    for tarinfo in members:
        if os.path.splitext(tarinfo.name)[1] == ".py":
            yield tarinfo

tar = tarfile.open("sample.tar.gz")
tar.extractall(members=py_files(tar))
tar.close()


#create an uncompressed tar archive from a list of filenames:
import tarfile
tar = tarfile.open("sample.tar", "w")
for name in ["foo", "bar", "quux"]:
    tar.add(name)
tar.close()

#OR 
import tarfile
with tarfile.open("sample.tar", "w") as tar:
    for name in ["foo", "bar", "quux"]:
        tar.add(name)




##Example zipfile , creation a ZIP (tarfile is similar)
$ python -m zipfile -c monty.zip spam.txt eggs.txt
$ python -m zipfile -c monty.zip life-of-brian_1979/

#extract a ZIP archive into the specified directory, use the -e option:
$ python -m zipfile -e monty.zip target-dir/

#For a list of the files in a ZIP archive, use the -l option:
$ python -m zipfile -l monty.zip


##Testing correct ZIP Files
import zipfile

for filename in [ 'README.txt', 'example.zip',   'bad_example.zip', 'notthere.zip' ]:
    print '%20s  %s' % (filename, zipfile.is_zipfile(filename))

#Output 
README.txt  False
example.zip  True
bad_example.zip  False
notthere.zip  False

##Reading Meta-data from a ZIP Archive
import datetime
import zipfile

zf = zipfile.ZipFile('example.zip', 'r')
print zf.namelist()  #list of files 

def print_info(archive_name):
    zf = zipfile.ZipFile(archive_name)
    for info in zf.infolist():
        print info.filename
        print '\tComment:\t', info.comment
        print '\tModified:\t', datetime.datetime(*info.date_time)
        print '\tSystem:\t\t', info.create_system, '(0 = Windows, 3 = Unix)'
        print '\tZIP version:\t', info.create_version
        print '\tCompressed:\t', info.compress_size, 'bytes'
        print '\tUncompressed:\t', info.file_size, 'bytes'
        print

print_info('example.zip')

#Writing 
with ZipFile('spam.zip', 'w') as myzip:
    myzip.write('eggs.txt')

#Reading 
with ZipFile('spam.zip') as myzip:
    with myzip.open('eggs.txt') as myfile:
        print(myfile.read())
        
#Create PY file zip 
zf = PyZipFile('myprog.zip')
def notests(s):
    fn = os.path.basename(s)
    return (not (fn == 'test' or fn.startswith('test_')))
zf.writepy('myprog', filterfunc=notests)

#The writepy() method makes archives with file names like this:
string.pyc                   # Top level name
test/__init__.pyc            # Package directory
test/testall.pyc             # Module test.testall
test/bogus/__init__.pyc      # Subpackage directory
test/bogus/myfile.pyc        # Submodule test.bogus.myfile
        

##API 
class zipfile.ZipFile(file, mode='r', compression=ZIP_STORED, allowZip64=True, compresslevel=None)
    Open a ZIP file
    The mode parameter should be 'r' to read an existing file, 'w' to truncate and write a new file, 
    'a' to append to an existing file, or 'x' to exclusively create and write a new file.
    compression is the ZIP compression method to use when writing the archive, 
    and should be ZIP_STORED, ZIP_DEFLATED, ZIP_BZIP2 or ZIP_LZMA; 
    Returns instance which have following attributes 
    ZipFile.close()
        Close the archive file. 
    ZipFile.getinfo(name)
        Return a ZipInfo object with information about the archive member name. 
    ZipFile.infolist()
        Return a list containing a ZipInfo object for each member of the archive. 
    ZipFile.namelist()
        Return a list of archive members by name.
    ZipFile.open(name, mode='r', pwd=None, *, force_zip64=False)
        Access a member of the archive as a binary file-like object. n
        ame can be either the name of a file within the archive or a ZipInfo object. 
        The mode parameter, if included, must be 'r' (the default) or 'w'. 
        pwd is the password used to decrypt encrypted ZIP files.
        With mode 'r' the file-like object (ZipExtFile) is read-only and provides the following methods: 
            read(), readline(), readlines(), seek(), tell(), __iter__(), __next__(). 
        With mode='w', a writable file handle is returned, which supports the write() method. 
        While a writable file handle is open, attempting to read or write other files in the ZIP file 
        will raise a ValueError.
        When writing a file, if the file size is not known in advance but may exceed 2 GiB, 
        pass force_zip64=True to ensure that the header format is capable of supporting large files. 
    ZipFile.extract(member, path=None, pwd=None)
        Extract a member from the archive to the current working directory;
        member must be its full name or a ZipInfo object. 
        Returns the normalized path created (a directory or new file).
    ZipFile.extractall(path=None, members=None, pwd=None)
        Extract all members from the archive to the current working directory. 
        path specifies a different directory to extract to. 
    ZipFile.printdir()
        Print a table of contents for the archive to sys.stdout.
    ZipFile.setpassword(pwd)
        Set pwd as default password to extract encrypted files.
    ZipFile.read(name, pwd=None)
        Return the bytes of the file name in the archive. 
        name is the name of the file in the archive, or a ZipInfo object. 
        The archive must be open for read or append. 
        pwd is the password used for encrypted files 
    ZipFile.testzip()
        Read all the files in the archive and check their CRC�s and file headers. 
        Return the name of the first bad file, or else return None.
    ZipFile.write(filename, arcname=None, compress_type=None, compresslevel=None)
        Write the file named filename to the archive, giving it the archive name arcname 
        (by default, this will be the same as filename, but without a drive letter and with leading path separators removed). 
    ZipFile.writestr(zinfo_or_arcname, data, compress_type=None, compresslevel=None)
        Write the string data to the archive; 
        zinfo_or_arcname is either the file name it will be given in the archive, or a ZipInfo instance.
    ZipFile.filename
        Name of the ZIP file.
    ZipFile.debug
        The level of debug output to use. This may be set from 0 (the default, no output) to 3 (the most output). 
        Debugging information is written to sys.stdout.
    ZipFile.comment
        The comment text associated with the ZIP file. 

class zipfile.PyZipFile(file, mode='r', compression=ZIP_STORED, allowZip64=True, optimize=-1)
    If the optimize parameter to PyZipFile was not given or -1, the corresponding file is a *.pyc file, compiling if necessary.
    Instances have one method in addition to those of ZipFile objects:
    writepy(pathname, basename='', filterfunc=None)
        Search for files *.py and add the corresponding file to the archive.


###*** shutil � High-level file operations

shutil.make_archive(base_name, format[, root_dir[, base_dir[, verbose[, dry_run[, owner[, group[, logger]]]]]]])
    Create an archive file (such as zip or tar) and return its name.
    base_name is the name of the file to create, including the path, minus any format-specific extension. 
    format is the archive format: one of �zip� (if the zlib module is available), �tar�, �gztar� (if the zlib module is available), �bztar� (if the bz2 module is available), or �xztar� (if the lzma module is available).
    root_dir is a directory that will be the root directory of the archive; for example, we typically chdir into root_dir before creating the archive.
    base_dir is the directory where we start archiving from; i.e. base_dir will be the common prefix of all files and directories in the archive.
    root_dir and base_dir both default to the current directory.
    If dry_run is true, no archive is created, but the operations that would be executed are logged to logger
shutil.unpack_archive(filename[, extract_dir[, format]])
    Unpack an archive. 
    filename is the full path of the archive.
    extract_dir is the name of the target directory where the archive is unpacked. 
    If not provided, the current working directory is used.
    format is the archive format: one of �zip�, �tar�, �gztar�, �bztar�, or �xztar�. 
    
#Example 
from shutil import make_archive
import os
archive_name = os.path.expanduser(os.path.join('~', 'myarchive'))
root_dir = os.path.expanduser(os.path.join('~', '.ssh'))
>>> make_archive(archive_name, 'gztar', root_dir)
'/Users/tarek/myarchive.tar.gz'


#remove a directory tree on Windows where some of the files have their read-only bit set. 
#It uses the onerror callback to clear the readonly bit and reattempt the remove. 
#Any subsequent failure will propagate.

import os, stat
import shutil

def remove_readonly(func, path, _):
    "Clear the readonly bit and reattempt the removal"
    os.chmod(path, stat.S_IWRITE)
    func(path)

shutil.rmtree(directory, onerror=remove_readonly)


#example that uses the ignore_patterns() helper:
from shutil import copytree, ignore_patterns

copytree(source, destination, ignore=ignore_patterns('*.pyc', 'tmp*'))


#example that uses the ignore argument to add a logging call:
from shutil import copytree
import logging

def _logpath(path, names):
    logging.info('Working in %s', path)
    return []   # nothing will be ignored

copytree(source, destination, ignore=_logpath)

##API 
shutil.copyfileobj(fsrc, fdst[, length])
    Copy the contents of the file-like object fsrc to the file-like object fdst. 
shutil.copyfile(src, dst, *, follow_symlinks=True)
    Copy the contents (no metadata) of the file named src to a file named dst and return dst. 
    src and dst are path names given as strings. 
shutil.copymode(src, dst, *, follow_symlinks=True)
    Copy the permission bits from src to dst. 
    The file contents, owner, and group are unaffected. 
    src and dst are path names given as strings. 
shutil.copystat(src, dst, *, follow_symlinks=True)
    Copy the permission bits, last access time, last modification time, and flags from src to dst. 
    The file contents, owner, and group are unaffected. 
    src and dst are path names given as strings.
shutil.copy(src, dst, *, follow_symlinks=True)
    Copies the file src to the file or directory dst. src and dst should be strings. 
    If dst specifies a directory, the file will be copied into dst using the base filename from src. 
    Returns the path to the newly created file.
shutil.copy2(src, dst, *, follow_symlinks=True)
    Identical to copy() except that copy2() also attempts to preserve all file metadata.
shutil.ignore_patterns(*patterns)
    This factory function creates a function that can be used as a callable 
    for copytree()�s ignore argument, 
shutil.copytree(src, dst, symlinks=False, ignore=None, copy_function=copy2, ignore_dangling_symlinks=False)
    Recursively copy an entire directory tree rooted at src, returning the destination directory. 
    The destination directory, named by dst, must not already exist; 
shutil.rmtree(path, ignore_errors=False, onerror=None)
    Delete an entire directory tree; 
    path must point to a directory (but not a symbolic link to a directory). 
shutil.move(src, dst, copy_function=copy2)
    Recursively move a file or directory (src) to another location (dst) and return the destination.
    If the destination is an existing directory, then src is moved inside that directory. 
    If the destination already exists but is not a directory
shutil.disk_usage(path)
    Return disk usage statistics about the given path as a named tuple 
    with the attributes total, used and free, 
    which are the amount of total, used and free space, in bytes. 
    On Windows, path must be a directory; on Unix, it can be a file or directory.
shutil.chown(path, user=None, group=None)
    Change owner user and/or group of the given path.
shutil.which(cmd, mode=os.F_OK | os.X_OK, path=None)
    Return the path to an executable which would be run if the given cmd was called. 

    
    
    
###*** Doctest 
#The output should exactly match interpretor output including blanks
#Next test case is either blank line or >>> (should not contain any blanks)

def square(x):
    r"""Saure function
    takes one arg
    
    >>> square(10)#doctest: +REPORT_NDIFF
    100
    
    >>> [1,2,3] #doctest: +ELLIPSIS
    [...
    
    >>> [1,2,3,4] #doctest: +NORMALIZE_WHITESPACE
    [1, 2, 
    3, 4]
    
    >>> print(1,2,3,4,sep='\n\n')
    1
    <BLANKLINE>
    2
    <BLANKLINE>
    3
    <BLANKLINE>
    4
    
    >>> 1/0
    Traceback (most recent call last):
    ...
    ZeroDivisionError: division by zero

    """
    z = x*x 
    return z
    
#python -m doctest -v filename 
#or 
#with below, python filename -v 
if __name__ == "__main__":
    import doctest
    doctest.testmod()
    
    
    
    
###*** Module Json 
#JSON (JavaScript Object Notation) specified by RFC 7159 

# to and from file 
json.dump(obj, fp, skipkeys=False, ensure_ascii=True, check_circular=True, 
   allow_nan=True, cls=None, indent=None, separators=None, default=None, sort_keys=False, **kw)
#fp is opened as fp = open(filename, "w")
#indent is string which is used for indentation

json.load(fp, cls=None, object_hook=None, parse_float=None, parse_int=None, 
    parse_constant=None, object_pairs_hook=None, **kw)
#fp is opened as fp = open(filename, "r")
#parse_type, if specified, will be called with the string of every JSON 'type' to be decoded


#To and from string  
json.dumps(obj, skipkeys=False, ensure_ascii=True, check_circular=True, 
    allow_nan=True, cls=None, indent=None, separators=None, default=None, sort_keys=False, **kw)

json.loads(s, encoding=None, cls=None, object_hook=None, parse_float=None, 
    parse_int=None, parse_constant=None, object_pairs_hook=None, **kw)
    
#Jason syntax 
JSON data is written as - "name":value pairs, eg -  "firstName":"John"
name is in double quote
JSON values can be:
    A number (integer or floating point)
    A string (in double quotes)
    A Boolean (true or false)
    An array (in square brackets with , as separator )
    An object (in curly braces with "name":value)
    null


#The file type for JSON files is ".json"
#The MIME type for JSON text is "application/json"
#No comment is allowed  even with /* */, // or #
#Only one root element or object is allowed, no multiple root elements 

#conversion table
#Python			JSON
dict 			object 
list, tuple 	array 
str 			string 
int, float,     int,float
True 			true 
False 			false 
None 			null 

#Note, separators=(',', ': ') as default if indent is not None.
#The json module always produces str objects, not bytes objects
#Keys in key/value pairs of JSON are always of the type str. 
#When a dictionary is converted into JSON, all the keys of the dictionary are coerced to strings
#That is, loads(dumps(x)) != x if x has non-string keys.
 

#Example file: example.json  
[
 { "empId: 1, "details": 
                        {                       
                          "firstName": "John",
                          "lastName": "Smith",
                          "isAlive": true,
                          "age": 25,
                          "salary": 123.5,
                          "address": {
                            "streetAddress": "21 2nd Street",
                            "city": "New York",
                            "state": "NY",
                            "postalCode": "10021-3100"
                          },
                          "phoneNumbers": [
                            {
                              "type": "home",
                              "number": "212 555-1234"
                            },
                            {
                              "type": "office",
                              "number": "646 555-4567"
                            },
                            {
                              "type": "mobile",
                              "number": "123 456-7890"
                            }
                          ],
                          "children": [],
                          "spouse": null
                        }
  } , { "empId: 20, "details": 
                            {                       
                              "firstName": "Johns",
                              "lastName": "Smith",
                              "isAlive": true,
                              "age": 25,
                              "salary": 123.5,
                              "address": {
                                "streetAddress": "21 2nd Street",
                                "city": "New York",
                                "state": "NY",
                                "postalCode": "10021-3100"
                              },
                              "phoneNumbers": [
                                {
                                  "type": "home",
                                  "number": "212 555-1234"
                                },
                                {
                                  "type": "office",
                                  "number": "646 555-4567"
                                },
                                {
                                  "type": "mobile",
                                  "number": "123 456-7890"
                                }
                              ],
                              "children": [],
                              "spouse": null
                            }
    }
]

#Example reading file 
import json 
import pprint 
fp = open("data/example.json", "r")
obj = json.load(fp)
fp.close()
pprint.pprint(obj)  #check size 
[{'details': {'address': {'city': 'New York',
                          'postalCode': '10021-3100',
                          'state': 'NY',
                          'streetAddress': '21 2nd Street'},
              'age': 25,
              'children': [],
              'firstName': 'John',
              'isAlive': True,
              'lastName': 'Smith',
              'phoneNumbers': [{'number': '212 555-1234', 'type': 'home'},
                               {'number': '646 555-4567', 'type': 'office'},
                               {'number': '123 456-7890', 'type': 'mobile'}],
              'salary': 123.5,
              'spouse': None},
  'empId': 1},
 {'details': {'address': {'city': 'New York',
                          'postalCode': '10021-3100',
                          'state': 'NY',
                          'streetAddress': '21 2nd Street'},
              'age': 25,
              'children': [],
              'firstName': 'Johns',
              'isAlive': True,
              'lastName': 'Smith',
              'phoneNumbers': [{'number': '212 555-1234', 'type': 'home'},
                               {'number': '646 555-4567', 'type': 'office'},
                               {'number': '123 456-7890', 'type': 'mobile'}],
              'salary': 123.5,
              'spouse': None},
  'empId': 20}]

#manipulations 
len(obj)        #2
type(obj)       #<class 'list'>
type(obj[0])    #<class 'dict'>
with open("data/example1.json", "w") as fp1:
    json.dump(obj, fp1, indent='\t')
  
#Obj is array , all array manipulations can be used 
[emp['details']['address']['state']   for emp in obj if emp['empId'] > 10] 



###*** xml.etree.ElementTree � The ElementTree XML API (same in Py3.x and Py2.7)
#std module 
 
#Example: country_data.xml file 
  
<?xml version="1.0"?>
<data>
    <country name="Liechtenstein">
        <rank>1</rank>
        <year>2008</year>
        <gdppc>141100</gdppc>
        <neighbor name="Austria" direction="E"/>
        <neighbor name="Switzerland" direction="W"/>
    </country>
    <country name="Singapore">
        <rank>4</rank>
        <year>2011</year>
        <gdppc>59900</gdppc>
        <neighbor name="Malaysia" direction="N"/>
    </country>
    <country name="Panama">
        <rank>68</rank>
        <year>2011</year>
        <gdppc>13600</gdppc>
        <neighbor name="Costa Rica" direction="W"/>
        <neighbor name="Colombia" direction="E"/>
    </country>
</data>


#code 
import xml.etree as etree


import xml.etree.ElementTree as ET
tree = ET.parse('example.xml')
root = tree.getroot()

print(ET.tostring(root))  #give element 

#Or directly from a string:
root = ET.fromstring(country_data_as_string)

#Every element has a tag and a dictionary of attributes

>>> root.tag
'data'
>>> root.attrib
{}


#It also has children nodes over which we can iterate

for child in root:
    print(child.tag, child.attrib)
...
country {'name': 'Liechtenstein'}
country {'name': 'Singapore'}
country {'name': 'Panama'}


#Children are nested, 
#access specific child nodes by index:

>>> root[0][1].text

#Finding interesting elements

#use Element.iter()
#any tag can be given, then it would return list of those 
for neighbor in root.iter('neighbor'):
		print(neighbor.attrib)

#Use Element.findall() finds only elements with a tag which are direct children of the current element. 
#Element.find() finds the first child with a particular tag, 
#Element.text accesses the element�s text content. 
#Element.get() accesses the element�s attributes


for country in root.findall('country'):
		rank = country.find('rank').text
		name = country.get('name')
		print(name, rank)

##XPath support - limited support via findall() and find()
#findall always return list of ELement 
#find always return single Element 

import xml.etree.ElementTree as ET

# Top-level elements
root.findall(".")

# All 'neighbor' grand-children of 'country' children of the top-level
# elements
root.findall("./country/neighbor")

# Nodes with name='Singapore' that have a 'year' child
root.findall(".//year/..[@name='Singapore']")
ET.tostring(x[0])

# 'year' nodes that are children of nodes with name='Singapore'
root.findall(".//*[@name='Singapore']/year")

# All 'neighbor' nodes that are the second child of their parent
root.findall(".//neighbor[2]")

#Modifying an XML File
#to update attribute,  use Element.set()
#to update text, just assign to text 

for rank in root.iter('rank'):
		new_rank = int(rank.text) + 1
		rank.text = str(new_rank)
		rank.set('updated', 'yes')

tree.write('output.xml')


#remove elements using Element.remove(). 

>>> for country in root.findall('country'):
		rank = int(country.find('rank').text)
		if rank > 50:
			root.remove(country)

>>> tree.write('output.xml')

#Building XML documents

>>> a = ET.Element('a')
>>> b = ET.SubElement(a, 'b')
>>> c = ET.SubElement(a, 'c')
>>> d = ET.SubElement(c, 'd')
>>> ET.dump(a)
<a><b /><c><d /></c></a>

##To add new element, use Element.append()
def SubElementWithText(parent, tag, text):
    attrib = {}
    element = parent.makeelement(tag, attrib)
    parent.append(element)
    element.text = text
    return element

#Usage 
import xml.etree.ElementTree as ET

tree = ET.parse('test.xml')
root = tree.getroot()

a = root.find('a')
b = ET.SubElement(a, 'b')
c = SubElementWithText(b, 'c', 'text3')
print(ET.tostring(root))

#Parsing XML with Namespaces
#If the XML input has namespaces, 
#tags and attributes with prefixes in the form prefix:sometag 
#get expanded to {uri}sometag where the prefix is replaced by the full URI.
#Also, if there is a default namespace, that full URI gets prepended to all of the non-prefixed tags

<?xml version="1.0"?>
<actors xmlns:fictional="http://characters.example.com"
        xmlns="http://people.example.com">
    <actor>
        <name>John Cleese</name>
        <fictional:character>Lancelot</fictional:character>
        <fictional:character>Archie Leach</fictional:character>
    </actor>
    <actor>
        <name>Eric Idle</name>
        <fictional:character>Sir Robin</fictional:character>
        <fictional:character>Gunther</fictional:character>
        <fictional:character>Commander Clement</fictional:character>
    </actor>
</actors>


#Option-1 

root = fromstring(xml_text)
for actor in root.findall('{http://people.example.com}actor'):
    name = actor.find('{http://people.example.com}name')
    print(name.text)
    for char in actor.findall('{http://characters.example.com}character'):
        print(' |-->', char.text)


#Option-2

ns = {'real_person': 'http://people.example.com',
      'role': 'http://characters.example.com'}

for actor in root.findall('real_person:actor', ns):
    name = actor.find('real_person:name', ns)
    print(name.text)
    for char in actor.findall('role:character', ns):
        print(' |-->', char.text)


		


###HTML Handling 
#Below methods has method is either "xml", "html" or "text" (default is "xml"). 
xml.etree.ElementTree.tostring(element, encoding="us-ascii", method="xml")
xml.etree.ElementTree.tostringlist(element, encoding="us-ascii", method="xml")
class xml.etree.ElementTree.ElementTree(element=None, file=None)
    write(file, encoding="us-ascii", xml_declaration=None, default_namespace=None, method="xml")


#html file 
<html>
    <head>
        <title>Example page</title>
    </head>
    <body>
        <p>Moved to <a href="http://example.org/">example.org</a>
        or <a href="http://example.com/">example.com</a>.</p>
    </body>
</html>

#example 

from xml.etree.ElementTree import ElementTree
tree = ElementTree()
tree.parse("index.xhtml")
#<Element 'html' at 0xb77e6fac>
p = tree.find("body/p")     # Finds first occurrence of tag p in body
links = list(p.iter("a"))   # Returns list of all links
links
#[<Element 'a' at 0xb77ec2ac>, <Element 'a' at 0xb77ec1cc>]
for i in links:             # Iterates through all found links
    i.attrib["target"] = "blank"

tree.write("output.xhtml")




###*** Apache requests 
$ pip install requests 

##MAIn API 
requests.request(method, url, **kwargs)
    Constructs and sends a Request.
    Parameters:
        method -- method for the new Request object.
        url -- URL for the new Request object.
        params -- (optional) Dictionary or bytes to be sent in the query string for the Request.
        data -- (optional) Dictionary or list of tuples [(key, value)] (will be form-encoded), bytes, or file-like object to send in the body of the Request.
        json -- (optional) json data to send in the body of the Request.
        headers -- (optional) Dictionary of HTTP Headers to send with the Request.
        cookies -- (optional) Dict or CookieJar object to send with the Request.
        files -- (optional) Dictionary of 'name': file-like-objects (or {'name': file-tuple}) for multipart encoding upload. file-tuple can be a 2-tuple ('filename', fileobj), 3-tuple ('filename', fileobj, 'content_type') or a 4-tuple ('filename', fileobj, 'content_type', custom_headers), where 'content-type' is a string defining the content type of the given file and custom_headers a dict-like object containing additional headers to add for the file.
        auth -- (optional) Auth tuple to enable Basic/Digest/Custom HTTP Auth.
        timeout (float or tuple) -- (optional) How many seconds to wait for the server to send data before giving up, as a float, or a (connect timeout, read timeout) tuple.
        allow_redirects (bool) -- (optional) Boolean. Enable/disable GET/OPTIONS/POST/PUT/PATCH/DELETE/HEAD redirection. Defaults to True.
        proxies -- (optional) Dictionary mapping protocol to the URL of the proxy.
        verify -- (optional) Either a boolean, in which case it controls whether we verify the server's TLS certificate, or a string, in which case it must be a path to a CA bundle to use. Defaults to True.
        stream -- (optional) if False, the response content will be immediately downloaded.
        cert -- (optional) if String, path to ssl client cert file (.pem). If Tuple, ('cert', 'key') pair.
    Returns:
        Response object
        >>> dir(requests.Response)
        ['__attrs__', '__bool__', '__class__', '__delattr__', '__dict__', '__dir__', '__doc__', '__enter__', 
        '__eq__', '__exit__', '__format__', '__ge__', '__getattribute__', '__getstate__', '__gt__', '__hash__', 
        '__init__', '__iter__', '__le__', '__lt__', '__module__', '__ne__', '__new__', '__nonzero__', '__reduce__', 
        '__reduce_ex__', '__repr__', '__setattr__', '__setstate__', '__sizeof__', '__str__', '__subclasshook__', 
        '__weakref__', 'apparent_encoding', 'close', 'content', 'is_permanent_redirect', 'is_redirect', 
        'iter_content', 'iter_lines', 'json', 'links', 'next', 'ok', 'raise_for_status', 'text']

#example
import requests
r = requests.get("http://www.yahoo.com")
r.text
r.status_code   # status code
r.headers  		# dict object

#With HTTPs
>>> r = requests.get('https://api.github.com/user', auth=('user', 'pass'), verify=False) #Requests could verify SSL certificates for https requests automatically and it sets verify=True as default.
>>> r.status_code
200
>>> r.headers['content-type']
'application/json; charset=utf8'
>>> r.encoding
'utf-8'
>>> r.text
u'{"type":"User"...'
>>> r.json()
{u'private_gists': 419, u'total_private_repos': 77, ...}


#with proxy 
p1 = 'http://proxy_username:proxy_password@proxy_server.com:port'
p2 = 'https://proxy_username:proxy_password@proxy_server.com:port'
proxy = {'http': p1, 'https':p2}
r = requests.get(site, proxies=proxy, auth=('site_username', 'site_password')) #Site basic authentication 



##RESTful API
r = requests.post(site)
r = requests.put("site/put")
r = requests.delete("site/delete")
r = requests.head("site/get")
r = requests.options("site/get")


##Get - use 'params'
import requests 
payload1 = {'key1': 'value1', 'key2': 'value2'}
r = requests.get("http://httpbin.org/get", params=payload1)
print(r.url)  #http://httpbin.org/get?key2=value2&key1=value1
r.headers
r.text
r.json()  # it's a python dict

#For Request debugging,
>>> r.request.url
'http://httpbin.org/forms/post?delivery=12&topping=onion&custtel=123&comments=ok&custname=das&custemail=ok%40com&size=small'
>>> r.request.headers
{'Content-Length': '0', 'User-Agent': 'Mozilla/5.0', 'Connection': 'keep-alive', 'Accept': '*/*', 'Accept-Encoding': 'gzip, deflate'}
>>> r.request.body


##POST, use 'data'
headers = {'User-Agent': 'Mozilla/5.0'}
payload = {'custname':'das', 'custtel': '123', 'custemail' : 'ok@com', 'size':'small',  'topping':'bacon',  'topping': 'onion',  'delivery':'12', 'comments': 'ok'}
r = requests.post("http://httpbin.org/post", data=payload, headers=headers)
r.text
r.headers
r.json()

r.request.headers
r.request.body #custname=das&custtel=123&custemail=ok@com&size=small&topping=bacon&topping=onion&delivery=12&comments=ok

##Content
r.text
r.content  # as bytes
r.json()  # json content


##Custom Headers and body 
import json
payload = {'some': 'data'}
headers = {'content-type': 'application/json'}
r = requests.post(url, data=json.dumps(payload), headers=headers)

##POST a Multipart-Encoded File
files = {'file': open('report.xls', 'rb')}
r = requests.post(url, files=files)

##Cookies
#get
r.cookies['example_cookie_name']

#or sending
cookies = dict(cookies_are='working')
r = requests.get(url, cookies=cookies)

##Or persisting across session
s = requests.Session()
s.get('http://httpbin.org/cookies/set/sessioncookie/123456789')
r = s.get("http://httpbin.org/cookies")
r.text # contains cookies from first access


##Example:
import requests
headers = {'User-Agent': 'Mozilla/5.0'}
payload = {'username':'niceusername','pass':'123456'}

session = requests.Session()
session.post('https://admin.example.com/login.php',headers=headers,data=payload)
# the session instance holds the cookie. So use it to get/post later.
# e.g. session.get('https://example.com/profile')











###*** XML Processing - Use BeautifulSoup for HTML/XML processing
#no xpath, but css select 
$ pip install BeautifulSoup4
$ pip install requests

#code 
#main attributes of a soup element - .name(for tag) .attrs(for attrib), .text (for text)
# tag['one_attrib'] gives attributes value 
from bs4 import BeautifulSoup
import requests

r  = requests.get("http://www.yahoo.com")
data = r.text

soup = BeautifulSoup(data, "html.parser")
print(soup.prettify())
#extracting all the text from a page:
print(soup.get_text())

#finding all 
#Signature: find_all(name=None, attrs={}, recursive=True, text=None, limit=None **kwargs)
#specify the name of the Tag and any attributes you want the Tag to have.
#name can be a string(inc tag), a regular expression, a list, a function, or the value True.
#The value of a key-value pair in the 'attrs' map can be a string, a list of strings, 
#a regular expression object, or a callable that takes a string and returns whether or not the string matches for some custom definition of 'matches'. 

for link in soup.find_all('a'):  # tag <a href=".."
		print(link.get('href'))	 # Attribute href


##Parser 
#lxml 
#from http://www.lfd.uci.edu/~gohlke/pythonlibs/#lxml

#html5lib 
$ pip install html5lib

BeautifulSoup(markup, "html.parser") #default
BeautifulSoup(markup, "lxml")  #very fast 
BeautifulSoup(markup, "lxml-xml")  #only xml parser
BeautifulSoup(markup, "xml")
BeautifulSoup(markup, "html5lib") #creates valid HTML5, �Extremely lenient, very slow


    
##	tag becomes attributes of soup object
soup = BeautifulSoup('<html><body><p class="title">data</p><p class="title">data</p></body></html>', 'html.parser')
#Only first P 
soup.html
soup.html.body.p
soup.html.body.text #or .string
soup.html.body.attrs  #{'class': ['title']}
soup.html.body.name
soup.html.body.p['class']
soup.body
soup.body.attrs
soup.p.text  		# can get all nested .p directly 
#to get all P 
list(soup.html.body.children) #[<p class="title">data</p>, <p class="title">data</p>]
soup.get_text()  
soup.html.name
soup.p.parent.name

##Tag 
soup = BeautifulSoup('<b id="boldest">Extremely bold</b>')
tag = soup.b
type(tag)
# <class 'bs4.element.Tag'>
tag.name
# u'b'
#modify 
tag.name = "blockquote"
tag
# <blockquote id="boldest">Extremely bold</blockquote>

##Attributes like dict 
tag.has_attr('id') #True 
tag['id']
# u'boldest'
tag.attrs
# {u'id': 'boldest'}
#add, remove, and modify a tag�s attributes
tag['id'] = 'verybold'
tag['another-attribute'] = 1
tag
# <b another-attribute="1" id="verybold"></b>

del tag['id']
del tag['another-attribute']
tag
# <b></b>

tag['id']
# KeyError: 'id'
print(tag.get('id'))
# None

##multivalued attribute
# Beautiful Soup presents the value(s) of a multi-valued attribute as a list:

css_soup = BeautifulSoup('<p class="body strikeout"></p>')
css_soup.p['class']
# ["body", "strikeout"]

css_soup = BeautifulSoup('<p class="body"></p>')
css_soup.p['class']
# ["body"]

#for non multivalued, does not convert to list 
id_soup = BeautifulSoup('<p id="my id"></p>')
id_soup.p['id']
# 'my id'


#turn a tag back into a string, multiple attribute values are consolidated:
rel_soup = BeautifulSoup('<p>Back to the <a rel="index">homepage</a></p>')
rel_soup.a['rel']
# ['index']
rel_soup.a['rel'] = ['index', 'contents']
print(rel_soup.p)
# <p>Back to the <a rel="index contents">homepage</a></p>

#use `get_attribute_list to get a value that�s always a list
id_soup.p.get_attribute_list('id') # ['my id']

#for XML, there are no multi-valued attributes:
xml_soup = BeautifulSoup('<p class="body strikeout"></p>', 'xml')
xml_soup.p['class']
# u'body strikeout'

##A string corresponds to  text within a tag
#NavigableString supports most of the features of Navigating the tree and Searching the tree
tag.string
# u'Extremely bold'
type(tag.string)
# <class 'bs4.element.NavigableString'>



##	Pretty-printing
print(soup.prettify())

##Non-pretty printing
print(str(soup))

##Navigating using tag names - other than tags become soup's attributes 
.contents and .children
#A tag�s children are available in a LIST called .contents
#The .contents and .children attributes only consider a tag�s direct children
#Instead of getting as a list, iterate over a tag�s children using the .children generator:
for child in title_tag.children:
    print(child)

    
.descendants
#The .descendants attribute iterates over all of a tag�s children, recursively: 
#its direct children, the children of its direct children, and so on
for child in head_tag.descendants:
    print(child)

.string
#If a tag has only one NavigableString as child
#or tag has one child tag who has another the NavigableString child 
#that is  .string, else it is NOne 

.strings and stripped_strings
#If there�s more than one thing inside a tag, 
# Use the .strings generator or .stripped_strings generator(whitespace removed)
for string in soup.strings:
    print(repr(string))


.parent
#an element�s parent
title_tag = soup.title
title_tag
# <title>The Dormouse's story</title>
title_tag.parent
# <head><title>The Dormouse's story</title></head>
#The title string itself has a parent: the <title> tag that contains it:
title_tag.string.parent
# <title>The Dormouse's story</title>
html_tag = soup.html
type(html_tag.parent)
# <class 'bs4.BeautifulSoup'>
print(soup.parent)
# None


.parents
#iterate over all of an element�s parents 


.next_sibling and .previous_sibling
#navigate to one sibling (elements that are on the same level of the parse tree)
#Example 
<a href="http://example.com/elsie" class="sister" id="link1">Elsie</a>
<a href="http://example.com/lacie" class="sister" id="link2">Lacie</a>
<a href="http://example.com/tillie" class="sister" id="link3">Tillie</a>
#Note  .next_sibling of the first <a> tag is not second <a> tag. 
#But actually, it�s a string: the comma and newline that separate the first <a> tag from the second:
link = soup.a
link
# <a class="sister" href="http://example.com/elsie" id="link1">Elsie</a>
link.next_sibling
# u',\n'

#The second <a> tag is actually the .next_sibling of the comma:
link.next_sibling.next_sibling
# <a class="sister" href="http://example.com/lacie" id="link2">Lacie</a>



.next_siblings and .previous_siblings
#iterate all siblings


.next_element and .previous_element
#next or previous element , might not be equivalent to siblings 

.next_elements and .previous_elements
#iterate all elements



s = """<html>
 <head>
  <title>
   Page title
  </title>
 </head>
 <body>
  <p id="firstpara" align="center">
   This is paragraph
   <b>
    one
   </b>
   .
  </p>
  <p id="secondpara" align="blah">
   This is paragraph
   <b>
    two
   </b>
   .
  </p>
 </body>
</html>"""
soup = BeautifulSoup(s)

##	Searching the string
find_all(tag_name, attrs, recursive, text, limit, **kwargs)  #returns list 
find(name, attrs, recursive, string, **kwargs) #returns first element
#The find_all() method looks through a tag�s descendants and retrieves all descendants in a list 
#specify the name of the Tag and any attributes you want the Tag to have.
#name can be a string(inc tag), a regular expression, a list, a function, or the value True.
#The value of a key-value pair in the 'attrs' map can be a string, a list of strings, 
#a regular expression object, or a callable that takes a string and returns whether or not the string matches for some custom definition of 'matches'. The
#The keyword arguments impose restrictions on the attributes of a tag. 


##Using - name 
#String 
#This code finds all the <B> Tags in the document:
soup.findAll('b')
# [<b>one</b>, <b>two</b>]

#RE 
#This code finds all the tags whose names start with B:
import re
tagsStartingWithB = soup.findAll(re.compile('^b'))
[tag.name for tag in tagsStartingWithB]
# [u'body', u'b', u'b']

#list or a dictionary. 
#find all the <TITLE> and all the <P> tags. 
soup.findAll(['title', 'p'])
# [<title>Page title</title>, 
#  <p id="firstpara" align="center">This is paragraph <b>one</b>.</p>, 
#  <p id="secondpara" align="blah">This is paragraph <b>two</b>.</p>]

soup.findAll({'title' : True, 'p' : True})
# [<title>Page title</title>, 
#  <p id="firstpara" align="center">This is paragraph <b>one</b>.</p>, 
#  <p id="secondpara" align="blah">This is paragraph <b>two</b>.</p>]


#True 
#which matches every tag with a name: that is, it matches every tag.
allTags = soup.findAll(True)
[tag.name for tag in allTags]
[u'html', u'head', u'title', u'body', u'p', u'b', u'p', u'b']


#Callable 
#which takes a Tag object as its only argument, and returns a boolean. 
#This code finds the tags that have two, and only two, attributes:
soup.findAll(lambda tag: len(tag.attrs) == 2)
# [<p id="firstpara" align="center">This is paragraph <b>one</b>.</p>, 
#  <p id="secondpara" align="blah">This is paragraph <b>two</b>.</p>]

#This code finds the tags that have one-character names and no attributes:
soup.findAll(lambda tag: len(tag.name) == 1 and not tag.attrs)
# [<b>one</b>, <b>two</b>]



##Using **kwargs
#The keyword arguments impose restrictions on the attributes of a tag. 
#value of keyword can be same like for name arg 

#This simple example finds all the tags with attribs 'align' and it's value 'center'
soup.findAll(align="center")
# [<p id="firstpara" align="center">This is paragraph <b>one</b>.</p>]

#RE 
soup.findAll(id=re.compile("para$"))
# [<p id="firstpara" align="center">This is paragraph <b>one</b>.</p>,
#  <p id="secondpara" align="blah">This is paragraph <b>two</b>.</p>]

#List 
soup.findAll(align=["center", "blah"])
# [<p id="firstpara" align="center">This is paragraph <b>one</b>.</p>,
#  <p id="secondpara" align="blah">This is paragraph <b>two</b>.</p>]

#Callable 
soup.findAll(align=lambda value : value and len(value) < 5)
# [<p id="secondpara" align="blah">This is paragraph <b>two</b>.</p>]

#True and None
#True matches a tag that has any value for the given attribute, 
#and None matches a tag that has no value for the given attribute
soup.findAll(align=True)
# [<p id="firstpara" align="center">This is paragraph <b>one</b>.</p>,
#  <p id="secondpara" align="blah">This is paragraph <b>two</b>.</p>]

[tag.name for tag in soup.findAll(align=None)]
# [u'html', u'head', u'title', u'body', u'b', u'b']

#What if you have a document with a tag that defines an attribute called name? 
#or a Python reserved word like for as a keyword argument.
#Use attrs
#attrs is a dictionary that acts  like the **kwargs, 
#ie can take string, RE, list of String and callable 

soup.findAll(id=re.compile("para$"))
# [<p id="firstpara" align="center">This is paragraph <b>one</b>.</p>,
#  <p id="secondpara" align="blah">This is paragraph <b>two</b>.</p>]

soup.findAll(attrs={'id' : re.compile("para$")})
# [<p id="firstpara" align="center">This is paragraph <b>one</b>.</p>,
#  <p id="secondpara" align="blah">This is paragraph <b>two</b>.</p>]

#with name as attribute (conflicts because find_all has name one of it's arg)
from BeautifulSoup import BeautifulStoneSoup
xml = '<person name="Bob"><parent rel="mother" name="Alice">'
xmlSoup = BeautifulStoneSoup(xml)

xmlSoup.findAll(name="Alice")
# []

xmlSoup.findAll(attrs={"name" : "Alice"})
# [parent rel="mother" name="Alice"></parent>]


##Searching by CSS class - special use of 'string' as attrs arg 
soup.find("tagName", attrs={ "class" : "cssClass" }), 
#OR  pass a string for attrs instead of a dictionary. 
#The string will be used to restrict the CSS class.

from BeautifulSoup import BeautifulSoup
soup = BeautifulSoup("""Bob's <b>Bold</b> Barbeque Sauce now available in 
                        <b class="hickory">Hickory</b> and <b class="lime">Lime</a>""")

soup.find("b", { "class" : "lime" })
# <b class="lime">Lime</b>

soup.find("b", "hickory")
# <b class="hickory">Hickory</b>

##text is an argument that lets you search for NavigableString objects instead of Tags. 
#Its value can be a string, a regular expression, a list or dictionary, True or None, 
#or a callable that takes a NavigableString object as its argument
#If you use text, then any values you give for name and the keyword arguments are ignored.

soup.findAll(text="one")
# [u'one']
soup.findAll(text=u'one')
# [u'one']

soup.findAll(text=["one", "two"])
# [u'one', u'two']

soup.findAll(text=re.compile("paragraph"))
# [u'This is paragraph ', u'This is paragraph ']

soup.findAll(text=True)
# [u'Page title', u'This is paragraph ', u'one', u'.', u'This is paragraph ', 
#  u'two', u'.']

soup.findAll(text=lambda x: len(x) < 12)
# [u'Page title', u'one', u'.', u'two', u'.']


##recursive is a boolean argument (defaulting to True) 
#which tells Beautiful Soup whether to go all the way down the parse tree, 
#or whether to only look at the immediate children of the Tag or the parser object.

[tag.name for tag in soup.html.findAll()]
# [u'head', u'title', u'body', u'p', u'b', u'p', u'b']

[tag.name for tag in soup.html.findAll(recursive=False)]
# [u'head', u'body']


##Setting limit argument lets to stop the search once Beautiful Soup finds a certain number of matches. 
#If there are a thousand tables in your document, but you only need the fourth one, pass in 4 to limit 
#By default, there is no limit.

soup.findAll('p', limit=1)
# [<p id="firstpara" align="center">This is paragraph <b>one</b>.</p>]

soup.findAll('p', limit=100)
# [<p id="firstpara" align="center">This is paragraph <b>one</b>.</p>, 
#  <p id="secondpara" align="blah">This is paragraph <b>two</b>.</p>]


##Calling a tag is like calling findall
#If you call the parser object or a Tag like a function, 
#then you can pass in all of findall's arguments and it's the same as calling findall. 

soup(text=lambda x: len(x) < 12)
# [u'Page title', u'one', u'.', u'two', u'.']

soup.body('p', limit=1)
# [<p id="firstpara" align="center">This is paragraph <b>one</b>.</p>]


##Special handling of Some attributes, 
#like the data-* attributes in HTML 5, can not be used 
data_soup = BeautifulSoup('<div data-foo="value">foo!</div>')
data_soup.find_all(data-foo="value")
# SyntaxError: keyword can't be an expression
#use as 
data_soup.find_all(attrs={"data-foo": "value"})
# [<div data-foo="value">foo!</div>]

#special handling of class attribute(use class_)
#you can pass class_ a string, a regular expression, a function, or True:
soup.find_all("a", class_="sister")
# [<a class="sister" href="http://example.com/elsie" id="link1">Elsie</a>,
#  <a class="sister" href="http://example.com/lacie" id="link2">Lacie</a>,
#  <a class="sister" href="http://example.com/tillie" id="link3">Tillie</a>]

soup.find_all(class_=re.compile("itl"))
# [<p class="title"><b>The Dormouse's story</b></p>]

def has_six_characters(css_class):
    return css_class is not None and len(css_class) == 6

soup.find_all(class_=has_six_characters)

#Maching any of class value 
css_soup = BeautifulSoup('<p class="body strikeout"></p>')
css_soup.find_all("p", class_="strikeout")
# [<p class="body strikeout"></p>]
css_soup.find_all("p", class_="body")
# [<p class="body strikeout"></p>]

#or full value in exact order 
css_soup.find_all("p", class_="body strikeout")
# [<p class="body strikeout"></p>]
#not in other order
css_soup.find_all("p", class_="strikeout body")
# []

#or use css selector where order does not matter 
css_soup.select("p.strikeout.body")
# [<p class="body strikeout"></p>]
#or use attrs 
soup.find_all("a", attrs={"class": "sister"})





##Other find methods - Usage is similar 
find_parents(name, attrs, text, limit, **kwargs)
find_parent(name, attrs, text, **kwargs)

find_next_siblings(name, attrs, text, limit, **kwargs)
find_next_sibling(name, attrs, text, **kwargs)

find_previous_siblings(name, attrs, text, limit, **kwargs)
find_previous_sibling(name, attrs, text, **kwargs)

find_all_next(name, attrs, text, limit, **kwargs)
find_next(name, attrs, text, **kwargs)

find_all_previous(name, attrs, text, limit, **kwargs)
find_previous(name, attrs, text, **kwargs)


##CSS Selector (supports a subset of CSS3)
select( selector, _candidate_generator=None, limit=None)

#Example 
html_doc = """
<html><head><title>The Dormouse's story</title></head>
<body>
<p class="title"><b>The Dormouse's story</b></p>

<p class="story">Once upon a time there were three little sisters; and their names were
<a href="http://example.com/elsie" class="sister" id="link1">Elsie</a>,
<a href="http://example.com/lacie" class="sister" id="link2">Lacie</a> and
<a href="http://example.com/tillie" class="sister" id="link3">Tillie</a>;
and they lived at the bottom of a well.</p>

<p class="story">...</p>"""
soup = BeautifulSoup(html_doc, 'html.parser')


#find tags:
soup.select("title")
# [<title>The Dormouse's story</title>]
soup.select("p:nth-of-type(3)")
# [<p class="story">...</p>]


#Find tags beneath other tags:
soup.select("body a")
# [<a class="sister" href="http://example.com/elsie" id="link1">Elsie</a>,
#  <a class="sister" href="http://example.com/lacie"  id="link2">Lacie</a>,
#  <a class="sister" href="http://example.com/tillie" id="link3">Tillie</a>]
soup.select("html head title")
# [<title>The Dormouse's story</title>]

#Find tags directly beneath other tags:
soup.select("head > title")
# [<title>The Dormouse's story</title>]

soup.select("p > a")
# [<a class="sister" href="http://example.com/elsie" id="link1">Elsie</a>,
#  <a class="sister" href="http://example.com/lacie"  id="link2">Lacie</a>,
#  <a class="sister" href="http://example.com/tillie" id="link3">Tillie</a>]

soup.select("p > a:nth-of-type(2)")
# [<a class="sister" href="http://example.com/lacie" id="link2">Lacie</a>]

soup.select("p > #link1")
# [<a class="sister" href="http://example.com/elsie" id="link1">Elsie</a>]

soup.select("body > a")
# []

#Find the siblings of tags:
soup.select("#link1 ~ .sister")
# [<a class="sister" href="http://example.com/lacie" id="link2">Lacie</a>,
#  <a class="sister" href="http://example.com/tillie"  id="link3">Tillie</a>]

soup.select("#link1 + .sister")
# [<a class="sister" href="http://example.com/lacie" id="link2">Lacie</a>]


#Find tags by CSS class:
soup.select(".sister")
# [<a class="sister" href="http://example.com/elsie" id="link1">Elsie</a>,
#  <a class="sister" href="http://example.com/lacie" id="link2">Lacie</a>,
#  <a class="sister" href="http://example.com/tillie" id="link3">Tillie</a>]

soup.select("[class~=sister]")
# [<a class="sister" href="http://example.com/elsie" id="link1">Elsie</a>,
#  <a class="sister" href="http://example.com/lacie" id="link2">Lacie</a>,
#  <a class="sister" href="http://example.com/tillie" id="link3">Tillie</a>]


#Find tags by ID:
soup.select("#link1")
# [<a class="sister" href="http://example.com/elsie" id="link1">Elsie</a>]

soup.select("a#link2")
# [<a class="sister" href="http://example.com/lacie" id="link2">Lacie</a>]

#Find tags that match any selector from a list of selectors:
soup.select("#link1,#link2") # [<a class=�sister� href=�http://example.com/elsie� id=�link1�>Elsie</a>, # <a class=�sister� href=�http://example.com/lacie� id=�link2�>Lacie</a>]

#Test for the existence of an attribute:
soup.select('a[href]')
# [<a class="sister" href="http://example.com/elsie" id="link1">Elsie</a>,
#  <a class="sister" href="http://example.com/lacie" id="link2">Lacie</a>,
#  <a class="sister" href="http://example.com/tillie" id="link3">Tillie</a>]

#Find tags by attribute value:
soup.select('a[href="http://example.com/elsie"]')
# [<a class="sister" href="http://example.com/elsie" id="link1">Elsie</a>]

soup.select('a[href^="http://example.com/"]')
# [<a class="sister" href="http://example.com/elsie" id="link1">Elsie</a>,
#  <a class="sister" href="http://example.com/lacie" id="link2">Lacie</a>,
#  <a class="sister" href="http://example.com/tillie" id="link3">Tillie</a>]

soup.select('a[href$="tillie"]')
# [<a class="sister" href="http://example.com/tillie" id="link3">Tillie</a>]

soup.select('a[href*=".com/el"]')
# [<a class="sister" href="http://example.com/elsie" id="link1">Elsie</a>]


#Match language codes:
multilingual_soup.select('p[lang|=en]')
# [<p lang="en">Hello</p>,
#  <p lang="en-us">Howdy, y'all</p>,
#  <p lang="en-gb">Pip-pip, old fruit</p>]


#Find only the first tag that matches a selector:
soup.select_one(".sister")
# <a class="sister" href="http://example.com/elsie" id="link1">Elsie</a>




##Changing tag names and attributes
soup = BeautifulSoup('<b class="boldest">Extremely bold</b>')
tag = soup.b

tag.name = "blockquote"
tag['class'] = 'verybold'
tag['id'] = 1
tag
# <blockquote class="verybold" id="1">Extremely bold</blockquote>

del tag['class']
del tag['id']
tag
# <blockquote>Extremely bold</blockquote>



##Modifying .string
markup = '<a href="http://example.com/">I linked to <i>example.com</i></a>'
soup = BeautifulSoup(markup)

tag = soup.a
tag.string = "New link text."
tag
# <a href="http://example.com/">New link text.</a>

##append()
#append to a tag�s contents
soup = BeautifulSoup("<a>Foo</a>")
soup.a.append("Bar")
soup
# <html><head></head><body><a>FooBar</a></body></html>
soup.a.contents
# [u'Foo', u'Bar']

#to add a string to a document
soup = BeautifulSoup("<b></b>")
tag = soup.b
tag.append("Hello")
new_string = NavigableString(" there")
tag.append(new_string)
tag
# <b>Hello there.</b>
tag.contents
# [u'Hello', u' there']


##to create a comment or some other subclass of NavigableString
from bs4 import Comment
new_comment = Comment("Nice to see you.")
tag.append(new_comment)
tag
# <b>Hello there<!--Nice to see you.--></b>
tag.contents
# [u'Hello', u' there', u'Nice to see you.']


##to create a whole new tag
soup = BeautifulSoup("<b></b>")
original_tag = soup.b

new_tag = soup.new_tag("a", href="http://www.example.com")
original_tag.append(new_tag)
original_tag
# <b><a href="http://www.example.com"></a></b>

new_tag.string = "Link text."
original_tag
# <b><a href="http://www.example.com">Link text.</a></b>

##insert()
#insert at whatever numeric position you say.
markup = '<a href="http://example.com/">I linked to <i>example.com</i></a>'
soup = BeautifulSoup(markup)
tag = soup.a

tag.insert(1, "but did not endorse ")
tag
# <a href="http://example.com/">I linked to but did not endorse <i>example.com</i></a>
tag.contents
# [u'I linked to ', u'but did not endorse', <i>example.com</i>]



##insert_before() and insert_after()
#inserts a tag or string immediately before/after something else in the parse tree:
soup = BeautifulSoup("<b>stop</b>")
tag = soup.new_tag("i")
tag.string = "Don't"
soup.b.string.insert_before(tag)
soup.b
# <b><i>Don't</i>stop</b>


soup.b.i.insert_after(soup.new_string(" ever "))
soup.b
# <b><i>Don't</i> ever stop</b>
soup.b.contents
# [<i>Don't</i>, u' ever ', u'stop']



##clear()
#removes the contents of a tag:
markup = '<a href="http://example.com/">I linked to <i>example.com</i></a>'
soup = BeautifulSoup(markup)
tag = soup.a

tag.clear()
tag
# <a href="http://example.com/"></a>


##extract()
#removes a tag or string from the tree
#returns the tag or string that was extracted:
markup = '<a href="http://example.com/">I linked to <i>example.com</i></a>'
soup = BeautifulSoup(markup)
a_tag = soup.a

i_tag = soup.i.extract()

a_tag
# <a href="http://example.com/">I linked to</a>

i_tag
# <i>example.com</i>

print(i_tag.parent)
None

#two parse trees
my_string = i_tag.string.extract()
my_string
# u'example.com'

print(my_string.parent)
# None
i_tag
# <i></i>



##decompose()
#removes a tag from the tree, then completely destroys it and its contents:
markup = '<a href="http://example.com/">I linked to <i>example.com</i></a>'
soup = BeautifulSoup(markup)
a_tag = soup.a

soup.i.decompose()

a_tag
# <a href="http://example.com/">I linked to</a>



##replace_with()
# removes a tag or string from the tree, and replaces it with the tag or string of your choice:
#returns the tag or string that was replaced
markup = '<a href="http://example.com/">I linked to <i>example.com</i></a>'
soup = BeautifulSoup(markup)
a_tag = soup.a

new_tag = soup.new_tag("b")
new_tag.string = "example.net"
a_tag.i.replace_with(new_tag)

a_tag
# <a href="http://example.com/">I linked to <b>example.net</b></a>

##wrap()
#wraps an element in the tag you specify. 
#It returns the new wrapper:
soup = BeautifulSoup("<p>I wish I was bold.</p>")
soup.p.string.wrap(soup.new_tag("b"))
# <b>I wish I was bold.</b>

soup.p.wrap(soup.new_tag("div")
# <div><p><b>I wish I was bold.</b></p></div>


##unwrap()
# opposite of wrap(). 
#It replaces a tag with whatever�s inside that tag. 
#returns the tag that was replaced.
#It�s good for stripping out markup:
markup = '<a href="http://example.com/">I linked to <i>example.com</i></a>'
soup = BeautifulSoup(markup)
a_tag = soup.a

a_tag.i.unwrap()
a_tag
# <a href="http://example.com/">I linked to example.com</a>



##use Unicode, Dammit without using Beautiful Soup. 
#It�s useful to guess correct encoding of the text 

from bs4 import UnicodeDammit
dammit = UnicodeDammit("Sacr\xc3\xa9 bleu!")
print(dammit.unicode_markup)
# Sacr� bleu!
dammit.original_encoding
# 'utf-8'


#Unicode, Dammit�s guesses will get a lot more accurate 
#if you install the chardet or cchardet Python libraries. 

#or can pass few our estimates 
dammit = UnicodeDammit("Sacr\xe9 bleu!", ["latin-1", "iso-8859-1"])
print(dammit.unicode_markup)
# Sacr� bleu!
dammit.original_encoding
# 'latin-1'


#use Unicode, Dammit to convert Microsoft smart quotes to HTML or XML entities:
markup = b"<p>I just \x93love\x94 Microsoft Word\x92s smart quotes</p>"

UnicodeDammit(markup, ["windows-1252"], smart_quotes_to="html").unicode_markup
# u'<p>I just &ldquo;love&rdquo; Microsoft Word&rsquo;s smart quotes</p>'

UnicodeDammit(markup, ["windows-1252"], smart_quotes_to="xml").unicode_markup
# u'<p>I just &#x201C;love&#x201D; Microsoft Word&#x2019;s smart quotes</p>'


#to convert Microsoft smart quotes to ASCII quotes:
UnicodeDammit(markup, ["windows-1252"], smart_quotes_to="ascii").unicode_markup
# u'<p>I just "love" Microsoft Word\'s smart quotes</p>'

#Beautiful Soup prefers the default behavior, 
#which is to convert Microsoft smart quotes to Unicode characters along with everything else:
UnicodeDammit(markup, ["windows-1252"]).unicode_markup
# u'<p>I just \u201clove\u201d Microsoft Word\u2019s smart quotes</p>'


##Inconsistent encodings
#Sometimes a document is mostly in UTF-8, 
#but contains Windows-1252 characters such as  Microsoft smart quotes. 


snowmen = (u"\N{SNOWMAN}" * 3)
quote = (u"\N{LEFT DOUBLE QUOTATION MARK}I like snowmen!\N{RIGHT DOUBLE QUOTATION MARK}")
doc = snowmen.encode("utf8") + quote.encode("windows_1252")
#messy display 
print(doc)
# ????I like snowmen!?
print(doc.decode("windows-1252"))
# ☃☃☃�I like snowmen!�

#use UnicodeDammit.detwingle() 
new_doc = UnicodeDammit.detwingle(doc)
print(new_doc.decode("utf8"))
# ???�I like snowmen!�


##Copying Beautiful Soup objects
import copy
p_copy = copy.copy(soup.p)
print p_copy
# <p>I want <b>pizza</b> and more <b>pizza</b>!</p>

print soup.p == p_copy
# True

print soup.p is p_copy
# False

##Comparing objects for equality
#content checking 
markup = "<p>I want <b>pizza</b> and more <b>pizza</b>!</p>"
soup = BeautifulSoup(markup, 'html.parser')
first_b, second_b = soup.find_all('b')
print first_b == second_b
# True

print first_b.previous_element == second_b.previous_element
# False

##Parsing only part of a document - use SoupStrainer
from bs4 import SoupStrainer

only_a_tags = SoupStrainer("a")

only_tags_with_id_link2 = SoupStrainer(id="link2")

def is_short_string(string):
    return len(string) < 10

only_short_strings = SoupStrainer(string=is_short_string)


html_doc = """
<html><head><title>The Dormouse's story</title></head>
<body>
<p class="title"><b>The Dormouse's story</b></p>

<p class="story">Once upon a time there were three little sisters; and their names were
<a href="http://example.com/elsie" class="sister" id="link1">Elsie</a>,
<a href="http://example.com/lacie" class="sister" id="link2">Lacie</a> and
<a href="http://example.com/tillie" class="sister" id="link3">Tillie</a>;
and they lived at the bottom of a well.</p>

<p class="story">...</p>
"""

print(BeautifulSoup(html_doc, "html.parser", parse_only=only_a_tags).prettify())
# <a class="sister" href="http://example.com/elsie" id="link1">
#  Elsie
# </a>
# <a class="sister" href="http://example.com/lacie" id="link2">
#  Lacie
# </a>
# <a class="sister" href="http://example.com/tillie" id="link3">
#  Tillie
# </a>

print(BeautifulSoup(html_doc, "html.parser", parse_only=only_tags_with_id_link2).prettify())
# <a class="sister" href="http://example.com/lacie" id="link2">
#  Lacie
# </a>

print(BeautifulSoup(html_doc, "html.parser", parse_only=only_short_strings).prettify())
# Elsie
# ,
# Lacie
# and
# Tillie
# ...
#


#You can also pass a SoupStrainer into any of the methods covered in Searching the tree. 
soup = BeautifulSoup(html_doc)
soup.find_all(only_short_strings)
# [u'\n\n', u'\n\n', u'Elsie', u',\n', u'Lacie', u' and\n', u'Tillie',
#  u'\n\n', u'...', u'\n']


###CSS Reference 
#Selector 			Example 		Description
.class 				.intro 			Selects all elements with class="intro" 
#id 				#firstname 		Selects the element with id="firstname" 
* 					* 				Selects all elements 
element 			p 				Selects all <p> elements 
element,element 	div, p 			Selects all <div> elements and all <p> elements 
element element 	div p 			Selects all <p> elements inside <div> elements 
element>element 	div > p 		Selects all <p> elements where the parent is a <div> element 
element+element 	div + p 		Selects all <p> elements that are placed immediately after <div> elements 
element1~element2 	p ~ ul 			Selects every <ul> element that are preceded by a <p> element 
[attribute] 		[target] 		Selects all elements with a target attribute 
[attribute=value] 	[target=_blank] Selects all elements with target="_blank" 
[attribute~=value] 	[title~=flower] Selects all elements with a title attribute containing the word "flower" 
[attribute|=value] 	[lang|=en] 		Selects all elements with a lang attribute value starting with "en" 
[attribute^=value] 	a[href^="https"] Selects every <a> element whose href attribute value begins with "https" 
[attribute$=value] 	a[href$=".pdf"] Selects every <a> element whose href attribute value ends with ".pdf" 
[attribute*=value] 	a[href*="w3schools"] Selects every <a> element whose href attribute value contains the substring "w3schools" 
:active 			a:active 		Selects the active link 
::after 			p::after 		Insert something after the content of each <p> element 
::before 			p::before 		Insert something before the content of each <p> element 
:checked 			input:checked 	Selects every checked <input> element 
:disabled 			input:disabled 	Selects every disabled <input> element 
:empty 				p:empty 		Selects every <p> element that has no children (including text nodes) 
:enabled 			input:enabled 	Selects every enabled <input> element 
:first-child 		p:first-child 	Selects every <p> element that is the first child of its parent 
::first-letter 		p::first-letter Selects the first letter of every <p> element 
::first-line 		p::first-line 	Selects the first line of every <p> element 
:first-of-type 		p:first-of-type Selects every <p> element that is the first <p> element of its parent 
:focus 				input:focus 	Selects the input element which has focus 
:in-range 			input:in-range 	Selects input elements with a value within a specified range 
:invalid 			input:invalid 	Selects all input elements with an invalid value 
:last-child 		p:last-child 	Selects every <p> element that is the last child of its parent 
:last-of-type 		p:last-of-type 	Selects every <p> element that is the last <p> element of its parent 
:link 				a:link 			Selects all unvisited links 
:not(selector) 		:not(p) 		Selects every element that is not a <p> element  
:nth-child(n) 		p:nth-child(2) 	Selects every <p> element that is the second child of its parent 
:nth-last-child(n) 	p:nth-last-child(2) Selects every <p> element that is the second child of its parent, counting from the last child 
:nth-last-of-type(n) p:nth-last-of-type(2) Selects every <p> element that is the second <p> element of its parent, counting from the last child 
:nth-of-type(n) 	p:nth-of-type(2) Selects every <p> element that is the second <p> element of its parent 
:only-of-type 		p:only-of-type 	Selects every <p> element that is the only <p> element of its parent 
:only-child 		p:only-child 	Selects every <p> element that is the only child of its parent 
:optional 			input:optional 	Selects input elements with no "required" attribute 
:out-of-range 		input:out-of-range Selects input elements with a value outside a specified range 
:required 			input:required Selects input elements with the "required" attribute specified 
:root 				:root 			Selects the document's root element 
::selection 		::selection 	Selects the portion of an element that is selected by a user   
:target 			#news:target  	Selects the current active #news element (clicked on a URL containing that anchor name) 3 
:valid 				input:valid 	Selects all input elements with a valid value 
:visited 			a:visited 		Selects all visited links 


###CSS Reference - Difference of  space, <, +, ~

<div id="container">            
   <p>First</p>
    <div>
        <p>Child Paragraph</p>
    </div>
   <p>Second</p>
   <p>Third</p>      
</div>

 
##Space: It is the descendant selector. all tags(any level) under one tag 

div#container p{
font-weight:bold;
}
#It will target all p tags within container div. 
#(First Child Paragraph Second Third)



## > Sign: elements which are DIRECT children of a particular element.
#all tags(only first level) under one tag 
div#container > p {
  border: 1px solid black;
}
#It will target all P element which are direct children of container div,
#not children of child div.
#(First Second Third)


 

## + Sign:It is Adjacent sibling combinator.
#one tag immediatly with another tag(same level) 
#selectors having the same parent 
#and the second one must come IMMEDIATELY after the first.


div + p {  
   color: green;  
} 
#(Second , note immediate p after <div></div> 
#as they have to be siblings )

 
##~ Sign:It is general sibling combinator 
##one tag with another tag(same level) (does not need to be immediate)
#the second selector does NOT have to immediately follow the first one
#It will select all elements that is preceded by the former selector.

div ~ p{
background-color:blue;
} 
#(Second Third, note any p after <div></div> as they have to be siblings)


###CSS Reference- Difference among Attribute selector 

##The [attribute] selector 
#is used to select elements with a specified attribute.

#Example selects all <a> elements with a target attribute
a[target] {
    background-color: yellow;
} 


##The [attribute="value"] selector 
#is used to select elements with a specified attribute and value.

#Example - selects all <a> elements with a target="_blank" attribute
a[target="_blank"] { 
    background-color: yellow;
} 


##The [attribute~="value"] selector 
#is used to select elements with an attribute value 
#containing a specified word(has to be word ie separated by space)

#Example - selects all elements with a title attribute 
#that contains a space-separated list of words, one of which is "flower":
[title~="flower"] {
    border: 5px solid yellow;
}


##The [attribute|="value"] selector 
#is used to select elements with the specified attribute 
#starting with the specified word (ie space after)
#either alone, like class="top", 
#or followed by a hyphen( - ), like class="top-text"


##[attribute^="value"] , [attribute$="value"] , [attribute*="value"]
#is used to select elements whose attribute value 
#begins/ends/contains with a specified string(might not be word)
[class*="te"] {
    background: yellow;
}


###CSS Refernce -  Pseudo elements(:: CSS3 but : in CSS2) and pseudo-classes (:)
selector::pseudo-element {
    property:value;
}

selector:pseudo-class {
    property:value;
}

###CSS Refernce -  All CSS Pseudo Elements
::after         p::after        Insert something after the content of each <p> element 
::before        p::before       Insert something before the content of each <p> element 
::first-letter  p::first-letter Selects the first letter of each <p> element 
::first-line    p::first-line   Selects the first line of each <p> element 
::selection     p::selection    Selects the portion of an element that is selected by a user 


###CSS Refernce -  All CSS Pseudo Classes

#a:hover MUST come after a:link and a:visited in the CSS definition 
#a:active MUST come after a:hover in the CSS definition 

:visited        a:visited       Selects all visited links 
:link           a:link          Selects all unvisited links 
:hover          a:hover         Selects links on mouse over 
:active         a:active        Selects the active link 

#Example 
/* unvisited link */
a:link {
    color: #FF0000;
}

/* visited link */
a:visited {
    color: #00FF00;
}

/* mouse over link */
a:hover {
    color: #FF00FF;
}

/* selected link */
a:active {
     color: #0000FF;
} 

##CSS Pseudo Classes - Others 
:empty          p:empty         Selects every <p> element that has no children 
:lang(language) p:lang(it)      Selects every <p> element with a lang attribute value starting with "it" 
:not(selector)  :not(p)         Selects every element that is not a <p> element 
:root           root            Selects the document's root element 
:target         #news:target    Selects the current active #news element (clicked on a URL containing that anchor name) 

##CSS Pseudo Classes - Form elements 
:checked        input:checked   Selects every checked <input> element 
:disabled       input:disabled  Selects every disabled <input> element 
:enabled        input:enabled   Selects every enabled <input> element 
:focus          input:focus     Selects the <input> element that has focus 
:invalid        input:invalid   Selects all <input> elements with an invalid value 
:optional       input:optional  Selects <input> elements with no "required" attribute 
:required       input:required  Selects <input> elements with a "required" attribute specified 
:valid          input:valid     Selects all <input> elements with a valid value 
:read-only      input:read-only Selects <input> elements with a "readonly" attribute specified 

:in-range       input:in-range      Selects <input> elements with a value within a specified range 
:out-of-range   input:out-of-range  Selects <input> elements with a value outside a specified range 
:read-write     input:read-write    Selects <input> elements with no "readonly" attribute 

#:in-range, :out-of-range selector only works for elements with range limitations, 
#such as input elements with min and max attributes



##CSS Pseudo Classes - Child selections 
:last-child     p:last-child    Selects every <p> elements that is the last child of its parent 
:first-child    p:first-child   Selects every <p> elements that is the first child of its parent 

:last-of-type   p:last-of-type  Selects every <p> element that is the last <p> element of its parent 
:first-of-type  p:first-of-type Selects every <p> element that is the first <p> element of its parent 

:only-of-type   p:only-of-type  Selects every <p> element that is the only <p> element of its parent 
:only-child     p:only-child    Selects every <p> element that is the only child of its parent 

#n can be a number, a keyword, or a formula.
:nth-child(n)           p:nth-child(2)          Selects every <p> element that is the second child of its parent 
:nth-last-child(n)      p:nth-last-child(2)     Selects every <p> element that is the second child of its parent, counting from the last child 
:nth-last-of-type(n)    p:nth-last-of-type(2)   Selects every <p> element that is the second <p> element of its parent, counting from the last child 
:nth-of-type(n)         p:nth-of-type(2)        Selects every <p> element that is the second <p> element of its parent 

#Odd and even are keywords that can be used to match child elements 
#whose index is odd or even (the index of the first child is 1).

p:nth-child(odd) {
     background: red;
}

p:nth-child(even) {
     background: blue;
} 

#Using a formula (a*n + b). 
#a represents a cycle size(can be negative to denote from last), 
#n is a counter (starts at 0), 
#and b is an offset value.

p:nth-child(3n+0) {
     background: red;
} 




###XPATh Reference 

#If the path starts with the slash / , 
#then it represents an absolute path to the required element.
/AAA
/AAA/CCC
/AAA/DDD/BBB

#If the path starts with // 
#then all elements in the document which fulfill following criteria are selected.
//BBB
//DDD/BBB


#The star * selects all elements located by preceeding path
/AAA/CCC/DDD/*
/*/*/*/BBB
//*


#Expresion in square brackets can further specify an element. 
#A number in the brackets gives the position of the element in the selected set. 
#The function last() selects the last element in the selection.
/AAA/BBB[1]
/AAA/BBB[last()]


#Attributes are specified by @ prefix.
//@id
//BBB[@id]
//BBB[@name]
//BBB[@*]
//BBB[not(@*)]

#Values of attributes can be used as selection criteria. 
#Function normalize-space removes leading and trailing spaces 
#and replaces sequences of whitespace characters by a single space.
//BBB[@id='b1']
//BBB[@name='bbb']
//BBB[normalize-space(@name)='bbb']

#Function count() counts the number of selected elements
//*[count(BBB)=2]
//*[count(*)=2]
//*[count(*)=3]


#Function name() returns name of the element, 
#the starts-with function returns true if the first argument string starts with the second argument string, 
#the contains function returns true if the first argument string contains the second argument string.
//*[name()='BBB']
//*[starts-with(name(),'B')]
//*[contains(name(),'C')]

#The string-length function returns the number of characters in the string. 
#You must use &lt; as a substitute for < and &gt; as a substitute for > .
//*[string-length(name()) = 3]
//*[string-length(name()) < 3]
//*[string-length(name()) > 3]

#Several paths can be combined with | separator.
//CCC | //BBB
/AAA/EEE | //BBB
/AAA/EEE | //DDD/CCC | /AAA | //BBB


##child axis
#The child axis contains the children of the context node. 
#The child axis is the default axis and it can be omitted.
/AAA
/child::AAA
/AAA/BBB
/child::AAA/child::BBB
/child::AAA/BBB


##Descendant axis
#The descendant axis contains the descendants of the context node; 
#a descendant is a child or a child of a child and so on; 
#thus the descendant axis never contains attribute or namespace nodes
/descendant::*
/AAA/BBB/descendant::*
//CCC/descendant::*
//CCC/descendant::DDD

##Parent axis
#The parent axis contains the parent of the context node, if there is one.
# It can be abbreviated as two periods (..).
//DDD/parent::*


##Ancestor axis
#The ancestor axis contains the ancestors of the context node; 
#the ancestors of the context node consist of the parent of context node 
#and the parent's parent and so on; 
#thus, the ancestor axis will always include the root node, unless the context node is the root node.
/AAA/BBB/DDD/CCC/EEE/ancestor::*
//FFF/ancestor::*

##Following-sibling axis
#The following-sibling axis contains all the following siblings of the context node.
/AAA/BBB/following-sibling::*
//CCC/following-sibling::*

##Preceding-sibling axis
#The preceding-sibling axis contains all the preceding siblings of the context node
/AAA/XXX/preceding-sibling::*
//CCC/preceding-sibling::*

##Following axis
#The following axis contains all nodes in the same document 
#as the context node that are after the context node in document order, 
#excluding any descendants and excluding attribute nodes and namespace nodes.
/AAA/XXX/following::*
//ZZZ/following::*

##Preceding axis
#The preceding axis contains all nodes in the same document 
#as the context node that are before the context node in document order,
#excluding any ancestors and excluding attribute nodes and namespace nodes
/AAA/XXX/preceding::*
//GGG/preceding::*

##Descendant-or-self axis
#The descendant-or-self axis contains the context node 
#and the descendants of the context node
/AAA/XXX/descendant-or-self::*
//CCC/descendant-or-self::*

##Ancestor-or-self axis
#The ancestor-or-self axis contains the context node 
#and the ancestors of the context node; 
#thus, the ancestor-or-self axis will always include the root node.
/AAA/XXX/DDD/EEE/ancestor-or-self::*
//GGG/ancestor-or-self::*

##Orthogonal axes
#The ancestor, descendant, following, preceding 
#and self axes partition a document (ignoring attribute and namespace nodes): 
#they do not overlap and together they contain all the nodes in the document.
//GGG/ancestor::*
//GGG/descendant::*
//GGG/following::*
//GGG/preceding::*
//GGG/self::*
//GGG/ancestor::* | //GGG/descendant::* | //GGG/following::* | //GGG/preceding::* | //GGG/self::*

##Numeric operations
#The div operator performs floating-point division, 
#the mod operator returns the remainder from a truncating division. 
#The floor function returns the largest (closest to positive infinity) number that is not greater than the argument and that is an integer.
#The ceiling function returns the smallest (closest to negative infinity) number that is not less than the argument and that is an integer.
//BBB[position() mod 2 = 0 ]
//BBB[ position() = floor(last() div 2 + 0.5) or position() = ceiling(last() div 2 + 0.5) ]
//CCC[ position() = floor(last() div 2 + 0.5) or position() = ceiling(last() div 2 + 0.5) ]

###XPATh Reference - Example - *S* means selected 
#http://www.zvon.org/comp/r/tut-XPath_1.html
/AAA
     <AAA>  *S*
          <BBB/>
          <CCC/>
          <BBB/>
          <BBB/>
          <DDD>
               <BBB/>
          </DDD>
          <CCC/>
     </AAA> *S*
 
/AAA/CCC

     <AAA>
          <BBB/>
          <CCC/> *S*
          <BBB/>
          <BBB/>
          <DDD>
               <BBB/>
          </DDD>
          <CCC/> *S*
     </AAA>
 
/AAA/DDD/BBB

     <AAA>
          <BBB/>
          <CCC/>
          <BBB/>
          <BBB/>
          <DDD>
               <BBB/> *S*
          </DDD>
          <CCC/>
     </AAA> 
     
     
//BBB

     <AAA>
          <BBB/>    *S*
          <CCC/>
          <BBB/>    *S*
          <DDD>
               <BBB/>   *S*
          </DDD>
          <CCC>
               <DDD>
                    <BBB/>  *S*
                    <BBB/> *S*
               </DDD>
          </CCC>
     </AAA>
 
//DDD/BBB

     <AAA>
          <BBB/>
          <CCC/>
          <BBB/>
          <DDD>
               <BBB/> *S*
          </DDD>
          <CCC>
               <DDD>
                    <BBB/> *S*
                    <BBB/> *S*
               </DDD>
          </CCC>
     </AAA>     
     
/AAA/CCC/DDD/*

     <AAA>
          <XXX>
               <DDD>
                    <BBB/>
                    <BBB/>
                    <EEE/>
                    <FFF/>
               </DDD>
          </XXX>
          <CCC>
               <DDD>
                    <BBB/> *S*
                    <BBB/> *S*
                    <EEE/> *S*
                    <FFF/> *S*
               </DDD>
          </CCC>
          <CCC>
               <BBB>
                    <BBB>
                         <BBB/>
                    </BBB>
               </BBB>
          </CCC>
     </AAA>
 
/*/*/*/BBB
Select all elements BBB which have 3 ancestors

     <AAA>
          <XXX>
               <DDD>
                    <BBB/> *S*
                    <BBB/> *S*
                    <EEE/>
                    <FFF/>
               </DDD>
          </XXX>
          <CCC>
               <DDD>
                    <BBB/> *S*
                    <BBB/> *S*
                    <EEE/>
                    <FFF/>
               </DDD>
          </CCC>
          <CCC>
               <BBB>
                    <BBB> *S*
                         <BBB/>
                    </BBB>
               </BBB>
          </CCC>
     </AAA>
 
//*
Select all elements

     <AAA>                      *S*
          <XXX>                 *S*
               <DDD>            *S*
                    <BBB/>      *S*
                    <BBB/>      *S*
                    <EEE/>      *S*
                    <FFF/>      *S*
               </DDD>           *S*
          </XXX>                *S*
          <CCC>                 *S*
               <DDD>            *S*
                    <BBB/>      *S*
                    <BBB/>      *S*
                    <EEE/>      *S*
                    <FFF/>      *S*
               </DDD>           *S*
          </CCC>                *S*
          <CCC>                 *S*
               <BBB>            *S*
                    <BBB>       *S*
                         <BBB/> *S*
                    </BBB>      *S*
               </BBB>           *S*
          </CCC>                *S*
     </AAA> 

     
/AAA/BBB[1]
Select the first BBB child of element AAA

     <AAA>
          <BBB/> *S*
          <BBB/>
          <BBB/>
          <BBB/>
     </AAA>
 
/AAA/BBB[last()]
Select the last BBB child of element AAA

     <AAA>
          <BBB/>
          <BBB/>
          <BBB/>
          <BBB/> *S*
     </AAA> 

//@id
Select all attributes @id

     <AAA>
          <BBB id = "b1" *S*/>
          <BBB id = "b2" *S*/>
          <BBB name = "bbb"/>
          <BBB/>
     </AAA>
 
//BBB[@id]
Select BBB elements which have attribute id

     <AAA>
          <BBB id = "b1"/> *S*
          <BBB id = "b2"/> *S*
          <BBB name = "bbb"/>
          <BBB/>
     </AAA>
 
//BBB[@name]
Select BBB elements which have attribute name

     <AAA>
          <BBB id = "b1"/>
          <BBB id = "b2"/>
          <BBB name = "bbb"/> *S*
          <BBB/>
     </AAA>
 
//BBB[@*]
Select BBB elements which have any attribute

     <AAA>
          <BBB id = "b1"/> *S*
          <BBB id = "b2"/> *S*
          <BBB name = "bbb"/> *S*
          <BBB/>
     </AAA>
 
//BBB[not(@*)]
Select BBB elements without an attribute

     <AAA>
          <BBB id = "b1"/>
          <BBB id = "b2"/>
          <BBB name = "bbb"/>
          <BBB/> *S*
     </AAA> 

//BBB[@id='b1']
Select BBB elements which have attribute id with value b1

     <AAA>
          <BBB id = "b1"/> *S*
          <BBB name = " bbb "/>
          <BBB name = "bbb"/>
     </AAA>
 
//BBB[@name='bbb']
Select BBB elements which have attribute name with value 'bbb'

     <AAA>
          <BBB id = "b1"/>
          <BBB name = " bbb "/>
          <BBB name = "bbb"/> *S*
     </AAA>
 
//BBB[normalize-space(@name)='bbb']
Select BBB elements which have attribute name with value bbb, leading and trailing spaces are removed before comparison

     <AAA>
          <BBB id = "b1"/>
          <BBB name = " bbb "/> *S*
          <BBB name = "bbb"/> *S*
     </AAA> 

//*[count(BBB)=2]
Select elements which have two children BBB

     <AAA>
          <CCC>
               <BBB/>
               <BBB/>
               <BBB/>
          </CCC>
          <DDD> *S*
               <BBB/>
               <BBB/>
          </DDD> *S*
          <EEE>
               <CCC/>
               <DDD/>
          </EEE>
     </AAA>
 
//*[count(*)=2]
Select elements which have 2 children

     <AAA>
          <CCC>
               <BBB/>
               <BBB/>
               <BBB/>
          </CCC>
          <DDD> *S*
               <BBB/>
               <BBB/>
          </DDD> *S*
          <EEE> *S*
               <CCC/>
               <DDD/>
          </EEE> *S*
     </AAA>
 
//*[count(*)=3]
Select elements which have 3 children

     <AAA> *S*
          <CCC> *S*
               <BBB/>
               <BBB/>
               <BBB/>
          </CCC> *S*
          <DDD>
               <BBB/>
               <BBB/>
          </DDD>
          <EEE>
               <CCC/>
               <DDD/>
          </EEE>
     </AAA>  *S*

//*[name()='BBB']
Select all elements with name BBB, equivalent with //BBB

     <AAA>
          <BCC>
               <BBB/> *S*
               <BBB/> *S*
               <BBB/> *S*
          </BCC>
          <DDB>
               <BBB/> *S*
               <BBB/> *S*
          </DDB>
          <BEC>
               <CCC/>
               <DBD/>
          </BEC>
     </AAA>
 
//*[starts-with(name(),'B')]
Select all elements name of which starts with letter B

     <AAA>
          <BCC> *S*
               <BBB/> *S*
               <BBB/> *S*
               <BBB/> *S*
          </BCC> *S*
          <DDB>
               <BBB/> *S*
               <BBB/> *S*
          </DDB>
          <BEC> *S*
               <CCC/>
               <DBD/>
          </BEC> *S*
     </AAA>
 
//*[contains(name(),'C')]
Select all elements name of which contain letter C

     <AAA>
          <BCC> *S*
               <BBB/>
               <BBB/>
               <BBB/>
          </BCC> *S*
          <DDB>
               <BBB/>
               <BBB/>
          </DDB>
          <BEC> *S*
               <CCC/> *S*
               <DBD/>
          </BEC> *S*
     </AAA> 

//*[string-length(name()) = 3]
Select elements with three-letter name

     <AAA> *S*
          <Q/>
          <SSSS/>
          <BB/>
          <CCC/> *S*
          <DDDDDDDD/>
          <EEEE/>
     </AAA> *S*
 
//*[string-length(name()) < 3]
Select elements name of which has one or two characters

     <AAA>
          <Q/> *S*
          <SSSS/>
          <BB/> *S*
          <CCC/>
          <DDDDDDDD/>
          <EEEE/>
     </AAA>
 
//*[string-length(name()) > 3]
Select elements with name longer than three characters

     <AAA>
          <Q/>
          <SSSS/> *S*
          <BB/>
          <CCC/>
          <DDDDDDDD/> *S*
          <EEEE/> *S*
     </AAA> 

//CCC | //BBB
Select all elements CCC and BBB

     <AAA>
          <BBB/> *S*
          <CCC/> *S*
          <DDD>
               <CCC/> *S*
          </DDD>
          <EEE/>
     </AAA>
 
/AAA/EEE | //BBB
Select all elements BBB and elements EEE which are children of root element AAA

     <AAA>
          <BBB/> *S*
          <CCC/>
          <DDD>
               <CCC/>
          </DDD>
          <EEE/> *S*
     </AAA>
 
/AAA/EEE | //DDD/CCC | /AAA | //BBB
Number of combinations is not restricted

     <AAA> *S*
          <BBB/> *S*
          <CCC/>
          <DDD>
               <CCC/> *S*
          </DDD>
          <EEE/> *S*
     </AAA>  *S*

/AAA
Equivalent of /child::AAA

     <AAA> *S*
          <BBB/>
          <CCC/>
     </AAA> *S*
 
/child::AAA
Equivalent of /AAA

     <AAA> *S*
          <BBB/>
          <CCC/>
     </AAA> *S*
 
/AAA/BBB
Equivalent of /child::AAA/child::BBB

     <AAA>
          <BBB/> *S*
          <CCC/>
     </AAA>
 
/child::AAA/child::BBB
Equivalent of /AAA/BBB

     <AAA>
          <BBB/> *S*
          <CCC/>
     </AAA>
 
/child::AAA/BBB
Both possibilities can be combined

     <AAA>
          <BBB/> *S*
          <CCC/>
     </AAA> 
/descendant::*
Select all descendants of document root and therefore all elements

     <AAA>                               *S*
          <BBB>                          *S*
               <DDD>                     *S*
                    <CCC>                *S*
                         <DDD/>          *S*
                         <EEE/>          *S*
                    </CCC>               *S*
               </DDD>                    *S*
          </BBB>                         *S*
          <CCC>                          *S*
               <DDD>                     *S*
                    <EEE>                *S*
                         <DDD>           *S*
                              <FFF/>     *S*
                         </DDD>          *S*
                    </EEE>               *S*
               </DDD>                    *S*
          </CCC>                         *S*
     </AAA>                              *S*
 
/AAA/BBB/descendant::*
Select all descendants of /AAA/BBB

     <AAA>
          <BBB>
               <DDD> *S*
                    <CCC> *S*
                         <DDD/> *S*
                         <EEE/> *S*
                    </CCC> *S*
               </DDD> *S*
          </BBB>
          <CCC>
               <DDD>
                    <EEE>
                         <DDD>
                              <FFF/>
                         </DDD>
                    </EEE>
               </DDD>
          </CCC>
     </AAA>
 
//CCC/descendant::*
Select all elements which have CCC among its ancestors

     <AAA>
          <BBB>
               <DDD>
                    <CCC>
                         <DDD/> *S*
                         <EEE/> *S*
                    </CCC>
               </DDD>
          </BBB>
          <CCC>
               <DDD> *S*
                    <EEE> *S*
                         <DDD> *S*
                              <FFF/> *S*
                         </DDD> *S*
                    </EEE> *S*
               </DDD> *S*
          </CCC>
     </AAA>
 
//CCC/descendant::DDD
Select elements DDD which have CCC among its ancestors

     <AAA>
          <BBB>
               <DDD>
                    <CCC>
                         <DDD/> *S*
                         <EEE/>
                    </CCC>
               </DDD>
          </BBB>
          <CCC>
               <DDD> *S*
                    <EEE>
                         <DDD> *S*
                              <FFF/>
                         </DDD> *S*
                    </EEE>
               </DDD> *S*
          </CCC>
     </AAA> 

//DDD/parent::*
Select all parents of DDD element

     <AAA>
          <BBB> *S*
               <DDD>
                    <CCC> *S*
                         <DDD/>
                         <EEE/>
                    </CCC> *S*
               </DDD>
          </BBB> *S*
          <CCC> *S*
               <DDD>
                    <EEE> *S*
                         <DDD>
                              <FFF/>
                         </DDD>
                    </EEE> *S*
               </DDD>
          </CCC> *S*
     </AAA> 
/AAA/BBB/DDD/CCC/EEE/ancestor::*
Select all elements given in this absolute path

     <AAA> *S*
          <BBB> *S*
               <DDD> *S*
                    <CCC> *S*
                         <DDD/>
                         <EEE/>
                    </CCC> *S*
               </DDD> *S*
          </BBB> *S*
          <CCC>
               <DDD>
                    <EEE>
                         <DDD>
                              <FFF/>
                         </DDD>
                    </EEE>
               </DDD>
          </CCC>
     </AAA> *S*
 
//FFF/ancestor::*
Select ancestors of FFF element

     <AAA> *S*
          <BBB>
               <DDD>
                    <CCC>
                         <DDD/>
                         <EEE/>
                    </CCC>
               </DDD>
          </BBB>
          <CCC> *S*
               <DDD> *S*
                    <EEE> *S*
                         <DDD> *S*
                              <FFF/>
                         </DDD> *S*
                    </EEE> *S*
               </DDD> *S*
          </CCC> *S*
     </AAA>  *S*
/AAA/BBB/following-sibling::*

     <AAA>
          <BBB>
               <CCC/>
               <DDD/>
          </BBB>
          <XXX> *S*
               <DDD>
                    <EEE/>
                    <DDD/>
                    <CCC/>
                    <FFF/>
                    <FFF>
                         <GGG/>
                    </FFF>
               </DDD>
          </XXX> *S*
          <CCC> *S*
               <DDD/>
          </CCC> *S*
     </AAA>
 
//CCC/following-sibling::*

     <AAA>
          <BBB>
               <CCC/>
               <DDD/> *S*
          </BBB>
          <XXX>
               <DDD>
                    <EEE/>
                    <DDD/>
                    <CCC/>
                    <FFF/> *S*
                    <FFF> *S*
                         <GGG/>
                    </FFF> *S*
               </DDD>
          </XXX>
          <CCC>
               <DDD/>
          </CCC>
     </AAA> 
/AAA/XXX/preceding-sibling::*

     <AAA>
          <BBB> *S*
               <CCC/>
               <DDD/>
          </BBB> *S*
          <XXX>
               <DDD>
                    <EEE/>
                    <DDD/>
                    <CCC/>
                    <FFF/>
                    <FFF>
                         <GGG/>
                    </FFF>
               </DDD>
          </XXX>
          <CCC>
               <DDD/>
          </CCC>
     </AAA>
 
//CCC/preceding-sibling::*

     <AAA>
          <BBB> *S*
               <CCC/>
               <DDD/>
          </BBB> *S*
          <XXX> *S*
               <DDD> 
                    <EEE/> *S*
                    <DDD/> *S*
                    <CCC/>
                    <FFF/>
                    <FFF>
                         <GGG/>
                    </FFF>
               </DDD>
          </XXX> *S*
          <CCC>
               <DDD/>
          </CCC>
     </AAA> 
/AAA/XXX/following::*

     <AAA>
          <BBB>
               <CCC/>
               <ZZZ>
                    <DDD/>
                    <DDD>
                         <EEE/>
                    </DDD>
               </ZZZ>
               <FFF>
                    <GGG/>
               </FFF>
          </BBB>
          <XXX>
               <DDD>
                    <EEE/>
                    <DDD/>
                    <CCC/>
                    <FFF/>
                    <FFF>
                         <GGG/>
                    </FFF>
               </DDD>
          </XXX>
          <CCC> *S*
               <DDD/> *S*
          </CCC> *S*
     </AAA>
 
//ZZZ/following::*

     <AAA>
          <BBB>
               <CCC/>
               <ZZZ>
                    <DDD/>
                    <DDD>
                         <EEE/>
                    </DDD>
               </ZZZ>
               <FFF> *S*
                    <GGG/> *S*
               </FFF> *S*
          </BBB>
          <XXX>                  *S*
               <DDD>             *S*
                    <EEE/>       *S*
                    <DDD/>       *S*
                    <CCC/>       *S*
                    <FFF/>       *S*
                    <FFF>        *S*
                         <GGG/>  *S*
                    </FFF>       *S*
               </DDD>            *S*
          </XXX>                 *S*
          <CCC>                  *S*
               <DDD/>            *S*
          </CCC>                 *S*
     </AAA> 
/AAA/XXX/preceding::*

     <AAA>
          <BBB> *S*
               <CCC/> *S*
               <ZZZ> *S*
                    <DDD/> *S*
               </ZZZ> *S*
          </BBB> *S*
          <XXX>
               <DDD>
                    <EEE/>
                    <DDD/>
                    <CCC/>
                    <FFF/>
                    <FFF>
                         <GGG/>
                    </FFF>
               </DDD>
          </XXX>
          <CCC>
               <DDD/>
          </CCC>
     </AAA>
 
//GGG/preceding::*

     <AAA>
          <BBB> *S*
               <CCC/> *S*
               <ZZZ> *S*
                    <DDD/> *S*
               </ZZZ> *S*
          </BBB> *S*
          <XXX>
               <DDD>
                    <EEE/> *S*
                    <DDD/> *S*
                    <CCC/> *S*
                    <FFF/> *S*
                    <FFF>
                         <GGG/>
                    </FFF>
               </DDD>
          </XXX>
          <CCC>
               <DDD/>
          </CCC>
     </AAA> 
/AAA/XXX/descendant-or-self::*

     <AAA>
          <BBB>
               <CCC/>
               <ZZZ>
                    <DDD/>
               </ZZZ>
          </BBB>
          <XXX>                  *S*
               <DDD>             *S*
                    <EEE/>       *S*
                    <DDD/>       *S*
                    <CCC/>       *S*
                    <FFF/>       *S*
                    <FFF>        *S*
                         <GGG/>  *S*
                    </FFF>       *S*
               </DDD>            *S*
          </XXX>                 *S*
          <CCC>
               <DDD/>
          </CCC>
     </AAA>
 
//CCC/descendant-or-self::*

     <AAA>
          <BBB>
               <CCC/> *S*
               <ZZZ>
                    <DDD/>
               </ZZZ>
          </BBB>
          <XXX>
               <DDD>
                    <EEE/>
                    <DDD/>
                    <CCC/> *S*
                    <FFF/>
                    <FFF>
                         <GGG/>
                    </FFF>
               </DDD>
          </XXX>
          <CCC> *S*
               <DDD/> *S*
          </CCC> *S*
     </AAA> 
     
/AAA/XXX/DDD/EEE/ancestor-or-self::*

     <AAA>*S*
          <BBB>
               <CCC/>
               <ZZZ>
                    <DDD/>
               </ZZZ>
          </BBB>
          <XXX>*S*
               <DDD>*S*
                    <EEE/>*S*
                    <DDD/>
                    <CCC/>
                    <FFF/>
                    <FFF>
                         <GGG/>
                    </FFF>
               </DDD>*S*
          </XXX>*S*
          <CCC>
               <DDD/>
          </CCC>
     </AAA>*S*
 
//GGG/ancestor-or-self::*

     <AAA>*S*
          <BBB>
               <CCC/>
               <ZZZ>
                    <DDD/>
               </ZZZ>
          </BBB>
          <XXX>*S*
               <DDD>*S*
                    <EEE/>
                    <DDD/>
                    <CCC/>
                    <FFF/>
                    <FFF>*S*
                         <GGG/>*S*
                    </FFF>*S*
               </DDD>*S*
          </XXX>*S*
          <CCC>
               <DDD/>
          </CCC>
     </AAA> *S*
     
//GGG/ancestor::*

     <AAA>*S*
          <BBB>
               <CCC/>
               <ZZZ/>
          </BBB>
          <XXX>*S*
               <DDD>*S*
                    <EEE/>
                    <FFF>*S*
                         <HHH/>
                         <GGG>
                              <JJJ>
                                   <QQQ/>
                              </JJJ>
                              <JJJ/>
                         </GGG>
                         <HHH/>
                    </FFF>*S*
               </DDD>*S*
          </XXX>*S*
          <CCC>
               <DDD/>
          </CCC>
     </AAA>*S*
 
//GGG/descendant::*

     <AAA>
          <BBB>
               <CCC/>
               <ZZZ/>
          </BBB>
          <XXX>
               <DDD>
                    <EEE/>
                    <FFF>
                         <HHH/>
                         <GGG>
                              <JJJ>*S*
                                   <QQQ/>*S*
                              </JJJ>*S*
                              <JJJ/>*S*
                         </GGG>
                         <HHH/>
                    </FFF>
               </DDD>
          </XXX>
          <CCC>
               <DDD/>
          </CCC>
     </AAA>
 
//GGG/following::*

     <AAA>
          <BBB>
               <CCC/>
               <ZZZ/>
          </BBB>
          <XXX>
               <DDD>
                    <EEE/>
                    <FFF>
                         <HHH/>
                         <GGG>
                              <JJJ>
                                   <QQQ/>
                              </JJJ>
                              <JJJ/>
                         </GGG>
                         <HHH/>*S*
                    </FFF>
               </DDD>
          </XXX>
          <CCC>*S*
               <DDD/>*S*
          </CCC>*S*
     </AAA>
 
//GGG/preceding::*

     <AAA>
          <BBB>*S*
               <CCC/>*S*
               <ZZZ/>*S*
          </BBB>*S*
          <XXX>
               <DDD>
                    <EEE/>
                    <FFF>
                         <HHH/>*S*
                         <GGG>
                              <JJJ>
                                   <QQQ/>
                              </JJJ>
                              <JJJ/>
                         </GGG>
                         <HHH/>
                    </FFF>
               </DDD>
          </XXX>
          <CCC>
               <DDD/>
          </CCC>
     </AAA>
 
//GGG/self::*
# It can be abbreviated as a single period (.).
     <AAA>
          <BBB>
               <CCC/>
               <ZZZ/>
          </BBB>
          <XXX>
               <DDD>
                    <EEE/>
                    <FFF>
                         <HHH/>
                         <GGG>*S*
                              <JJJ>
                                   <QQQ/>
                              </JJJ>
                              <JJJ/>
                         </GGG>*S*
                         <HHH/>
                    </FFF>
               </DDD>
          </XXX>
          <CCC>
               <DDD/>
          </CCC>
     </AAA>
 
//GGG/ancestor::* | //GGG/descendant::* | //GGG/following::* | //GGG/preceding::* | //GGG/self::*

     <AAA>                                      *S*   
          <BBB>                                 *S*
               <CCC/>                           *S*
               <ZZZ/>                           *S*
          </BBB>                                *S*
          <XXX>                                 *S*
               <DDD>                            *S*
                    <EEE/>                      *S*
                    <FFF>                       *S*
                         <HHH/>                 *S*
                         <GGG>               *S*
                              <JJJ>             *S*
                                   <QQQ/>       *S*
                              </JJJ>            *S*
                              <JJJ/>            *S*
                         </GGG>            *S*
                         <HHH/>                 *S*
                    </FFF>                      *S*
               </DDD>                           *S*
          </XXX>                                *S*
          <CCC>                                 *S*
               <DDD/>                           *S*
          </CCC>                                *S*
     </AAA>                                     *S*
     
//BBB[position() mod 2 = 0 ]
Select even BBB elements

     <AAA>
          <BBB/>
          <BBB/> *S*
          <BBB/>
          <BBB/> *S*
          <BBB/>
          <BBB/> *S*
          <BBB/>
          <BBB/> *S*
          <CCC/>
          <CCC/>
          <CCC/>
     </AAA>
 
//BBB[ position() = floor(last() div 2 + 0.5) or position() = ceiling(last() div 2 + 0.5) ]
Select middle BBB element(s)

     <AAA>
          <BBB/>
          <BBB/>
          <BBB/>
          <BBB/> *S*
          <BBB/> *S*
          <BBB/>
          <BBB/>
          <BBB/>
          <CCC/>
          <CCC/>
          <CCC/>
     </AAA>
 
//CCC[ position() = floor(last() div 2 + 0.5) or position() = ceiling(last() div 2 + 0.5) ]
Select middle CCC element(s)

     <AAA>
          <BBB/>
          <BBB/>
          <BBB/>
          <BBB/>
          <BBB/>
          <BBB/>
          <BBB/>
          <BBB/>
          <CCC/>
          <CCC/> *S*
          <CCC/>
     </AAA> 
     

