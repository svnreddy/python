import cgi 

cgi.test()