from django.apps import AppConfig


class AdvancedConfig(AppConfig):
    name = 'advanced'
