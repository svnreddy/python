'''
ManytoOne , ManyToMany and Making Queries 
Objectives- Understanding Associations, Models, Queries
'''