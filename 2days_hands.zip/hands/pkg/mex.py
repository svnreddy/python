def square(x):
    """square function
    takes one number
    """
    z = x*x 
    return z 
    
#mean(lst) = Sum of lst/length of lst 
#sd(lst) = sqrt of( SUM of square of ( each element - mean)  / length of lst  )
#sum([1,2,3])

def mean(lst):
    return sum(lst)/len(lst)
    
import math 
def sd(lst):
    m = mean(lst)
    out = []
    for e in lst:
        out.append( square(e-m))
    return math.sqrt(sum(out)/len(lst)) 
    
    
