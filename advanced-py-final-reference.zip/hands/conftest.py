import pytest 
from pkg import MyInt 

@pytest.fixture(scope='module')
def two(request):
    a = MyInt(2)
    yield a 
    print("any shutdowncode here")
    