from .mex import MyInt
from .mex import Complex
#from pkg import MyInt

__all__ = ['MyInt', 'Complex']
#from pkg import *

#from pkg import square
def square(x):
    """Square method 
    squares a number """
    return x*x 
    
__version__ = '0.1'
__author__ = 'body'