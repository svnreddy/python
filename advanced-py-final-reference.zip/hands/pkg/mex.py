import requests, time 


class MyInt:
    def __init__(self,v):
        self.value = v 
    def __add__(self, other):
        z = self.value + other.value 
        return MyInt(z)
    def __str__(self):
        z = "MyInt("+str(self.value)+")"
        return z
    def __sub__(self, other):
        z = self.value - other.value 
        return MyInt(z)
    def __eq__(self, other):
        z = self.value == other.value 
        return z
    def square(self):
        return MyInt(self.value * self.value)

###############################
#from pkg import Complex 
#a = Complex(1,2)
#b = Complex(2,3)
#c = a+b 
#print(c) #Complex(3,5)


class Complex:
    def __init__(self,re, img):
        self.re = re 
        self.img = img 
    def __add__(self, other):        
        return Complex(self.re+other.re, self.img+other.img)
    def __str__(self):
        z = "Complex("+str(self.re)+","+str(self.img)+")"



def mea(f):
    def _inner(*args, **kwargs):
        st = time.time()
        res = f(*args, **kwargs)
        print("Time taken", time.time()-st, " secs")
        return res 
    return _inner 

#@mea
import threading 
def download(url):  #download = mea(download)
    r = requests.get(url)
    print("From", threading.current_thread().getName())
    return [url, len(r.text)]



class Fib:
    def __init__(self,a,b):
        self.a, self.b = a,b 
    def __iter__(self):
        while True:
            yield self.b 
            self.a, self.b = self.b, self.a+self.b


       
        
        
