import threading 
import requests, concurrent.futures 
import time 

def download(url):  
    r = requests.get(url)
    #print("From", threading.current_thread().getName())
    return [url, len(r.text)]
    
if __name__ == '__main__':
    urls = ["https://www.google.co.in" for i in range(10)]
    st = time.time()
    print("sequential")
    r = download(urls[0])
    one = time.time()-st 
    print(r, "took ", one, "secs")
    print("now Parallel")
    ex = concurrent.futures.ThreadPoolExecutor(max_workers=10)
    st = time.time()
    rs = ex.map(download, urls)
    print(list(rs), " took ", time.time()-st, 
        " secs supposed to take ", 10*one, " secs")
    ex.shutdown()
    
    
    
    
