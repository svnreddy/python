import multiprocessing, time 

#shared var - does nor work in multiprocess 
#shared = []

def proc(lck, shared):
    print("before", multiprocessing.current_process().name)
    with lck: #lck.accquire
        print("Accquired", multiprocessing.current_process().name)
        time.sleep(2)
        shared.value += 1 
    #lck.release
    time.sleep(2)    
if __name__ == '__main__':
    ids = []
    num = multiprocessing.Value('i', 0)
    lock = multiprocessing.RLock()
    #lock = multiprocessing.Semaphore(2)
    for i in range(10):
        t = multiprocessing.Process(target=proc, args=(lock,num))
        ids.append(t)
    [t.start() for t in ids]
    [t.join() for t in ids]
    print(num.value)

