import threading, time 

#shared var 
shared = []

def proc(lck):
    global shared
    print("before", threading.current_thread().getName())
    with lck: #lck.accquire
        print("Accquired", threading.current_thread().getName())
        time.sleep(2)
        shared.append(threading.current_thread().getName())
    #lck.release
    time.sleep(2)
    
ids = []
#lock = threading.RLock()
lock = threading.Semaphore(2)
for i in range(10):
    t = threading.Thread(target=proc, args=(lock,))
    ids.append(t)
[t.start() for t in ids]
[t.join() for t in ids]
print(shared)

