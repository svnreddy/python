from pkg import MyInt 
import pytest 

#py.test -v test_myint.py
#pip install pytest-cov
#py.test --cov=pkg/ test_myint.py
class TestMyint:
    def test_add(self):
        a = MyInt(2)
        b = MyInt(3)
        assert a+b == MyInt(5)
    def test_sub(self):
        a = MyInt(2)
        b = MyInt(3)
        assert a-b == MyInt(-1)
#py.test -v -m addl test_myint.py 
@pytest.mark.addl      
def test_square(two):
    """Testing square"""
    assert two.square() == MyInt(4)


    
    
    
    
    
    
    
    

    
