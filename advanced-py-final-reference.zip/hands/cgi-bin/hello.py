import cgi, os, sys , json 

form = cgi.FieldStorage()  #for form handling 

string = """
<form method="post" action="hello.py">
<p>Name: <input type="text" name="name" /></p>
<p>Address1: <input type="text" name="addr" /></p>
<p>Address2: <input type="text" name="addr" /></p>
<input type="submit" value="Submit" />
</form>
"""
#python -m http.server --bind 127.0.0.1 --cgi 8080
#http://127.0.0.1:8080/cgi-bin/hello.py
#print("Content-Type: text/html")
print("Content-Type: application/json")
print()
#then content 
# print("""
# <html><head><title>First CGI</title></head>
# <body><h1>Give Input</h1>""")
# if 'REQUEST_METHOD' in os.environ and os.environ['REQUEST_METHOD'].upper() == 'POST':
    # print(form.getfirst("name", "NO-NAME"), form.getlist("addr"))
# else:
    # print(string)
# print("</body></html>")
obj = {'name': "ABC"}
string = json.dumps(obj)
print(string)
