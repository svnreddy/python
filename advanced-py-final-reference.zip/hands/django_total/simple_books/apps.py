from django.apps import AppConfig


class SimpleBooksConfig(AppConfig):
    name = 'simple_books'
