from django.shortcuts import render 

import logging 
log = logging.getLogger(__name__)

def index2(request, id,url):
    query = request.GET  #request type is HttpRequest, contains many attributes
    log.info("GET "+str(query))
    return render(request, 'index.html', {'id':id, 'queries': dict(query)})    
    
from django.http import HttpResponseRedirect
from django.urls import reverse 
def hello(request):
    return HttpResponseRedirect(reverse('views_index', args=(10,)))
    
from django.http import JsonResponse, Http404 
import json as J 
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def json(request):
    if request.method.upper() == 'POST':
        json_data = J.loads(request.body.decode("ascii"))
        res = {'greetings': "Hello" + json_data.get('name', "NO-NAME")}
        return JsonResponse(res)
    else:
        return Http404("This is rest api")


'''
import requests
headers = {'Content-Type': 'application/json'}
data = {'name' : 'OK'}
import json
r = requests.post("http://localhost:8000/json/", data=json.dumps(data), headers=headers)
r.json()

'''   
    
import os 
from django.http import FileResponse
from django.conf import settings

def download(request, filename):
    file = os.path.join(settings.MEDIA_ROOT, filename)
    res = FileResponse(open(file, "rb"))
    res['Content-Disposition'] = "attachement; filename=%s" % (filename,)
    res['Content-Length'] = os.path.getsize(file)
    return res 
    
    
    
    
