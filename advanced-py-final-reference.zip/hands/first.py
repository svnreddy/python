import sys 

# def f(x,y):
    # return x+y 
    

# result = 0
# for x in sys.argv[1:]:
    # i = int(x)
    # result += i 
    
# print(result)

################################
import subprocess as S
import re 

def getIp(url):
    command = 'nslookup %s' % (url,)
    proc = S.Popen(command, shell=True, stdout=S.PIPE, stderr=S.PIPE, universal_newlines=True)
    outs,oute = proc.communicate()
    #Name:    www.google.co.in
    #Addresses:  2404:6800:4002:805::2003
    #          172.217.167.35
    pat = r"Name:\s+%s\s+(?:Address|Addresses):\s+(.+)$" % (url,)
    result = re.findall(pat,outs, re.DOTALL)
    #['2404:6800:4002:805::2003\n          172.217.167.35']
    #[r.split()   for r in result]
    #[['2404:6800:4002:805::2003', '172.217.167.35']]
    return [ e for r in result for e in r.split()]
    #['2404:6800:4002:805::2003', '172.217.167.35']


print(getIp("www.google.co.in"))



import glob, os.path 
def getMaxFileName(directory):
    files = glob.glob(directory+"/*")
    d = { e: os.path.getsize(e) 
            for e in files if os.path.isfile(e)}
    return sorted(d, key=lambda k: d[k])[-1]

import requests
params = {'name': 'xyz'}
r = requests.get("http://httpbin.org/get", params=params)
>>> r.json()
{'headers': {'Host': 'httpbin.org', 'Accept-Encoding': 'gzip, deflate', 'User-Ag
ent': 'python-requests/2.21.0', 'Accept': '*/*'}, 'origin': '118.185.171.58, 118
.185.171.58', 'args': {'name': 'xyz'}, 'url': 'https://httpbin.org/get?name=xyz'
}
data = {'name': 'xyz'}
headers = {'Content-Type': 'application/json'}
import json
r = requests.post("http://httpbin.org/post", 
    data=json.dumps(data), headers=headers)
r.json()
############################
from sqlite3 import connect
con = connect(r"iris.db")

import mysql.connector
con = mysql.connector.connect(user='root', password='root', 
        host='127.0.0.1', database='python')
cur = con.cursor()
cur.execute("drop table if exists iris")
cur.execute("""create table iris (sl double, sw double, 
    pl double, pw double, name varchar(20))""")

for row in rowsd:
    s = cur.execute("insert into iris values(%s,%s,%s,%s,%s)", row)
    #s = cur.execute("insert into iris values(?,?,?,?,?)", row)
    
con.commit()
cur.execute("select name, max(sl) from iris group by name")
#q = cur.execute("select name, max(sl) from iris group by name")
result = list(cur.fetchall())
#result = list(q.fetchall())
print(result)
#[('Iris-setosa', 5.8), ('Iris-versicolor', 7.0), ('Iris-virginica', 7


   
def is_prime(n):
	import math
	if n % 2 == 0:	return False
	sqrt_n = int(math.sqrt(n))
	a = [1 for i in range(3, sqrt_n + 1, 2) if n % i == 0]
	return False if sum(a) > 0 else True

    
    
    

