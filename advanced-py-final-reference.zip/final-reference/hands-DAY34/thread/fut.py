import threading , time 
import requests , concurrent.futures

def download(url):
    print("Download ", url, "in ", threading.current_thread().getName())
    con = requests.get(url)
    return [url, len(con.text)]
    
urls = ["http://www.google.co.in" for i in range(10)]
st = time.time()
print("sequential")
r = download(urls[0])
one = time.time()-st
print(r, " took", one)
print("Now parallel")
ex = concurrent.futures.ThreadPoolExecutor(max_workers=10)
st = time.time()
rs = ex.map(download, urls)
print(list(rs), " took ", time.time()-st , "supposed to take ", 10*one , " sequentally")
ex.shutdown()









