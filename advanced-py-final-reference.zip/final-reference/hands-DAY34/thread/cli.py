import socket

host = 'localhost'
port = 50007 

#TCP is STREAM, UDP is DATAGRAM 
with socket.socket(socket.AF_INET, 
        socket.SOCK_STREAM) as s :
    s.connect( (host, port))
    s.sendall(b'Hello World')
    print(s.recv(1024))
    s.sendall(b'Hello You')
    print(s.recv(1024))