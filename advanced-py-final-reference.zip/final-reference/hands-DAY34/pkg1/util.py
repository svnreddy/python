import glob 
import os.path 

def getLineNoAndLength(filename):
    with open(filename, "rt") as f:
            lines = f.readlines()
    return {i:len(e) for i,e in enumerate(lines) if not e.startswith('#')}
    
class EmptyResult(Exception):
    pass
    
class Directory:
    def __init__(self, directory):
        self.directory = directory    
    def getMaxFile(self):
        ''' Returns file Name having max size'''
        files = glob.glob(os.path.join(self.directory,"*"))
        d = { f:os.path.getsize(f) 
            for f in files  if os.path.isfile(f)}
        if not d:
            raise EmptyResult("Result is empty")
        else:
            sd = sorted(d, key= lambda k: d[k])
            maxFileName = sd[-1]
            return maxFileName
    
    
    
########################
df = pd.DataFrame(np.random.rand(6,4), index=list('abcdef'), columns=list('ABCD'))
iris = pd.read_csv(r"D:\Desktop\PPT\python\final-reference\data\iris.csv")
df1 = iris.groupby('Name').agg({'SepalLength':'count', 'PetalLength': 'mean'})
#%matplotlib inline 
iris.Name.value_counts().plot(kind='bar')
plt.show()   #inline display 
iris.Name.value_counts().plot(kind='bar')
plt.savefig(r"D:\Desktop\PPT\python\final-reference\data\name.png")
iris.groupby('Name').plot(kind='line', subplots=True)
plt.show() 
#scatter_matrix 
from pandas.plotting import scatter_matrix
scatter_matrix(iris.iloc[:, 0:4], diagonal='kde')
plt.show()

#BS4 
soup.find_all(['a', 'p'], {'class': 'gb1'})
soup.select('a')
soup.select('a.gb1')
#HTTP 
>>> res = r.get("http://httpbin.org/get", params={'name':'xyz'})
>>> res.json()
{'args': {'name': 'xyz'}, 'headers': {'Accept': '*/*', 'Accept-Encoding': 'gzip,
 deflate', 'User-Agent': 'python-requests/2.20.0', 'Host': 'httpbin.org'}, 'orig
in': '157.44.132.50, 157.44.132.50', 'url': 'https://httpbin.org/get?name=xyz'}
>>> headers = {'Content-Type':'application/json'}
>>> import json
>>> data = json.dumps({'name':'xyz'})
>>> res = r.post("http://httpbin.org/post", data=data,headers=headers)
>>> res.json()
{'args': {}, 'json': {'name': 'xyz'}, 'form': {}, 'files': {}, 'headers': {'Acce
pt': '*/*', 'Accept-Encoding': 'gzip, deflate', 'User-Agent': 'python-requests/2
.20.0', 'Content-Type': 'application/json', 'Host': 'httpbin.org', 'Content-Leng
th': '15'}, 'data': '{"name": "xyz"}', 'origin': '157.44.132.50, 157.44.132.50',
 'url': 'https://httpbin.org/post'}
>>>


























