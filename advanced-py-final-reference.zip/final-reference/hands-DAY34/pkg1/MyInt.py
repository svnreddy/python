class MyInt:
    def __init__(self, v):
        self.value = v 
    def __add__(self, other):
        z = self.value + other.value 
        return MyInt(z) 
    def __str__(self):
        z = "MyInt(" + str(self.value) + ")"
        return z 
    def __sub__(self, other):
        z = self.value - other.value 
        return MyInt(z)
    def __eq__(self, other):
        return self.value == other.value 
    def square(self):
        return MyInt(self.value * self.value)
    def __call__(self, mul):
        return mul * self.square()

        
        
        
        
        
        