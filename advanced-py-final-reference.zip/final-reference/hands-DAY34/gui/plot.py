import matplotlib.pyplot as plt 
import pandas as pd 
import numpy as np

t = np.arange(0,5,0.1)
#x,y, style
#style has many symbols 
plt.plot(t, t**2, 'r-', t, np.sin(t), 'b--', t, np.sin(t)+np.cos(t), 'g^')
plt.legend(['t**2', 'sin(t)', 'sin(t)+cos(t)'] , loc='best')
plt.grid(True)
plt.show()
