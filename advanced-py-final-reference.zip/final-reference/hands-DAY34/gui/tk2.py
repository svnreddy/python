from tkinter import *

class App:
    def __init__(self, master):
        self.root = master 
        f = Frame(master)
        f.pack(fill=BOTH, expand=1)
        self.button = Button(f, text="Quit", fg='red', command=self.quit)
        self.button.pack(side=TOP, fill=BOTH, expand=1)
        self.hi = Button(f, text="Hello",  command=self.hi_there)
        self.hi.pack(side=TOP, fill=BOTH, expand=1)
        self.w = Label(f, text='Enter Text:')
        self.w.pack(side=LEFT,fill=BOTH, expand=1)
        self.text = StringVar()
        self.input = Entry(f, textvariable=self.text)
        self.input.pack(side=RIGHT, fill=BOTH, expand=1)
        self.text.set("command")
        self.input.bind("<Return>", lambda event: self_hi_there())
    def hi_there(self):
        print("hi", self.text.get())        
    def quit(self):
        self.root.destroy()
root = Tk()
app = App(root)
root.mainloop()
#three layout mgmt - pack, grid and place 