import pkg1.util 
from pkg1.util import Directory 

try:
    d = Directory("..")
    print(d.getMaxFile())
except Exception as ex:
    print(ex)