from pkg1.MyInt import MyInt 

import unittest

class MyTest(unittest.TestCase):
    def test_addition(self):
        """Testing adding functionality"""
        a = MyInt(2)
        b = MyInt(3)
        c = a + b 
        self.assertEqual(c, MyInt(5))
    def test_sub(self):
        """Testing sub functionality"""
        a = MyInt(2)
        b = MyInt(3)
        c = a - b 
        self.assertEqual(c, MyInt(-1))