from __future__ import print_function
# import sys 
# a = sys.argv[1]
# b = sys.argv[2]
# c = int(a)
# d = int(b)
# print(a,"+", b , "=", int(a)+int(b))

s = "OK and OK"
for ele in s:
    if ele == 'O':
        print(ele)

s = "Hello World"

# Take each char(ch) from s 
for ch in s:
    # initialize counter 
    counter = 0
    # Take each char(ch1) from s 
    for ch1 in s:
        # if ch and ch1 are same 
        if ch == ch1:
            # increment counter 
            counter = counter + 1
    # print ch and counter 
    print(ch, counter)
    
Create empty dict 
Take each char(ch) from s 
    if ch does not exist in empty dict 
        create a new key of ch 
        and it's value as 1 
    else 
        increment value of key,ch 
        and update that key  
print that empty dict 

s = "Hello World"
ed = {}
for ch in s:
    if ch not in ed:
        ed[ch] = 1
    else:
        ed[ch] = ed[ch] + 1
print(ed)


input = "abbbcdd"
output = "abcd"

out = Create an empty string
Take each char(ch) from input 
    if ch does not exist in out 
        append ch to out 
print out 

out = ""
for ch in input:
    if ch not in out:
        out = out + ch 
print(out)
#####################
[]    list - duplicates - A , indexing - A, 
           - insertion ordered- A, M 
()        tuple - immutable, --above--
    
{}    set - Duplicates-NA, Index - NA, IO-No, Mutable
        frozenset - immutable, --above--
        
-----------
{k:v,...}    dict - Key and it's value 
           keys are like set ie Unique



input = [1,5,4,2,7]
output = [1,25,16,4,49]

Create an empty list 
Take each element from input 
    square it and append to above empty list 
print that empty list 

output = []
for ele in input:
    sq = ele*ele 
    output.append(sq)
print(output)

input = [1,5,4,2,7]
output = [1,25,49]

Create an empty list 
Take each element from input 
    if that element is odd 
        square it and append to above empty list 
print that empty list 


output = []
for ele in input:
    if ele % 2 == 1:
        sq = ele*ele 
        output.append(sq)
print(output)
s = "[1,2,3,4]"   
lst = [1,2,3,4]

strip s with "[]" and then split with ","   #['1','2','3','4']
and store to s2 
Create empty list 
Take each char(e) from s2 
    convert to int and append to emptylist 
print that empty list 

out = []
for e in s.strip("[]").split(","):
    out.append(int(e))

#########################################
empty 
    list   []
    set    set()
    tuple   ()
    dict    {}

Creation of 
    list   [e1,e2..]
    set    {e1, e2 ..} 
    tuple  (e1,e2,...)
    dict   {k1:v1, k2:v2, ...}

Adding element 
        list     list_var.append(e)
        set      set_var.add(e)
        tuple    Can not add, immutable 
        dict     dict_var[key] = value 
    
Updating a value 
        list        list_var[index] = new_value , index is int 
        dict        dict_var[key] = new_value , key is int or string etc 
        
accessing a value 
        list        list_var[index]  , index is int
        dict        dict_var[key] , key is int or string etc 
        tuple       tuple_var[index] , index is int
        set         can not 
        str         str_var[index], index is int
    
Getting length 
        for all         len(var)
Checking a element exists 
        for all         element in var   , returns True 
        for dict, element is key 
Checking a element does not exist
        for all         element not in var ,  returns True 
        for dict, element is key 
Iterating/looping/take each element 
        for all         for element in var:
        for dict, element is key 
   
Map Pattern when some condition is true 
#If you want result as list 
out = [] 
for ele in some_collection:
    if condition_is_true:
        new_ele = transform old element 
        out.append( new_ele)

#If you want result as set  
out = set()
for ele in some_collection:
    if condition_is_true:
        new_ele = transform old element 
        out.add( new_ele)

#If you want result as dict  
out = {}
for ele in some_collection:
    if condition_is_true:
        value = transform  element 
        key = think of some key 
        out[key] = value 

##############
with open(r"D:\PPT\python\hands\first.py", "rt") as f:
    with open(r"D:\PPT\python\hands\first.py.bk", "wt") as f2:
            lines = f.readlines()
            f2.writelines(lines)

import glob
glob.glob(r"D:\PPT\python\hands\*") #dir command in windows 


import csv
with open(r"data\iris.csv", "rt") as f:
    rd = csv.reader(f)
    rows = list(rd)

rows[0:5]          #rows is list of list, each row is a list 
header = rows[1]
rows= rows[1:]
len(rows)
#['4.9', '3.0', '1.4', '0.2', 'Iris-setosa']
rowsd = []   #list of list, each row is list, not converted to float 
for r in rows:
    rowsd.append([ float(r[0]), float(r[1]), 
        float(r[2]),float(r[3]),r[4]])

rowsd[:5]

import sqlite3 import connect 
con = connect("iris.db")
cur = con.cursor()
#5 columns, create table sql 
cur.execute("""create table if not exists iris (sl double, sw double,
               pl double, pw double, name varchar(20))""")
#insert table sql 
for r in rowsd:
    res = cur.execute("insert into iris values(?,?,?,?,?)", r)

con.commit()
#select sql 
q = cur.execute("select name, max(sl) from iris group by name")
result = list(q.fetchall())
print(result)








