#spark-submit --master local[*] wordcount_df.py 
#spark-submit --master  spark://192.168.43.210:7077 wordcount_df.py 
#set HADOOP_CONF_DIR=c:\hadoop\etc\hadoop
#spark-submit --master yarn --deploy-mode client wordcount_df.py 
#spark-submit --master yarn --deploy-mode cluster wordcount_df.py 

#yarn logs -applicationId <<app_id>>

from pyspark import * 
from pyspark.sql import * 
import pyspark.sql.functions as F 
from pyspark.sql.types  import * 

inputFile = "hdfs://localhost:19000/user/das/README"

#conf = SparkConf().setAppName("wordcount")
#sc = SparkContext(conf=conf)
spark = SparkSession.builder.appName("WordCount").\
    config("spark.sql.warehouse.dir", 
        "file:///D:/Desktop/PPT/1.run_pyspark_here/spark_warehouse").\
    enableHiveSupport().getOrCreate()

#input = sc.textFile(inputFile)
input = spark.read.text(inputFile) #value 

#words = input.flatMap(lambda line: line.split())  #map with flatten 
words = input.select(F.split("value", " ").alias("words"))

#counts = words.map(lambda w: (w,1)).reduceByKey(lambda v1,v2: v1+v2) #reduce 
counts = words.select(F.explode("words").alias("word"))
grp = counts.groupBy("word")
print(grp.count().collect()) #into driver

#sql 
counts.createOrReplaceTempView("words")
df = spark.sql("select word, count(*) from words group by word")
df.show()



 



