#spark-submit --master local[*] wordcount.py 
#spark-submit --master  spark://192.168.43.210:7077 wordcount.py 
#set HADOOP_CONF_DIR=c:\hadoop\etc\hadoop
#spark-submit --master yarn --deploy-mode client wordcount.py 
#spark-submit --master yarn --deploy-mode cluster wordcount.py 

#yarn logs -applicationId <<app_id>>

from pyspark import * 

inputFile = "hdfs://localhost:19000/user/das/README"
conf = SparkConf().setAppName("wordcount")
sc = SparkContext(conf=conf)
input = sc.textFile(inputFile)
words = input.flatMap(lambda line: line.split())  #map with flatten 
counts = words.map(lambda w: (w,1)).\
               reduceByKey(lambda v1,v2: v1+v2) #reduce 
print(counts.collect()) #into driver 