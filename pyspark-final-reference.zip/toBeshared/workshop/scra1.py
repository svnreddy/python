import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
iris = pd.read_csv(r"./data/iris.csv")
>>> iris.head(3)
   SepalLength  SepalWidth  PetalLength  PetalWidth         Name
0          5.1         3.5          1.4         0.2  Iris-setosa
1          4.9         3.0          1.4         0.2  Iris-setosa
2          4.7         3.2          1.3         0.2  Iris-setosa
>>> iris.columns
Index(['SepalLength', 'SepalWidth', 'PetalLength', 'PetalWidth', ''object')
>>> iris.index
RangeIndex(start=0, stop=150, step=1)
#creation of new columns 
iris2 = iris.assign(SepalRatio= iris.SepalLength/iris["SepalWidth"])

iris2 = iris.assign(SepalRatio= iris.SepalLength/iris["SepalWidth"],
            PetalRatio= lambda df:df.PetalLength/df.PetalWidth)
            
iris2.plot(kind='scatter', x='SepalRatio', y='PetalRatio')
plt.show() #plt.savefig("plot1.png")

#uniques 
un = iris.Name.unique()
iris['target'] = iris.Name.apply(lambda e: un.tolist().index(e))
iris.loc[:, ['target']]

iris.target
iris['target']
iris[['Name', 'target']

iris[0:5] 
#loc, ix, iloc 
iris.loc[0:5, 'target']
iris.loc[0:5, ['target', 'Name']]
iris.loc[iris.Name == 'Iris-setosa', 'SepalLength']
iris.query('Name == "Iris-setosa"')[['SepalLength','target']]
#index 
iris.iloc[0:5, 4]
iris.iloc[0:5, [4, 3]]
#iris.loc[iris.Name == 'Iris-setosa', 'SepalLength']
#
iris.ix[0:5, 4]
iris.ix[0:5, [4, 3]]


#bining 
sl_bin = pd.cut(iris.SepalLength, 14)
sl_bin.value_counts()
iris['category'] = sl_bin 

###sorting 
iris.SepalLength.sort_values()
iris.sort_values(by=['Name', 'SepalLength'])
#groupby 
gr1 = iris.groupby('Name')
#gr1 = iris.groupby(['Name', 'col1'])

#all columns mean 
gr1.mean()
gr1.agg({'SepalLength':'count',
    'PetalLength':['max','min']})

gr1['SepalLength'].\
    plot(kind='line', subplots=True)
plt.legend()
plt.show()

#excel
dft = pd.read_excel(r"data\Nifty-17_Years_Data-V1.xlsx", 
    parseDates=True, index_col=0, header=0, 
    date_parser=lambda x: pd.to_datetime(x, 
    format="%d-%b-%y"))
    
from pandas.tseries.offsets import *
dft.index.freq = Day()

dft["Close"].plot(kind='line')
plt.show()

#rolling
dft_r = dft.rolling(30)
dft_r.mean()['High'].plot(kind='line')
plt.show()

#resmapling 
dft_s = dft.resample('M')
dft_s.agg({'Open': 'mean', 'Close': 'std'})


##Json 
import json 
with open(r"data/example.json", "rt") as f:
    obj = json.load(f)

    
def proc(e):  #e = dict 
    return e['empId']
    
def getOffficePhoneNumber(e):
    phs = e['details']["phoneNumbers"]
    for ph in phs:
        if ph["type"] = 'office':
            return ph['number']
      
list(map(getOffficePhoneNumber , obj))

[ ph['number'] for e in obj for ph in e['details']["phoneNumbers"] if ph['type'] == 'office' ]

##requests 
import requests , json 

#obj coming from earlier 
headers = {'Content-Type': 'application/json'}
r = requests.post("http://httpbin.org/post", data = json.dumps(obj), headers=headers)

#get back 
obj1 = r.json()
import pprint 
pprint.pprint(obj1)

def getOffficePhoneNumber(e):
    phs = e['details']["phoneNumbers"]
    for ph in phs:
        if ph["type"] = 'office':
            return ph['number']
      
list(map(getOffficePhoneNumber , obj1['json']))
#===========================================================================

##sc Operations
rdd = sc.parallelize([0,1,2,3], 4)


##RDD Operations 
#foreach 
rdd.foreach(lambda e: print(e)) 
rdd.take(10)

# keyBy(f)
rdd = sc.parallelize([0,1,2,3], 4)  #[0,1,2,3]
rdd.keyBy( lambda e: e%2)  #[(0, 0), (1, 1), (0, 2), (1, 3)]
rdd.reduce(lambda r,e: (print(r,e), r+e)[-1])
rdd1.reduce(lambda r,e: (print(r,e), r+e)[-1])
rdd1.reduceByKey(lambda r,e: (print(r,e), r+e)[-1]).collect()

#join and any others 




#map 

#filter 


#mapPartitions 


#zip 


#zipWithIndex 


#sortBy 

#



##Full example  
def fun(it):            #[('Iris-virginica', <pyspark.resu)]
    lst =list(it)[0]    #('Iris-virginica', [[row1], [row2]....])
    return [ (lst[0], [e[0] for e in lst[1]]) ]

iris4 = iris3.mapPartitions(fun, True)
[('Iris-virginica', [6.3, 5.8, 7.1, 6.3, 6.5, 7.6, 4.9, 7.3, 6.7, 7.
 6.8, 5.7, 5.8, 6.4, 6.5, 7.7, 7.7, 6.0, 6.9, 5.6, 7.7, 6.3, 6.7, 7.
 6.4, 7.2, 7.4, 7.9, 6.4, 6.3, 6.1, 7.7, 6.3, 6.4, 6.0, 6.9, 6.7, 6.
 6.7, 6.7, 6.3, 6.5, 6.2, 5.9]), ('Iris-setosa', [5.1, 4.9, 4.7, 4.6
4.6, 5.0, 4.4, 4.9, 5.4, 4.8, 4.8, 4.3, 5.8, 5.7, 5.4, 5.1, 5.7, 5.1
4.6, 5.1, 4.8, 5.0, 5.0, 5.2, 5.2, 4.7, 4.8, 5.4, 5.2, 5.5, 4.9, 5.0
4.4, 5.1, 5.0, 4.5, 4.4, 5.0, 5.1, 4.8, 5.1, 4.6, 5.3, 5.0]), ('Iris
, [7.0, 6.4, 6.9, 5.5, 6.5, 5.7, 6.3, 4.9, 6.6, 5.2, 5.0, 5.9, 6.0,
7, 5.6, 5.8, 6.2, 5.6, 5.9, 6.1, 6.3, 6.1, 6.4, 6.6, 6.8, 6.7, 6.0,
5, 5.8, 6.0, 5.4, 6.0, 6.7, 6.3, 5.6, 5.5, 5.5, 6.1, 5.8, 5.0, 5.6,
2, 5.1, 5.7])]
>>> iris4.map(lambda t :(t[0], {'max':max(t[1])})).collect()#RDD[(string, dict(string,Int)]


###*** RDD - HandsOn Device.txt 
#Open device.txt 
#eventTime,deviceId,signal 
from dateutil.parser import parse

#Q1. Count of unique deviceId and count by each deviceId 

lines = sc.textFile("./data/spark/device.txt")
#split and convert 
rows = lines.map(lambda l:l.split(',')).\
             map(lambda r: (parse(r[0]), r[1], int(r[2])))

#key as deviceID 
kv_rows = rows.keyBy(lambda r: r[1])
 
un = kv_rows.map(lambda r: r[0]).distinct().collect()  #['yours', 'his', 'mine']


#Q2. Parition based on DeviceId and get all signals and its size for each deviceId
def part(k, lst):
    return lst.index(k) % len(lst)

kv = rows.groupBy(lambda r:r[1], len(un), lambda k: part(k, un))

def fun(it):            #[(deviceId, Itr)]
    lst =list(it)[0]    #(deviceId, Itr)
    sigs = [r[-1] for r in  lst[1]]
    return [ (lst[0], sigs, len(sigs) ) ]

q2res = kv.mapPartitions(fun)
q2res.collect()
#which device is giving max signal 
q2res.max(lambda r: r[-1])
#sort 
q2res.sortBy(lambda r: (r[-1], r[0]))




Q3.Find deviceId and it's signal between 2017-08-23T00:00:00.002Z - 2017-08-23T00:10:00.002Z 


Q4. Find all Device IDs between 10 min windows   


##############################
lines = sc.textFile(r"./data/spark/Cartier+for+WinnersCurse.csv")
headers = lines.first()

rdd = lines.filter(lambda r: r!=headers).map(lambda r: r.split(",")).\
        map(lambda r: Row(*r))
        
fs = [StructField(h,StringType()) for h in headers.split(",")]

df = spark.createDataFrame(rdd, StructType(fs))
#or 
df = rdd.toDF(StructType(fs))
df.show()

#new 
curse = spark.read.option("inferSchema", "true").\
    option("header", "true").csv(r"./data/spark/Cartier+for+WinnersCurse.csv")

curse.groupby("bidder").count().show()
curse.groupby("bidder").count().sort(F.col("count").desc()).show()
curse.select("auctionid").distinct().count()
n = curse.select("auctionid").distinct().count()
#repartition 
spark.conf.set("spark.sql.shuffle.partitions", n)
c_r_c = curse.repartition(n, "auctionid").cache()

#filter
curse.filter(F.col("bidder").like("a%")).show()
curse.filter("bidder like 'a%'").show()

df1 = curse.groupby("bidder").count().sort(F.col("count").desc())
df1.repartition(1).write.format("csv").option("header", "true").\
  mode("append").save("./data/spark/processed")
  

#____________________________________
from pyspark import * 
from pyspark.sql import * 
import pyspark.sql.functions as F 
from pyspark.sql.types import * 


#Read iris.csv 
raw = spark.read.format("csv").option("header","true")\
       .option("inferSchema", "true").load("./data/spark/iris.csv")
       
#spark.conf.set("spark.sql.shuffle.partitions",3)
iris = raw.repartition("Name").cache()



# display 5 rows 
iris.show(5)

# check datatypes 
iris.dtypes


# Create new column sepal_ratio = 'SepalWidth'/'SepalLength' and round to 2 decimal digit 
#withColumn(colName, col)
iris.withColumn('sepal_ratio', F.round(iris['SepalWidth']/iris.SepalLength, 2)).show()



# Display rows where SepalLength > 5 and  SepalLength < 5.2
    # with string expression 
iris.where("SepalLength > 5 AND  SepalLength < 5.2").show() 
    # with column operations 
iris.filter( (F.col("SepalLength") > 5) &  (F.col("SepalLength") < 5.2)).show()  

  
# Display rows where SepalLength is between 5.01 and 5.1 
# Filter rows where SepalLength > 5 and create new column SepalRatio = 'SepalWidth'/'SepalLength'
# and new column 'PetalRatio'= PetalWidth / PetalLength 
# and then convert to Pandas and scatter plot SepalRatio vs PetalRatio
iris.filter('SepalLength > 5 ')\
    .withColumn('SepalRatio', iris.SepalWidth/iris.SepalLength)\
    .withColumn('PetalRatio', iris.PetalWidth / iris.PetalLength )\
    .toPandas() \
    .plot(kind='scatter', x='SepalRatio', y='PetalRatio')
        
plt.show()
# Get Unique value of Name column 
iris.select(F.collect_set("Name")).collect()

# Transform each Name to lower 
iris.select(F.lower(F.col("Name"))).show(5)


# Write UDF to transform Name column to a column without Iris- prefix 
@F.udf(returnType=StringType())
def get(e):
    return e[5:]

iris.select(get(F.col("Name"))).show(5)

# Similarly use pandas_udf , SCALAR to get  a column without Iris- prefix , use Series.str.slice 

@F.pandas_udf("string", F.PandasUDFType.SCALAR)
def get1(sr):
    return sr.str.slice(5)


iris.select(get1(F.col("Name"))).show(5)    


# Similary, do the above in SQL after create temp view iris 
spark.udf.register("get", lambda e: e[5:], StringType())
iris.createOrReplaceTempView("iris")
spark.sql("select get(name) as nm from iris").show()

# Create a pandas_udf with GROUPED_MAP for zscore of SepalLength and PetalLength
# and then apply to dataframe 
@F.pandas_udf(iris.schema, F.PandasUDFType.GROUPED_MAP)
def zscore(pdf):
    def _norm(se):
        return ((se - se.mean())/se.std()).round(2)
    return pdf.assign(SepalLength=_norm(pdf.SepalLength),PetalLength=_norm(pdf.PetalLength))

iris.groupby("Name").apply(zscore).show()
 


# Get Iris descriptive Stats and cache it 

# Write above summary in CSV file 

# For each Name , get all columns count and SepalLength's min and get the result to driver 
# For each Name , use F.count and sepelaLenght's stddev 

# Get sorted array of SepalLength

# Get count distinct value of SepalLength

# For each distinct value of sepalLength, count it's number 
    # Use count("SepalLength").over(Window.partitionBy("SepalLength"))
    # then create a array of two columns SepalLength and above count 
    # then Select distinct of above array 
# For above distinct value of SepalLength, create pivot Table of avg of SepalWidth 

# Create a pandas_udf with GROUPED_MAP for Zscore of SepalLength and PetalLength
# and then apply to dataframe 

# Create iris table and 

# get sql version of count, min SepalLength after group by on Name and order by Name 




    How many clusters?
    
    Can you get those clusters?
        Use pyspark.mllib.clustering.KMeans 
        Create One new column 
            features - array of 'SepalRatio', 'PetalRatio' after rounding to 2 digits 
        Create trainData, testData using DF.randomSplit- check help 
        clusters(ie model) = Kmeans.train with trainData 
            after converting(ie rdd.map) 'features' column to mllib.DenseVector by Vectors.dense 
            with k=2 and maxIterations=10, initializationMode="random"
        Get clusters points from clusters.clusterCenters or clusters.centers
        Predict testData after again converting to Vectors.dense - use clusters.predict(denseVector)
        Evaluate clustering by computing Within Set Sum of Squared Errors
            for all features of test data , find predicted point, convert to cluster 2D point 
            For all features , find square of distance between original point and predicted center point 
            sum above and sqrt of the above 


#Json
df = spark.read.format("json").option("multiLine", "true")\
     .load("./data/spark/input-json")
     
schema = df.schema 
df.printSchema()

#spread struct 
df.select(F.col("empId"), F.col("details.phoneNumbers")[1].alias("phs"))\
  .select("empId", "phs.*").show()
#output 
+-----+------------+------+
|empId|      number|  type|
+-----+------------+------+
|    1|646 555-4567|office|
+-----+------------+------+

df.select(F.col("empId"), F.explode(F.col("details.phoneNumbers")).alias("phs"))\
  .select("empId", "phs.*")\
  .where("type == 'office'").select("empId", "number")\
  .repartition(1).write\
  .format("csv").option("header", "true")\
  .save("./data/spark/out_csv_from_json")
  
     
#Streaming 
schema = df.schema 

q0 = spark.readStream.format("json")\
     .schema(schema).option("multiLine", "true")\
     .load("./data/spark/input-json")\
     .select(F.col("empId"), F.explode(F.col("details.phoneNumbers")).alias("phs"))\
     .select("empId", "phs.*")\
     .where("type == 'office'").select("empId", "number")\
     .writeStream\
     .outputMode("append")\
     .format("console")\
     .trigger(processingTime="10 seconds")\
     .start()
  
q1 = spark.readStream.format("json")\
     .schema(schema).option("multiLine", "true")\
     .load("./data/spark/input-json")\
     .select(F.col("empId"), F.explode(F.col("details.phoneNumbers")).alias("phs"))\
     .select("empId", "phs.*")\
     .where("type == 'office'").select("empId", "number")\
     .writeStream\
     .outputMode("append")\
     .format("csv")\
     .trigger(processingTime="10 seconds")\
     .option("checkpointLocation", "./stream_1")\
     .start("./data/spark/out_csv_from_json_stream")   
     
     
q01 = spark.readStream.format("json")\
     .schema(schema).option("multiLine", "true")\
     .load("./data/spark/input-json")\
     .select(F.col("empId"), F.explode(F.col("details.phoneNumbers")).alias("phs"))\
     .select("empId", "phs.*")\
     .where("type == 'office'").select("empId", "number")\
     .groupBy("empId").agg(F.first("number").alias("numbers"))\
     .writeStream\
     .outputMode("complete")\
     .format("console")\
     .trigger(processingTime="10 seconds")\
     .start()     
     
##Parquet 
df = spark.read.json("./data/spark/people.json")
df.write.parquet("./data/spark/peole.parquet")

df2 = spark.read.parquet("./data/spark/peole.parquet")

df2.createOrReplaceTempView("people")
spark.sql("select name from people where age >=13").show()



##RDMS - JDBC 
#pyspark --packages org.xerial:sqlite-jdbc:3.21.0.1

df = spark.read.json("./data/spark/people.json")
df.write.format("jdbc").options(url="jdbc:sqlite:file.db", 
    driver="org.sqlite.JDBC", dbtable="persons").mode("append").save()
    
#reading 
df1 = spark.read.format("jdbc").options(url="jdbc:sqlite:file.db", 
    driver="org.sqlite.JDBC", dbtable="persons").load()
    
###Spark-SQL 
spark.sql("""
    drop table  if exists src
    """)
spark.sql("""
    create table if not exists src (key INT, value String)
    """)    
spark.sql("""
    load data local inpath './data/spark/kv1.txt' into table src
    """)
spark.sql("""
    select * from src 
    """).show()
     
spark.sql("create table hive_par(key int, value string) stored as parquet")
df = spark.table("src")
df.write.mode("overwrite").saveAsTable("hive_par")

df2 = spark.table("hive_par")
#on dynamic partition 
spark.conf.set("hive.exec.dynamic.partition", "true")
spark.conf.set("hive.exec.dynamic.partition.mode", "true")

df.write.partitionBy("key").format("hive").saveAsTable("hive_part_table")
spark.catalog.listTables()
     
##
from pyspark import * 
from pyspark.sql import * 
import pyspark.sql.functions as F 
from pyspark.sql.types import * 
    

rawData  = spark.\
  readStream.\
  format("kafka").\
  option("subscribe", "topic1").\
  option("kafka.bootstrap.servers", "localhost:9092").\
  load()   
     
rawData.printSchema()
#2017-08-23T00:00:00.002Z,"mine",20
df = rawData.select(F.col("value").cast("string"))\
            .withColumn("tokens", F.split("value", ","))\
            .withColumn("eventTime", F.to_timestamp(F.col("tokens").getItem(0)))\
            .withColumn("deviceId", F.col("tokens").getItem(1).cast("string"))\
            .withColumn("signal", F.col("tokens").getItem(2).cast("int"))\
            .select("eventTime", "deviceId", "signal")

#proc-1 
avgDf = df.groupBy("deviceId").avg("signal")

#window with watermark 
windowDf = df.withWatermark("eventTime", "20 minutes")\
             .groupBy(F.col("deviceId"), F.window("eventTime", "5 minutes"))\
             .agg(F.collect_list("signal").alias("signals"))\
             .select(F.col("deviceId"), F.col("signals"), F.size("signals"), F.col("window"))
             
sq = windowDf.writeStream.format("console")\
             .option("truncate", "false")\
             .outputMode("update")\
             .trigger(processingTime="20 seconds")\
             .start()
             
sq2 = windowDf.select(F.col("deviceId").alias("value")).writeStream\
  .format("kafka")\
  .option("topic", "topicName")\
  .option("kafka.bootstrap.servers", "localhost:9092")\
  .option("checkpointLocation", "./kafka-checkpoint") \
  .start()             

#pyspark   --packages com.databricks:spark-avro_2.11:4.0.0

df = spark.read.format("com.databricks.spark.avro").load("./data/spark/users.avro")
new_df = df.where("name == 'Ben'")
new_df.write.format("com.databricks.spark.avro").save("./data/spark/user_new.avro")


##MongoDB 
#pyspark --packages org.mongodb.spark:mongo-spark-connector_2.11:2.3.0

#cd  C:\trg\mongodb 
#mongod.exe --dbpath data --config mongod.cfg 
$ mongo 
> show dbs 
> use test 
> show collections 
> db.inventory.find()

#spark
df = spark.read.json("./data/spark/people.json")

df.write.format("com.mongodb.spark.sql.DefaultSource").mode("append"). \
    option("database","people").option("uri","mongodb://127.0.0.1/")\
    .option("collection", "users").save()

#to read from a different MongoDB collection, use the .option method when reading data into a DataFrame.
df2 = spark.read.format("com.mongodb.spark.sql.DefaultSource").\
   option("uri","mongodb://127.0.0.1/people.users").load()

df2.show()

###
import pyspark.sql.functions as F 

def melt(df, id_vars, value_vars, var_name="variable", value_name="value") :
    """Convert :class:`DataFrame` from wide to long format."""
    # Create array<struct<variable: str, value: ...>>
    _vars_and_vals = F.array(*(
        F.struct(F.lit(c).alias(var_name), F.col(c).alias(value_name)) 
        for c in value_vars))

    # Add to the DataFrame and explode
    _tmp = df.withColumn("_vars_and_vals", F.explode(_vars_and_vals))

    cols = id_vars + [F.col("_vars_and_vals")[x].alias(x) for x in [var_name, value_name]]
    return _tmp.select(*cols)


##
context, partition, var1, var2 
1,A,X,Y 
2,B,X,Y
3,C,Z,L 

id_vars = [ "context", "partition"]
value_vars=['var1', 'var2']
var_name = "variable"
value_name="value"

_vars_and_vals = F.array(*(
        F.struct(F.lit(c).alias(var_name), F.col(c).alias(value_name)) 
        for c in value_vars))

# Add to the DataFrame and explode
df = spark.read.format("csv").option("inferSchema", "true").option("header", "true").\
    load("./data/spark/example_t.csv")
    
_tmp = df.withColumn("_vars_and_vals", F.explode(_vars_and_vals))

cols = id_vars + [F.col("_vars_and_vals")[x].alias(x) for x in [var_name, value_name]]

_tmp.select(*cols)







