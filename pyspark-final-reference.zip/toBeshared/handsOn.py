
##Concatenate-DF 
df1 = pd.DataFrame({'A': ['A0', 'A1', 'A2', 'A3'],  #keys are columns                    
    'B': ['B0', 'B1', 'B2', 'B3'],                    
    'C': ['C0', 'C1', 'C2', 'C3'],                    
    'D': ['D0', 'D1', 'D2', 'D3']},                    
    index=[0, 1, 2, 3])
df2 = pd.DataFrame({'A': ['A4', 'A5', 'A6', 'A7'],                   
    'B': ['B4', 'B5', 'B6', 'B7'],                   
    'C': ['C4', 'C5', 'C6', 'C7'],                    
    'D': ['D4', 'D5', 'D6', 'D7']},                    
    index=[4, 5, 6, 7])
df3 = pd.DataFrame({'A': ['A8', 'A9', 'A10', 'A11'],                    
    'B': ['B8', 'B9', 'B10', 'B11'],                     
    'C': ['C8', 'C9', 'C10', 'C11'],                        
    'D': ['D8', 'D9', 'D10', 'D11']},                    
    index=[8, 9, 10, 11])




#merge 
>>> A              >>> B
    lkey value        rkey value
0   foo  1            foo  5
1   bar  2            bar  6
2   baz  3            qux  7
3   foo  4            bar  8


left = pd.DataFrame({'key1': ['K0', 'K0', 'K1', 'K2'],                      
        'key2': ['K0', 'K1', 'K0', 'K1'],                     
        'A': ['A0', 'A1', 'A2', 'A3'],                     
        'B': ['B0', 'B1', 'B2', 'B3']})
right = pd.DataFrame({'key1': ['K0', 'K1', 'K1', 'K2'],                      
        'key2': ['K0', 'K0', 'K0', 'K0'],                        
        'C': ['C0', 'C1', 'C2', 'C3'],                         
        'D': ['D0', 'D1', 'D2', 'D3']}) 


#dropna 
df = pd.DataFrame([[np.nan, 2, np.nan, 0], [3, 4, np.nan, 1],
                        [np.nan, np.nan, np.nan, 5]],
                    columns=list('ABCD'))


#fillna 
df = pd.DataFrame([[np.nan, 2, np.nan, 0],
                        [3, 4, np.nan, 1],
                        [np.nan, np.nan, np.nan, 5],
                        [np.nan, 3, np.nan, 4]],
                        columns=list('ABCD'))


#map 
x = pd.Series([1,2,3], index=['one', 'two', 'three'])
y = pd.Series(['foo', 'bar', 'baz'], index=[1,2,3])


df = pd.DataFrame({'key1': ['K0', 'K0', 'K1', 'K2'],                      
        'key2': ['K0', 'K1', 'K0', 'K1'],                     
        'A': ['A0', 'A1', 'A2', 'A3'],                     
        'B': ['B0', 'B1', 'B2', 'B3']})


#trnsform 
df = pd.DataFrame(np.random.randn(10, 3), columns=['A', 'B', 'C'],
            index=pd.date_range('1/1/2000', periods=10))
        
        
        
#assign 
df = pd.DataFrame({'A': range(1, 11), 'B': np.random.randn(10)})        
        
#apply 
df = pd.DataFrame([[4, 9],] * 3, columns=['A', 'B'])       
        
#applymap 
df = pd.DataFrame([[1, 2.12], [3.356, 4.567]])    
        
#agg 
df = pd.DataFrame({'A': [1, 1, 2, 2],
                    'B': [1, 2, 3, 4],
                    'C': np.random.randn(4)})       
        
#grp.apply 
df = pd.DataFrame({'A': 'a a b'.split(), 'B': [1,2,3], 'C': [4,6, 5]})      
        
#grp.transform 
   A      B         C         D
0  foo    one  0.162003  0.087469
1  bar    one -1.156319 -1.526272
2  foo    two  0.833892 -1.666304
3  bar  three -2.026673 -0.322057
4  foo    two  0.411452 -0.954371
5  bar    two  0.765878 -0.095968
6  foo    one -0.654890  0.678091
7  foo  three -1.789842 -1.130922
        
#pipe 
df = pd.DataFrame({'A': 'a b a b'.split(), 'B': [1, 2, 3, 4]})     
    
df = pd.DataFrame(dict(
    A=list('XXXXYYYYYY'),
    B=range(10)
))    
        
#filter 
df = pd.DataFrame({'A' : ['foo', 'bar', 'foo', 'bar',
                          'foo', 'bar'],
                   'B' : [1, 2, 3, 4, 5, 6],
                   'C' : [2.0, 5., 8., 1., 2., 9.]})      
        
        
#excel 
dft = pd.read_excel(r"data\Nifty-17_Years_Data-V1.xlsx", parseDates=True, index_col=0, header=0, date_parser=lambda x: pd.to_datetime(x, format="%d-%b-%y"))


###*** Pandas Hands on 

1.Read data/ver.csv

#columns 
#index,year,day of the year,time,atmospheric pressure (mBar),rainfall (mm),wind speed (m/s),wind direction (degrees),surface temperature (C),relative humidity (%),wind_max (m/s),Tdew (C),wind_chill (C),uncalibrated solar flux (Kw/m2), calibrated solar flux (Kw/m2),battery (V),not used

2.Check/do below 
    index 
    Display head 
    Shape 
    columns 
    datatypes 
    Get the first five rows of  column 'atmospheric pressure (mBar)'
    Create 14 bins  of  column 'atmospheric pressure (mBar)'
    Get value frequencies  of  column 'atmospheric pressure (mBar)' in the ranges created above
    Get first six columns of the first row
    Sort column 'atmospheric pressure (mBar)' and display first five rows 
    Sort by 'atmospheric pressure (mBar)', 'day of the year' 
    
    Obtain a cross-section(all rows, only first 6 columns) of that data
    Obtain the first three rows and first three columns of the sorted data
    Obtain value counts of column 'atmospheric pressure (mBar)'
    Get the unique values for a column 'year'
    Get a count of the unique values of column 'year'
    Get first four rows of column 'atmospheric pressure (mBar)'

    Get rows where 'atmospheric pressure (mBar) = 1025
    Get rows where 'atmospheric pressure (mBar)' > 1010 and 'atmospheric pressure (mBar)' < 1016) 
    
    Query the data where year = 2015
    
    Replace following in all columns 
        Space by _ 
        '(' by ''
        ')' by '' 
    Then Query the data where atmospheric_pressure_mBar = 1016
    Check whether any row is having 'atmospheric_pressure_mBar' > 1016 

    Get descriptive statistics of the dataset- mean, std etc is calculated for each column
    Get descriptive statistics of atmospheric_pressure_mBar
    
    Do sum , min aggregation in each column 
    Do sum , min aggregation of atmospheric_pressure_mBar and min, max of rainfall_mm
    Do mean aggregation of each row 

    group by 'atmospheric_pressure_mBar', and then 'rainfall_mm 
        find mean of all other columns
        find sum, count of all other columns 
    
    Add new column 
        atmospheric_pressure_mBar_str which is string conversion of atmospheric_pressure_mBar
        How many of above column ends with '5'
    
    Apply np.sum to each column 
    Convert each element to string 
    Transform column 3 and 4 with zscore =(element - mean)/std
        
    Drop duplicates of 'atmospheric pressure (mBar)'
    
    excel styple pivot table (pd.pivot_table)
    values=ColumnNames for aggfun ,  'atmospheric pressure (mBar)','rainfall (mm)'
    index=ColumnsNames for row-groupby , 'year', 'day of the year'
    columns=ColumnNames on column-groupby ,  'battery (V)'
    aggfunc=not string, but functions , np.sum, np.max, lambda x:x.size

    plot horizontal bar graph of values of 'atmospheric_pressure_mBar'
    plot median values (bar) of surface_temperature_C column after group by with 'atmospheric_pressure_mBar'







###*** RDD - HandsOn Device.txt 
#Open device.txt 
#eventTime,deviceId,signal 

Q1. Count of unique deviceId and count by each deviceId 

Q2. Parition based on DeviceId and get all signals and its size for each deviceId

Q3.Find deviceId and it's signal between 2017-08-23T00:00:00.002Z - 2017-08-23T00:10:00.002Z 


Q4. Find all Device IDs between 10 min windows    
    

    
    
    
    
    
###ArrayType and MapType columns - String interpretation with the array() method
df = sc.parallelize([Row(word1="i like blue and red"),Row(word1="you pink and blue")]).toDF()


###Splitting a string into an ArrayType column
singersDF = sc.parallelize([  ("beatles", "help|hey jude"),  ("romeo", "eres mia")]).toDF(["name", "hit_songs"])


###array_contains() and explode() methods for ArrayType columns
val peopleDF = spark.createDataFrame(
  sc.parallelize([
    Row("bob", ("red", "blue")),
    Row("maria", ("green", "red")),
    Row("sue", ("black",))
  ]), StructType([
    StructField("name", StringType(), True),
    StructField("favorite_colors", ArrayType(StringType(), True), True)
  ])
)



###Example of complex schema - Each row is Person 

Person = Row('userId', 'tech')  #tech is instance of below Tech 
Tech = Row('browsers', 'oss')   #browsers is list of instance of below Browser 
Browser = Row('family','major', 'minor','language','timesSeen')

#userId: string, tech: struct<browsers: array<struct<family:string,major:int,minor:int,language:string,timesSeen:bigint>>, oss: string>

df = sc.parallelize([Person("abc",Tech([
    Browser("IE", 7, 0, "en", 3),
    Browser(None, None, None, "en-us", 1),
    Browser("Firefox",54, None,None, 1)], "win")),
  Person("abc", Tech([
    Browser("IE", 7, 0, "en", 3),
    Browser(None, None, None, "en-us", 1),
    Browser("Firefox",54, None,None, 1)], "linux"))]).toDF()
    
    
    
    
    
    
###Spark - DataFrame - Userdefined function to operate on each element of a DF column

#for normal udf and pandas_udf with SCALAR 
df = spark.createDataFrame([(1, "John Doe", 21)], ("id", "name", "age"))

#pandas_udf with  GROUPED_MAP 
df = spark.createDataFrame(
    [(1, 1.0), (1, 2.0), (2, 3.0), (2, 5.0), (2, 10.0)],
    ("id", "v")) 



### handsOn   - Pandas_udf
#Write a pandas_udf (SCALAR) to multiply two columns 
#test with pd.Series([1, 2, 3])




    
    
###Handas On - iris
from pyspark import * 
from pyspark.sql import * 
import pyspark.sql.functions as F 
from pyspark.sql.types import * 


1. Read iris.csv 

2. do following 
    display 5 rows 
    check datatypes 
    Create new column sepal_ratio = 'SepalWidth'/'SepalLength' and round to 2 decimal digit 
    
    Display rows where SepalLength > 5 and  SepalLength < 5.2
        with string expression 
        with column operations 
    Display rows where SepalLength is between 5.01 and 5.1 

    Filter rows where SepalLength > 5 and create new column SepalRatio = 'SepalWidth'/'SepalLength'
    and new column 'PetalRatio'= PetalWidth / PetalLength 
    and then convert to Pandas and scatter plot SepalRatio vs PetalRatio
    How many clusters?
    
    Can you get those clusters?
        Use pyspark.mllib.clustering.KMeans 
        Create One new column 
            features - array of 'SepalRatio', 'PetalRatio' after rounding to 2 digits 
        Create trainData, testData using DF.randomSplit- check help 
        clusters(ie model) = Kmeans.train with trainData 
            after converting(ie rdd.map) 'features' column to mllib.DenseVector by Vectors.dense 
            with k=2 and maxIterations=10, initializationMode="random"
        Get clusters points from clusters.clusterCenters or clusters.centers
        Predict testData after again converting to Vectors.dense - use clusters.predict(denseVector)
        Evaluate clustering by computing Within Set Sum of Squared Errors
            for all features of test data , find predicted point, convert to cluster 2D point 
            For all features , find square of distance between original point and predicted center point 
            sum above and sqrt of the above 
            
        Get Unique value of Name column 
        Transform each Name to lower 
        Write UDF to transform Name column to a column without Iris- prefix 
        Similarly use pandas_udf , SCALAR to get  a column without Iris- prefix , use Series.str.slice 
        Similary, do the above in SQL after create temp view iris 
        
        Get Iris descriptive Stats and cache it 
        Write above summary in CSV file 
        
        For each Name , get all columns count and SepalLength's min and get the result to driver 
        For each Name , use F.count and sepelaLenght's stddev 
        
        Get sorted array of SepalLength
        Get count distinct value of SepalLength
        For each distinct value of sepalLength, count it's number 
            Use count("SepalLength").over(Window.partitionBy("SepalLength"))
            then create a array of two columns SepalLength and above count 
            then Select distinct of above array 
        For above distinct value of SepalLength, create pivot Table of avg of SepalWidth 
        
        Create a pandas_udf with GROUPED_MAP for Zscore of SepalLength and PetalLength
        and then apply to dataframe 
        
        Create iris table and 
        get sql version of count, min SepalLength after group by on Name and order by Name 







###HandsON - boston data 
    :Attribute Information (in order):
        - CRIM     per capita crime rate by town
        - ZN       proportion of residential land zoned for lots over 25,000 sq.ft.
        - INDUS    proportion of non-retail business acres per town
        - CHAS     Charles River dummy variable (= 1 if tract bounds river; 0 otherwise)
        - NOX      nitric oxides concentration (parts per 10 million)
        - RM       average number of rooms per dwelling
        - AGE      proportion of owner-occupied units built prior to 1940
        - DIS      weighted distances to five Boston employment centres
        - RAD      index of accessibility to radial highways
        - TAX      full-value property-tax rate per $10,000
        - PTRATIO  pupil-teacher ratio by town
        - B        1000(Bk - 0.63)^2 where Bk is the proportion of blacks by town
        - LSTAT    % lower status of the population
        - MEDV     Median value of owner-occupied homes in $1000s

"crim", "zn",   "indus", "chas", "nox",  "rm",  "age",  "dis",  "rad", "tax", "ptratio", "b",   "lstat","medv"
0.00632, 18,     2.31,    "0",    0.538,  6.575, 65.2,   4.09,  1,      296,   15.3,      396.9, 4.98,   24

1. read data in boston 

2. Create a column crimxmedv = crim X medv 

3. select columns crimxmedv , tax 

4. what is the max value of crim 


5. what is max value of medv 

5. select rows of crim where medv is max 


6. select rows of medv where crim is max 


7. how many unique value in chas and rad 


8. what is max and min value of medv for each chas 


9. put crimxmedv and tax in csv 


  
###HandsOn - device.txt 
#eventTime,deviceId,signal  
2017-08-23T00:00:00.002Z,"mine",20
2017-08-23T00:05:00.002Z,"mine",30
2017-08-23T00:09:00.002Z,"mine",40
2017-08-23T00:11:00.002Z,"mine",50
2017-08-23T01:00:00.002Z,"mine",60
2017-08-23T00:49:59.002Z,"mine",70


1. read text file in DF 
2. extract each column  and then 'cast' to correct type with name eventTime,deviceId,signal
col1 - timestamp, column2 - string, column3-int 
3. group by deviceId and collect all signals into a list 'signals'
4. select deviceId,signals, it's size and dump into csv file '



_____________________________________


###HandsOn - SPARK-SQL 

1. Create csv table boxes with  (width INT, length INT, height INT)
   options are path= boxes.csv , header true nd partiton columns width and legth 

   insert width=3, length=4 and height ranges from 1 to 3 
    insert width 4, length 3 and height 7 and 8 

2. Create another parquet table rectangles with same schema as boxes and dump boxes into that 
   here option is path to rectangles.PARQUET and partition column is width 
   clustering col is length and partitioned into 8 buckets 
   
  
3. DO below 
        select all from boxes 
        select remaining from boxes where height is 3 
        select onlt 2 rows and distinct remaining cols  from boxes for height 2 
        select (1, 2, 3), (2, 3, 4) as width, length, height 
        select all from boxes with 
            ordering by width col 
            distribute and sort by width
            cluster by length 
            sample only 3 rows 
            sample only 25% 
            
        inner join boxes and rectangles on width column 
        full outer join of boxes and rectangles on width and length 
        natural join of boxes and rectangles
        #based on Common columns ie that have the same name in both tables
        
        Select height, count of each group as num_rows based on height group in boxes 
        Select width, avg of length as num_rows based on width  group in boxes 
        select all cols from boxes after grouping on all columns and rollup 
        select width, length and avg of height from boxes after grouping on width, length 
            with grouping sets of width and length 



###Join DF 
df = sc.parallelize([(2, 'Alice'), (5, 'Bob')])\
        .toDF(StructType([StructField('age', IntegerType()),
                          StructField('name', StringType())]))
df2 = sc.parallelize([Row(name='Tom', height=80), Row(name='Bob', height=85)]).toDF()
df3 = sc.parallelize([Row(name='Alice', age=2),
                           Row(name='Bob', age=5)]).toDF()
df4 = sc.parallelize([Row(name='Alice', age=10, height=80),
                           Row(name='Bob', age=5, height=None),
                           Row(name='Tom', age=None, height=None),
                           Row(name=None, age=None, height=None)]).toDF()


###HandsON - Join

left = sc.parallelize([(0, "zero"), (1, "one")]).toDF(["id", "left"])
right = sc.parallelize([(0, "zero"), (2, "two"), (3, "three")]).toDF(["id", "right"])

1.Inner join - for common 'id' in both 

2.for common left.left  and right.right

3. on id, do below joins 
    full , left, right, left_semi, left_anti 
    and tell the difference 
4. Check num of partitions on left and right 
   How many partitions are there in inner join 
 
 
 
 
###HandsON - Join

Person = Row("id", "name", "cityId")
City = Row("id", "name")

Create below DF 
  Person(0, "Agata", 0),
  Person(1, "Iweta", 0),
  Person(2, "Patryk", 2),
  Person(3, "Maksym", 0)  
AND 
  City(0, "Warsaw"),
  City(1, "Washington"),
  City(2, "Sopot")

  
1. join on cityid and id of person and city respetively 
2. what is the schema of above 




###HandsON - from JSON 
1. Create a schema for 
[("""
  {
    "firstName" : "Jacek",
    "lastName" : "Laskowski",
    "email" : "jacek@japila.pl",
    "addresses" : [
      {
        "city" : "Warsaw",
        "state" : "N/A",
        "zip" : "02-791"
      }
    ]
  }""",),   ]
  

addressesSchema = StructType()  \
  .add("city", StringType(), True)  \
  .add("state", StringType(), True) \
  .add("zip", StringType(), True)   
schema =  StructType()   \
  .add("firstName", StringType(), True) \
  .add("lastName", StringType(), True)  \
  .add("email", StringType(), True) \
  .add("addresses", ArrayType(addressesSchema ))
  

2. Create DF of above string as rawJsons
3. Convert each string to json struct 
   Then flatten the structure 
   then explode addresses with column address 
   drop addresses columns 
   only select firstname, lastname, email and all address 



   
   
###GroupBy, cube, rollup 
df = sc.parallelize([(2, 'Alice'), (5, 'Bob')])\
        .toDF(StructType([StructField('age', IntegerType()),
                          StructField('name', StringType())]))
           

inventory = sc.parallelize([
  ("table", "blue", 124),
  ("table", "red", 223),
  ("chair", "blue", 101),
  ("chair", "red", 210)]).toDF(["item", "color", "quantity"])

           
                          
###HandsOn - GroupBy, cube, rollup 

#Understand Rollup using Group By 
1. Create sales DF ("city", "year", "amount") using below 
[
  ("Warsaw", 2016, 100),
  ("Warsaw", 2017, 200),
  ("Boston", 2015, 50),
  ("Boston", 2016, 150),
  ("Toronto", 2017, 50)]


S1.Get groupByCityAndYear by grouping on city and year and getting aggregation - sum of amount 
S2.Get groupByCityOnly by grouping on city and sum aggregation of amount 
   then selecting city, None and sum-amount
S3. Then union of above two and sorting city and year (both desc) 

Result is equivalen to ROllup 
R1:   rollup on sales with cols city and year 
      then sum aggegation of amount (and optional get grouping_id) 
      then sorting like S3 (and optionally filtering grouping id != 3) 
      then selecting city, year and sum-amount 
      

#grouping(*cols)  is an aggregate function that indicates whether a specified column is aggregated or not and:
#    returns  1  if the column is in a subtotal and is  NULL 
#    returns  0  if the underlying value is  NULL  or any other value
#grouping_id(*cols)  is an aggregate function that computes the level of grouping:
#    Returns 
#        0  for combinations of each column
#        1  for subtotals of column 1
#        2  for subtotals of column 2
#        And so on�

R2: Implement above using SQL (group by and grouping sets on city, year  
sales.createOrReplaceTempView("sales")


R3: If you remove optional steps of R1 , what do you get?
    Hint- you get grand total as well as subtotals for each city 

R4: Can you implement R3 by using only groupBy and join 



##HandsON - Another hands on 
1. Create quarterlyScores  DF ( "period", "student", "score") of below 
[
  ("winter2014", "Agata", 99),
  ("winter2014", "Jacek", 97),
  ("summer2015", "Agata", 100),
  ("summer2015", "Jacek", 63),
  ("winter2015", "Agata", 97),
  ("winter2015", "Jacek", 55),
  ("summer2016", "Agata", 98),
  ("summer2016", "Jacek", 97)]


2. Find all total score for each period and student 
   as well for each period only and each student only 
   as well as total score 


##HandsON - Another handsOn 

1. Create expenses DF ("date", "amount") of below 
[
  (datetime.date(2012, 12, 12), 5),
  (datetime.date(2016, 8, 13), 10),
  (datetime.date(2017, 5, 27), 15)]
  
  
2. Get total amount for each year and month as well 
   as for each year only and each month only 
   and also sort above on year and month ascending 










##Window 
df = spark.createDataFrame([("2016-03-11 09:00:07", 1)]).toDF("date", "val")






##HandsOn - window 
1. create levels DF "time", "level" of below 
[
  # (year, month, dayOfMonth, hour, minute, second)
  ((2012, 12, 12, 12, 12, 12), 5),
  ((2012, 12, 12, 12, 12, 14), 9),
  ((2012, 12, 12, 13, 13, 14), 4),
  ((2016, 8,  13, 0, 0, 0), 10),
  ((2017, 5,  27, 0, 0, 0), 15)]
  
2. Select level and 5 seconds tumbling window on time 
3. check schema 
4. calculate the sum of levels every 5 seconds







###Records Window 
Salary = Row('depName', 'empNo', 'salary')
empsalary = sc.parallelize([
  Salary("sales", 1, 5000),
  Salary("personnel", 2, 3900),
  Salary("sales", 3, 4800),
  Salary("sales", 4, 4800),
  Salary("personnel", 5, 3500),
  Salary("develop", 7, 4200),
  Salary("develop", 8, 6000),
  Salary("develop", 9, 4500),
  Salary("develop", 10, 5200),
  Salary("develop", 11, 5200)]).toDF()
  
  
  
pairs = [(x, 10 * x * y) for x in range(1,6) for y in range(1,3)]
ds = sc.parallelize(pairs).toDF(["ns", "tens"])
  
  
###HandsOn - RecordWindow 

1. create a tokens DF "id","token" of below 
[(0,'hello'),(1,'henry'),(2,'and'),(3,'harry')]

2.  partition records into two groups
    a.tokens starting with "h"
    b.others
3. get the count of ids in each group of above partition 
   and order by id 

tokens = sc.parallelize([(0,'hello'),(1,'henry'),(2,'and'),(3,'harry')]).toDF(["id","token"])

byHTokens = Window.partitionBy(col('token').startswith("h"))  #'




##Another HandsOn  -Top N per Group
#Top N per Group is useful when you need to compute the first and second best-sellers in category.

1. create dataset DF "product", "category", "revenue" of below 

[
  ("Thin",       "cell phone", 6000),
  ("Normal",     "tablet",     1500),
  ("Mini",       "tablet",     5500),
  ("Ultra thin", "cell phone", 5000),
  ("Very thin",  "cell phone", 6000),
  ("Big",        "tablet",     2500),
  ("Bendable",   "cell phone", 3000),
  ("Foldable",   "cell phone", 3000),
  ("Pro",        "tablet",     4500),
  ("Pro2",       "tablet",     6500)]
  
2. display dataset where tablet category 

3.What are the best-selling and the second best-selling products in every category
  Hint - use dense_rank (or use rank , understand the difference)
  Hint - use both partition by and orderby with relevant columns 


4. Find Revenue Difference with max revenue of that category per Category






##HandsOn - Running Total
#The running total is the sum of all previous lines including the current one.
1. create a sales DF , "id", "orderID", "prodID", "orderQty" of below 
[
  (0, 0, 0, 5),
  (1, 0, 1, 3),
  (2, 0, 2, 1),
  (3, 1, 0, 2),
  (4, 2, 0, 8),
  (5, 2, 2, 8)]

2. find running total of orderQty over ordered ID 

3. Find running total of orderQty over ordered Id for each orderID








###HandsOn - avro - 
1.append a new value to array col of earlier read DF 
2. Select Name is Ben 
   and If "favorite_numbers" is empty update with [1,2,3]




   
 
###HandsOn - sql table 
1.Dump Iris.csv into sql table 
2. then read from sql table 
   and find max, min of one column for each Name 

   



###Write to MongoDB
people = spark.createDataFrame([("Bilbo Baggins",  50), ("Gandalf", 1000), ("Thorin", 195), ("Balin", 178), ("Kili", 77),
   ("Dwalin", 169), ("Oin", 167), ("Gloin", 158), ("Fili", 82), ("Bombur", None)], ["name", "age"])

   
   
###Output mode and Trigger 
query = spark.  \
  readStream.\
  format("rate").  \
  option("rowsPerSecond", 1).\
  load().\
  writeStream.\
  format("console").\
  outputMode('complete').\
  option("truncate", False).\
  trigger(processingTime="10 second"). \
  queryName("rate-once").\
  start()
  
   
   
###HandsOn - Drop Duplicates - check dropDuplicates reference at first  

1. Start a streaming query from rate with 1 rowsPerSecond
2. Create a DF , ids, out of above with 'id' column which is value col's mod 5 
3. Drop based on id column 
4. then start a 'memory' sink (queryName dups) of above  with processingTime="30 seconds"  with append output mode 
5. Read 'dups' table couple of times 
6. Stop the query 
Use with complete output mode - Note this requires aggregation 
7. Check first  timestamp of id recieved in ids , Hint: groupby and first(col)
8. Restart 'memory' sink (queryName dups) of above with processingTime="30 seconds"  with 'complete' output mode 
9. Read 'dups' table couple of times




###HandsOn - GroupByKey 

#GroupByKey means group by based on some Key 
1. create a rate source with 1 rowsPerSecond
   Create a DF out of above with 
    column device_value  - value mod 10 
    column deviceId - rnadom value between 0 to 10 
    
3. printschema 

4. Write a groupby where key function groups data into two group based on deviceId > 5 or not 
    Hint - write UDF which takes all columns and return accordingly 
   based on above groupBy , get all values 
    
5. Dumps to console with complete mode 






    
##Break files 
def breakFiles(file, n, ext_length = 3):
    import os.path
    def write(fileName, lst):
        with open(fileName, "wt") as f:
            f.writelines(lst) 
        #print(fileName, "written", len(lst))
    def sliding(lst, w, s):
        res = [] 
        n = ((len(lst)-w)/s)+1
        for i in range(0, int(n)):
            start = i*s 
            end = w + s*i 
            res.append(lst[start:end])
        #last segment 
        if  lst[end:]:
                res.append(lst[end:])
        return res     
    def grouped(lst, n):
        return sliding(lst, n, n)        
    onlyFileName, ext = file[0: len(file)-ext_length-1], file[len(file)-ext_length:]
    with open(file, "rt") as f:
        lines = f.readlines()
    howmany = len(lines) // n 
    gr = grouped(lines, howmany)
    if len(gr) > n : #extra last part      
        gr[-2] += gr[-1]
        del gr[-1]         
    #now len(gr) == n 
    names = [ onlyFileName+str(i)+"."+ext     for i in range(1,len(gr)+1)]
    #print(names, n, len(gr))
    for lst, n in zip(gr, names):
        write(n,lst)

        
        
        
        
        
        
        
        
        
        
        
        
        
        
###HANDSON -kafka   groupBy Streaming Aggregation with Append Output Mode
##Append output mode requires that a streaming aggregation defines a watermark 
#(using withWatermark operator) on at least one of the grouping expressions 
#(directly or using window function).

#withWatermark operator has to be used before the aggregation operator (for the watermark to be used).


#Sorting is only supported on streaming aggregated Datasets with Complete output mode.


#Step1 
#create a file events.txt - seconds,id, batch 
1,1,1
15,2,1

#do 
$ cat events.txt  | kafka-console-producer.bat --broker-list localhost:9092 --topic topic1


#Start 
$ pyspark --packages org.apache.spark:spark-sql-kafka-0-10_2.11:2.3.0

1. Create idsPerbatch DF containing cols 
        event_time  <- timestamp based on seconds from input  
        id  <- id from input (string)
        batch <- batch from input (int) 
   Then Apply watermark on event_time and 10 seconds 
   and grouping on event_time
   Then collect all batch and id and event-time 
2. Dump this to console with append mode and processing time 5 seco
