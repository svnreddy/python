#Set anaconda in path 
#spark-submit --master local[4] correlations_example.py 
from __future__ import print_function

import numpy as np

from pyspark import SparkContext

from pyspark.mllib.stat import Statistics


if __name__ == "__main__":
    sc = SparkContext(appName="CorrelationsExample")  # SparkContext


    seriesX = sc.parallelize([1.0, 2.0, 3.0, 3.0, 5.0])  # a series
    # seriesY must have the same number of partitions and cardinality as seriesX
    seriesY = sc.parallelize([11.0, 22.0, 33.0, 33.0, 555.0])

    # Compute the correlation using Pearson's method. Enter "spearman" for Spearman's method.
    # If a method is not specified, Pearson's method will be used by default.
    print("Correlation is: " + str(Statistics.corr(seriesX, seriesY, method="pearson")))

    data = sc.parallelize(
        [np.array([1.0, 10.0, 100.0]), np.array([2.0, 20.0, 200.0]), np.array([5.0, 33.0, 366.0])]
    )  # an RDD of Vectors

    # calculate the correlation matrix using Pearson's method. Use "spearman" for Spearman's method.
    # If a method is not specified, Pearson's method will be used by default.
    
    #each column vs other column corelation 
    print(Statistics.corr(data, method="pearson"))
    
    """
          col1                col2                col3  
    col1  1.0                 0.978883465889473   0.9903895695275671
    col2  0.978883465889473   1.0                 0.9977483233986101
    col3  0.9903895695275671  0.9977483233986101  1.0


    """


    sc.stop()
