from __future__ import print_function

from pyspark import SparkConf, SparkContext

if __name__ == "__main__":
    inputFile = "hdfs://localhost:19000/user/das/README"
      
    conf = SparkConf().setAppName("wordCount")
    #Create a Scala Spark Context.
    sc = SparkContext(conf=conf)
    #Load our input data.
    input =  sc.textFile(inputFile)
    #Split up into words.
    words = input.flatMap(lambda line : line.split(" "))
    #Transform into word and count.
    counts = words.map(lambda word : (word, 1)).reduceByKey(lambda v1, v2 : v1 + v2) #same key, func for values 
      
    #print, returns list
    output = counts.collect()
    for word, count in output:
        print("%s, %i" % (word, count)) 


