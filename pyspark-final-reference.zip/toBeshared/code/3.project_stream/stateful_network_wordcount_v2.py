#nc -lk 9998 
#spark-submit --conf spark.ui.showConsoleProgress=false --master local[4] stateful_network_wordcount_v2.py 192.168.1.2 9998
#for stopping stage info, use: --conf spark.ui.showConsoleProgress=false
#Note nc to spark data movement and RDD processing takes some time, increase batchDuration

"""
 Counts words in UTF8 encoded, '\n' delimited text received from the
 network every second.

 Usage: stateful_network_wordcount.py <hostname> <port>
   <hostname> and <port> describe the TCP server that Spark Streaming
    would connect to receive data.

 
"""
from __future__ import print_function

import sys

from pyspark import SparkContext
from pyspark.streaming import StreamingContext

def createContext(host, port):    
    print("Creating for first time...")
    sc = SparkContext(appName="PythonStreamingStatefulNetworkWordCount")
    ssc = StreamingContext(sc, 20)  #batch size make it big
    
    # RDD with initial state (key, value) pairs
    initialStateRDD = sc.parallelize([(u'hello', 1), (u'world', 1)])

    def updateFunc(new_values, last_sum):  #last_sum for non existing key is None
        print(new_values, last_sum)
        return sum(new_values) + (last_sum or 0)

    lines = ssc.socketTextStream(host, port)
    running_counts = lines.flatMap(lambda line: line.split(" "))\
                          .map(lambda word: (word, 1))\
                          .updateStateByKey(updateFunc, initialRDD=initialStateRDD)

    running_counts.pprint()
    return ssc


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: stateful_network_wordcount.py <hostname> <port>", file=sys.stderr)
        exit(-1)
    host, port = sys.argv[1:]
    checkpoint = "./checkpoint_v2"
    ssc = StreamingContext.getOrCreate(checkpoint,  lambda: createContext(host, int(port)))
    ssc.start()
    ssc.awaitTermination()