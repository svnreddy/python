Day-1
    � Python function refreshers 
        Functional Programming 
        lambda and function as object 
        json and xml processing 
    � Advanced data structure 
        Array in numpy 
        DF in pandas 
        csv and excel reading 
    � Introduction to Big Data environment
        Hadoop and HDFS 
        MapReduce vs Impala vs Hive 
        Cloud environment storage - S3 and Wasb 
    � Spark cluster computing Evironment 
        � Various components 
        � Various cluster configuration 
        � Web UI
        � Identfying Performance bottleneck 
        � Optimizing stage boundary 
        � spark-submit and spark configurations
        � Calculating resources required for spark job 
-------------------------------------------------------------------

###*** Module Json 
#JSON (JavaScript Object Notation) specified by RFC 7159 

# to and from file 
json.dump(obj, fp, skipkeys=False, ensure_ascii=True, check_circular=True, 
   allow_nan=True, cls=None, indent=None, separators=None, default=None, sort_keys=False, **kw)
#fp is opened as fp = open(filename, "w")
#indent is string which is used for indentation

json.load(fp, cls=None, object_hook=None, parse_float=None, parse_int=None, 
    parse_constant=None, object_pairs_hook=None, **kw)
#fp is opened as fp = open(filename, "r")
#parse_type, if specified, will be called with the string of every JSON 'type' to be decoded


#To and from string  
json.dumps(obj, skipkeys=False, ensure_ascii=True, check_circular=True, 
    allow_nan=True, cls=None, indent=None, separators=None, default=None, sort_keys=False, **kw)

json.loads(s, encoding=None, cls=None, object_hook=None, parse_float=None, 
    parse_int=None, parse_constant=None, object_pairs_hook=None, **kw)
    
#Jason syntax 
JSON data is written as - "name":value pairs, eg -  "firstName":"John"
name is in double quote
JSON values can be:
    A number (integer or floating point)
    A string (in double quotes)
    A Boolean (true or false)
    An array (in square brackets with , as separator )
    An object (in curly braces with "name":value)
    null


#The file type for JSON files is ".json"
#The MIME type for JSON text is "application/json"
#No comment is allowed  even with /* */, // or #
#Only one root element or object is allowed, no multiple root elements 

#conversion table
#Python			JSON
dict 			object 
list, tuple 	array 
str 			string 
int, float,     int,float
True 			true 
False 			false 
None 			null 

#Note, separators=(',', ': ') as default if indent is not None.
#The json module always produces str objects, not bytes objects
#Keys in key/value pairs of JSON are always of the type str. 
#When a dictionary is converted into JSON, all the keys of the dictionary are coerced to strings
#That is, loads(dumps(x)) != x if x has non-string keys.
 

#Example file: example.json  
[
 { "empId: 1, "details": 
                        {                       
                          "firstName": "John",
                          "lastName": "Smith",
                          "isAlive": true,
                          "age": 25,
                          "salary": 123.5,
                          "address": {
                            "streetAddress": "21 2nd Street",
                            "city": "New York",
                            "state": "NY",
                            "postalCode": "10021-3100"
                          },
                          "phoneNumbers": [
                            {
                              "type": "home",
                              "number": "212 555-1234"
                            },
                            {
                              "type": "office",
                              "number": "646 555-4567"
                            },
                            {
                              "type": "mobile",
                              "number": "123 456-7890"
                            }
                          ],
                          "children": [],
                          "spouse": null
                        }
  } , { "empId: 20, "details": 
                            {                       
                              "firstName": "Johns",
                              "lastName": "Smith",
                              "isAlive": true,
                              "age": 25,
                              "salary": 123.5,
                              "address": {
                                "streetAddress": "21 2nd Street",
                                "city": "New York",
                                "state": "NY",
                                "postalCode": "10021-3100"
                              },
                              "phoneNumbers": [
                                {
                                  "type": "home",
                                  "number": "212 555-1234"
                                },
                                {
                                  "type": "office",
                                  "number": "646 555-4567"
                                },
                                {
                                  "type": "mobile",
                                  "number": "123 456-7890"
                                }
                              ],
                              "children": [],
                              "spouse": null
                            }
    }
]

#Example reading file 
import json 
import pprint 
fp = open("data/example.json", "r")
obj = json.load(fp)
fp.close()
pprint.pprint(obj)  #check size 
[{'details': {'address': {'city': 'New York',
                          'postalCode': '10021-3100',
                          'state': 'NY',
                          'streetAddress': '21 2nd Street'},
              'age': 25,
              'children': [],
              'firstName': 'John',
              'isAlive': True,
              'lastName': 'Smith',
              'phoneNumbers': [{'number': '212 555-1234', 'type': 'home'},
                               {'number': '646 555-4567', 'type': 'office'},
                               {'number': '123 456-7890', 'type': 'mobile'}],
              'salary': 123.5,
              'spouse': None},
  'empId': 1},
 {'details': {'address': {'city': 'New York',
                          'postalCode': '10021-3100',
                          'state': 'NY',
                          'streetAddress': '21 2nd Street'},
              'age': 25,
              'children': [],
              'firstName': 'Johns',
              'isAlive': True,
              'lastName': 'Smith',
              'phoneNumbers': [{'number': '212 555-1234', 'type': 'home'},
                               {'number': '646 555-4567', 'type': 'office'},
                               {'number': '123 456-7890', 'type': 'mobile'}],
              'salary': 123.5,
              'spouse': None},
  'empId': 20}]

#manipulations 
len(obj)        #2
type(obj)       #<class 'list'>
type(obj[0])    #<class 'dict'>
with open("data/example1.json", "w") as fp1:
    json.dump(obj, fp1, indent='\t')
  
#Obj is array , all array manipulations can be used 
[emp['details']['address']['state']   for emp in obj if emp['empId'] > 10] 



###*** xml.etree.ElementTree � The ElementTree XML API (same in Py3.x and Py2.7)
#std module 
 
#Example: country_data.xml file 
  
<?xml version="1.0"?>
<data>
    <country name="Liechtenstein">
        <rank>1</rank>
        <year>2008</year>
        <gdppc>141100</gdppc>
        <neighbor name="Austria" direction="E"/>
        <neighbor name="Switzerland" direction="W"/>
    </country>
    <country name="Singapore">
        <rank>4</rank>
        <year>2011</year>
        <gdppc>59900</gdppc>
        <neighbor name="Malaysia" direction="N"/>
    </country>
    <country name="Panama">
        <rank>68</rank>
        <year>2011</year>
        <gdppc>13600</gdppc>
        <neighbor name="Costa Rica" direction="W"/>
        <neighbor name="Colombia" direction="E"/>
    </country>
</data>


#code 
import xml.etree as etree


import xml.etree.ElementTree as ET
tree = ET.parse('example.xml')
root = tree.getroot()

print(ET.tostring(root))  #give element 

#Or directly from a string:
root = ET.fromstring(country_data_as_string)

#Every element has a tag and a dictionary of attributes

>>> root.tag
'data'
>>> root.attrib
{}


#It also has children nodes over which we can iterate

for child in root:
    print(child.tag, child.attrib)
...
country {'name': 'Liechtenstein'}
country {'name': 'Singapore'}
country {'name': 'Panama'}


#Children are nested, 
#access specific child nodes by index:

>>> root[0][1].text

#Finding interesting elements

#use Element.iter()
#any tag can be given, then it would return list of those 
for neighbor in root.iter('neighbor'):
		print(neighbor.attrib)

#Use Element.findall() finds only elements with a tag which are direct children of the current element. 
#Element.find() finds the first child with a particular tag, 
#Element.text accesses the element�s text content. 
#Element.get() accesses the element�s attributes


for country in root.findall('country'):
		rank = country.find('rank').text
		name = country.get('name')
		print(name, rank)

##XPath support - limited support via findall() and find()
#findall always return list of ELement 
#find always return single Element 

import xml.etree.ElementTree as ET

# Top-level elements
root.findall(".")

# All 'neighbor' grand-children of 'country' children of the top-level
# elements
root.findall("./country/neighbor")

# Nodes with name='Singapore' that have a 'year' child
root.findall(".//year/..[@name='Singapore']")
ET.tostring(x[0])

# 'year' nodes that are children of nodes with name='Singapore'
root.findall(".//*[@name='Singapore']/year")

# All 'neighbor' nodes that are the second child of their parent
root.findall(".//neighbor[2]")

#Modifying an XML File
#to update attribute,  use Element.set()
#to update text, just assign to text 

for rank in root.iter('rank'):
		new_rank = int(rank.text) + 1
		rank.text = str(new_rank)
		rank.set('updated', 'yes')

tree.write('output.xml')


#remove elements using Element.remove(). 

>>> for country in root.findall('country'):
		rank = int(country.find('rank').text)
		if rank > 50:
			root.remove(country)

>>> tree.write('output.xml')

#Building XML documents

>>> a = ET.Element('a')
>>> b = ET.SubElement(a, 'b')
>>> c = ET.SubElement(a, 'c')
>>> d = ET.SubElement(c, 'd')
>>> ET.dump(a)
<a><b /><c><d /></c></a>

##To add new element, use Element.append()
def SubElementWithText(parent, tag, text):
    attrib = {}
    element = parent.makeelement(tag, attrib)
    parent.append(element)
    element.text = text
    return element

#Usage 
import xml.etree.ElementTree as ET

tree = ET.parse('test.xml')
root = tree.getroot()

a = root.find('a')
b = ET.SubElement(a, 'b')
c = SubElementWithText(b, 'c', 'text3')
print(ET.tostring(root))

#Parsing XML with Namespaces
#If the XML input has namespaces, 
#tags and attributes with prefixes in the form prefix:sometag 
#get expanded to {uri}sometag where the prefix is replaced by the full URI.
#Also, if there is a default namespace, that full URI gets prepended to all of the non-prefixed tags

<?xml version="1.0"?>
<actors xmlns:fictional="http://characters.example.com"
        xmlns="http://people.example.com">
    <actor>
        <name>John Cleese</name>
        <fictional:character>Lancelot</fictional:character>
        <fictional:character>Archie Leach</fictional:character>
    </actor>
    <actor>
        <name>Eric Idle</name>
        <fictional:character>Sir Robin</fictional:character>
        <fictional:character>Gunther</fictional:character>
        <fictional:character>Commander Clement</fictional:character>
    </actor>
</actors>


#Option-1 

root = fromstring(xml_text)
for actor in root.findall('{http://people.example.com}actor'):
    name = actor.find('{http://people.example.com}name')
    print(name.text)
    for char in actor.findall('{http://characters.example.com}character'):
        print(' |-->', char.text)


#Option-2

ns = {'real_person': 'http://people.example.com',
      'role': 'http://characters.example.com'}

for actor in root.findall('real_person:actor', ns):
    name = actor.find('real_person:name', ns)
    print(name.text)
    for char in actor.findall('role:character', ns):
        print(' |-->', char.text)


		


###HTML Handling 
#Below methods has method is either "xml", "html" or "text" (default is "xml"). 
xml.etree.ElementTree.tostring(element, encoding="us-ascii", method="xml")
xml.etree.ElementTree.tostringlist(element, encoding="us-ascii", method="xml")
class xml.etree.ElementTree.ElementTree(element=None, file=None)
    write(file, encoding="us-ascii", xml_declaration=None, default_namespace=None, method="xml")


#html file 
<html>
    <head>
        <title>Example page</title>
    </head>
    <body>
        <p>Moved to <a href="http://example.org/">example.org</a>
        or <a href="http://example.com/">example.com</a>.</p>
    </body>
</html>

#example 

from xml.etree.ElementTree import ElementTree
tree = ElementTree()
tree.parse("index.xhtml")
#<Element 'html' at 0xb77e6fac>
p = tree.find("body/p")     # Finds first occurrence of tag p in body
links = list(p.iter("a"))   # Returns list of all links
links
#[<Element 'a' at 0xb77ec2ac>, <Element 'a' at 0xb77ec1cc>]
for i in links:             # Iterates through all found links
    i.attrib["target"] = "blank"

tree.write("output.xhtml")


###*** Apache requests 
$ pip install requests 

##MAIn API 
requests.request(method, url, **kwargs)
    Constructs and sends a Request.
    Parameters:
        method -- method for the new Request object.
        url -- URL for the new Request object.
        params -- (optional) Dictionary or bytes to be sent in the query string for the Request.
        data -- (optional) Dictionary or list of tuples [(key, value)] (will be form-encoded), bytes, or file-like object to send in the body of the Request.
        json -- (optional) json data to send in the body of the Request.
        headers -- (optional) Dictionary of HTTP Headers to send with the Request.
        cookies -- (optional) Dict or CookieJar object to send with the Request.
        files -- (optional) Dictionary of 'name': file-like-objects (or {'name': file-tuple}) for multipart encoding upload. file-tuple can be a 2-tuple ('filename', fileobj), 3-tuple ('filename', fileobj, 'content_type') or a 4-tuple ('filename', fileobj, 'content_type', custom_headers), where 'content-type' is a string defining the content type of the given file and custom_headers a dict-like object containing additional headers to add for the file.
        auth -- (optional) Auth tuple to enable Basic/Digest/Custom HTTP Auth.
        timeout (float or tuple) -- (optional) How many seconds to wait for the server to send data before giving up, as a float, or a (connect timeout, read timeout) tuple.
        allow_redirects (bool) -- (optional) Boolean. Enable/disable GET/OPTIONS/POST/PUT/PATCH/DELETE/HEAD redirection. Defaults to True.
        proxies -- (optional) Dictionary mapping protocol to the URL of the proxy.
        verify -- (optional) Either a boolean, in which case it controls whether we verify the server's TLS certificate, or a string, in which case it must be a path to a CA bundle to use. Defaults to True.
        stream -- (optional) if False, the response content will be immediately downloaded.
        cert -- (optional) if String, path to ssl client cert file (.pem). If Tuple, ('cert', 'key') pair.
    Returns:
        Response object
        >>> dir(requests.Response)
        ['__attrs__', '__bool__', '__class__', '__delattr__', '__dict__', '__dir__', '__doc__', '__enter__', 
        '__eq__', '__exit__', '__format__', '__ge__', '__getattribute__', '__getstate__', '__gt__', '__hash__', 
        '__init__', '__iter__', '__le__', '__lt__', '__module__', '__ne__', '__new__', '__nonzero__', '__reduce__', 
        '__reduce_ex__', '__repr__', '__setattr__', '__setstate__', '__sizeof__', '__str__', '__subclasshook__', 
        '__weakref__', 'apparent_encoding', 'close', 'content', 'is_permanent_redirect', 'is_redirect', 
        'iter_content', 'iter_lines', 'json', 'links', 'next', 'ok', 'raise_for_status', 'text']

#example
import requests
r = requests.get("http://www.yahoo.com")
r.text
r.status_code   # status code
r.headers  		# dict object

#With HTTPs
>>> r = requests.get('https://api.github.com/user', auth=('user', 'pass'), verify=False) #Requests could verify SSL certificates for https requests automatically and it sets verify=True as default.
>>> r.status_code
200
>>> r.headers['content-type']
'application/json; charset=utf8'
>>> r.encoding
'utf-8'
>>> r.text
u'{"type":"User"...'
>>> r.json()
{u'private_gists': 419, u'total_private_repos': 77, ...}


#with proxy 
p1 = 'http://proxy_username:proxy_password@proxy_server.com:port'
p2 = 'https://proxy_username:proxy_password@proxy_server.com:port'
proxy = {'http': p1, 'https':p2}
r = requests.get(site, proxies=proxy, auth=('site_username', 'site_password')) #Site basic authentication 



##RESTful API
r = requests.post(site)
r = requests.put("site/put")
r = requests.delete("site/delete")
r = requests.head("site/get")
r = requests.options("site/get")


##Get - use 'params'
import requests 
payload1 = {'key1': 'value1', 'key2': 'value2'}
r = requests.get("http://httpbin.org/get", params=payload1)
print(r.url)  #http://httpbin.org/get?key2=value2&key1=value1
r.headers
r.text
r.json()  # it's a python dict

#For Request debugging,
>>> r.request.url
'http://httpbin.org/forms/post?delivery=12&topping=onion&custtel=123&comments=ok&custname=das&custemail=ok%40com&size=small'
>>> r.request.headers
{'Content-Length': '0', 'User-Agent': 'Mozilla/5.0', 'Connection': 'keep-alive', 'Accept': '*/*', 'Accept-Encoding': 'gzip, deflate'}
>>> r.request.body


##POST, use 'data'
headers = {'User-Agent': 'Mozilla/5.0'}
payload = {'custname':'das', 'custtel': '123', 'custemail' : 'ok@com', 'size':'small',  'topping':'bacon',  'topping': 'onion',  'delivery':'12', 'comments': 'ok'}
r = requests.post("http://httpbin.org/post", data=payload, headers=headers)
r.text
r.headers
r.json()

r.request.headers
r.request.body #custname=das&custtel=123&custemail=ok@com&size=small&topping=bacon&topping=onion&delivery=12&comments=ok

##Content
r.text
r.content  # as bytes
r.json()  # json content


##Custom Headers and body 
import json
payload = {'some': 'data'}
headers = {'content-type': 'application/json'}
r = requests.post(url, data=json.dumps(payload), headers=headers)

##POST a Multipart-Encoded File
files = {'file': open('report.xls', 'rb')}
r = requests.post(url, files=files)

##Cookies
#get
r.cookies['example_cookie_name']

#or sending
cookies = dict(cookies_are='working')
r = requests.get(url, cookies=cookies)

##Or persisting across session
s = requests.Session()
s.get('http://httpbin.org/cookies/set/sessioncookie/123456789')
r = s.get("http://httpbin.org/cookies")
r.text # contains cookies from first access


##Example:
import requests
headers = {'User-Agent': 'Mozilla/5.0'}
payload = {'username':'niceusername','pass':'123456'}

session = requests.Session()
session.post('https://admin.example.com/login.php',headers=headers,data=payload)
# the session instance holds the cookie. So use it to get/post later.
# e.g. session.get('https://example.com/profile')



###*** Numpy 

# A numpy array(homogeneous)(numpy.ndarray) is created from python list or List of List for higher dimension
#indexed by a tuple of nonnegative integers.

#Stored as colum major way 

#dimensions are called axes. The number of axes(plural of axis) is rank. 
#axis starts from zero , axis=0 means 1st dimension(x) , axis=1 means 2nd dimension(y)...
#OR axis=-1 means last dimension, axis=-2 means 2nd last dimension 

#shape  is a tuple of integers giving the size of the array along each dimension.
#a 1D array can be .reshape(tuple_of_dims) if total elements are same 

#Note many function take 'axis' argument, means the dimension on which function operates
#For 2D , axis=0 means 1st dimension=Row , axis=1 means 2nd dimension=Column
#eg insert, delete etc 

#For certain methods (eg sum, prod etc) axis=0 means, operation along the 1st dimension
#ie 1st dimension  for 2D,  Row varying which is equivalent to ColumnWise 

#Hence Understand meaning of axis per function from reference documents 

#For  example, np.sum(axis=n),  dimension n is collapsed and deleted, 
#For example, if b has shape (5,6,7,8), and c = b.sum(axis=2), 
#then axis 2 (dimension with size 7) is collapsed, and the result has shape (5,6,8). 
#c[x,y,z] is equal to the sum of all elements c[x,y,:,z]



#Example 

import numpy as np

a = np.array([1, 2, 3])  # Create a rank 1 array
print type(a)            # Prints "<type 'numpy.ndarray'>"
print a.shape            # Prints "(3,)"
print a.ndim 			 # 1
print a[0], a[1], a[2]   # Prints "1 2 3"
a[0] = 5                 # Change an element of the array
print a                  # Prints "[5, 2, 3]"

b = np.array([[1,2,3],[4,5,6]])   # Create a rank 2 array
print b.shape                     # Prints "(2, 3)"
print b[0, 0], b[0, 1], b[1, 0]   # Prints "1 2 4"
b[0,]	#or b[0,:]   			  # array([1, 2, 3])  
b[:,0]                            #array([1, 4])



#Note the difference of below, one is vector and another is 1x3
>>> x = np.array([[1,2,3]])        
>>> x.shape                         #rank 2 as two dimension 
(1, 3)

>>> x = np.array([1,2,3])           # rank 1, generally called vector 
>>> x.shape
(3,)

## Array(ndarray) attributes
# Memory layout
ndarray.flags 			Information about the memory layout of the array. 
ndarray.shape 			Tuple of array dimensions. 
ndarray.strides 		Tuple of bytes to step in each dimension when traversing an array. 
ndarray.ndim 			Number of array dimensions. 
ndarray.data 			Python buffer object pointing to the start of the arrays data. 
ndarray.size 			Number of elements in the array. 
ndarray.itemsize 		Length of one array element in bytes. 
ndarray.nbytes 			Total bytes consumed by the elements of the array. 
ndarray.base 			Base object if memory is from some other object. 

#example 
>>> x = np.zeros((3, 5, 2), dtype=np.complex128)
>>> x.size
30
>>> np.prod(x.shape)
30

##Creation of array - these methods take (m,n,...) dimensions 
# similar methods (zeros/ones/full)_like(another_array) which creates based on another_array.shape
import numpy as np

a = np.zeros((2,2))  # Create an array of all zeros 

    
b = np.ones((1,2))   # Create an array of all ones

c = np.full((2,2), 7) # Create a constant array
print c               # Prints "[[ 7.  7.]
                      #          [ 7.  7.]]"

d = np.eye(2)        # Create a 2x2 identity matrix

#random 
e = np.random.random((2,2)) # Create an array filled with random values
print e                     # Might print "[[ 0.91940167  0.08143941]
                            #               [ 0.68744134  0.87236687]]"
#array range 
>>> np.arange(10).reshape(2,5)
array([[0, 1, 2, 3, 4],
       [5, 6, 7, 8, 9]])
       
>>> np.arange(10)[:8].reshape(2,2,2)
array([[[0, 1],
        [2, 3]],

       [[4, 5],
        [6, 7]]])
        
##Array indexing - Slice Indexing (can be mutated)
#index can be single number, or start:stop:step (stop exclusive)
#or :(means all elements of that dimension) or array of indexes
#or boolean array(where True indexes are selected)
import numpy as np

# Create the following rank 2 array with shape (3, 4)
a = np.array([[1,2, 3, 4], 
              [5,6, 7, 8], 
              [9,10,11,12]])

# index 0 to 1 and columns 1 and 2; 
#b is the following array of shape (2, 2):
# [[2 3]
#  [6 7]]
b = a[:2, 1:3]

# A slice of an array is a view into the same data, so modifying it
# will modify the original array.
print a[0, 1]   # Prints "2"
b[0, 0] = 77    # b[0, 0] is the same piece of data as a[0, 1]
print a[0, 1]   # Prints "77"


#Mixing integer indexing with slice indexing.
#yields an array of lower rank than the original array. 

row_r1 = a[1, :]    # Rank 1 view of the second row of a  
row_r2 = a[1:2, :]  # Rank 2 view of the second row of a
print row_r1, row_r1.shape  # Prints "[5 6 7 8] (4,)"
print row_r2, row_r2.shape  # Prints "[[5 6 7 8]] (1, 4)"

# We can make the same distinction when accessing columns of an array:
col_r1 = a[:, 1]
col_r2 = a[:, 1:2]
print col_r1, col_r1.shape  # Prints "[ 2  6 10] (3,)"
print col_r2, col_r2.shape  # Prints "[[ 2]
                            #          [ 6]
                            #          [10]] (3, 1)"

##Array indexing - Integer array indexing to create subarray , use [ [],[] ]

import numpy as np

a = np.array([[1,2], [3, 4], [5, 6]])


# The returned array will have shape (3,) 
print a[ [0, 1, 2], [0, 1, 0] ]  # Prints "[1 4 5]"   #takes element from (first_array_index1, second_array_index1)  and so on..

# Same as 
print np.array([a[0, 0], a[1, 1], a[2, 0]])  # Prints "[1 4 5]"



##Boolean array indexing - a[bool], bool and a are of same dimension 

import numpy as np

a = np.array([[1,2], [3, 4], [5, 6]])

bool_idx = (a > 2)  
            
print bool_idx      # Prints "[[False False]
                    #          [ True  True]
                    #          [ True  True]]"

print a[bool_idx]  # Prints "[3 4 5 6]", 

# We can do all of the above in a single concise statement:
print a[a > 2]     # Prints "[3 4 5 6]"

>>> a[ (a > 2) & (a<5)]    #Use &, | and ~ for boolean operation , ==, !=, > >= etc for comparison
array([3, 4])
>>> a[ (a > 2) | (a<5)]
array([1, 2, 3, 4, 5, 6])
>>> a[ ~(a > 2) ]
array([1, 2])

>>> a[ a == 2]
array([2])
>>> a[ a != 2]
array([1, 3, 4, 5, 6])

##Numpy - Array indexing - using ... (means all remaining dimensions)
>>> from numpy import arange
>>> a = arange(16).reshape(2,2,2,2)

#you have a 4-dimensional matrix of order 2x2x2x2. 
#To select all first elements in the 4th dimension, you can use the ellipsis notation
>>> a[..., 0].flatten()
array([ 0,  2,  4,  6,  8, 10, 12, 14])

#which is equivalent to
>>> a[:,:,:,0].flatten()
array([ 0,  2,  4,  6,  8, 10, 12, 14])


##Array math and all np.methods - operates elementwise on array 
#check by 
dir(np)

#Basic mathematical functions operate elementwise on arrays, 
#and are available both as operator overloads and as functions in the numpy module

import numpy as np

x = np.array([[1,2],[3,4]], dtype=np.float64)
y = np.array([[5,6],[7,8]], dtype=np.float64)

# Elementwise sum; both produce the array
# [[ 6.0  8.0]
#  [10.0 12.0]]
print x + y                 
print np.add(x, y)

# Elementwise
print x - y    #print np.subtract(x, y)
print x * y    #print np.multiply(x, y)
print x / y    #print np.divide(x, y)
print np.sqrt(x)  #other math methods eg np.sin(), np.log() ....

##Use .dot  for inner product of vector or matrix multiplication 
v = np.array([9,10])
w = np.array([11, 12])

# Inner product of vectors; both produce 219
print v.dot(w)
print np.dot(v, w)

# Matrix / vector product; both produce the rank 1 array [29 67]
print x.dot(v)
print np.dot(x, v)

# Matrix / matrix product; both produce the rank 2 array
# [[19 22]
#  [43 50]]
print x.dot(y)
print np.dot(x, y)


##Sum -  for performing computations on arrays 

# For , np.sum(axis=n),  then dimension n is collapsed and deleted, 
#For example, if b has shape (5,6,7,8), and c = b.sum(axis=2), 
#then axis 2 (dimension with size 7) is collapsed, and the result has shape (5,6,8). 
#c[x,y,z] is equal to the sum of all elements c[x,y,:,z].

import numpy as np

x = np.array([[1,2],[3,4]])

print np.sum(x)  # Compute sum of all elements; prints "10"
print np.sum(x, axis=0)  # Compute sum of each column; prints "[4 6]"
print np.sum(x, axis=1)  # Compute sum of each row; prints "[3 7]"


##Transposing  an array 

import numpy as np

x = np.array([[1,2], [3,4]])
print x    # Prints "[[1 2]
           #          [3 4]]"
print x.T  # Prints "[[1 3]
           #          [2 4]]"

# Note that taking the transpose of a rank 1 array does nothing:
v = np.array([1,2,3])
print v    # Prints "[1 2 3]"
print v.T  # Prints "[1 2 3]"

##r_ , c_ , stack etc 
#In general use concatenate for row(vertical) stacking or column(horizontal) stacking
#Many other functions do the same activity, 
#Use .r_[] or .c_[] if you want to use integer slice 

#rowwise append    
>>> np.concatenate( [[1,2],[3,4]])   #[array1,array2,..] , only 1 positional arg 
array([1, 2, 3, 4])

#vertically stacking array - note each is 2D 
>>> np.concatenate(( [[1,2],[3,4]] , [[5,6]]  ), axis=0)
array([[1, 2],
       [3, 4],
       [5, 6]])
#2nd array appended columnwise - note each is 2D 
>>> np.concatenate(( [[1,2],[3,4]] , [[5],[6]]  ), axis=1)
array([[1, 2, 5],
       [3, 4, 6]])

##Otherways 
np.r_  
    By default: create a array(1D) from comma seperated many slices start:stop:step (stop exclusive)
    or comman seperated numbers (along the first axis ie row)
    it has many other functonalities - check Reference 

np.c_ 
    create a array(2D) from comma seperated many 1D arrays or start:stop:step (stop exclusive)
    but  along the second axis(ie column) -> Column stack 


#note used with []   not ()

>>> np.c_[np.array([1,2,3]), np.array([4,5,6])]
array([[1, 4],
       [2, 5],
       [3, 6]])
>>> np.c_[np.array([[1,2,3]]), 0, 0, np.array([[4,5,6]])]
array([[1, 2, 3, 0, 0, 4, 5, 6]])


>>> x = np.r_[-2:3, 0,0, 3:9]
>>> x
array([-2, -1,  0,  1,  2,  0,  0,  3,  4,  5,  6,  7,  8]



##Difference between .r_, .c_ , column_stack, hstack, vstack, stack, concatenate, title, broadcast_to
#columnwise append 
>>> np.c_[1:3,1:3]  
array([[1, 1],
       [2, 2]])
       
#rowwise append 
>>> np.r_[1:3,1:3]
array([1, 2, 1, 2])

#columnwise append 
>>> np.column_stack( [[1,2], [1,2]] ) #[array1,array2,..] , only 1 positional arg 
array([[1, 1],
       [2, 2]])
       
#rowwise append       
>>> np.hstack( [[1,2],[1,2]] ) #[array1,array2,..] , only 1 positional arg 
array([1, 2, 1, 2])

#vertically stacking array*
>>> np.vstack( [[1,2],[1,2]] ) #[array1,array2,..] , only 1 positional arg 
array([[1, 2],
       [1, 2]])
#vertically stacking array*
>>> np.stack( [[1,2],[10,11]] )
array([[ 1,  2],
       [10, 11]])
       
#columnwise append 
>>> np.stack( [[1,2],[10,11]] , axis=1)
array([[ 1, 10],
       [ 2, 11]])    
       

       
#Repeat array to N times       
>>> np.tile([1,2],3)
array([1, 2, 1, 2, 1, 2])
#repeat array to MxN times 
>>> np.tile([1,2],(3,3))
array([[1, 2, 1, 2, 1, 2],
       [1, 2, 1, 2, 1, 2],
       [1, 2, 1, 2, 1, 2]])
#Repeat 
>>> x = np.array([[1,2],[3,4]])
>>> np.repeat(x, 2)  #each element 2 times 
array([1, 1, 2, 2, 3, 3, 4, 4])
>>> np.repeat(x, 3, axis=1) #each column 3 times along axis=1 (column)
array([[1, 1, 1, 2, 2, 2],
       [3, 3, 3, 4, 4, 4]])
>>> np.repeat(x, [1, 2], axis=0) #along row, 1st row once, 2nd  row twice 
array([[1, 2],
       [3, 4],
       [3, 4]])
       
#broadcasting 
>>> np.broadcast_to([1,2],(2,2)) #original shape=(2,) => (2,n)
array([[1, 2],
       [1, 2]])
>>> np.broadcast_to([[1,2]],(5,2)) #original shape=(1,2) => (n,2) 
array([[1, 2],
       [1, 2],
       [1, 2],
       [1, 2],
       [1, 2]])
>>> np.broadcast_to([10],(3,3))#original shape=(1,) => (m,n,k,..) 
array([[10, 10, 10],
       [10, 10, 10],
       [10, 10, 10]])
>>> np.broadcast_to(10,(3,3))#original shape=scaler => (m,n,k,..) 
array([[10, 10, 10],
       [10, 10, 10],
       [10, 10, 10]])       

       
       

##numpy.where(condition[, x, y])
#condition : array_like, bool, When True, yield x, otherwise yield y.
#x, y : array_like, optional
#out : ndarray or tuple of ndarrays
#If both x and y are specified, the output array contains elements of x 
#where condition is True, and elements from y elsewhere.
#If only condition is given, return the tuple of indices where condition is True.
 
>>> x = np.arange(9.).reshape(3, 3)
>>> x
array([[ 0.,  1.,  2.],
       [ 3.,  4.,  5.],
       [ 6.,  7.,  8.]])
>>> np.where( x > 5 )
(array([2, 2, 2]), array([0, 1, 2]))     # indices [2,0], [2,1], [2,2] are true
>>> x[np.where( x > 3.0 )]               # Note: result is 1D.
array([ 4.,  5.,  6.,  7.,  8.])
>>> np.where(x < 5, x, -1)               # Note: broadcasting.
array([[ 0.,  1.,  2.],
       [ 3.,  4., -1.],
       [-1., -1., -1.]])

##Array creation routines - Numerical ranges
arange([start,] stop[, step,][, dtype]) 			
    Return evenly spaced values within a given interval.
linspace(start, stop[, num, endpoint, ...]) 		
    Return evenly spaced numbers over a specified interval.
logspace(start, stop[, num, endpoint, base, ...]) 	
    Return numbers spaced evenly on a log scale.
meshgrid(*xi, **kwargs) 							
    Return coordinate matrices from coordinate vectors.
mgrid 												
    nd_grid instance which returns a dense multi-dimensional 'meshgrid'.
ogrid 												
    nd_grid instance which returns an open multi-dimensional 'meshgrid'.


#numpy.linspace(start, stop, num=50, endpoint=True, retstep=False, dtype=None)
>>> np.linspace(2.0, 3.0, num=5)
array([ 2.  ,  2.25,  2.5 ,  2.75,  3.  ])
#numpy.arange([start, ]stop, [step, ]dtype=None)
>>> np.arange(3.0)
array([ 0.,  1.,  2.])
#numpy.logspace(start, stop, num=50, endpoint=True, base=10.0, dtype=None)
#base ** start is the starting value of the sequence.
>>> np.logspace(2.0, 3.0, num=4)
array([  100.        ,   215.443469  ,   464.15888336,  1000.        ])


#meshgrid- It is used to vectorise functions of two variables, so that you can write
x = np.array([1, 2, 3])
y = np.array([10, 20, 30]) 
XX, YY = np.meshgrid(x, y)  #XX is row stack of x, YY is column stack of y 
XX                          #
=> array([[1, 2, 3],
       [1, 2, 3],
       [1, 2, 3]])
YY
=> array([[10, 10, 10],
       [20, 20, 20],
       [30, 30, 30]])


ZZ = XX + YY    #all the combinations of x and y put into the function
ZZ => array([[11, 12, 13],
             [21, 22, 23],
             [31, 32, 33]])



#mgrid and ogrid are helper classes which use index notation 
#without having to use 'linspace'. 
#Note The order in which the output are generated is reversed.
YY, XX = np.mgrid[10:40:10, 1:4]
XX
array([[1, 2, 3],
       [1, 2, 3],
       [1, 2, 3]])
YY
array([[10, 10, 10],
       [20, 20, 20],
       [30, 30, 30]])
ZZ = XX + YY # These are equivalent to the output of meshgrid

YY, XX = numpy.ogrid[10:40:10, 1:4]
XX  #array([[1, 2, 3]])
YY 
array([[10],
       [20],
       [30]])
ZZ = XX + YY # 





##Numpy - Array manipulation routines - changing arrayshape
copyto(dst, src[, casting, where]) 		
    Copies values from one array to another, broadcasting as necessary.
reshape(a, newshape[, order]) 			
    Gives a new shape to an array without changing its data.
    One shape dimension can be -1. In this case, the value is inferred from the length of the array and remaining dimensions
ravel(a[, order]) 						
    Return a contiguous flattened array.
ndarray.flat 							
    A 1-D iterator over the array.
ndarray.flatten([order]) 				
    Return a copy of the array collapsed into one dimension.

#Example 
>>> a = np.arange(6).reshape((3, 2))
>>> a
array([[0, 1],
       [2, 3],
       [4, 5]])
	   
>>> np.ravel(a)
array([0, 1, 2, 3, 4, 5])

##Conversion/casting of each element of ndarray to a new type 
ndarray.astype(dtype[, order, casting, ...]) 	
    Copy of the array, cast to a specified type. 

#Example 
x = np.array([1, 2, 2.5])
>>> x
array([ 1. ,  2. ,  2.5])

x.astype(int)
array([1, 2, 2])
>>> x.astype(str)
array(['1.0', '2.0', '2.5'],
      dtype='|S32')


##Array manipulation routines - Transpose-like operations
moveaxis(a, source, destination) 		
    Move axes of an array to new positions. 
rollaxis(a, axis[, start]) 				
    Roll the specified axis backwards, until it lies in a given position.
swapaxes(a, axis1, axis2) 				
    Interchange two axes of an array.
ndarray.T 								
    Same as self.transpose(), except that self is returned if self.ndim < 2.
transpose(a[, axes]) 					
    Permute the dimensions of an array.

#Example 
#moveaxis
#source : int or sequence of int
#Original positions of the axes to move. These must be unique.
#destination : int or sequence of int
#Destination positions for each of the original axes. These must also be unique

>>> x = np.zeros((3, 4, 5))
>>> np.moveaxis(x, 0, -1).shape   #move 0th dimension to last dimension 
(4, 5, 3)
>>> np.moveaxis(x, -1, 0).shape
(5, 3, 4)

#All same 
#transpose
#axes : list of ints, optional
#By default, reverse the dimensions, otherwise permute the axes according to the values given

>>> np.transpose(x).shape
(5, 4, 3)
>>> np.swapaxis(x, 0, -1).shape         #swap 0th dimension with last dimension 
(5, 4, 3)
>>> np.moveaxis(x, [0, 1], [-1, -2]).shape
(5, 4, 3)
>>> np.moveaxis(x, [0, 1, 2], [-1, -2, -3]).shape
(5, 4, 3)


##Numpy - numpy.newaxis
#Either ndarray.reshape or numpy.newaxis can be used to add a new dimension to an array. 
#the newaxis is used to increase the dimension of the existing array 
#by one more dimension, when used once. 
�1D array will become 2D array
�2D array will become 3D array
�3D array will become 4D array

##Scenario-1: 
#Example
# 1D array
In [7]: arr = np.arange(4)
In [8]: arr.shape
Out[8]: (4,)

# make it as row vector by inserting an axis along first dimension
In [9]: row_vec = arr[np.newaxis, :]
In [10]: row_vec.shape
Out[10]: (1, 4)

# make it as column vector by inserting an axis along second dimension
In [11]: col_vec = arr[:, np.newaxis]
In [12]: col_vec.shape
Out[12]: (4, 1)


##Scenario-2: 

#to add the following two arrays:
x1 = np.array([1, 2, 3, 4, 5])
x2 = np.array([5, 4, 3])

In [2]: x1_new = x1[:, np.newaxis]
# now, the shape of x1_new is (5, 1)
# array([[1],
#        [2],
#        [3],
#        [4],
#        [5]])

In [3]: x1_new + x2
Out[3]:
array([[ 6,  5,  4],
       [ 7,  6,  5],
       [ 8,  7,  6],
       [ 9,  8,  7],
       [10,  9,  8]])


#Alternatively, you can also add new axis to the array x2:
In [6]: x2_new = x2[:, np.newaxis]
In [7]: x2_new     # shape is (3, 1)
Out[7]: 
array([[5],
       [4],
       [3]])

Now, add:
In [8]: x1 + x2_new
Out[8]: 
array([[ 6,  7,  8,  9, 10],
       [ 5,  6,  7,  8,  9],
       [ 4,  5,  6,  7,  8]])

#Example
In [13]: A = np.ones((3,4,5,6))
In [14]: B = np.ones((4,6))
In [15]: (A + B[:, np.newaxis, :]).shape
Out[15]: (3, 4, 5, 6)

#You can also use None in place of np.newaxis; 
In [13]: np.newaxis is None
Out[13]: True


##Record Array(numpy.recarray) vs Structured array(numpy.ndarray with complex dtype)
#Arrays may have a data-types containing fields
#An example is [(x, int), (y, float)], where each entry in the array is a pair of (int, float). 
#Normally, access is eg  arr['x'] and arr['y']. 
#Record arrays allows access using arr.x and arr.y

#Structured Array 
x = np.array([(1.0, 2), (3.0, 4)], dtype=[('x', float), ('y', int)])
>>> x
array([(1.0, 2), (3.0, 4)],
      dtype=[('x', '<f8'), ('y', '<i4')])

>>> x['x']  #all 'x'
array([ 1.,  3.])

#Convert to  record array:
>>> x = x.view(np.recarray)
>>> x.x  #all 'x'
array([ 1.,  3.])

>>> x.y
array([2, 4])

#Create a new, empty two elements record array
#1st arg  , shape tuple(could be xD)
#=> , how many elements where each element is having dtype structure 
#does not initialize array 

# 1D array of two elements, each element having x,y,z
>>> r = np.recarray((2,), dtype=[('x', int), ('y', float), ('z', int)]) 
>>> r.x   #all x 
array([3, 1])
>>> r
rec.array([(3, 2.1219957915e-314, 3), (1, 2.1219957915e-314, 2)],
          dtype=[('x', '<i4'), ('y', '<f8'), ('z', '<i4')])
>>> r.x = np.array([0,0]) #assign to all x 
>>> r
rec.array([(0, 2.1219957915e-314, 3), (0, 2.1219957915e-314, 2)],
          dtype=[('x', '<i4'), ('y', '<f8'), ('z', '<i4')])
>>> r.y[0] = 500  #first y 
>>> r
rec.array([(0, 500.0, 3), (0, 2.1219957915e-314, 2)],
          dtype=[('x', '<i4'), ('y', '<f8'), ('z', '<i4')])
>>> r.z = [2,2]
>>> r
rec.array([(0, 500.0, 2), (0, 2.1219957915e-314, 2)],
          dtype=[('x', '<i4'), ('y', '<f8'), ('z', '<i4')])
          
>>> r['x']
array([0, 0])



##Sorting
#Note axis=n means operation along nth dimension 
#which means nth dimension varying 
sort(a[, axis, kind, order]) 				Return a sorted copy of an array.
lexsort(keys[, axis]) 						Perform an indirect sort using a sequence of keys.
argsort(a[, axis, kind, order]) 			Returns the indices that would sort an array.
ndarray.sort([axis, kind, order]) 			Sort an array, in-place.
msort(a) 									Return a copy of an arraysorted along the first axis.
sort_complex(a) 							Sort a complex array using the real part first, then the imaginary part.
partition(a, kth[, axis, kind, order]) 		Return a partitioned copy of an array.
argpartition(a, kth[, axis, kind, order]) 	Perform an indirect partition along the given axis using the algorithm specified by the kind keyword.


#Example of sort - immutable 
#numpy.sort(a, axis=-1, kind='quicksort', order=None)	Return a sorted copy of an array.
#-1 means along last axis 
#kind        speed       worst case      work space      stable
'quicksort'     1       O(n^2)          0               no 
'mergesort'     2       O(n*log(n))     ~n/2            yes 
'heapsort'      3       O(n*log(n))     0               no 

>>> a = np.array([[1,4],[3,1]])
>>> np.sort(a)                # sort along the last axis ie row wise 
array([[1, 4],       
[1, 3]])
>>> np.sort(a, axis=None)     # sort the flattened array
array([1, 1, 3, 4])
>>> np.sort(a, axis=0)        # sort along the first axis, cloumnwise 
array([[1, 1],       
[3, 4]])

#Structured array sorting : Use the order keyword to specify a field to use when sorting a structured array:
dtype = [('name', 'S10'), ('height', float), ('age', int)]
values = [('Arthur', 1.8, 41), ('Lancelot', 1.9, 38),     ('Galahad', 1.7, 38)]
a = np.array(values, dtype=dtype)       # create a structured array
>>> a['height']
array([1.8, 1.9, 1.7])
>>> a[['height', 'name']]
array([(1.8, b'Arthur'), (1.9, b'Lancelot'), (1.7, b'Galahad')],
      dtype=[('height', '<f8'), ('name', 'S10')])
np.sort(a, order='height')
array([('Galahad', 1.7, 38), ('Arthur', 1.8, 41),       
('Lancelot', 1.8999999999999999, 38)],      
dtype=[('name', '|S10'), ('height', '<f8'), ('age', '<i4')])

#Sort by age, then height if ages are equal:
>>> np.sort(a, order=['age', 'height'])
array([('Galahad', 1.7, 38), ('Lancelot', 1.8999999999999999, 38),       
('Arthur', 1.8, 41)],      
dtype=[('name', '|S10'), ('height', '<f8'), ('age', '<i4')])

#Sort names: first by first_names, then by surnames.
>>> surnames =    ('Hertz',    'Galilei', 'Hertz')
>>> first_names = ('Heinrich', 'Galileo', 'Gustav')
>>> ind = np.lexsort((first_names, surnames)) #returns index 
>>> ind
array([1, 2, 0])

>>> [surnames[i] + ", " + first_names[i] for i in ind]
['Galilei, Galileo', 'Hertz, Gustav', 'Hertz, Heinrich']


#Sort two columns of numbers:
>>> a = [1,5,1,4,3,4,4] # First column
>>> b = [9,4,0,4,0,2,1] # Second column
>>> ind = np.lexsort((b,a)) # Sort by a, then by b
>>> print(ind)
[2 0 4 6 5 3 1]

>>> [(a[i],b[i]) for i in ind]
[(1, 0), (1, 9), (3, 0), (4, 1), (4, 2), (4, 4), (5, 4)]



##Searching
#Note axis=n means operation along nth dimension 
#which means nth dimension varying 
#When no axis is given, either array is flattened or based on last axis/dimension(ie -1), check ref 

argmax(a[, axis, out]) 				Returns the indices of the maximum values along an axis.
nanargmax(a[, axis]) 				Return the indices of the maximum values in the specified axis ignoring NaNs.
argmin(a[, axis, out]) 				Returns the indices of the minimum values along an axis.
nanargmin(a[, axis]) 				Return the indices of the minimum values in the specified axis ignoring NaNs.
argwhere(a) 						Find the indices of array elements that are non-zero, grouped by element.
nonzero(a) 							Return the indices of the elements that are non-zero.
flatnonzero(a) 						Return indices that are non-zero in the flattened version of a.
where(condition, [x, y]) 			Return elements, either from x or y, depending on condition.
searchsorted(a, v[, side, sorter]) 	Find indices where elements should be inserted to maintain order.
extract(condition, arr) 			Return the elements of an array that satisfy some condition.

#example of argmax - returns indices 
>>> a = np.arange(6).reshape(2,3)
>>> a
array([[0, 1, 2],
       [3, 4, 5]])
>>> np.argmax(a)   #falttens 
5
>>> np.argmax(a, axis=0)  #1st dimension varying ie columnwise 
array([1, 1, 1])
>>> np.argmax(a, axis=1) #2nd dimension varying ie rowwise 
array([2, 2])
#to get actual values 
>>> a.max(axis=0)
array([3, 4, 5])
>>> a.max(axis=1)
array([2, 5])
>>> np.amax(a,axis=0)
array([3, 4, 5])
>>> np.amax(a,axis=1)
array([2, 5])
#between two array 
>>> np.maximum([2, 3, 4], [1, 5, 2])
array([2, 5, 4])





##ndarray IO: Raw binary files
fromfile(file[, dtype, count, sep]) 			
    Construct an array from data in a text or binary file.
ndarray.tofile(fid[, sep, format]) 				
    Write array to a file as text or binary (default ).
load(file[, mmap_mode, allow_pickle, ...]) 		
    Load arrays or pickled objects from .npy, .npz or pickled files.
save(file, arr[, allow_pickle, fix_imports]) 	
    Save an array to a binary file in NumPy .npy forma t.
savez(file, *args, **kwds) 						
    Save several arrays into a single file in uncompressed .npz format.
savez_compressed(file, *args, **kwds) 			
    Save several arrays into a single file in compressed .npz format.
#The format of these binary file types is documented in http://docs.scipy.org/doc/numpy/neps/npy-format.html


#Example 
>>> dt = np.dtype([('time', [('min', int), ('sec', int)]), ('temp', float)])
>>> x = np.zeros((1,), dtype=dt)
>>> x['time']['min'] = 10; x['temp'] = 98.25
>>> x
array([((10, 0), 98.25)],
      dtype=[('time', [('min', '<i4'), ('sec', '<i4')]), ('temp', '<f8')])

#The recommended way to store and load data:
>>> np.save(fname, x)
>>> np.load(fname + '.npy')
array([((10, 0), 98.25)],
      dtype=[('time', [('min', '<i4'), ('sec', '<i4')]), ('temp', '<f8')])
      
#Save the raw data to disk:
import os
fname = os.tmpnam()
x.tofile(fname)

#Read the raw data from disk:
>>> np.fromfile(fname, dtype=dt)
array([((10, 0), 98.25)],
      dtype=[('time', [('min', '<i4'), ('sec', '<i4')]), ('temp', '<f8')])



##Datetimes and Timedeltas - subclass of numpy.ndarray 
#Starting in NumPy 1.7, there are core array data types which natively support datetime functionality. 
#The data type is called 'datetime64'

#A simple ISO date: YYY-MM-DD
>>> np.datetime64('2005-02-25')
numpy.datetime64('2005-02-25')


#Using months for the unit:
>>> np.datetime64('2005-02')
numpy.datetime64('2005-02')


#Specifying just the month, but forcing a 'days unit:
>>> np.datetime64('2005-02', 'D')
numpy.datetime64('2005-02-01')


#From a date and time:
>>> np.datetime64('2005-02-25T03:30')
numpy.datetime64('2005-02-25T03:30')


>>> np.array(['2007-07-13', '2006-01-13', '2010-08-13'], dtype='datetime64')
array(['2007-07-13', '2006-01-13', '2010-08-13'], dtype='datetime64[D]')

>>> np.array(['2001-01-01T12:00', '2002-02-03T13:56:03.172'], dtype='datetime64')
array(['2001-01-01T12:00:00.000-0600', '2002-02-03T13:56:03.172-0600'], dtype='datetime64[ms]')


#Using arange - All the dates for one month:
>>> np.arange('2005-02', '2005-03', dtype='datetime64[D]')
array(['2005-02-01', '2005-02-02', '2005-02-03', '2005-02-04',
       '2005-02-05', '2005-02-06', '2005-02-07', '2005-02-08',
       '2005-02-09', '2005-02-10', '2005-02-11', '2005-02-12',
       '2005-02-13', '2005-02-14', '2005-02-15', '2005-02-16',
       '2005-02-17', '2005-02-18', '2005-02-19', '2005-02-20',
       '2005-02-21', '2005-02-22', '2005-02-23', '2005-02-24',
       '2005-02-25', '2005-02-26', '2005-02-27', '2005-02-28'],
       dtype='datetime64[D]')


#The datetime object represents a single moment in time, 
#if two datetimes have different units,
>>> np.datetime64('2005') == np.datetime64('2005-01-01')
True
>>> np.datetime64('2010-03-14T15Z') == np.datetime64('2010-03-14T15:00:00.00Z')
True


##Datetime and Timedelta Arithmetic
#NumPy allows the subtraction of two Datetime values, 
#an operation which produces a number with a time unit. 

>>> np.datetime64('2009-01-01') - np.datetime64('2008-01-01')
numpy.timedelta64(366,'D')

>>> np.datetime64('2009') + np.timedelta64(20, 'D')
numpy.datetime64('2009-01-21')

>>> np.datetime64('2011-06-15T00:00') + np.timedelta64(12, 'h')
numpy.datetime64('2011-06-15T12:00-0500')

>>> np.timedelta64(1,'W') / np.timedelta64(1,'D')
7.0


#There are two Timedelta units ('Y', years and 'M,' months) 
#which are treated specially,
#While a timedelta day unit is equivalent to 24 hours, there is no way to convert a month unit into days, 
#because different months have different numbers of days
>>> a = np.timedelta64(1, 'Y')

#converts to Month 
>>> np.timedelta64(a, 'M')
numpy.timedelta64(12,'M')
#but can not be converted to Days 
>>> np.timedelta64(a, 'D')
Traceback (most recent call last):  
File "<stdin>", line 1, in <module>
TypeError: Cannot cast NumPy timedelta64 scalar from metadata [Y] to [D] according to the rule 'same_kind'

##date units:
# the time span for 'W' (week) is exactly 7 times longer than the time span for 'D' (day), 
#and the time span for 'D' (day) is exactly 24 times longer than the time span for 'h' (hour).


##conversion is done as belows - use .astype()
>>> x = np.timedelta64(2069211000000000, 'ns')
>>> days = x.astype('timedelta64[D]')
>>> days / np.timedelta64(1, 'D')
23
#from python datetime 
>>> from datetime import datetime
>>> import numpy as np
>>> dt = datetime.utcnow()
>>> dt
datetime.datetime(2012, 12, 4, 19, 51, 25, 362455)
>>> dt64 = np.datetime64(dt)
>>> ts = (dt64 - np.datetime64('1970-01-01T00:00:00Z')) / np.timedelta64(1, 's')
>>> ts
1354650685.3624549
>>> datetime.utcfromtimestamp(ts)
datetime.datetime(2012, 12, 4, 19, 51, 25, 362455)


>>> np.datetime64('2002-06-28T01:00:00.000000000+0100').astype(datetime)
1025222400000000000L


##String operations - Use with prefix numpy.char 
#Most of them mimic python str methods, 
#but operate with array of strings and return array of strings
#after operation done on elementwise , hence returns result array 

>>> dir(np.char)

#Example of strip
>>> c = np.array(['aAaAaA', '  aA  ', 'abBABba'])
>>> c
array(['aAaAaA', '  aA  ', 'abBABba'],    
dtype='|S7')	

>>> np.char.strip(c)
array(['aAaAaA', 'aA', 'abBABba'],    
dtype='|S7')	

>>> np.char.strip(c, 'a') # 'a' unstripped from c[1] because whitespace leads
array(['AaAaA', '  aA  ', 'bBABb'],    
dtype='|S7')	

>>> np.char.strip(c, 'A') # 'A' unstripped from c[1] because (unprinted) ws trails
array(['aAaAa', '  aA  ', 'abBABba'],    
dtype='|S7')

>>> np.char.split(c, "a")
array([list(['', 'A', 'A', 'A']), list(['  ', 'A  ']),
       list(['', 'bBABb', ''])], dtype=object)

#Example of count	
>>> np.char.count(c, 'A')
array([3, 1, 1])
>>> np.char.count(c, 'aA')
array([3, 1, 0])

>>> np.char.count(c, 'A', start=1, end=4)
array([2, 1, 1])
>>> np.char.count(c, 'A', start=1, end=3)
array([1, 0, 0])

##Matrix objects, use with prefix numpy.

#matrix objects inherit from the ndarray and therefore, 
#they have the same attributes and methods of ndarrays. 

#1. Matrix objects can be created using a string notation to allow Matlab-style syntax 
#where spaces separate columns and semicolons (';) separate rows.

#2. Matrix objects are always two-dimensional.

#3. Matrices have special attributes which make calculations easier. These are
matrix.T 
    Returns the transpose of the matrix. 
matrix.H 
    Returns the (complex) conjugate transpose of self. 
matrix.I 
    Returns the (multiplicative) inverse of invertible self. 
matrix.A 
    Return self as an ndarray object. 

 
#4. Matrix objects over-ride multiplication, *, and power, **, 
#to be matrix-multiplication and matrix power
	   
#Creation of matrix    
#The name 'mat' is an alias for 'matrix' in NumPy.
matrix 							Returns a matrix from an array-like object, or from a string of data. 
asmatrix(data[, dtype]) 		Interpret the input as a matrix. 
bmat(obj[, ldict, gdict]) 		Build a matrix object from a string, nested sequence, or array. 

#Example 
#Example 

>>> x = np.array([[1, 2], [3, 4]])
>>> m = np.asmatrix(x)
>>> x[0,0] = 5
>>> m
matrix([[5, 2],
        [3, 4]])

#Example of bmat 
>>> A = np.mat('1 1; 1 1')
>>> B = np.mat('2 2; 2 2')
>>> C = np.mat('3 4; 5 6')
>>> D = np.mat('7 8; 9 0')

#All the following expressions construct the same block matrix:
>> np.bmat([[A, B], [C, D]])
matrix([[1, 1, 2, 2],
        [1, 1, 2, 2],
        [3, 4, 7, 8],
        [5, 6, 9, 0]])
>>> np.bmat(np.r_[np.c_[A, B], np.c_[C, D]])
matrix([[1, 1, 2, 2],
        [1, 1, 2, 2],
        [3, 4, 7, 8],
        [5, 6, 9, 0]])
>>> np.bmat('A,B; C,D')
matrix([[1, 1, 2, 2],
        [1, 1, 2, 2],
        [3, 4, 7, 8],
        [5, 6, 9, 0]])
# Matrix creation from a string
>> a=np.mat('1 2 3; 4 5 3')
>>> print (a*a.T).I
[[ 0.2924 -0.1345]
 [-0.1345  0.0819]]


# Matrix creation from nested sequence
>>> np.mat([[1,5,10],[1.0,3,4j]])
matrix([[  1.+0.j,   5.+0.j,  10.+0.j],
        [  1.+0.j,   3.+0.j,   0.+4.j]])


#Matrix creation from an array
>>> np.mat(random.rand(3,3)).T
matrix([[ 0.7699,  0.7922,  0.3294],
        [ 0.2792,  0.0101,  0.9219],
        [ 0.3398,  0.7571,  0.8197]])

		
##Attributes
A           Return self as an ndarray object. 
A1          Return self as a flattened ndarray. 
H           Returns the (complex) conjugate transpose of self. 
I           Returns the (multiplicative) inverse of invertible self. 
T           Returns the transpose of the matrix. 

base        Base object if memory is from some other object. 
ctypes      An object to simplify the interaction of the array with the ctypes module. 
data        Python buffer object pointing to the start of the array's data. 
dtype       Data-type of the array's elements. 
flags       Information about the memory layout of the array. 

flat        A 1-D iterator over the array. 
imag        The imaginary part of the array. 
itemsize    Length of one array element in bytes. 
nbytes      Total bytes consumed by the elements of the array. 
ndim        Number of array dimensions. 
real        The real part of the array. 
shape       Tuple of array dimensions. 
size        Number of elements in the array. 
strides     Tuple of bytes to step in each dimension when traversing an array. 




###*** Pandas 

    
##Pandas supported IO operation 
#Format Type    Data Description        Reader              Writer
text            CSV                     read_csv            to_csv 
text            JSON                    read_json           to_json 
text            HTML                    read_html           to_html 
text            Local clipboard         read_clipboard      to_clipboard 
binary          MS Excel                read_excel          to_excel 
binary          HDF5 Format             read_hdf            to_hdf 
binary          Feather Format          read_feather        to_feather 
binary          Parquet Format          read_parquet        to_parquet 
binary          Msgpack                 read_msgpack        to_msgpack 
binary          Stata                   read_stata          to_stata 
binary          SAS                     read_sas   
binary          Python Pickle Format    read_pickle         to_pickle 
SQL             SQL                     read_sql            to_sql 
SQL             Google Big Query        read_gbq            to_gbq 

#CSV 
pandas.read_csv(filepath_or_buffer, sep=', ', delimiter=None, header='infer', names=None, index_col=None, usecols=None, squeeze=False, prefix=None, mangle_dupe_cols=True, dtype=None, engine=None, converters=None, true_values=None, false_values=None, skipinitialspace=False, skiprows=None, nrows=None, na_values=None, keep_default_na=True, na_filter=True, verbose=False, skip_blank_lines=True, parse_dates=False, infer_datetime_format=False, keep_date_col=False, date_parser=None, dayfirst=False, iterator=False, chunksize=None, compression='infer', thousands=None, decimal=b'.', lineterminator=None, quotechar='"', quoting=0, escapechar=None, comment=None, encoding=None, dialect=None, tupleize_cols=None, error_bad_lines=True, warn_bad_lines=True, skipfooter=0, skip_footer=0, doublequote=True, delim_whitespace=False, as_recarray=None, compact_ints=None, use_unsigned=None, low_memory=True, buffer_lines=None, memory_map=False, float_precision=None)
df.to_csv(path_or_buf=None, sep=', ', na_rep='', float_format=None, columns=None, header=True, index=True, index_label=None, mode='w', encoding=None, compression=None, quoting=None, quotechar='"', line_terminator='\n', chunksize=None, tupleize_cols=None, date_format=None, doublequote=True, escapechar=None, decimal='.')


#JSON 
pandas.read_json(path_or_buf=None, orient=None, typ='frame', dtype=True, convert_axes=True, convert_dates=True, keep_default_dates=True, numpy=False, precise_float=False, date_unit=None, encoding=None, lines=False, chunksize=None, compression='infer')
df.to_json(path_or_buf=None, orient=None, date_format=None, double_precision=10, force_ascii=True, date_unit='ms', default_handler=None, lines=False, compression=None)

#Clipboard
pandas.read_clipboard(sep='\\s+', **kwargs)
df.to_clipboard(excel=True, sep=None, **kwargs)

#EXCEl: xlrd is required to be installed, 
pandas.read_excel(io, sheet_name=0, header=0, skiprows=None, skip_footer=0, index_col=None, names=None, usecols=None, parse_dates=False, date_parser=None, na_values=None, thousands=None, convert_float=True, converters=None, dtype=None, true_values=None, false_values=None, engine=None, squeeze=False, **kwds)
    df = pd.read_excel("file_name", 'Sheet1') #needs xlrd
    #for example setting correct index from one column, if datetime, use to_datetime
    df.index = pd.to_datetime(df.Date)
df.to_excel(excel_writer, sheet_name='Sheet1', na_rep='', float_format=None, columns=None, header=True, index=True, index_label=None, startrow=0, startcol=0, engine=None, merge_cells=True, encoding=None, inf_rep='inf', verbose=True, freeze_panes=None)

#SQL 
pandas.read_sql(sql, con, index_col=None, coerce_float=True, params=None, parse_dates=None, columns=None, chunksize=None)
    sql : string or SQLAlchemy Selectable (select or text object)
          can be database table name or sql query
    con : SQLAlchemy connectable(engine/connection) or database string URI
        or DBAPI2 connection (fallback mode) 
        Using SQLAlchemy makes it possible to use any DB supported by that library. 
        If a DBAPI2 object, only sqlite3 is supported.
        #Example 
        from sqlalchemy import create_engine
        engine = create_engine('sqlite:///:memory:')
        engine = create_engine('postgresql://scott:tiger@localhost:5432/mydatabase')
        #Engine URL format 
        dialect+driver://username:password@host:port/
        # default
        engine = create_engine('mysql://scott:tiger@localhost/foo')
        # mysql-python
        engine = create_engine('mysql+mysqldb://scott:tiger@localhost/foo')
        # MySQL-connector-python
        engine = create_engine('mysql+mysqlconnector://scott:tiger@localhost/foo')
        # OurSQL
        engine = create_engine('mysql+oursql://scott:tiger@localhost/foo')
        # sqlite://<nohostname>/<path>
        # where <path> is relative:
        engine = create_engine('sqlite:///foo.db')
        #Unix/Mac - 4 initial slashes in total
        engine = create_engine('sqlite:////absolute/path/to/foo.db')
        #Windows
        engine = create_engine('sqlite:///C:\\path\\to\\foo.db')
        #Windows alternative using raw string
        engine = create_engine(r'sqlite:///C:\path\to\foo.db')
        #To use a SQLite :memory: database, specify an empty URL:
        engine = create_engine('sqlite://')
        #quick sqlalchemy 
        connection = engine.connect()
        result = connection.execute("select username from users")
        for row in result:
            print("username:", row['username'])
        result.close()
        connection.close()
 
df.to_sql(name, con, flavor=None, schema=None, if_exists='fail', index=True, index_label=None, chunksize=None, dtype=None)
    Write records stored in a DataFrame to a SQL database.
    name : string
        Name of SQL table
    con : SQLAlchemy engine or DBAPI2 connection (legacy mode)
    if_exists : {'fail', 'replace', 'append'}, default 'fail'
        �fail: If table exists, do nothing.
        �replace: If table exists, drop it, recreate it, and insert data.
        �append: If table exists, insert data. Create if does not exist.

        
#HTML - requires lxml or BeautifulSoup4 or html5lib,
#read_html returns a list of DataFrame objects, 
#even if there is only a single table contained in the HTML content
pandas.read_html(io, match='.+', flavor=None, header=None, index_col=None, skiprows=None, attrs=None, parse_dates=False, tupleize_cols=None, thousands=', ', encoding=None, decimal='.', converters=None, na_values=None, keep_default_na=True)
    df_list = pd.read_html('http://www.fdic.gov/bank/individual/failed/banklist.html')
    io : str or file-like
        A URL, a file-like object, or a raw string containing HTML. 
        Note that lxml only accepts the http, ftp and file url protocols. 
        If you have a URL that starts with 'https' you might try removing the 's'.
    match : str or compiled regular expression, optional
        The set of tables containing text matching this regex or string will be returned.
        Defaults to '.+' (match any non-empty string). 
        The default value will return all tables contained on a page. 
    attrs : dict or None, optional
        This is a dictionary of attributes that you can pass to use to identify the table in the HTML
        For example,
        attrs = {'id': 'table'}
df.to_html(buf=None, columns=None, col_space=None, header=True, index=True, na_rep='NaN', formatters=None, float_format=None, sparsify=None, index_names=True, justify=None, bold_rows=True, classes=None, escape=True, max_rows=None, max_cols=None, show_dimensions=False, notebook=False, decimal='.', border=None)
    classes : str or list or tuple, default None
        CSS class(es) to apply to the resulting html table
    escape : boolean, default True
        Convert the characters <, >, and & to HTML-safe sequences.=
    max_rows : int, optional
        Maximum number of rows to show before truncating. If None, show all.
    max_cols : int, optional
        Maximum number of columns to show before truncating. If None, show all.

##To and from dict 
classmethod DataFrame.from_dict(data, orient='columns', dtype=None)
    Construct DataFrame from dict of array-like 
    Note dict can be passed to directly to pd.DataFrame constructor
    Parameters:
    data : dict
        {columnName : array-like of all values of that column} 
        Specify orient='index' to create the DataFrame using dictionary keys as rows
    orient : {'columns', 'index'}, default 'columns'
        The 'orientation' of the data. 
        If the keys of the passed dict should be the columns of the resulting DataFrame,  pass 'columns' (default). 
        Otherwise if the keys should be rows, pass 'index'.
    dtype : dtype, default None
        Data type to force, otherwise infer
    
df.to_dict(orient='dict', into=<class 'dict'>)
    Convert DataFrame to dictionary.
    Parameters:
    orient : str {'dict', 'list', 'series', 'split', 'records', 'index'}
        Determines the type of the values of the dictionary.
        �dict (default) : dict like {column -> {index -> value}}
        �list : dict like {column -> [values]}
        �series : dict like {column -> Series(values)}
        �split : dict like {index -> [index], columns -> [columns], data -> [values]}
        �records : list like [{column -> value}, ... , {column -> value}]
        �index : dict like {index -> {column -> value}}
        Abbreviations are allowed. s indicates series and sp indicates split.
        
##To and From python list and ndarray 
Series.tolist()
    Return a list of the values.
    These are each a scalar type, which is a Python scalar (for str, int, float) 
    or a pandas scalar (for Timestamp/Timedelta/Interval/Period) 
Series.values, DataFrame.values , DataFrame.as_matrix()
    Convert to ndArray 
    
#Example DF to list 
#Use .values to get a numpy.array and then .tolist() to get a list.
import pandas as pd
df = pd.DataFrame({'a':[1,3,5,7,4,5,6,4,7,8,9],
                   'b':[3,5,6,2,4,6,7,8,7,8,9]})

>>> df['a'].values.tolist()
[1, 3, 5, 7, 4, 5, 6, 4, 7, 8, 9]

>>> df.as_matrix()
array([[1, 3],
       [3, 5],
       [5, 6],
       [7, 2],
       [4, 4],
       [5, 6],
       [6, 7],
       [4, 8],
       [7, 7],
       [8, 8],
       [9, 9]], dtype=int64)
    

          
          
##DF Creation  
#DF is composed of list of Series with one column is designated by Index 
#Dataframe can be created from 
#Along with the below data, pass 'index' (row labels) and 'columns' (column labels) arguments
#By default row, column labels are integer, 0 to n ,For time series, index is datetime based 
    1.Dict , where key is column name and value is column data  of 1D ndarrays, lists, Series
     OR list of dicts, where each element of list is one row, and dict's key is column name, value is cell value 
    2.2D numpy.ndarray
    3.Structured or record ndarray
    4.A Series
    5.Another DataFrame
    5.Any pandas IO read_* methods 
#For conversion use, pd.to_numeric(arg), pd.to_datetime(arg, ,format='%Y %m %d'), pd.to_timedelta(arg, unit='ns')
#where arg could be single or list or Series of values 
#For generating daterange, use pd.date_range(start, end, periods, freq)

#Freq 
#check http://pandas.pydata.org/pandas-docs/stable/timeseries.html#offset-aliases for offset aliases, 
#note for multiple, you can give '5H' ie every 5th hour 
#check https://github.com/pandas-dev/pandas/blob/master/doc/source/timeseries.rst#id11        
#eg '2Q'  denotes two quarterly, '30min' means 30 min

#Weekly can take day to denote which day of week eg 'W-MON' means Monday of week

#Q can take Month eg 'Q-Feb' means every 2nd month of Q

#B,D,H,Min,S,MS,U,N can be combined eg '30min20s' means 30 min 20 second
#eg '2H20min30s' , '2D12H20Min30s'

#Alias      Description
B           business day frequency 
C           custom business day frequency 
D           calendar day frequency 
W           weekly frequency 
M           month end frequency 
SM          semi-month end frequency (15th and end of month) 
BM          business month end frequency 
CBM         custom business month end frequency 
MS          month start frequency 
SMS         semi-month start frequency (1st and 15th) 
BMS         business month start frequency 
CBMS        custom business month start frequency 
Q           quarter end frequency 
BQ          business quarter end frequency 
QS          quarter start frequency 
BQS         business quarter start frequency 
A, Y        year end frequency 
BA, BY      business year end frequency 
AS, YS      year start frequency 
BAS, BYS    business year start frequency 
BH          business hour frequency 
H           hourly frequency 
T, min      minutely frequency 
S           secondly frequency 
L,ms        milliseconds 
U, us       microseconds 
N           nanoseconds 


##DataFrame Accessing 
df[column]
    column can be 
        Single column label eg ['City']
        Array of column lables eg ['City', 'City']
        A boolean eg df[df.City == 'Chicago']
        A callable, fn(df):returns_any_from_above eg. df[lambda d: d.City == 'Chicago']
    Can be used for update dfi['C'] = dfi['A']
df.column_name
    when column_name is string
    Only for accessing or update 
    Not for creation of new column, use df['column_name'] style 
    For index column, access always like df.index 
df[row_slice]
    row_slice can be 
        start:stop:step, stop exclusive 
        where start,stop are row index 
    there is no way to get row based on index label
    But for DatetimeIndex, it's possible to access based on datetime index 
df.loc[row,column] 
    label based(both row and column)
    row,column takes 
        A single label, e.g. 5 or 'a', 
        A list or array of labels ['a', 'b', 'c']
        A slice object with labels 'a':'f' (end inclusive)
        A boolean array eg df.A > 0 
        :  means all 
        A Callable fn(df):returns_any_from_above eg. lambda d: d.A > 0 
        For DatetimeIndex, row can be as given in above example 
    Can be used for update eg dfi.loc[:,'C'] = dfi.loc[:,'A']
df.loc[row]
    equivalent to df.loc[row,:]
df.iloc[row,column] 
    index based(both row, column)
    row,column takes 
        An integer e.g. 5
        A list or array of integers [4, 3, 0]
        A slice object with ints 1:7:1 , end exclusive 
        A boolean array *** NOT IMPLEMENTED *** 
        :  means all 
        A Callable fn(df):returns_any_from_above eg. lambda d: d.A > 0 
    Can be used for update eg dfi.loc[:,'C'] = dfi.loc[:,'A']    
df.iloc[row]
    equivalent to df.iloc[row,:]
df.ix[row,column] 
    For each of row,column ,at first tries label based like df.loc[] 
    if Fails, then tries index based like df.iloc[]
    If the index or column does not have label,then behaves like df.iloc[] always 
    For DatetimeIndex, row can be as given in above example 
df.ix[row]
    equivalent to df.ix[row,:]
    For DatetimeIndex, row can be as given in above example
df.iat[row_index,column_index], df.at[row_label, column_label] 
    for accessing a cell 

    
#Example 
import numpy as np
import pandas as pd

df1 = pd.DataFrame(np.random.randn(6,4),index=list('abcdef'),columns=list('ABCD'))

#datetime based freq= 'M', 'D'(default), 'Y','YS','Q','W','H','T'(min),'S'(sec),'ms','us', or n muliples eg "nH" or combination "xD yH zT"
#start is generally "yyymmdd" or "yyyDELIMmmDELIMdd" where DELIM is some deliminator 
dft = pd.DataFrame(np.random.randn(100000,1),columns=['A'],index=pd.date_range('20130101',periods=100000,freq='T')) 
ts = pd.Series(np.random.randn(100000), index=pd.date_range('20130101',periods=100000,freq='T'))

>>> dft.head()
                            A
2013-01-01 00:00:00  2.375359
2013-01-01 00:01:00  0.663875
2013-01-01 00:02:00 -0.534566
2013-01-01 00:03:00  0.172524
2013-01-01 00:04:00  0.502204

#special index based access only for DatetimeIndex 
from datetime import datetime

#For specific exact index for Only DF , use .loc 
dft['2013-01-01 00:00:00'] #ERROR 
dft[datetime(2013, 1, 1)] #equivalent to exact  #ERROR 
#use below 
dft.loc['2013-01-01 00:00:00']
dft.loc[datetime(2013, 1, 1)] 
#note for Series, below works 
ts['2013-01-01 00:00:00']
ts[datetime(2013, 1, 1)]
ts.loc[datetime(2013, 1, 1)]

#for both DF and Series- any partial date string or slice of exact index works 
dft['2013-01-01 00:00:00':'2013-01-01 00:04:00']
dft['2013-1-1']             #from 2013-01-01 00:00:00 till upto 2013-01-01 23:59:00
dft['2013']                 #Year based , from 2013-01-01 00:00:00 till upto 2013-03-11 10:39:00
dft['2013-1':'2013-2']      #slice, end inclusive 
dft['2013-1':'2013-2-28']   # stop time that includes all of the times on the last day
dft['2013-1':'2013-2-28 00:00:00'] #exact stop time     
dft[datetime(2013, 1, 1):datetime(2013,2,28)] #exact start and stop time 
dft[datetime(2013, 1, 1, 10, 12, 0):datetime(2013, 2, 28, 10, 12, 0)] #exact start and stop time 

#Note the difference, first one is Series, 2nd one is DF 
>>> dft.loc[datetime(2013, 1, 1)]
A    2.375359
Name: 2013-01-01 00:00:00, dtype: float64
>>> dft.loc[ [datetime(2013, 1, 1)] ]
                   A
2013-01-01  2.375359

#Note 
ts[0] #first item , scalar 
#but 
dft[0] #error as for DF, [] includes column label 
dft['A'] #OK 
#but for slicing , works as it is row slicing 
ts[0:5]
dft[0:5]

##If a DF's Column or Series or Index is of strings , check string methods 
s = pd.Series(['A', 'B', 'C', 'Aaba', 'Baca', np.nan, 'CABA', 'dog', 'cat'])
dir(s.str)
s.str.lower() #elementwise 

##if a DF's Column or Series or Index is of datetime , check datetime methods 
s1 = pd.Series(pd.date_range('20130101 09:10:12', periods=4))
dir(s1.dt)
s1.dt.hour #ekementwise 

##if a DF's Column or Series or Index is of type categorical, check category method 
s = pd.Series(["a","b","c","a"], dtype="category")
dir(s.cat)
s.cat.categories
s.cat.rename_categories([1,2,3])



##Check DF methods 
dir(dft)
dft.describe()

##Note Column is a  Series,  can be plotted 
s1 = pd.Series(pd.date_range('20130101 09:10:12', periods=4))
dir(s1.plot)
s1.plot.line()

##check Column(ie Series) methods 
s = pd.Series(pd.RangeIndex(stop=10))#start,stop,step
dir(s)
#for example conversion 
s.astype(str)
s.sum()
#np.methods() can be applied 
np.log(s)
#or arithmatic 
s * 2 
#or logical 
s == 2 






##iris example 
iris = pd.read_csv('data/iris.csv')
>>> iris.head()
SepalLength  SepalWidth  PetalLength  PetalWidth         Name
0          5.1         3.5          1.4         0.2  Iris-setosa
1          4.9         3.0          1.4         0.2  Iris-setosa
2          4.7         3.2          1.3         0.2  Iris-setosa
3          4.6         3.1          1.5         0.2  Iris-setosa
4          5.0         3.6          1.4         0.2  Iris-setosa
#Return new DF 
>>> (iris.assign(sepal_ratio = iris['SepalWidth'] / iris['SepalLength']).head())
SepalLength  SepalWidth  PetalLength  PetalWidth         Name  sepal_ratio
0          5.1         3.5          1.4         0.2  Iris-setosa       0.6863
1          4.9         3.0          1.4         0.2  Iris-setosa       0.6122
2          4.7         3.2          1.3         0.2  Iris-setosa       0.6809
3          4.6         3.1          1.5         0.2  Iris-setosa       0.6739
4          5.0         3.6          1.4         0.2  Iris-setosa       0.7200


#Or use function of one argument which is the  DF
>>> iris.assign(sepal_ratio = lambda df: (df['SepalWidth'] /df['SepalLength'])).head()
SepalLength  SepalWidth  PetalLength  PetalWidth         Name  sepal_ratio
0          5.1         3.5          1.4         0.2  Iris-setosa       0.6863
1          4.9         3.0          1.4         0.2  Iris-setosa       0.6122
2          4.7         3.2          1.3         0.2  Iris-setosa       0.6809
3          4.6         3.1          1.5         0.2  Iris-setosa       0.6739
4          5.0         3.6          1.4         0.2  Iris-setosa       0.7200



#Example - limit the DataFrame with a Sepal Length greater than 5, calculate the ratio, and plot:

(iris.query('SepalLength > 5').assign( SepalRatio = lambda df: df.SepalWidth / df.SepalLength,            
                     PetalRatio = lambda df: df.PetalWidth / df.PetalLength)   
                .plot(kind='scatter', x='SepalRatio', y='PetalRatio'))
plt.show()

#Clearly two clusters 
iris_m = iris.assign( SepalRatio = lambda df: df.SepalWidth / df.SepalLength, PetalRatio = lambda df: df.PetalWidth / df.PetalLength) 
iris_m.plot(kind='scatter', x='SepalRatio', y='PetalRatio')

##Quick K-Means - Find those two clusters 
from sklearn.cluster import KMeans
numpy_features = iris_m[ ['SepalRatio','PetalRatio' ]].values
kmeans = KMeans(n_clusters=2, random_state=0).fit(numpy_features)
>>> kmeans.cluster_centers_
array([[0.68569927, 0.16512688],
       [0.46103872, 0.33785156]])
>>> kmeans.labels_  #each point's cluster index 
array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
       0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
       
#Assignment       
iris['sepalRatio'] = iris.SepalWidth / iris.SepalLength
iris.columns
       
#Get the names of the columns
>>> iris.columns
Index(['SepalLength', 'SepalWidth', 'PetalLength', 'PetalWidth', 'Name','sepalRatio'],
      dtype='object')
      
#Any np.methods() can be used 
>>> np.unique(iris.Name)
array(['Iris-setosa', 'Iris-versicolor', 'Iris-virginica'], dtype=object)      

>>> iris.Name.unique()
array(['Iris-setosa', 'Iris-versicolor', 'Iris-virginica'], dtype=object)

#access string column by .str 
dir(iris.Name.str)
iris.Name.str.lower()

>>> np.unique(iris.Name.apply(lambda x: un.tolist().index(x)))
array([0, 1, 2], dtype=int64)
#apply for Series, fn takes each element, for DF, fn takes each col if axis=0 else takes each row if axis=1
iris["target"] = iris.Name.apply(lambda x: un.tolist().index(x))

#Get the first five rows of a column by name
iris['SepalLength'][:5]                     #Series
iris[ [ 'SepalLength', 'SepalWidth'] ][:5]  #DF 


#Create categorical ranges for numerical data. 14 is number of bins
sl_bin = pd.cut(iris['SepalLength'], 14)
sl_bin[:5]

#Look at the frequencies in the ranges created above
pd.value_counts(sl_bin)
sl_bin.value_counts()

#Access through .cat 
iris["category"] = sl_bin
iris.category.cat.categories
#to get index of each bin 
iris.category.cat.rename_categories(range(14))

#first six columns of the first row
#ix like .loc[row,column] , ie label based at first if not then iloc[row,column], index based
iris.ix[0,0:6]

#Order the data by specified column
iris['SepalLength'].sort_values()[:5]

#Sort by a column and that obtain a cross-section of that data , multiple can be given
sorteddata = iris.sort_values(by=['SepalLength', 'PetalLength'])  #DF
sorteddata.ix[:,0:6].head(3)  

#Obtain the first three rows and first three columns of the sorted data
sorteddata.iloc[0:3,0:3]

#Obtain value counts of specific column
iris['PetalLength'].value_counts()

#to obtain the datatype 
iris.dtypes

#Get the unique values for a column by name.
iris['Name'].unique()

#Get a count of the unique values of a column
len(iris['Name'].unique())

#Index into a column and get the first four rows
iris.ix[0:3,'Name']

#Obtain True/False  values which could be used inside iloc, loc etc 
iris.ix[:,'Name'] == 'Iris-setosa'
#Can get any columns , use  | , &, ~ for boolean conjunction, disjunction and inverse 
iris.loc[iris['Name'] == 'Iris-setosa', 'SepalLength']  #Series
iris.ix[iris['Name'] == 'Iris-setosa', 0] #note .iloc with boolean not available 
iris.loc[iris['Name'] == 'Iris-setosa', ['SepalLength','PetalLength']] #DF

#Query the data
qry1 = iris.query('Name == "Iris-setosa"')  #returns DF of original only where cond is valid 
qry1.head(10)

#Check a boolean condition
(iris.ix[:,'SepalLength'] > 4.3).any()


#Return descriptive statistics of the dataset- mean, std etc is calculated for each colu mn
>>> iris.describe()
       SepalLength
count   150.000000
mean      5.843333
std       0.828066
min       4.300000
25%       5.100000
50%       5.800000
75%       6.400000
max       7.900000
>>> iris.Name.describe()
count                 150
unique                  3
top       Iris-versicolor
freq                   50
Name: Name, dtype: object

#Crosstab(frequency) of the data by specified columns (of one column vs another)
pd.crosstab(iris['category'],iris['target']) #DF, multiindex 


#Group data and obtain the mean,
#group by col1 and then col2 and find mean of all other columns
grouped1 = iris.groupby('SepalLength') #single column 
grouped1 = iris.groupby(['SepalLength','PetalLength']) #pandas.core.groupby.DataFrameGroupBy
dir(grouped1)
grouped1.mean()  #DF
grouped1.agg(np.mean) #DF 
grouped1.mean().index #MultiIndex 
grouped1.agg({'SepalWidth':'count', 'PetalWidth':'mean'}) #DF 




##Visualization

#Plot counts of a specified column using Pand as
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns  #install it, pip install seaborn

iris.Name.value_counts().plot(kind='bar')
plt.show()
#with x and y 
iris.plot(x=None, y='SepalWidth', kind='line')
plt.show()
#full DF 
iris.plot( kind='line')
plt.show()
#for sub DF 
iris.iloc[:,0:4].plot(kind='line')
plt.show()
#with groupby 
iris.groupby('Name').plot(kind='line')
plt.show()
#as subplots 
iris.groupby('Name').plot(kind='line', subplots=True)
plt.show()
#for partial DF 
iris.iloc[:,0:5].groupby('Name')['SepalLength'].plot(kind='line', subplots=True)
plt.show()


#note 
iris.plot(kind='line') 
#is equivalent to 
iris.plot.line()
#and similarly for others 

#with subplots 
#multiple in one plot 
iris.plot(kind='line', y=['SepalLength','PetalLength'] )
#with subplots 
iris.plot(kind='line', y=['SepalLength','PetalLength'], subplots=True )

#Bar plot of median values
iris.groupby('Name')['SepalLength'].agg(np.mean).plot(kind = 'bar')
plt.show()

#Scatter_matrix or sns.pairplot
#hue is categorical data and for each hue, scatter_matrix is done
sns.pairplot(iris.iloc[:,0:5], hue='Name', size=2.5)
plt.show()

from pandas.plotting import scatter_matrix
scatter_matrix(iris.iloc[:,0:4], alpha=0.2, figsize=(6, 6), diagonal='kde')
plt.show()
#for only one Name 
scatter_matrix(iris.ix[iris.Name=='Iris-virginica',0:4], alpha=0.2, figsize=(6, 6), diagonal='kde')
plt.show()
#only density plot 
iris.SepalLength.plot.kde()
plt.show()
#or 
sns.kdeplot(iris.SepalLength)
sns.kdeplot(iris.SepalWidth)
plt.show()
#or
sns.distplot(iris.SepalLength)
plt.show()
#for bivariate kernel density estimate
sns.kdeplot(iris.iloc[:,0:4]) #bivariate kernel density estimate
plt.show()
#joint distribution of x,y and the marginal distributions (joit distribution with one const)
#For this plot, we'll set the style to a white background
#pearsonr = correlation coefficient  , -1 to 1, 0= not correlated, H0:not correlated 
#kind : { �scatter� | �reg� | �resid� | �kde� | �hex� }, optional
with sns.axes_style('white'):
    sns.jointplot(x="SepalLength", y="PetalLength", data=iris.iloc[:,0:4], kind='kde');

plt.show()

#Box plot - x= x axis categorical data, y= box plot variable  , hue=categorical data, for each, x vs y box plot is done 
#box plot - box-25%,median, 75%(third quartiles), min-max data - some convension of min and max - https://en.wikipedia.org/wiki/Box_plot, outliers
#seaborn.factorplot(x=None, y=None, hue=None, data=None, row=None, col=None, col_wrap=None, estimator=<function mean>, ci=95, n_boot=1000, units=None, order=None, hue_order=None, row_order=None, col_order=None, kind='point', size=4, aspect=1, orient=None, color=None, palette=None, legend=True, legend_out=True, sharex=True, sharey=True, margin_titles=False, facet_kws=None, **kwargs)
#kind : {point, bar, count, box, violin, strip}
import seaborn as sns
g = sns.factorplot(x="Name", y="PetalLength", hue="Name" ,data=iris.iloc[:,0:5], kind="box", palette="PRGn",aspect=2.25)
g.set(ylim=(0, 10))
plt.show()

#Barplot 
g = sns.factorplot(x="Name", data=iris.iloc[:,0:5], aspect=2,  kind="count", color='steelblue')







###*EXCEl: xlrd is required for pandas.read_excel 
pandas.read_excel(io, sheet_name=0, header=0, skiprows=None, skip_footer=0, index_col=None, names=None, usecols=None, parse_dates=False, date_parser=None, na_values=None, thousands=None, conirist_float=True, coniristers=None, dtype=None, true_values=None, false_values=None, engine=None, squeeze=False, **kwds)
    df = pd.read_excel("file_name", 'Sheet1') #needs xlrd
    #for example setting correct index from one column, if datetime, use to_datetime
    df.index = pd.to_datetime(df.Date)
DataFrame.to_excel(excel_writer, sheet_name='Sheet1', na_rep='', float_format=None, columns=None, header=True, index=True, index_label=None, startrow=0, startcol=0, engine=None, merge_cells=True, encoding=None, inf_rep='inf', irisbose=True, freeze_panes=None)
pandas.to_datetime(arg, errors='raise', dayfirst=False, yearfirst=False, utc=None, box=True, format=None, exact=True, unit=None, infer_datetime_format=False, origin='unix')[source]
    Convert argument to datetime.
    arg : integer, float, string, datetime, list, tuple, 1-d array, Series
    #common format 
    %w  Weekday as a decimal number, where 0 is Sunday and 6 is Saturday. 0, 1, �, 6   
    %d  Day of the month as a zero-padded decimal number. 01, 02, �, 31 
    %b  Month as locale's abbreviated name. Jan, Feb, �, Dec (en_US);
    %B  Month as locale's full name. January, February, �, December (en_US);
    %m  Month as a zero-padded decimal number. 01, 02, �, 12   
    %y  Year without century as a zero-padded decimal number. 00, 01, �, 99   
    %Y  Year with century as a decimal number. 1970, 1988, 2001, 2013   
    %H  Hour (24-hour clock) as a zero-padded decimal number. 00, 01, �, 23   
    %I  Hour (12-hour clock) as a zero-padded decimal number. 01, 02, �, 12   
    %p  Locale's equivalent of either AM or PM. AM, PM (en_US);
    %M  Minute as a zero-padded decimal number. 00, 01, �, 59   
    %S  Second as a zero-padded decimal number. 00, 01, �, 59 
    %f  Microsecond as a decimal number, zero-padded on the left. 000000, 000001, �, 999999 
    %z  UTC offset in the form +HHMM or -HHMM (empty string if the the object is naive). (empty), +0000, -0400, +1030 
    %Z  Time zone name (empty string if the object is naive). (empty), UTC, EST, CST   
    %j  Day of the year as a zero-padded decimal number. 001, 002, �, 366   
    %U  Week number of the year (Sunday as the first day of the week) as a zero padded decimal number. All days in a new year preceding the first Sunday are considered to be in week 0. 00, 01, �, 53 
    %W  Week number of the year (Monday as the first day of the week) as a decimal number. All days in a new year preceding the first Monday are considered to be in week 0. 00, 01, �, 53 

#Example  
import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 
import statsmodels.api as sm 

dft = pd.read_excel(r"data\Nifty-17_Years_Data-V1.xlsx", parseDates=True, index_col=0, header=0, date_parser=lambda x: pd.to_datetime(x, format="%d-%b-%y"))
dft.index
>> df.head()

from pandas.tseries.offsets import *
dft.index.freq = Day() #set freq as D 

import datetime
#For specific exact index for DF , use .loc 
dft['2000-06-01'] #ERROR 
dft[datetime.date(2000, 6, 1)] #equivalent to exact  #ERROR #datetime.date(year, month, day)
#use below 
dft.loc['2000-06-01']
dft.iloc[0]
dft.loc[datetime.date(2000, 6, 1)] 
#for both DF and Series- any partial date string or slice of exact index works 
dft['2000-06-01']             #from 2013-01-01 00:00:00 till upto 2013-01-01 23:59:00
dft['2013']                 #Year based , from 2013-01-01 00:00:00 till upto 2013-03-11 10:39:00
dft['2013-1':'2013-2']      #slice, end inclusive 
dft['2013-1':'2013-2-28']   # stop time that includes all of the times on the last day
dft['2013-1':'2013-2-28 00:00:00'] #exact stop time     
dft[datetime.date(2013, 1, 1):datetime.date(2013,2,28)] #exact start and stop time 
dft[datetime.datetime(2013, 1, 1, 10, 12, 0):datetime.datetime(2013, 2, 28, 10, 12, 0)] #exact start and stop time 
#Note the difference, first one is Series, 2nd one is DF 
>>> dft.loc[datetime.date(2013, 1, 1)]
A    2.375359
Name: 2013-01-01 00:00:00, dtype: float64
>>> dft.loc[[datetime.date(2013, 1, 1)]]
                   A
2013-01-01  2.375359

#Note 
ts[0] #first item , scalar 
#but 
dft[0] #error as for DF, [] includes column label 
dft['Open'] #OK 
#but for slicing , works as it is row slicing 
ts[0:5]
dft[0:5]


#plot 
dft.plot(kind='line', subplots=True)
plt.show()
dft.Close.plot(kind='line')
plt.show()


#complex plot 
#4x4 gridspecs, specification for 0,0 cell , row spanning 3 rows, column spanning 4 columns 
top = plt.subplot2grid((4,4), (0, 0), rowspan=3, colspan=4)
top.plot(dft.index, dft["Close"])
plt.title('Nifty close from 2000 - 2018')

#4x4 gridspecs, specification for 3,0 cell , row spanning 1 rows, column spanning 4 columns 
bottom = plt.subplot2grid((4,4), (3,0), rowspan=1, colspan=4)
bottom.bar(dft.index, dft['Day Wise Variation ( points) '])
plt.title('Nifty Day wise variations ')

plt.show()

##(for Time series, equivalent to aggregation)
#Calculate moving avarages 
#window : int,Size of the moving window. 
#This is the number of observations used for calculating the statistic.
dft_r = dft.rolling(30)  #rolling 30 samples 
dir(dft_r)
#plot rolling average 
dft_r.mean()['Open'] #DF 
dft_r.mean().dropna().plot(kind='line') #DF
plt.show()
#
dft_s = dft.ewm(com=0.5)#Returns Exponentially-weighted moving window(EWM) class ,com=decay in terms of center of mass
#
dft_s = dft.expanding(2) #Expanding window, Minimum number of observations in window required to have a value         (otherwise result is NA)
#or downsampling at month 
dft_s = dft.resample('M')
dir(dft_s)
#month value would be mean()
dft_s.mean() #DF 
dft_s['Open'].mean() #Series
dft_s['Open'].agg([np.sum, np.mean, np.std])
dft_s.agg({'Open':'mean', 'Close':'std'})
dft_s.agg({'Open':['mean',np.std], 'Close':['std','sum']})

#KDE plot
dft_s.Close.plot(kind='kde')

#lagplot -Lag plots are used to check if a data set or time series is random. 
#Random data should not exhibit any structure in the lag plot. 
#Non-random structure implies that the underlying data are not random.
from pandas.plotting import lag_plot
lag_plot(df.Close)
plt.show()


##Autocorrelation plots are often used for checking randomness in time series
#If time series is random, such autocorrelations should be near zero for  all time-lag separations(other than lag=0)
from pandas.plotting import autocorrelation_plot
autocorrelation_plot(df.Close)

##Time Series analysis - statsmodel 
import statsmodels.api as sm
import statsmodels.tsa.api as smt
##Checking stationary 
#constant mean
#constant variance
#an autocovariance that does not depend on time
#run plot 
ts = dft.Close 

#clearly shows overall increasing trend 
ts.plot(kind='line')
plt.show()

#further checking of stationary 
#rolling statistics plots - ever increasing 
#and  Dickey-Fuller test - adfuller
#H0: TS is non-stationary


def test_stationarity(timeseries):    
    #Determing rolling statistics
    rolmean = timeseries.rolling(window=12, center=False).mean()
    rolstd = timeseries.rolling(window=12, center=False).std()
    #Plot rolling statistics:
    orig = plt.plot(timeseries, color='blue',label='Original')
    mean = plt.plot(rolmean, color='red', label='Rolling Mean')
    std = plt.plot(rolstd, color='black', label = 'Rolling Std')
    plt.legend(loc='best')
    plt.title('Rolling Mean & Standard Deviation')
    plt.show(block=False)
    #Perform Dickey-Fuller test:
    print('Results of Dickey-Fuller Test:')
    dftest = smt.adfuller(timeseries, autolag='AIC')
    dfoutput = pd.Series(dftest[0:4], index=['Test Statistic','p-value','#Lags Used','Number of Observations Used'])
    for key,value in dftest[4].items():
        dfoutput['Critical Value (%s)'%key] = value
    print(dfoutput)
    

>>> test_stationarity(ts)  
#variation in standard deviation is small, mean is clearly increasing with time 
#p-value>0.05, hence accept H0(=TS is non-stationary)
Results of Dickey-Fuller Test:
Test Statistic                    0.411488
p-value                           0.981920
#Lags Used                       14.000000
Number of Observations Used    4370.000000
Critical Value (10%)             -2.567122
Critical Value (5%)              -2.862202
Critical Value (1%)              -3.431847
dtype: float64


##How to make a Time Series Stationary?
#Reasons for nonstionary 
#1. Trend � varying mean over time. 
#    In this case, average mean increasing over time 
#2. Seasonality � variations at specific time-frames. 
#    eg people might have a tendency to buy cars in a particular month 
#    because of pay increment or festivals.

#First option for reducing increasing trend  - Tranformation 
#eg log, sqrt or cube root to dampen the trend 
#for decreasing trend, exp, square, cube etc 
ts_log = np.log(ts)
plt.plot(ts_log)
plt.show()


##Eliminating Trend and Seasonality
#Differencing � taking the differece with a particular time lag
#Decomposition � modeling both trend and seasonality and removing them from the model.

##Eliminating both Trend and Seasonality - Differencing
ts_log_diff = ts_log - ts_log.shift(1)
#or 
ts_log_diff = ts_log.diff(periods=1) #Periods to shift for forming difference

ts_log_diff.dropna(inplace=True)
>>> test_stationarity(ts_log_diff)
Results of Dickey-Fuller Test:
Test Statistic                -1.445462e+01
p-value                        7.006666e-27
#Lags Used                     1.900000e+01
Number of Observations Used    4.364000e+03
Critical Value (10%)          -2.567123e+00
Critical Value (5%)           -2.862203e+00
Critical Value (1%)           -3.431849e+00
dtype: float64

#Note 2nd differencing is extremly rare , DOn't use 
ts_log_diff2 = ts_log_diff - ts_log_diff.shift(1)
#or 
ts_log_diff2 = ts_log_diff.diff(1) #Note, it is not ts_log.diff(periods=2), which is diff with every 2nd period 

ts_log_diff2.dropna(inplace=True)
>>> test_stationarity(ts_log_diff2)
Results of Dickey-Fuller Test:
Test Statistic                -8.196629e+00
p-value                        7.419305e-13
#Lags Used                     1.300000e+01
Number of Observations Used    1.280000e+02
Critical Value (1%)           -3.482501e+00
Critical Value (10%)          -2.578960e+00
Critical Value (5%)           -2.884398e+00
dtype: float64


##Eliminating both Trend and Seasonality - Decomposing
#In this approach, both trend and seasonality are modeled separately 
#and the remaining part of the series is returned
'''
Arg freq : int, optional
        Frequency of the series. Must be used if x is not a pandas object. 
        Overrides default periodicity of x 
        if x is a pandas object with a timeseries index.
            #freqstr      Seasonal period    # of datapoints for aggregation
            A              1                 aggregate yearly 
            Q              4                 aggregate yearly 
            M              12                aggregate yearly
            W              52                aggregate yearly
            D              7                 aggregate weekly 
            B              5                 aggregate weekly 
            H              24                aggregate daily 
'''

from statsmodels.tsa.seasonal import seasonal_decompose

decomposition = seasonal_decompose(ts_log, freq=7) 
trend = decomposition.trend
seasonal = decomposition.seasonal
residual = decomposition.resid  #we need to work with this series further 
decomposition.plot()
plt.show()

#Get stats 
ts_log_decompose = residual
ts_log_decompose.dropna(inplace=True)
>>> test_stationarity(ts_log_decompose)
Test Statistic                  -18.851623
p-value                           0.000000
#Lags Used                       30.000000
Number of Observations Used    4348.000000
Critical Value (10%)             -2.567124
Critical Value (5%)              -2.862205
Critical Value (1%)              -3.431855
dtype: float64

##Forecasting a Time Series
#Use differencingfor making stationary 

#ACF and PACF plots:
#p � The lag value where the PACF chart crosses the upper confidence interval for the first time. 
#     If you notice closely, in this case p=1.
#q � The lag value where the ACF chart crosses the upper confidence interval for the first time. 
#     If you notice closely, in this case q=1.


#below line must, must not contain NaN 
ts_log_diff.dropna(inplace=True)

fig = plt.figure(figsize=(12,8))
ax1 = fig.add_subplot(211)
sm.graphics.tsa.plot_acf(ts_log_diff, lags=40, ax=ax1,alpha=0.05) #confidence level 95%
ax2 = fig.add_subplot(212)
sm.graphics.tsa.plot_pacf(ts_log_diff, lags=40, ax=ax2,alpha=0.05)
plt.show()

#or 
#x13 - 
import pandas as pd
df = pd.DataFrame(ts_log, index=dft.index)
#Requires x13as.exe in PATH , Only monthly and quarterly periods are supported
#download from https://www.census.gov/srd/www/winx13/winx13_down.html
import statsmodels
res = statsmodels.tsa.x13.x13_arima_select_order(df.resample('M').mean())
>>> res.order
(0, 1, 1)

#or 
ts_log_diff.dropna(inplace=True) #note if input contains nan, Error would happen 
res = sm.tsa.arma_order_select_ic(ts_log_diff, ic=['aic', 'bic'], trend='nc') #nc - no constant term
res.aic_min_order #(p,q) = (3, 2)
res.bic_min_order #(0, 1)
>>> res
{'bic_min_order': (0, 1), 'bic':               0             1             2
0           NaN -24712.161789 -24711.432984
1 -24709.468202 -24709.834026 -24703.079027
2 -24711.557674 -24703.279453 -24696.956015
3 -24703.333590 -24696.489131 -24696.783230
4 -24695.555535 -24687.204379           NaN, 'aic':               0
1             2
0           NaN -24724.933223 -24730.590135
1 -24722.239636 -24728.991176 -24728.621895
2 -24730.714824 -24728.822320 -24728.884599
3 -24728.876458 -24728.417715 -24735.097531
4 -24727.484119 -24725.518680           NaN, 'aic_min_order': (3, 2)}


#Fit now 
#since 1st order differntiation is done, hence d= 1
from statsmodels.tsa.arima_model import ARIMA

fig = plt.figure(figsize=(12,8))
#AR Model
model = ARIMA(ts_log, order=(1, 1, 0))  
results_AR = model.fit(disp=-1)   #disp:If True, convergence information is output.
ax1 = fig.add_subplot(311)
ax1.plot(ts_log_diff)
ax1.plot(results_AR.fittedvalues, color='red')
ax1.set_title('RSS: %.4f'% sum((results_AR.fittedvalues-ts_log_diff)**2))

#MA Model
model = ARIMA(ts_log, order=(0, 1, 1))  
results_MA = model.fit(disp=-1)  
ax2 = fig.add_subplot(312)
ax2.plot(ts_log_diff)
ax2.plot(results_MA.fittedvalues, color='red')
ax2.set_title('RSS: %.4f'% sum((results_MA.fittedvalues-ts_log_diff)**2), x=0.4)

#ARIMA 
model = ARIMA(ts_log, order=(1, 1, 1))  
results_ARIMA = model.fit(disp=-1)  
ax3 = fig.add_subplot(313)
ax3.plot(ts_log_diff)
ax3.plot(results_ARIMA.fittedvalues, color='red') #fittedvalues  is after differencing, d=1
ax3.set_title('RSS: %.4f'% sum((results_ARIMA.fittedvalues-ts_log_diff)**2), x=0.4)

plt.show()

#Note - all below are after differencing d=1
>>> ts_log_diff[1:5]  #with d=1 
Date
2000-06-02    0.029400
2000-06-05    0.010989
2000-06-06    0.012136
2000-06-07    0.006031
Name: Close, dtype: float64
>>> results_ARIMA.fittedvalues[0:4]  #with d=1 
Date
2000-06-02    0.000470
2000-06-05    0.002797
2000-06-06    0.000337
2000-06-07    0.001505
dtype: float64
>>> results_ARIMA.predict(start=1,end=4)  #in place , with d=1 
Date
2000-06-02    0.000470
2000-06-05    0.002797
2000-06-06    0.000337
2000-06-07    0.001505
dtype: float64
#out of sample prediction 
>>> results_ARIMA.predict(start=len(ts_log)-1, end=len(ts_log)+5)
4384    0.001018
4385    0.000623
4386    0.000416
4387    0.000488
4388    0.000463
4389    0.000472
4390    0.000469
dtype: float64

>>> results_ARIMA.forecast(steps=5)[0] #without d=1 , returns forecast,stderr, confInterval
array([9.26534234, 9.26575853, 9.26624702, 9.2667102 , 9.26718224])
>>> ts_log[-1]
9.2647196498149

#get summary 
results_ARIMA.summary()
#predict , next 20 values 
steps=20
predict_arima = results_ARIMA.forecast(steps=steps) #without d=1 , returns forecast,stderr, confInterval




##Taking it back to original scale
index = pd.date_range(ts.index[-1], periods=steps+1)[-steps:]
predictions_ARIMA_log = pd.Series(predict_arima[0], copy=True, index=index)
predictions_ARIMA_diff_orig = pd.Series(results_ARIMA.fittedvalues, copy=True)


#we took a lag by 1  for differencing 
#To undo, first determine the cumulative sum at index 
#add it to first value 
predictions_ARIMA_log_orig = predictions_ARIMA_diff_orig.cumsum() + ts_log.ix[0]


#and then anti-log 
predictions_ARIMA = np.exp(predictions_ARIMA_log)
predicted = np.exp(predictions_ARIMA_log_orig.append(predictions_ARIMA_log) ) 

plt.plot(ts)
plt.plot(predicted)
#use ts[1:] because predictions_ARIMA_log_orig does not initial d samples 
plt.title('RMSE: %.4f'% np.sqrt(sum((np.exp(predictions_ARIMA_log_orig)-ts[1:])**2)/len(ts[1:])))
plt.show()



###Melt Example 
data = {'weekday': ["Monday", "Tuesday", "Wednesday", 
         "Thursday", "Friday", "Saturday", "Sunday"],
        'Person 1': [12, 6, 5, 8, 11, 6, 4],
        'Person 2': [10, 6, 11, 5, 8, 9, 12],
        'Person 3': [8, 5, 7, 3, 7, 11, 15]}
df = pd.DataFrame(data, columns=['weekday',
        'Person 1', 'Person 2', 'Person 3'])
#output 
     weekday  Person 1  Person 2  Person 3
0     Monday        12        10         8
1    Tuesday         6         6         5
2  Wednesday         5        11         7

#How can you do group by on person 
#this is not normalized table 
#Melt data  - creating a generic form internally, which you can cast to specific shape
#each row is converted into id_vars versus other columns into 'variable'/var_name and 'value'/value_name
melt = pd.melt(df, id_vars=["weekday"], var_name="Person", value_name="Score")
#output 
     weekday    Person  Score
0     Monday  Person 1     12
1    Tuesday  Person 1      6
2  Wednesday  Person 1      5

#umpivot 
#pivot-unmelt - pivot(index=None, columns=None, values=None)
#'columns' columns name would be new DF's column labels 
#'values'= columnName  to use for populating new frame's cell values 
#'index'=Columnname for new frame's index

pm = melt.pivot(index='weekday', columns='Person', values='Score')
#output 
Person    Person 1  Person 2  Person 3
weekday
Friday          11         8         7
Monday          12        10         8
#reset_index()
pm2 = pm.reset_index()



##excel style pivot table 
#values=ColumnNames for aggfun , index=ColumnsNames for row-groupby , columns=ColumnNames on column-groupby , aggfunc=not string, but functions 
>>> table = pd.pivot_table(melt, values=['Score'], 
    index=['weekday'], 
    columns=['Person'], 
    aggfunc=[np.sum, np.max, lambda x:x.size]) #no np method for count , we have np.count_nonzero 

#or to get to get all of those 
pd.pivot_table(melt, values=['Score'], 
    columns=['Person'], 
    aggfunc=[np.sum, np.max, lambda x:x.size])



    

##Pandas - Merge, join, concat, append
DataFrame.append(other[, ignore_index, ...]) 
    Append rows of other to the end of this frame, returning a new object. 
DataFrame.assign(**kwargs) 
    Assign new columns to a DataFrame, returning a new object (a copy) with all the original columns in addition to the new ones. 

pandas.concat(objs[, axis, join, join_axes, ...]) 
    Concatenate pandas objects along a particular axis with optional set logic along the other axes. 
DataFrame.insert(loc, column, value[, ...]) 
    Insert column into DataFrame at specified location. 

DataFrame.join(other[, on, how, lsuffix, ...]) 
    Join columns with other DataFrame either on index or on a key column. 
DataFrame.merge(right[, how, on, left_on, ...]) 
    Merge DataFrame objects by performing a database-style join operation by columns or indexes. 
DataFrame.update(other[, join, overwrite, ...]) 
    Modify DataFrame in place using non-NA values from passed DataFrame. 



##DF -  insert 
DataFrame.insert(loc, column, value, allow_duplicates=False)
    Insert column into DataFrame at specified location
        loc : int
            Insertion index. Must verify 0 <= loc <= len(columns)
        column : string, number, or hashable object
            label of the inserted column
        value : int, Series, or array-like
        allow_duplicates : bool, optional

#Example 
df.insert(1, 'bar', df['one'])
>>> df
   one  bar   flag  foo  one_trunc
a  1.0  1.0  False  bar        1.0
b  2.0  2.0  False  bar        2.0
c  3.0  3.0   True  bar        NaN
d  NaN  NaN  False  bar        NaN

##DF- assign 
DataFrame.assign(**kwargs)
    kwargs : keyword, value pairs
        column_label=fn(df):return_newSeries
        or column_label=Series, scalar, or array
    Returns:
    df : DataFrame
        A new DataFrame with the new columns in addition to all the existing columns
 
#All expressions are computed first, and then assigned.
#So you can't refer to another column being assigned in the same call to assign.

# Don't do this, bad reference to `C` 
df.assign(C = lambda x: x['A'] + x['B'], D = lambda x: x['A'] + x['C'])
# Instead, break it into two assigns
new_df = (df.assign(C = lambda x: x['A'] + x['B']).assign(D = lambda x: x['A'] + x['C']))

##DF-append 
DataFrame.append(other, ignore_index=False, verify_integrity=False)
    Append rows of other as vertical stacking 
    Parameters:
        other : DataFrame or Series/dict-like object, or list of these
            The data to append.
        ignore_index : boolean, default False
            If True, do not use the index labels.
        verify_integrity : boolean, default False
            If True, raise ValueError on creating index with duplicates.
        Returns:
            appended : DataFrame

>>> df = pd.DataFrame([[1, 2], [3, 4]], columns=list('AB'))
>>> df
   A  B
0  1  2
1  3  4
>>> df2 = pd.DataFrame([[5, 6], [7, 8]], columns=list('AB'))
>>> df.append(df2)
   A  B
0  1  2
1  3  4
0  5  6
1  7  8
>>> df.append(df2).reset_index()
   index  A  B
0      0  1  2
1      1  3  4
2      0  5  6
3      1  7  8

##DF  - Concat 
pd.concat(objs, axis=0, join='outer', join_axes=None, ignore_index=False,       
        keys=None, levels=None, names=None, verify_integrity=False)
    Concatenate pandas objects along a particular axis 
    with optional set logic along the other axes.
        �objs: a sequence or mapping of Series, DataFrame, or Panel objects.    
        �axis: {0, 1}, default 0(index). 
            =0 means vertical(row) stacking, =1 means horizontal(column) stacking 
        �join: {'inner', 'outer'}, default 'outer'. 
            Outer for union and inner for intersection.
        keys: new columns name 
        ignore_index : boolean, default False
            If True, do not use the index values along the concatenation axis. 
            The resulting axis will be labeled 0, ..., n - 1.
#Note numpy axis means the same as pandas 
#vertically(row) stacking array - note each is 2D 
>>> np.concatenate(( [[1,2],[3,4]] , [[5,6]]  ), axis=0) #, arg = list of 2D matrix 
array([[1, 2],
       [3, 4],
       [5, 6]])
#2nd array appended columnwise - note each is 2D 
>>> np.concatenate(( [[1,2],[3,4]] , [[5],[6]]  ), axis=1)
array([[1, 2, 5],
       [3, 4, 6]])
#Example 
df1 = pd.DataFrame({'A': ['A0', 'A1', 'A2', 'A3'],  #keys are columns                    
    'B': ['B0', 'B1', 'B2', 'B3'],                    
    'C': ['C0', 'C1', 'C2', 'C3'],                    
    'D': ['D0', 'D1', 'D2', 'D3']},                    
    index=[0, 1, 2, 3])
df2 = pd.DataFrame({'A': ['A4', 'A5', 'A6', 'A7'],                   
    'B': ['B4', 'B5', 'B6', 'B7'],                   
    'C': ['C4', 'C5', 'C6', 'C7'],                    
    'D': ['D4', 'D5', 'D6', 'D7']},                    
    index=[4, 5, 6, 7])
df3 = pd.DataFrame({'A': ['A8', 'A9', 'A10', 'A11'],                    
    'B': ['B8', 'B9', 'B10', 'B11'],                     
    'C': ['C8', 'C9', 'C10', 'C11'],                        
    'D': ['D8', 'D9', 'D10', 'D11']},                    
    index=[8, 9, 10, 11])

#Note same index values in multiple DFs would be duplicated in result DF 
#To ignore index in input DF, use ignore_index=True 
frames = [df1, df2, df3]
result = pd.concat(frames)    #Using concat, default axis=0, vertically(row) append 
>>> result
      A    B    C    D
0    A0   B0   C0   D0
1    A1   B1   C1   D1
2    A2   B2   C2   D2
3    A3   B3   C3   D3
4    A4   B4   C4   D4
5    A5   B5   C5   D5
6    A6   B6   C6   D6
7    A7   B7   C7   D7
8    A8   B8   C8   D8
9    A9   B9   C9   D9
10  A10  B10  C10  D10
11  A11  B11  C11  D11
>>> result = pd.concat(frames, axis=1) #horizontal(column) stacking 
>>> result
      A    B    C    D    A    B    C    D    A    B    C    D
0    A0   B0   C0   D0  NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN
1    A1   B1   C1   D1  NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN
2    A2   B2   C2   D2  NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN
3    A3   B3   C3   D3  NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN
4   NaN  NaN  NaN  NaN   A4   B4   C4   D4  NaN  NaN  NaN  NaN
5   NaN  NaN  NaN  NaN   A5   B5   C5   D5  NaN  NaN  NaN  NaN
6   NaN  NaN  NaN  NaN   A6   B6   C6   D6  NaN  NaN  NaN  NaN
7   NaN  NaN  NaN  NaN   A7   B7   C7   D7  NaN  NaN  NaN  NaN
8   NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN   A8   B8   C8   D8
9   NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN   A9   B9   C9   D9
10  NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN  A10  B10  C10  D10
11  NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN  A11  B11  C11  D11

#Note append  is similar to axis=0 
result = df1.append(df2)
>>> result
    A   B   C   D
0  A0  B0  C0  D0
1  A1  B1  C1  D1
2  A2  B2  C2  D2
3  A3  B3  C3  D3
4  A4  B4  C4  D4
5  A5  B5  C5  D5
6  A6  B6  C6  D6
7  A7  B7  C7  D7

#the indexes must be disjoint or use ignore_index=True 
>>> result = df1.append([df1.copy()])
>>> result
    A   B   C   D
0  A0  B0  C0  D0
1  A1  B1  C1  D1
2  A2  B2  C2  D2
3  A3  B3  C3  D3
0  A0  B0  C0  D0
1  A1  B1  C1  D1
2  A2  B2  C2  D2
3  A3  B3  C3  D3

#To concatenate a mix of Series and DataFrames.
s1 = pd.Series(['X0', 'X1', 'X2', 'X3'], name='X')
result = pd.concat([df1, s1], axis=1) #horzontal stacking 
>>> result
    A   B   C   D   X
0  A0  B0  C0  D0  X0
1  A1  B1  C1  D1  X1
2  A2  B2  C2  D2  X2
3  A3  B3  C3  D3  X3



##DF - Database-style DataFrame merging
pandas.merge(left, right, how='inner', on=None, left_on=None, right_on=None,      
        left_index=False, right_index=False, sort=True,      
        suffixes=('_x', '_y'), copy=True, indicator=False)
DataFrame.merge(right, how='inner', on=None, left_on=None, right_on=None, 
        left_index=False, right_index=False, sort=False, suffixes=('_x', '_y'), copy=True, indicator=False, validate=None)
    If joining columns on columns, ie 'on' or (left_on,right_on), 
    the DataFrame indexes will be ignored. 
    Otherwise if joining indexes on indexes ie left_index,right_index 
    or indexes on a column(ie on*, *_index combination, Note, one's index values must match with other's column's value) 
    the index will be passed on.    
    left, right : DataFrame
    how : {'left', 'right', 'outer', 'inner'}, default 'inner'
        �left: use only keys from left frame, similar to a SQL left outer join; preserve key order
        �right: use only keys from right frame, similar to a SQL right outer join; preserve key order
        �outer: use union of keys from both frames, similar to a SQL full outer join; sort keys lexicographically
        �inner: use intersection of keys from both frames, similar to a SQL inner join; preserve the order of the left keys
    on: Columns (names) to join on. 
        Must be found in both the left and right DataFrame objects. 
        If not passed and left_index and right_index are False, 
        the intersection of the columns in the DataFrames will be inferred to be the join keys
    �left_on: Columns from the left DataFrame to use as keys. 
        Can either be column names or arrays with length equal to the length of the DataFrame
    �right_on: Columns from the right DataFrame to use as keys. 
        Can either be column names or arrays with length equal to the length of the DataFrame
    �left_index: If True, use the index (row labels) from the left DataFrame as its join key(s). 
        In the case of a DataFrame with a MultiIndex (hierarchical), 
        the number of levels must match the number of join keys from the right DataFrame
    right_index: Same usage as left_index for the right DataFrame
    sort : boolean, default False
        Sort the join keys lexicographically in the result DataFrame. 
    suffixes : 2-length sequence (tuple, list, ...)
        Suffix to apply to overlapping column names in the left and right side, 
    copy : boolean, default True
        If False, do not copy data unnecessarily
    indicator : boolean or string, default False
        If True, adds a column to output DataFrame called '_merge' with information 
        on the source of each row.eg 'left_only', 'right_only','both' 
    validate : string, default None
        If specified, checks if merge is of specified type.
        �'one_to_one' or '1:1': check if merge keys are unique in both left and right datasets.
        �'one_to_many' or '1:m': check if merge keys are unique in left dataset.
        �'many_to_one' or 'm:1': check if merge keys are unique in right dataset.
        �'many_to_many' or 'm:m': allowed, but does not result in checks.

#Type of joins
�one-to-one joins: for example when joining two DataFrame objects 
on their indexes (which must contain unique values)
�many-to-one joins: for example when joining an index (unique) to one or more                    
columns in a DataFrame
�many-to-many joins: joining columns on columns.

>>> A              >>> B
    lkey value        rkey value
0   foo  1            foo  5
1   bar  2            bar  6
2   baz  3            qux  7
3   foo  4            bar  8
#read above and split 
df = pd.read_clipboard() #lkey  value rkey  value.1
A = df.iloc[:,[0,1]]
B = df.iloc[:, [2,3]]
B.columns= [ B.columns[0], 'value'] #rename 

#note for below index-column joining, one can use 'join' as well 
>>> pd.merge(A, B,  left_on='value',right_index = True) #left column 'value' == right index
   value lkey  value_x rkey  value_y
0      1  foo        1  bar        6
1      2  bar        2  qux        7
2      3  baz        3  bar        8


>>> A.merge(B, left_index=True, right_index=True) #index joining 
  lkey  value_x rkey  value_y
0  foo        1  foo        5
1  bar        2  bar        6
2  baz        3  qux        7
3  foo        4  bar        8
>>> A.merge(B, left_index=True, right_index=True, how='outer')#does not matter 
  lkey  value_x rkey  value_y
0  foo        1  foo        5
1  bar        2  bar        6
2  baz        3  qux        7
3  foo        4  bar        8
>>> A.merge(B, left_on='lkey', right_on='rkey', how='outer') #column joining 
   lkey  value_x  rkey  value_y
0  foo   1        foo   5
1  foo   4        foo   5
2  bar   2        bar   6
3  bar   2        bar   8
4  baz   3        NaN   NaN
5  NaN   NaN      qux   7
>>> A.merge(B, left_on='lkey', right_on='rkey', how='inner')
  lkey  value_x rkey  value_y
0  foo        1  foo        5
1  foo        4  foo        5
2  bar        2  bar        6
3  bar        2  bar        8
>>> A.merge(B, left_on='lkey', right_on='rkey', how='left')
  lkey  value_x rkey  value_y
0  foo        1  foo      5.0
1  bar        2  bar      6.0
2  bar        2  bar      8.0
3  baz        3  NaN      NaN
4  foo        4  foo      5.0
>>> A.merge(B, left_on='lkey', right_on='rkey', how='right')
  lkey  value_x rkey  value_y
0  foo      1.0  foo        5
1  foo      4.0  foo        5
2  bar      2.0  bar        6
3  bar      2.0  bar        8
4  NaN      NaN  qux        7




#Example 
left = pd.DataFrame({'key1': ['K0', 'K0', 'K1', 'K2'],                      
        'key2': ['K0', 'K1', 'K0', 'K1'],                     
        'A': ['A0', 'A1', 'A2', 'A3'],                     
        'B': ['B0', 'B1', 'B2', 'B3']})
right = pd.DataFrame({'key1': ['K0', 'K1', 'K1', 'K2'],                      
        'key2': ['K0', 'K0', 'K0', 'K0'],                        
        'C': ['C0', 'C1', 'C2', 'C3'],                         
        'D': ['D0', 'D1', 'D2', 'D3']}) 
#multiple keys 
result = pd.merge(left, right, on=['key1', 'key2'])
>>> result
    A   B key1 key2   C   D
0  A0  B0   K0   K0  C0  D0
1  A2  B2   K1   K0  C1  D1
2  A2  B2   K1   K0  C2  D2

# With The merge indicator
pd.merge(left, right, on=['key1', 'key2'], indicator=True)





##DF - Joining on index 
DataFrame.join(other, on=None, how='left', lsuffix='', rsuffix='', sort=False)
    Join : this DF's index or column(if 'on' given) with 'other' index 
    'other' index values sud be similar to 'this' DF's index or column
    Efficiently Join multiple DataFrame objects by index at once by passing a list.
    Parameters:
        other : DataFrame, Series with name field set, or list of DataFrame
            Index should be similar to one of the columns in this one. 
            If a Series is passed, its name attribute must be set, 
            and that will be used as the column name in the resulting joined DataFrame
        on : column name, tuple/list of column names, or array-like
            Column(s) in the caller to join on the index in other, 
            otherwise joins index-on-index. 
            If multiples columns given, the passed DataFrame must have a MultiIndex. 
            Can pass an array as the join key if not already contained in the calling DataFrame. Like an Excel VLOOKUP operation
        how : {'left', 'right', 'outer', 'inner'}, default: 'left'
        How to handle the operation of the two objects.
            �left: use calling frame's index (or column if on is specified)
            �right: use other frame's index
            �outer: form union of calling frame's index (or column if on is specified) with other frame's index, and sort it lexicographically
            �inner: form intersection of calling frame's index (or column if on is specified) with other frame's index, preserving the order of the calling's one
        lsuffix : string
            Suffix to use from left frame's overlapping columns
        rsuffix : string
            Suffix to use from right frame's overlapping columns
        sort : boolean, default False
            Order result DataFrame lexicographically by the join key. 
            If False, the order of the join key depends on the join type (how keyword)
#Example 
left = pd.DataFrame({'A': ['A0', 'A1', 'A2'],                       
        'B': ['B0', 'B1', 'B2']},                     
        index=['K0', 'K1', 'K2'])


right = pd.DataFrame({'C': ['C0', 'C2', 'C3'],                      
    'D': ['D0', 'D2', 'D3']},                      
    index=['K0', 'K2', 'K3']) 

#index, index joining , default left (hence take only left's index)
#Note both index should be similar 
result = left.join(right)
>>> result
     A   B    C    D
K0  A0  B0   C0   D0
K1  A1  B1  NaN  NaN
K2  A2  B2   C2   D2

result = left.join(right, how='outer')
result = left.join(right, how='inner')

#Note, above can be implemented via merge as well 
result = pd.merge(left, right, left_index=True, right_index=True, how='outer')
result = pd.merge(left, right, left_index=True, right_index=True, how='inner');


##DF - Conversion and NA handling 
DataFrame.astype(dtype[, copy, errors])         Cast a pandas object to a specified dtype dtype. 
DataFrame.convert_objects([convert_dates, ...]) Deprecated. 
DataFrame.infer_objects()                       Attempt to infer better dtypes for object columns. 
DataFrame.copy([deep])                          Make a copy of this objects data. 

DataFrame.isna()        Return a boolean same-sized object indicating if the values are NA. 
DataFrame.notna()       Return a boolean same-sized object indicating if the values are not NA. 
pandas.isna(obj)        Detect missing values (NaN in numeric arrays, None/NaN in object arrays) 
pandas.isnull(obj)      Detect missing values (NaN in numeric arrays, None/NaN in object arrays) 
pandas.notna(obj)       Replacement for numpy.isfinite / -numpy.isnan which is suitable for use on object arrays. 
pandas.notnull(obj)     Replacement for numpy.isfinite / -numpy.isnan which is suitable for use on object arrays. 

DataFrame.dropna([axis, how, thresh, ...])      Return object with labels on given axis omitted where alternately any 
DataFrame.fillna([value, method, axis, ...])    Fill NA/NaN values using the specified method 
DataFrame.replace([to_replace, value, ...])     Replace values given in 'to_replace' with 'value'. 

DataFrame.astype(dtype, copy=True, errors='raise', **kwargs)
    Cast a pandas object to a specified dtype dtype.
    Parameters:
        dtype : data type, or dict of column name -> data type
        Use a numpy.dtype or Python type to cast entire pandas object to the same type. 
        Alternatively, use {col: dtype, ...}, where col is a column label 
    copy : bool, default True.
        Return a copy when copy=True 
    
#Example  
>>> ser = pd.Series([1, 2], dtype='int32')
>>> ser
0    1
1    2
dtype: int32
>>> ser.astype('int64')
0    1
1    2
dtype: int64


DataFrame.dropna(axis=0, how='any', thresh=None, subset=None, inplace=False)
    Return object with labels on given axis omitted 
    where alternately any or all of the data are missing
    Parameters:
        axis : {0 or 'index', 1 or 'columns'}, or tuple/list thereof
            Pass tuple or list to drop on multiple axes
        how : {'any', 'all'}
            �any : if any NA values are present, drop that label
            �all : if all values are NA, drop that label
        thresh : int, default None
            int value : require that many non-NA values
        subset : array-like
            Labels along other axis to consider, 
            e.g. if you are dropping rows these would be a list of columns to include
        inplace : boolean, default False
            If True, do operation inplace and return None.
#Example 
>>> df = pd.DataFrame([[np.nan, 2, np.nan, 0], [3, 4, np.nan, 1],
                        [np.nan, np.nan, np.nan, 5]],
                    columns=list('ABCD'))
>>> df
     A    B   C  D
0  NaN  2.0 NaN  0
1  3.0  4.0 NaN  1
2  NaN  NaN NaN  5
#Drop the columns where all elements are nan:
>>> df.dropna(axis=1, how='all')
     A    B  D
0  NaN  2.0  0
1  3.0  4.0  1
2  NaN  NaN  5
#Drop the columns where any of the elements is nan
>>> df.dropna(axis=1, how='any')
   D
0  0
1  1
2  5
#Drop the rows where all of the elements are nan 
#(there is no row to drop, so df stays the same):
>>> df.dropna(axis=0, how='all')
     A    B   C  D
0  NaN  2.0 NaN  0
1  3.0  4.0 NaN  1
2  NaN  NaN NaN  5


DataFrame.fillna(value=None, method=None, axis=None, 
            inplace=False, limit=None, downcast=None, **kwargs)
    Fill NA/NaN values using the specified method
    Parameters:
        value : scalar, dict, Series, or DataFrame
            Value to use to fill holes (e.g. 0), 
            alternately a dict/Series/DataFrame of values 
            specifying which value to use for each index (for a Series) 
            or column (for a DataFrame). 
            (values not in the dict/Series/DataFrame will not be filled). 
            This value cannot be a list.
        method : {'backfill', 'bfill', 'pad', 'ffill', None}, default None
            Method to use for filling holes in reindexed Series 
            pad / ffill: propagate last valid observation forward to next valid 
            backfill / bfill: use NEXT valid observation to fill gap
        axis : {0 or 'index', 1 or 'columns'}
        inplace : boolean, default False
            If True, fill in place. 
            
#Example 
>>> df = pd.DataFrame([[np.nan, 2, np.nan, 0],
                        [3, 4, np.nan, 1],
                        [np.nan, np.nan, np.nan, 5],
                        [np.nan, 3, np.nan, 4]],
                        columns=list('ABCD'))
>>> df
     A    B   C  D
0  NaN  2.0 NaN  0
1  3.0  4.0 NaN  1
2  NaN  NaN NaN  5
3  NaN  3.0 NaN  4
#Replace all NaN elements with 0s.
>>> df.fillna(0)
    A   B   C   D
0   0.0 2.0 0.0 0
1   3.0 4.0 0.0 1
2   0.0 0.0 0.0 5
3   0.0 3.0 0.0 4
#We can also propagate non-null values forward or backward.
>>> df.fillna(method='ffill') #forward
    A   B   C   D
0   NaN 2.0 NaN 0
1   3.0 4.0 NaN 1   #  |
2   3.0 4.0 NaN 5   #  v
3   3.0 3.0 NaN 4

#Replace all NaN elements in column 'A', 'B', 'C', and 'D', 
#with 0, 1, 2, and 3 respectively.
>>> values = {'A': 0, 'B': 1, 'C': 2, 'D': 3}
>>> df.fillna(value=values)
    A   B   C   D
0   0.0 2.0 2.0 0
1   3.0 4.0 2.0 1
2   0.0 1.0 2.0 5
3   0.0 3.0 2.0 4

#Only replace the first NaN element.
>>> df.fillna(value=values, limit=1)
    A   B   C   D
0   0.0 2.0 2.0 0
1   3.0 4.0 NaN 1
2   NaN 1.0 NaN 5
3   NaN 3.0 NaN 4


DataFrame.replace(to_replace=None, value=None, inplace=False, limit=None, regex=False, method='pad', axis=None)
    Replace values given in 'to_replace' with 'value'.
    Parameters:
        to_replace : str, regex, list, dict, Series, numeric, or None
            �str or regex:
                ?str: string exactly matching to_replace will be replaced with value
                ?regex: regexs matching to_replace will be replaced with value
            �list of str, regex, or numeric:
                ?First, if to_replace and value are both lists, they must be the same length.
                ?Second, if regex=True then all of the strings in both lists will be interpreted as regexs otherwise they will match directly. 
                This doesn't matter much for value since there are only a few possible substitution regexes you can use.
                ?str and regex rules apply as above.
            �dict:
                ?Nested dictionaries, e.g., {'a': {'b': nan}}, are read as follows: 
                look in column 'a' for the value 'b' and replace it with nan. 
                You can nest regular expressions as well. 
                Note that column names (the top-level dictionary keys in a nested dictionary) cannot be regular expressions.
                ?Keys map to column names and values map to substitution values. 
                You can treat this as a special case of passing two lists 
                except that you are specifying the column to search in.
            �None:
                ?This means that the regex argument must be a string, compiled regular expression, or list, dict, ndarray or Series of such elements. If value is also None then this must be a nested dictionary or Series.
        value : scalar, dict, list, str, regex, default None
            Value to use to fill holes (e.g. 0), alternately a dict of values specifying which value to use for each column (columns not in the dict will not be filled). Regular expressions, strings and lists or dicts of such objects are also allowed.
        inplace : boolean, default False
            If True, in place. Note: this will modify any other views on this object (e.g. a column from a DataFrame). Returns the caller if this is True.
        limit : int, default None
            Maximum size gap to forward or backward fill
        regex : bool or same types as to_replace, default False
            Whether to interpret to_replace and/or value as regular expressions. 
            If this is True then to_replace must be a string. 
            Otherwise, to_replace must be None because this parameter will be interpreted as a regular expression or a list, dict, or array of regular expressions.
        method : string, optional, {'pad', 'ffill', 'bfill'}
            The method to use when for replacement, when to_replace is a list
        
#Example 
>>> data
   resp          A          B          C
0     1       poor       poor       good
1     2       good       poor       good
2     3  very_good  very_good  very_good
3     4       bad        poor       bad 
4     5   very_bad   very_bad   very_bad
5     6       poor       good   very_bad
6     7       good       good       good
7     8  very_good  very_good  very_good
8     9       bad        bad    very_bad
9    10   very_bad   very_bad   very_bad

#
data.replace({'very_bad': 1, 'bad': 2, 'poor': 3, 'good': 4, 'very_good': 5}, inplace=True)
#or 
>>> data.replace(['very_bad', 'bad', 'poor', 'good', 'very_good'], [1, 2, 3, 4, 5]) 
      resp  A  B  C
   0     1  3  3  4
   1     2  4  3  4
   2     3  5  5  5
   3     4  2  3  2
   4     5  1  1  1
   5     6  3  4  1
   6     7  4  4  4
   7     8  5  5  5
   8     9  2  2  1
   9    10  1  1  1
   

##DF - sorting, filter, drop, idxmax, truncate 
DataFrame.sort_values(by[, axis, ascending, ...])   Sort by the values along either axis 
DataFrame.sort_index([axis, level, ...])            Sort object by labels (along an axis) 
DataFrame.nlargest(n, columns[, keep])              Get the rows of a DataFrame sorted by the n largest values of columns. 
DataFrame.nsmallest(n, columns[, keep])             Get the rows of a DataFrame sorted by the n smallest values of columns. 
DataFrame.swaplevel([i, j, axis])                   Swap levels i and j in a MultiIndex on a particular axis 
DataFrame.T                                         Transpose index and columns 
DataFrame.to_xarray()                               Return an xarray object from the pandas object. 
DataFrame.transpose(*args, **kwargs)                Transpose index and columns 

DataFrame.add_prefix(prefix)                        Concatenate prefix string with panel items names. 
DataFrame.add_suffix(suffix)                        Concatenate suffix string with panel items names. 
DataFrame.align(other[, join, axis, level, ...])    Align two objects on their axes with the 
DataFrame.drop([labels, axis, index, ...])          Return new object with labels in requested axis removed. 
DataFrame.equals(other)                             Determines if two NDFrame objects contain the same elements. 

DataFrame.idxmax([axis, skipna])                    Return index of first occurrence of maximum over requested axis. 
DataFrame.idxmin([axis, skipna])                    Return index of first occurrence of minimum over requested axis. 

DataFrame.filter([items, like, regex, axis])        Subset rows or columns of dataframe according to labels in the specified index. 
DataFrame.first(offset)                             Convenience method for subsetting initial periods of time series data based on a date offset. ts.first('10D') -> First 10 days
DataFrame.head([n])                                 Return the first n rows. 
DataFrame.last(offset)                              Convenience method for subsetting final periods of time series data based on a date offset. 
DataFrame.tail([n])                                 Return the last n rows. 
DataFrame.take(indices[, axis, convert, is_copy])   Return the elements in the given positional indices along an axis. 
DataFrame.truncate([before, after, axis, copy])     Truncates a sorted DataFrame/Series before and/or after some particular index value. 


DataFrame.sort_values(by, axis=0, ascending=True, inplace=False, 
        kind='quicksort', na_position='last')
    Sort by the values along either axis
    Parameters:
    by : str or list of str
        Name or list of names which refer to the axis items.
    axis : {0 or 'index', 1 or 'columns'}, default 0=index =columnwise 
        Axis to direct sorting
    ascending : bool or list of bool, default True
        Sort ascending vs. descending. Specify list for multiple sort orders. 
        If this is a list of bools, must match the length of the by.
    inplace : bool, default False
        if True, perform operation in-place
    kind : {'quicksort', 'mergesort', 'heapsort'}, default 'quicksort'
    na_position : {'first', 'last'}, default 'last'
        first puts NaNs at the beginning, last puts NaNs at the end
 
 
#Examples
>>> df = pd.DataFrame({
        'col1' : ['A', 'A', 'B', np.nan, 'D', 'C'],
        'col2' : [2, 1, 9, 8, 7, 4],
        'col3': [0, 1, 9, 4, 2, 3],
    })
>>> df
    col1 col2 col3
0   A    2    0
1   A    1    1
2   B    9    9
3   NaN  8    4
4   D    7    2
5   C    4    3
>>> df.sort_values(by=['col1']) #axis=0 ie columnwise 
    col1 col2 col3
0   A    2    0
1   A    1    1
2   B    9    9
5   C    4    3
4   D    7    2
3   NaN  8    4
#Sort by multiple columns
>>> df.sort_values(by=['col1', 'col2'])
    col1 col2 col3
1   A    1    1
0   A    2    0
2   B    9    9
5   C    4    3
4   D    7    2
3   NaN  8    4
>>> df.sort_values(by=['col1', 'col2'],ascending=[True,False])
  col1  col2  col3
0    A     2     0
1    A     1     1
2    B     9     9
5    C     4     3
4    D     7     2
3  NaN     8     4


DataFrame.nlargest(n, columns, keep='first')
    Get the rows of a DataFrame sorted by the n largest values of columns.
    Parameters:
    n : int
        Number of items to retrieve
    columns : list or str
        Column name or names to order by
    keep : {'first', 'last'}, default 'first'
        Where there are duplicate values: 
        - first : take the first occurrence. 
        - last : take the last occurrence.
 
#Examples
>>> df = DataFrame({'a': [1, 10, 8, 11, -1],
                    'b': list('abdce'),
                    'c': [1.0, 2.0, np.nan, 3.0, 4.0]})
>>> df.nlargest(3, 'a')
    a  b   c
3  11  c   3
1  10  b   2
2   8  d NaN




DataFrame.truncate(before=None, after=None, axis=None, copy=True)
    Truncates a sorted DataFrame/Series 
    before and/or after some particular index value. 
    If the axis contains only datetime values, 
    before/after parameters are converted to datetime values.
    Parameters:
        before : date, string, int
            Truncate all rows before this index value
        after : date, string, int
            Truncate all rows after this index value
        axis : {0 or 'index', 1 or 'columns'}
            �0 or 'index': apply truncation to rows
            �1 or 'columns': apply truncation to columns
        copy : boolean, default is True,
            return a copy of the truncated section
 
 
#Examples
>>> df = pd.DataFrame({'A': ['a', 'b', 'c', 'd', 'e'],
                        'B': ['f', 'g', 'h', 'i', 'j'],
                        'C': ['k', 'l', 'm', 'n', 'o']},
                        index=[1, 2, 3, 4, 5])
>>> df.truncate(before=2, after=4) #from 2 to 4 inclusive 
   A  B  C
2  b  g  l
3  c  h  m
4  d  i  n
>>> df = pd.DataFrame({'A': [1, 2, 3, 4, 5],
                        'B': [6, 7, 8, 9, 10],
                        'C': [11, 12, 13, 14, 15]},
                        index=['a', 'b', 'c', 'd', 'e'])
>>> df.truncate(before='b', after='d')
   A  B   C
b  2  7  12
c  3  8  13
d  4  9  14

>>> dates = pd.date_range('2016-01-01', '2016-02-01', freq='s') #'s' = second 
>>> df = pd.DataFrame(index=dates, data={'A': 1})
#note the difference 
>>> df.truncate('2016-01-05', '2016-01-10').tail()
                     A
2016-01-09 23:59:56  1
2016-01-09 23:59:57  1
2016-01-09 23:59:58  1
2016-01-09 23:59:59  1
2016-01-10 00:00:00  1  
>>> df.loc['2016-01-05':'2016-01-10', :].tail()
                     A
2016-01-10 23:59:55  1
2016-01-10 23:59:56  1
2016-01-10 23:59:57  1
2016-01-10 23:59:58  1
2016-01-10 23:59:59  1




DataFrame.take(indices, axis=0, convert=None, is_copy=True, **kwargs)
    Return the elements in the given positional indices along an axis.
    similar to iloc indexing 
    Parameters:
    indices : array-like
        An array of ints indicating which positions to take.
    axis : int, default 0
        The axis on which to select elements. 
        '0' means that we are selecting rows, 
        '1' means that we are selecting columns, etc.
    convert : bool, default True
        For example, -1 would map to the len(axis) - 1. 
    is_copy : bool, default True
        Whether to return a copy of the original object or not.
 

 
#Examples
>>> df = pd.DataFrame([('falcon', 'bird',    389.0),
                       ('parrot', 'bird',     24.0),
                       ('lion',   'mammal',   80.5),
                       ('monkey', 'mammal', np.nan)],
                      columns=('name', 'class', 'max_speed'),
                      index=[0, 2, 3, 1])
>>> df
     name   class  max_speed
0  falcon    bird      389.0
2  parrot    bird       24.0
3    lion  mammal       80.5
1  monkey  mammal        NaN
#0th index, 3rd index 
>>> df.take([0, 3])
0  falcon    bird      389.0
1  monkey  mammal        NaN
#Take elements at indices 1 and 2 along the axis 1 (column selection).
>>> df.take([1, 2], axis=1)
    class  max_speed
0    bird      389.0
2    bird       24.0
3  mammal       80.5
1  mammal        NaN
We may take elements using negative integers for positive indices, starting from the end of the object, just like with Python lists.
>>> df.take([-1, -2])
     name   class  max_speed
1  monkey  mammal        NaN
3    lion  mammal       80.5



DataFrame.idxmax(axis=0, skipna=True)
    Return index of first occurrence of maximum over requested axis. 
    NA/null values are excluded.
    Parameters:
        axis : {0 or 'index', 1 or 'columns'}, default 0
            0 or 'index' for columnwise, 1 or 'columns' for row-wise
        skipna : boolean, default True
            Exclude NA/null values. 
            If an entire row/column is NA, the result will be NA.
     
#Example 
>>> df1
          A         B         C         D
a  0.659510 -0.067171  1.849775  0.232036
b  0.806557  0.327022  1.269242 -0.021473
c -1.063328  0.587773  1.571305 -0.618556
d  1.443707 -1.259372  0.258808  1.464349
e -1.529423 -2.167431 -0.846262 -2.248487
f  0.997932 -2.210722  0.415821 -1.012406
#result is pandas.core.series.Series
>>> df1.idxmax(axis=0) #columnwise ie in each column , index of max value 
A    d
B    c
C    a
D    d
dtype: object
>>> s['A']
'd'
>>> s.index
Index(['A', 'B', 'C', 'D'], dtype='object')
>>> s.index[0]
'A'
>>> df1.at[ s[s.index[0]], s.index[0]]
1.443707
>>> df1.idxmax(axis=1) #rowwise ie in each row, column name for max value 
a    C
b    C
c    C
d    D
e    C
f    A
dtype: object



DataFrame.filter(items=None, like=None, regex=None, axis=None)
    Note that this routine does not filter a dataframe on its contents. 
    The filter is applied to the labels of the index.
    Parameters:
        items : list-like
            List of info axis to restrict to (must not all be present)
        like : string
            Keep info axis where 'arg in col == True'
        regex : string (regular expression)
            Keep info axis with re.search(regex, col) == True
        axis : int or string axis name
            The axis to filter on. By default this is 'index' for Series, 
            'columns' for DataFrame
     
 
#Examples
>>> df
        one  two  three
mouse     1    2      3
rabbit    4    5      6
# select columns by name
>>> df.filter(items=['one', 'three'])
        one  three
mouse     1      3
rabbit    4      6
# select columns by regular expression
>>> df.filter(regex='e$', axis=1)
        one  three
mouse     1      3
rabbit    4      6
# select rows containing 'bbi'
>>> df.filter(like='bbi', axis=0)
        one  two  three
rabbit    4    5      6



DataFrame.drop(labels=None, axis=0, index=None, 
            columns=None, level=None, inplace=False, errors='raise')
    Return new object with labels in requested axis removed.
    Parameters:
        labels : single label or list-like
            Index or column labels to drop.
        axis : int or axis name
            Whether to drop labels from the index (0 / 'index') or columns (1 / 'columns').
        index, columns : single label or list-like
            Alternative to specifying axis 
            (labels, axis=1 is equivalent to columns=labels).
        level : int or level name, default None
        For MultiIndex
        inplace : bool, default False
            If True, do operation inplace and return None.
        errors : {'ignore', 'raise'}, default 'raise'
            If 'ignore', suppress error and existing labels are dropped.
 
#Examples
>>> df = pd.DataFrame(np.arange(12).reshape(3,4),
                      columns=['A', 'B', 'C', 'D'])
>>> df
   A  B   C   D
0  0  1   2   3
1  4  5   6   7
2  8  9  10  11
#Drop columns
>>> df.drop(['B', 'C'], axis=1)
   A   D
0  0   3
1  4   7
2  8  11
>>> df.drop(columns=['B', 'C'])
   A   D
0  0   3
1  4   7
2  8  11
#Drop a row by index
>>> df.drop([0, 1])
   A  B   C   D
2  8  9  10  11


##DF - stats 
DataFrame.abs() Return an object with absolute value taken�only applicable to objects that are all numeric. 
DataFrame.all([axis, bool_only, skipna, level]) Return whether all elements are True over requested axis 
DataFrame.any([axis, bool_only, skipna, level]) Return whether any element is True over requested axis 
DataFrame.clip([lower, upper, axis, inplace])   Trim values at input threshold(s). 
DataFrame.clip_lower(threshold[, axis, inplace]) Return copy of the input with values below given value(s) truncated. 
DataFrame.clip_upper(threshold[, axis, inplace]) Return copy of input with values above given value(s) truncated. 
DataFrame.corr([method, min_periods])           Compute pairwise correlation of columns, excluding NA/null values 
DataFrame.corrwith(other[, axis, drop])         Compute pairwise correlation between rows or columns of two DataFrame objects. 
DataFrame.count([axis, level, numeric_only])    Return Series with number of non-NA/null observations over requested axis. 
DataFrame.cov([min_periods])                    Compute pairwise covariance of columns, excluding NA/null values 
DataFrame.cummax([axis, skipna])                Return cumulative max over requested axis. 
DataFrame.cummin([axis, skipna])                Return cumulative minimum over requested axis. 
DataFrame.cumprod([axis, skipna])               Return cumulative product over requested axis. 
DataFrame.cumsum([axis, skipna])                Return cumulative sum over requested axis. 
DataFrame.describe([percentiles, include, ...]) Generates descriptive statistics that summarize the central tendency, dispersion and shape of a dataset's distribution, excluding NaN values. 
DataFrame.diff([periods, axis])                 1st discrete difference of object 
DataFrame.eval(expr[, inplace])                 Evaluate an expression in the context of the calling DataFrame instance. 
DataFrame.kurt([axis, skipna, level, ...])      Return unbiased kurtosis over requested axis using Fisher's definition of kurtosis (kurtosis of normal == 0.0). 
DataFrame.mad([axis, skipna, level])            Return the mean absolute deviation of the values for the requested axis 
DataFrame.max([axis, skipna, level, ...])       This method returns the maximum of the values in the object. 
DataFrame.mean([axis, skipna, level, ...])      Return the mean of the values for the requested axis 
DataFrame.median([axis, skipna, level, ...])    Return the median of the values for the requested axis 
DataFrame.min([axis, skipna, level, ...])       This method returns the minimum of the values in the object. 
DataFrame.mode([axis, numeric_only])            Gets the mode(s) of each element along the axis selected. 
DataFrame.pct_change([periods, fill_method, ...]) Percent change over given number of periods. 
DataFrame.prod([axis, skipna, level, ...])      Return the product of the values for the requested axis 
DataFrame.quantile([q, axis, numeric_only, ...]) Return values at the given quantile over requested axis, a la numpy.percentile. 
DataFrame.rank([axis, method, numeric_only, ...]) Compute numerical data ranks (1 through n) along axis. 
DataFrame.round([decimals])                     Round a DataFrame to a variable number of decimal places. 
DataFrame.sem([axis, skipna, level, ddof, ...]) Return unbiased standard error of the mean over requested axis. 
DataFrame.skew([axis, skipna, level, ...])      Return unbiased skew over requested axis 
DataFrame.sum([axis, skipna, level, ...])       Return the sum of the values for the requested axis 
DataFrame.std([axis, skipna, level, ddof, ...]) Return sample standard deviation over requested axis. 
DataFrame.var([axis, skipna, level, ddof, ...]) Return unbiased variance over requested axis. 



DataFrame.all(axis=None, bool_only=None, skipna=None, level=None, **kwargs)
    Return whether all elements are True over requested axis
    Parameters:
        axis : {index (0) ie columnwise, columns (1)ie rowise}
        default 0
    skipna : boolean, default True
        Exclude NA/null values. 
        If an entire row/column is NA, the result will be NA
    level : int or level name, default None
        If the axis is a MultiIndex (hierarchical), 
        count along a particular level, collapsing into a Series
    bool_only : boolean, default None
        Include only boolean columns. 
        If None, will attempt to use everything, then use only boolean data. Not implemented for Series.
#Example 
import pandas as pd
df = pd.DataFrame()
df['x'] = [1,2,3]
df['y'] = [3,4,5]
print (df['x'] < df['y']).all() # '<' returns series 
print (df['x'] < df['y']).any() #

>>> df.all()
x    True
y    True
dtype: bool
>>> df.all(axis=0)
x    True
y    True
dtype: bool
>>> df.all(axis=1)
0    True
1    True
2    True
dtype: bool



##DF - Duplicate Data 
DataFrame.duplicated(subset=None, keep='first')
    returns a boolean vector whose length is the number of rows,
    and which indicates whether a row is duplicated.
DataFrame.drop_duplicates(subset=None, keep='first', inplace=False)
    Return DataFrame with duplicate rows removed, 
    Parameters:
    subset : column label or sequence of labels, optional
        Only consider certain columns for identifying duplicates, 
        by default use all of the columns
    keep : {'first', 'last', False}, default 'first'
        �first : Drop duplicates except for the first occurrence.
        �last : Drop duplicates except for the last occurrence.
        �False : Drop all duplicates.
    inplace : boolean, default False
        Whether to drop duplicates in place or to return a copy

#Example 
df2 = pd.DataFrame({'a': ['one', 'one', 'two', 'two', 'two', 'three', 'four'],                        
            'b': ['x', 'y', 'x', 'y', 'x', 'x', 'x'],                        
            'c': np.random.randn(7)})  
>>> df2
       a  b         c
0    one  x  0.340520
1    one  y -0.252382
2    two  x -1.206215
3    two  y  1.233196
4    two  x  1.671173
5  three  x  0.120314
6   four  x  0.779461

>>> df2.duplicated('a')
0    False
1     True
2    False
3     True
4     True
5    False
6    False
dtype: bool

>>> df2.duplicated('a', keep='last')
0     True
1    False
2     True
3     True
4    False
5    False
6    False
dtype: bool

>>> df2.duplicated('a', keep=False)
0     True
1     True
2     True
3     True
4     True
5    False
6    False
dtype: bool

>>> df2.drop_duplicates('a')
       a  b         c
0    one  x  0.340520
2    two  x -1.206215
5  three  x  0.120314
6   four  x  0.779461





##Pandas - GroupBy 
##Group-by - split-apply-combine
�Splitting the data into groups based on some criteria
�Applying a function to each group independently
    Aggregation
    Transformation
    Filtration
�Combining the results into a data structure


##Understanding key 
# default is axis=0,columnwise
>>> grouped = obj.groupby(key)
>>> grouped = obj.groupby(key, axis=1)
>>> grouped = obj.groupby([key1, key2])

#key can be 
    �A Python function, to be called on the axis labels(axis=0, with Index, axis=1, with Columns)
    �A list or NumPy array of the same length as the selected axis
    �A dict or Series, providing a label -> group name mapping
    �For DataFrame objects, a string indicating a column to be used to group. 
     df.groupby('A') is just syntactic sugar for df.groupby(df['A']), 
    �For DataFrame objects, a string indicating an index level to be used to group.
    �A list of any of the above things
    �A Grouper object 


    
DataFrame.groupby(by=None, axis=0, level=None, as_index=True, sort=True, group_keys=True, squeeze=False, **kwargs)
    Returns DataFrameGroupBy or SeriesGroupBy
    When aggregation function is applied on returned type,
    final return would be DataFrame or Series respectively 
    Parameters:
    by : mapping, function, str, or iterable
        Used to determine the groups for the groupby. 
        If by is a function, it's called on each value of the object's index. 
        If a dict or Series is passed, 
        the Series or dict VALUES will be used to determine the groups 
        (the Series' values are first aligned; see .align() method). 
        If an ndarray is passed, the values are used as-is determine the groups. 
        A str or list of strs may be passed to group by the columns in self
    axis : int, default 0(index, columnwise)
    level : int, level name, or sequence of such, default None
        If the axis is a MultiIndex (hierarchical), group by a particular level or levels
    as_index : boolean, default True
        For aggregated output, return object with group labels as the index. 
        Only relevant for DataFrame input. as_index=False is effectively "SQL-style' grouped output
    sort : boolean, default True
        Sort group keys. Get better performance by turning this off. 
    group_keys : boolean, default True
        When calling apply, add group keys to index to identify pieces
    squeeze : boolean, default False
        reduce the dimensionality of the return type if possible, 
        otherwise return a consistent type
 
#Example 
#DataFrame results
>>> data.groupby(func, axis=0).mean()
>>> data.groupby(['col1', 'col2'])['col3'].mean() #
#Example 
df = pd.read_excel("./data/sales_transactions.xlsx")
>>> df.groupby('order').mean()
        account  quantity  unit price  ext price
order
10001  383080.0      7.00   30.266667   192.0400
10005  412290.0     31.60   53.264000  1637.0980
10006  218895.0     14.25   65.672500   931.1225
>>> df.groupby('order')["ext price"].mean() #returntype is Series
order
10001     192.0400
10005    1637.0980
10006     931.1225
Name: ext price, dtype: float64
>>> df.groupby('order')[["ext price"]].mean() #return type ise Dataframe 
       ext price
order
10001   192.0400
10005  1637.0980
10006   931.1225
>>> g =df.groupby('order')
>>> g.groups
{10001: Int64Index([0, 1, 2], dtype='int64'), 10005: Int64Index
 dtype='int64'), 10006: Int64Index([8, 9, 10, 11], dtype='int64
>>> g.indices
{10001: array([0, 1, 2], dtype=int64), 10005: array([3, 4, 5, 6
), 10006: array([ 8,  9, 10, 11], dtype=int64)}
>>> g.ngroup()  #row_index vs group_index 
0     0
1     0
2     0
3     1
4     1
5     1
6     1
7     1
8     2
9     2
10    2
11    2
dtype: int64
>>> g.size() #group size
order
10001    3
10005    5
10006    4
dtype: int64



#Q= "What percentage of the order total does each sku represent?"
#First Approach - Merging(joining like SQL JOIN)
#Series with index =order 
>>> df.groupby('order')["ext price"].sum().rename("Order_Total")
order
10001     576.12
10005    8185.49
10006    3724.49
Name: Order_Total, dtype: float64

>>> df.groupby('order')["ext price"].sum().rename("Order_Total").reset_index()
   order  Order_Total
0  10001       576.12
1  10005      8185.49
2  10006      3724.49

#how to combine this data back with the original dataframe. 
order_total = df.groupby('order')["ext price"].sum().rename("Order_Total").reset_index()
df_1 = df.merge(order_total, on='order')
>>> df_1.head(3)
   account      name  order       sku  quantity  unit price  ext price  \
0   383080  Will LLC  10001  B1-20000         7       33.69     235.83
1   383080  Will LLC  10001  S1-27722        11       21.12     232.32
2   383080  Will LLC  10001  B1-86481         3       35.99     107.97

   Order_Total
0       576.12
1       576.12
2       576.12
df_1["Percent_of_Order"] = df_1["ext price"] / df_1["Order_Total"]


#Second Approach - Using Transform
>>> df.groupby('order')["ext price"]
<pandas.core.groupby.SeriesGroupBy object at 0x00000093AC67B978>
>>> df.groupby('order')["ext price"].transform('sum')
0      576.12
1      576.12
2      576.12
3     8185.49
4     8185.49
5     8185.49
6     8185.49
7     8185.49
8     3724.49
9     3724.49
10    3724.49
11    3724.49
Name: ext price, dtype: float64

df["Order_Total"] = df.groupby('order')["ext price"].transform('sum')
df["Percent_of_Order"] = df["ext price"] / df["Order_Total"]



##GroupBy Objects -Indexing, iteration
GroupBy.__iter__()                       Groupby iterator 
GroupBy.groups                          dict {group name -> group labels} 
GroupBy.indices                         dict {group name -> group indices} 
GroupBy.get_group(name[, obj])          Constructs NDFrame from group with provided name 

##GroupBy Objects -Function application
GroupBy.apply(func, *args, **kwargs)        Apply function func group-wise and combine the results together. 
GroupBy.aggregate(func, *args, **kwargs)  
GroupBy.transform(func, *args, **kwargs)  
GroupBy.pipe(func, *args, **kwargs)         Apply a function with arguments to this GroupBy object, 

##GroupBy Objects -Computations / Descriptive Stats
GroupBy.count()                 Compute count of group, excluding missing values 
GroupBy.cumcount([ascending])   Number each item in each group from 0 to the length of that group - 1. 
GroupBy.first(**kwargs)         Compute first of group values 
GroupBy.head([n])               Returns first n rows of each group. 
GroupBy.last(**kwargs)          Compute last of group values 
GroupBy.max(**kwargs)           Compute max of group values 
GroupBy.mean(*args, **kwargs)   Compute mean of groups, excluding missing values 
GroupBy.median(**kwargs)        Compute median of groups, excluding missing values 
GroupBy.min(**kwargs)           Compute min of group values 

GroupBy.ngroup([ascending])     Number each group from 0 to the number of groups - 1. 
GroupBy.nth(n[, dropna])        Take the nth row from each group if n is an int, or a subset of rows if n is a list of ints. 
GroupBy.ohlc()                  Compute sum of values, excluding missing values 
GroupBy.prod(**kwargs)          Compute prod of group values 
GroupBy.size()                  Compute group sizes 
GroupBy.sem([ddof])             Compute standard error of the mean of groups, excluding missing values 
GroupBy.std([ddof])             Compute standard deviation of groups, excluding missing values 
GroupBy.sum(**kwargs)           Compute sum of group values 
GroupBy.var([ddof])             Compute variance of groups, excluding missing values 
GroupBy.tail([n])               Returns last n rows of each group 

#For both SeriesGroupBy and DataFrameGroupBy objects
#in DataFrameGroupBy version usually permits the specification of an axis argument, 
#and often an argument indicating whether to restrict application to columns of a specific data type.

DataFrameGroupBy.agg(arg, *args, **kwargs)  Aggregate using callable, string, dict, or list of string/callables 
DataFrameGroupBy.all                        Return whether all elements are True over requested axis 
DataFrameGroupBy.any                        Return whether any element is True over requested axis 
DataFrameGroupBy.bfill([limit])             Backward fill the values 
DataFrameGroupBy.corr                       Compute pairwise correlation of columns, excluding NA/null values 
DataFrameGroupBy.count()                    Compute count of group, excluding missing values 
DataFrameGroupBy.cov                        Compute pairwise covariance of columns, excluding NA/null values 
DataFrameGroupBy.cummax([axis])             Cumulative max for each group 
DataFrameGroupBy.cummin([axis])             Cumulative min for each group 
DataFrameGroupBy.cumprod([axis])            Cumulative product for each group 
DataFrameGroupBy.cumsum([axis])             Cumulative sum for each group 

DataFrameGroupBy.describe(**kwargs)         Generates descriptive statistics that summarize the central tendency, dispersion and shape of a dataset's distribution, excluding NaN values. 
DataFrameGroupBy.diff                       1st discrete difference of object 
DataFrameGroupBy.ffill([limit])             Forward fill the values 
DataFrameGroupBy.fillna                     Fill NA/NaN values using the specified method 
DataFrameGroupBy.filter(func[, dropna])     Return a copy of a DataFrame excluding elements from groups that do not satisfy the boolean criterion specified by func. 

DataFrameGroupBy.idxmax                     Return index of first occurrence of maximum over requested axis. 
DataFrameGroupBy.idxmin                     Return index of first occurrence of minimum over requested axis. 
DataFrameGroupBy.mad                        Return the mean absolute deviation of the values for the requested axis 
DataFrameGroupBy.pct_change                 Percent change over given number of periods. 

DataFrameGroupBy.plot                       Class implementing the .plot attribute for groupby objects 
DataFrameGroupBy.hist                       Draw histogram of the DataFrame's series using matplotlib / pylab. 

DataFrameGroupBy.quantile                   Return values at the given quantile over requested axis, a la numpy.percentile. 
DataFrameGroupBy.rank                       Compute numerical data ranks (1 through n) along axis. 
DataFrameGroupBy.resample(rule, *args, **kwargs) Provide resampling when using a TimeGrouper 

DataFrameGroupBy.shift([periods, freq, axis])   Shift each group by periods observations 
DataFrameGroupBy.size()                         Compute group sizes 
DataFrameGroupBy.skew                           Return unbiased skew over requested axis 
DataFrameGroupBy.take                           Return the elements in the given positional indices along an axis. 
DataFrameGroupBy.tshift                         Shift the time index, using the index's frequency if available. 

##for SeriesGroupBy objects.
SeriesGroupBy.nlargest          Return the largest n elements. 
SeriesGroupBy.nsmallest         Return the smallest n elements. 
SeriesGroupBy.nunique([dropna]) Returns number of unique elements in the group 
SeriesGroupBy.unique            Return unique values in the object. 
SeriesGroupBy.value_counts([normalize, ...])  

##for DataFrameGroupBy objects.
DataFrameGroupBy.corrwith                   Compute pairwise correlation between rows or columns of two DataFrame objects. 
DataFrameGroupBy.boxplot(grouped[, ...])    Make box plots from DataFrameGroupBy data. 


##String acceptable for apply 
_common_apply_whitelist = frozenset([
    'last', 'first',
    'head', 'tail', 'median',
    'mean', 'sum', 'min', 'max',
    'cumcount', 'ngroup',
    'resample',
    'rank', 'quantile',
    'fillna',
    'mad',
    'any', 'all',
    'take',
    'idxmax', 'idxmin',
    'shift', 'tshift',
    'ffill', 'bfill',
    'pct_change', 'skew',
    'corr', 'cov', 'diff',
]) | _plotting_methods

_series_apply_whitelist = ((_common_apply_whitelist |
                            {'nlargest', 'nsmallest'}) -
                           {'boxplot'}) | frozenset(['dtype', 'unique'])

_dataframe_apply_whitelist = ((_common_apply_whitelist |
                              frozenset(['dtypes', 'corrwith'])) -
                              {'boxplot'})

##String acceptable for transforms                       
_cython_transforms = frozenset(['cumprod', 'cumsum', 'shift',
                                'cummin', 'cummax'])
                                
##String acceptable for aggregate                          
'aggregate': {
            'add': 'group_add',
            'prod': 'group_prod',
            'min': 'group_min',
            'max': 'group_max',
            'mean': 'group_mean',
            'median': {
                'name': 'group_median'
            },
            'var': 'group_var',
            'first': {
                'name': 'group_nth',
                'f': lambda func, a, b, c, d, e: func(a, b, c, d, 1, -1)
            },
            'last': 'group_last',
            'ohlc': 'group_ohlc',
        },
        
        
        
        
DataFrameGroupBy.agg(arg, *args, **kwargs)
    Aggregate using callable, string, dict, or list of string/callables
    Check further description from DataFrame.aggregate
    Parameters:
    func : callable, string, dictionary, or list of string/callables
        Accepted Combinations are:
        �string function name
        �function
        �list of functions
        �dict of column names -> functions (or list of functions)
 
#Examples
>>> df = pd.DataFrame({'A': [1, 1, 2, 2],
                    'B': [1, 2, 3, 4],
                    'C': np.random.randn(4)})
>>> df
   A  B         C
0  1  1  0.362838
1  1  2  0.227877
2  2  3  1.267767
3  2  4 -0.562860

#The aggregation is for each column.
>>> df.groupby('A').agg('min')
   B         C
A
1  1  0.227877
2  3 -0.562860
#Multiple aggregations
>>> df.groupby('A').agg(['min', 'max'])
    B             C
  min max       min       max
A
1   1   2  0.227877  0.362838
2   3   4 -0.562860  1.267767

#Select a column for aggregation
>>> df.groupby('A').B.agg(['min', 'max'])
   min  max
A
1    1    2
2    3    4

#Different aggregations per column
>>> df.groupby('A').agg({'B': ['min', 'max'], 'C': 'sum'})
    B             C
  min max       sum
A
1   1   2  0.590716
2   3   4  0.704907







GroupBy.apply(func, *args, **kwargs)
    Apply function func group-wise and combine the results together.
    The function passed to apply must take a dataframe as its first argument 
    and return a dataframe, a series or a scalar. 
    apply will then take care of combining the results back together into a single dataframe or series. 
    apply is therefore a highly flexible grouping method.
    Parameters:
        func : function
            A callable that takes a dataframe as its first argument, 
            and returns a dataframe, a series or a scalar. 
            In addition the callable may take positional and keyword arguments
        args, kwargs : tuple and dict
            Optional positional and keyword arguments to pass to func
 

#In the current implementation apply calls func twice on the first group to decide 
#whether it can take a fast or slow code path. 
#Examples
>>> df = pd.DataFrame({'A': 'a a b'.split(), 'B': [1,2,3], 'C': [4,6, 5]})
>>> g = df.groupby('A')

#Example 1: below the function passed to apply takes a dataframe as its argument 
#and returns a dataframe. 
#apply combines the result for each group together into a new dataframe:
>>> g.apply(lambda x: x / x.sum())
          B    C
0  0.333333  0.4
1  0.666667  0.6
2  1.000000  1.0

#Example 2: The function passed to apply takes a dataframe as its argument 
#and returns a series. 
#apply combines the result for each group together into a new dataframe:
>>> g.apply(lambda x: x.max() - x.min())
   B  C
A
a  1  2
b  0  0

#Example 3: The function passed to apply takes a dataframe as its argument 
#and returns a scalar. 
#apply combines the result for each group together into a series, 
#including setting the index as appropriate:
>>> g.apply(lambda x: x.C.max() - x.B.min())
A
a    5
b    2
dtype: int64



GroupBy.pipe(func, *args, **kwargs)
    Apply a function with arguments to this GroupBy object,
    Parameters:
    func : callable or tuple of (callable, string)
        Function to apply to this GroupBy object or, 
        alternatively, a (callable, data_keyword) tuple 
        where data_keyword is a string indicating the keyword of callable that expects the GroupBy object.
    args : iterable, optional
        positional arguments passed into func.
    kwargs : dict, optional
        a dictionary of keyword arguments passed into func.
 
#Use .pipe when chaining together functions that expect Series, DataFrames or GroupBy objects. 
#Instead of writing
>>> f(g(h(df.groupby('group')), arg1=a), arg2=b, arg3=c)
#You can write
>>> (df
        .groupby('group')
        .pipe(f, arg1)
        .pipe(g, arg2)
        .pipe(h, arg3))
        
        

>>> df = pd.DataFrame({'A': 'a b a b'.split(), 'B': [1, 2, 3, 4]})
>>> df
   A  B
0  a  1
1  b  2
2  a  3
3  b  4


#To get the difference between each groups maximum and minimum value in one pass, you can do
>>> df.groupby('A').pipe(lambda x: x.max() - x.min())
   B
A
a  2
b  2

##Difference between pipe and apply 

#The main difference between what you can do with a pipe in a groupby context is that 
#you have available to the callable the entire scope of the the groupby object. 
#For apply, you only know about the local slice-slices of the dataframe that called groupby where each slice is a dataframe itself


df = pd.DataFrame(dict(
    A=list('XXXXYYYYYY'),
    B=range(10)
))

   A  B
0  X  0
1  X  1
2  X  2
3  X  3
4  Y  4
5  Y  5
6  Y  6
7  Y  7
8  Y  8
9  Y  9

#Example 1
#Make the entire 'B' column sum to 1 while each sub-group sums to the same amount. 
#This requires that the calculation be aware of how many groups exist. 
#This is something we can't do with apply because apply wouldn't know how many groups exist.
s = df.groupby('A').B.pipe(lambda g: df.B / g.transform('sum') / g.ngroups)
s

0    0.000000
1    0.083333
2    0.166667
3    0.250000
4    0.051282
5    0.064103
6    0.076923
7    0.089744
8    0.102564
9    0.115385
Name: B, dtype: float64

#Note:
s.sum()

0.99999999999999989

#And:
s.groupby(df.A).sum()

A
X    0.5
Y    0.5
Name: B, dtype: float64


#Example 2 -  Subtract the mean of one group from the values of another. 
#Again, this can't be done with apply because apply doesn't know about other groups.
df.groupby('A').B.pipe(
    lambda g: (
        g.get_group('X') - g.get_group('Y').mean()
    ).append(
        g.get_group('Y') - g.get_group('X').mean()
    )
)

0   -6.5
1   -5.5
2   -4.5
3   -3.5
4    2.5
5    3.5
6    4.5
7    5.5
8    6.5
9    7.5
Name: B, dtype: float64

DataFrameGroupBy.filter(func, dropna=True, *args, **kwargs)
    Return a copy of a DataFrame excluding elements from groups 
    that do not satisfy the boolean criterion specified by func.
    Parameters:
        f : function
            Function to apply to each subframe. Should return True or False.
        dropna : Drop groups that do not pass the filter. True by default;
            if False, groups that evaluate False are filled with NaNs.
    Returns:
    filtered : DataFrame 



>>> import pandas as pd
>>> df = pd.DataFrame({'A' : ['foo', 'bar', 'foo', 'bar',
...                           'foo', 'bar'],
...                    'B' : [1, 2, 3, 4, 5, 6],
...                    'C' : [2.0, 5., 8., 1., 2., 9.]})
>>> grouped = df.groupby('A')
>>> grouped.filter(lambda x: x['B'].mean() > 3.)
     A  B    C
1  bar  2  5.0
3  bar  4  1.0
5  bar  6  9.0
        
        
        
        
###Melt Example 
data = {'weekday': ["Monday", "Tuesday", "Wednesday", 
         "Thursday", "Friday", "Saturday", "Sunday"],
        'Person 1': [12, 6, 5, 8, 11, 6, 4],
        'Person 2': [10, 6, 11, 5, 8, 9, 12],
        'Person 3': [8, 5, 7, 3, 7, 11, 15]}
df = pd.DataFrame(data, columns=['weekday',
        'Person 1', 'Person 2', 'Person 3'])
#output 
     weekday  Person 1  Person 2  Person 3
0     Monday        12        10         8
1    Tuesday         6         6         5
2  Wednesday         5        11         7

#How can you do group by on person 
#this is not normalized table 
#Melt data  - creating a generic form internally, which you can cast to specific shape
#each row is converted into id_vars versus other columns into 'variable'/var_name and 'value'/value_name
melt = pd.melt(df, id_vars=["weekday"], var_name="Person", value_name="Score")
#output 
     weekday    Person  Score
0     Monday  Person 1     12
1    Tuesday  Person 1      6
2  Wednesday  Person 1      5

#umpivot 
#pivot-unmelt - pivot(index=None, columns=None, values=None)
#'columns' columns name would be new DF's column labels 
#'values'= columnName  to use for populating new frame's cell values 
#'index'=Columnname for new frame's index

pm = melt.pivot(index='weekday', columns='Person', values='Score')
#output 
Person    Person 1  Person 2  Person 3
weekday
Friday          11         8         7
Monday          12        10         8
#reset_index()
pm2 = pm.reset_index()



##excel style pivot table 
#values=ColumnNames for aggfun , index=ColumnsNames for row-groupby , columns=ColumnNames on column-groupby , aggfunc=not string, but functions 
>>> table = pd.pivot_table(melt, values=['Score'], 
    index=['weekday'], 
    columns=['Person'], 
    aggfunc=[np.sum, np.max, lambda x:x.size]) #no np method for count , we have np.count_nonzero 

#or to get to get all of those 
pd.pivot_table(melt, values=['Score'], 
    columns=['Person'], 
    aggfunc=[np.sum, np.max, lambda x:x.size])

      
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
###Another example 
##Example  of Various operations possible in DataFrame, 
ver=pd.read_csv("data/ver.csv")  
#columns 
#index,year,day of the year,time,atmospheric pressure (mBar),rainfall (mm),wind speed (m/s),wind direction (degrees),surface temperature (C),relative humidity (%),wind_max (m/s),Tdew (C),wind_chill (C),uncalibrated solar flux (Kw/m2), calibrated solar flux (Kw/m2),battery (V),not used

#index 
ver.index 

#category 
ver['year'].astype('category')
ver['year'].astype('category').cat.categories
ver['year'].astype('category').cat.add_categories([2018])
ver['year'].astype('category').cat.rename_categories({2015:'a'})
ver['year'].astype('category').cat.rename_categories({2015:'a'}).astype(str)

#display few rows
pd.set_option('display.max_columns', 80)
ver.head(3)

#Determine the number of rows and columns in the dataset
ver.shape

#Find the number of rows in the dataset
len(ver)

#Get the names of the columns
ver.columns

#Get the first five rows of a column by name
ver['atmospheric pressure (mBar)'][:5]

#Create categorical ranges for numerical data. 14 is number of bins
atmospheric_pressure = pd.cut(ver['atmospheric pressure (mBar)'], 14)
atmospheric_pressure[:5]

#Look at the frequencies in the ranges created above
pd.value_counts(atmospheric_pressure)

#first six columns of the first row
#ix like .loc[row,column] , ie label based at first if not then iloc[row,column], index based
ver.ix[0,0:6]

#Order the data by specified column
ver['atmospheric pressure (mBar)'].sort_values()[:5]

#Sort by a column and that obtain a cross-section of that data , multiple can be given
sorteddata = ver.sort_values(by=['atmospheric pressure (mBar)', 'day of the year'])
sorteddata.ix[:,0:6].head(3)  

#Obtain the first three rows and first three columns of the sorted data
sorteddata.iloc[0:3,0:3]

#Obtain value counts of specific column
ver['atmospheric pressure (mBar)'].value_counts()

#to obtain the datatype for every colu mn
zip(ver.columns, [type(x) for x in ver.ix[0,:]])
#OR
ver.dtypes

#Get the unique values for a column by name.
ver['year'].unique()

#Get a count of the unique values of a column
len(ver['year'].unique())

#Index into a column and get the first four rows
ver.ix[0:3,'atmospheric pressure (mBar)']

#Obtain True/False  values
ver.ix[0:3,'atmospheric pressure (mBar)'] == 1025

#Return a subset of the data, >, >=, == and ~, |, &
atmsubset = ver[ (ver['atmospheric pressure (mBar)'] > 1010 ) & (ver['atmospheric pressure (mBar)'] < 1016) ]
atmsubset.head(5)
#Look at the shape of the dataset
atmsubset.shape

#Query the data
qry1 = ver.query('year == 2015')   #here column name must not contain any space etc
qry1.head(10)

#if column names contains space , use below to remove , required for even attribute access
originals = ver.columns[:]
ver.columns = [c.replace(' ', '_') for c in ver.columns]
ver.columns = [c.replace('(', '') for c in ver.columns]
ver.columns = [c.replace(')', '') for c in ver.columns]
qry1 = ver.query('atmospheric_pressure_mBar == 1016')
#Look at the shape of the data
qry1.shape

#Check a boolean condition
(ver.ix[:,'atmospheric_pressure_mBar'] > 1016).any()

#Return descriptive statistics of the dataset- mean, std etc is calculated for each colu mn
ver.describe()
#output 
atmospheric pressure (mBar)
count                 45000.000000
mean                   1015.946356
std                      12.309651
min                     977.000000
25%                    1010.000000
50%                    1016.000000
75%                    1025.000000
max                    1034.000000


#Crosstab(frequency) of the data by specified columns (of one column vs another)
pd.crosstab(ver['atmospheric pressure (mBar)'],ver['rainfall (mm)'])

#Get descriptive statistics for a specified column
ver.atmospheric_pressure_mBar.describe()

#Aggregate 
#aggregate(func, axis=0, *args, **kwargs), args, kargs are passed to func, axis=0, means columnwise, axis=1, rowwise 
ver.agg(['sum', 'min'])
ver.agg({'atmospheric_pressure_mBar' : ['sum', 'min'], 'rainfall_mm' : ['min', 'max']})
df.agg("mean", axis=1)


#Group data and obtain the mean,
#group by col1 and then col2 and find mean of all other columns
grouped1 = ver.groupby(['atmospheric_pressure_mBar','rainfall_mm']).mean()
grouped1

#Group data and obtain the mean/median/etc  values of all other colum ns
grpagg = ver.groupby('atmospheric_pressure_mBar').aggregate(np.median)
grpagg

#Group data and get the sums of all other colum ns
grpsum = ver.groupby('atmospheric_pressure_mBar').aggregate(['sum', 'count'])
grpsum

# add a new column which is string version of one colu mn
ver['applicant_race_name_1'] = pd.Series(np.array(map(str, ver['atmospheric_pressure_mBar'])), index=ver.index)
ver['applicant_race_name_1'][0]  #'1025'


#Return boolean values for a specified criteria
criterion = ver['applicant_race_name_1'].map(lambda x: x.endswith('5'))  #x= each elements 
>>> criterion.value_counts()  #single variable- frequency
False    40005
True      4995

##other 
#DataFrame.apply(func, axis=0, broadcast=None, raw=False, reduce=None, result_type=None, args=(), **kwds)
#apply func on axis(0, varying row ie columnwise, 1=rowwise), fun(Series):one_value
#DataFrame.applymap(func)  , apply func elementwise, func(each_element)
#DataFrame.aggregate(func, axis=0, *args, **kwargs)
#func is agg function or list of functions or dict(key columnName, value =agg funcs on ColumnName), could be strings eg mean, median, prod, sum, std, var,count 
#for List of functions strings, see pandas.DataFrame.GroupBy
#DataFrame.transform(func, *args, **kwargs), func(each_column):new_column
ver.apply(np.sum)
ver.applymap(lambda x:str(x))
ver.aggregate({'atmospheric pressure (mBar)':['mean','count','sum']})
ver.iloc[:,[3,4]].transform(lambda x: (x-x.mean())/x.std)


#Melt data  - creating a generic form internally, which you can cast to specific shape
#each row is converted into id_vars versus other columns into 'variable' and 'value'
melt = pd.melt(ver, id_vars = 'atmospheric pressure (mBar)')
#Obtain the first five rows of melted data
melt.iloc[0:5,:]   
#output - called 'stacked' or 'record' format:
        atmospheric pressure (mBar) variable  value
0                         1025      index       101.0
1                         1025      index       101.0
2                         1025      index       101.0
3                         1025      index       101.0
4                         1025      index       101.0
#Select 
melt[melt['variable'] == 'rainfall (mm)']

#check unique 
#subset : Only consider certain columns for identifying duplicates, by default use all of the columns
melt.drop_duplicates(subset=['variable', 'value'], keep='first') #keep : {'first', 'last', False}, default 'first'

#note melt can be on multiple id_vars and can be DF instance method
#and 'variable' can be renamed 
ver.melt(id_vars=['atmospheric pressure (mBar)', 'rainfall (mm)'], var_name='melted_variable')



#pivot-unmelt - pivot(index=None, columns=None, values=None)
#'columns' columns name would be new DF's column labels 
#'values'= columnName  to use for populating new frame's cell values 
#'index'=Columnname for new frame's index

#Note index has to be unique 

ver_new = ver.drop_duplicates(subset=['atmospheric pressure (mBar)'])
melt1 = pd.melt(ver_new, id_vars = 'atmospheric pressure (mBar)')
pm = melt1.pivot(index='atmospheric pressure (mBar)', columns='variable', values='value')
>>> pm.index
Int64Index([ 977,  978,  979,  980,  981,  982,  983,  984,  985,  986,  987,
             988,  989,  990,  991,  992,  993,  994,  995,  996,  997,  998,
             999, 1000, 1001, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1009,
            1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1020,
            1021, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1030, 1031,
            1032, 1033, 1034],
           dtype='int64', name='atmospheric pressure (mBar)')
>>> pm.columns
Index([' calibrated solar flux (Kw/m2)', 'Tdew (C)', 'battery (V)',
       'day of the year', 'index', 'not used', 'rainfall (mm)',
       'relative humidity (%)', 'surface temperature (C)', 'time',
       'uncalibrated solar flux (Kw/m2)', 'wind direction (degrees)',
       'wind speed (m/s)', 'wind_chill (C)', 'wind_max (m/s)', 'year'],
      dtype='object', name='variable')


##excel styple pivot table 
#values=ColumnNames for aggfun , index=ColumnsNames for row-groupby , columns=ColumnNames on column-groupby , aggfunc=not string, but functions 
>>> table = pd.pivot_table(ver, values=['atmospheric pressure (mBar)','rainfall (mm)'], index=['year', 'day of the year'], columns=['battery (V)'], aggfunc=[np.sum, np.max, lambda x:x.size]) #no np method for count , we have np.count_nonzero 





## Using Pandas for Analyzing Data - Visualization

#Plot counts of a specified column using Pand as
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns  #install it, conda install seaborn

ver.atmospheric_pressure_mBar.value_counts().plot(kind='barh')
plt.show()
#or use 
ver.plot(x=None, y='atmospheric_pressure_mBar', kind='line', 
    ax=None, subplots=False, sharex=None, sharey=False, layout=None, 
    figsize=None, use_index=True, title=None, grid=None, legend=True, 
    style=None, logx=False, logy=False, loglog=False, xticks=None, yticks=None, 
    xlim=None, ylim=None, rot=None, fontsize=None, colormap=None, table=False, 
    yerr=None, xerr=None, secondary_y=False, sort_columns=False, **kwds)
#x : label string or position, default None means index 
#y : label string or position, default None, means each column 
#kind:
#line : line plot (default)
#'bar' : vertical bar plot
#'barh' : horizontal bar plot
#'hist' : histogram
#'box' : boxplot
#'kde' : Kernel Density Estimation plot
#'density' : same as 'kde'
#'area' : area plot
#'pie' : pie plot
#'scatter' : scatter plot
#'hexbin' : hexbin plot

#note 
df.plot(kind='line') 
#is equivalent to 
df.plot.line()
#and similarly for others 

#with subplots 
#multiple in one plot 
ver.plot(kind='line', y=['Open', 'Day Wise Variation ( points) '] )
#with subplots 
ver.plot(kind='line', y=['Open', 'Day Wise Variation ( points) '], subplots=True )

#Bar plot of median values
ver.groupby('atmospheric_pressure_mBar')['surface_temperature_C'].agg(np.median).plot(kind = 'bar')
plt.show()

#Box plot example - only for first 200 rows
g = sns.factorplot("atmospheric_pressure_mBar", "surface_temperature_C", "rainfall_mm" ,ver.loc[0:200], kind="box", palette="PRGn",aspect=2.25)
g.set(ylim=(0, 10))
plt.show()

#Bar plot example
g = sns.factorplot("atmospheric_pressure_mBar","rainfall_mm", data=ver.loc[0:200], hue="surface_temperature_C",size=3,aspect=2)
plt.show()



##scatter_matrix 
#https://pandas.pydata.org/pandas-docs/stable/visualization.html

from pandas.plotting import scatter_matrix
df = pd.DataFrame(np.random.randn(1000, 4), columns=['a', 'b', 'c', 'd'])
scatter_matrix(ver, alpha=0.2, figsize=(6, 6), diagonal='kde')
#only density plot 
df.a.plot.kde()

##lagplot -Lag plots are used to check if a data set or time series is random. 
#Random data should not exhibit any structure in the lag plot. 
#Non-random structure implies that the underlying data are not random.
from pandas.plotting import lag_plot
lag_plot(df.a)

##Autocorrelation plots are often used for checking randomness in time series
#If time series is random, such autocorrelations should be near zero for any and all time-lag separations
from pandas.plotting import autocorrelation_plot
autocorrelation_plot(df.a)

#Bootstrap plots are used to visually assess the uncertainty of a statistic, 
#such as mean, median, midrange, etc. 
#A random subset of a specified size is selected from a data set, 
#the statistic in question is computed for this subset 
#and the process is repeated a specified number of times. 
#Resulting plots and histograms are what constitutes the bootstrap plot.
from pandas.plotting import bootstrap_plot
bootstrap_plot(df.a, size=50, samples=500, color='grey')



##Time/Date Plot 
ts = pd.Series(np.random.randn(1000), index=pd.date_range('1/1/2000', periods=1000))
ts = ts.cumsum()
ts.plot()

df = pd.DataFrame(np.random.randn(1000, 4), index=ts.index, columns=list('ABCD'))
df = df.cumsum()
plt.figure(); 
df.plot();

#with subplots 
df.plot(subplots=True, figsize=(6, 6));
#means 2 rows and 3 columns , each one is 6x6 
df.plot(subplots=True, layout=(2, 3), figsize=(6, 6), sharex=False);

#or maximum control 
fig, axes = plt.subplots(4, 4, figsize=(6, 6));
plt.subplots_adjust(wspace=0.5, hspace=0.5);
target1 = [axes[0][0], axes[1][1], axes[2][2], axes[3][3]]
target2 = [axes[3][0], axes[2][1], axes[1][2], axes[0][3]]
df.plot(subplots=True, ax=target1, legend=False, sharex=False, sharey=False);
(-df).plot(subplots=True, ax=target2, legend=False, sharex=False, sharey=False);
#or 
fig, axes = plt.subplots(nrows=2, ncols=2)
df['A'].plot(ax=axes[0,0]); axes[0,0].set_title('A');
df['B'].plot(ax=axes[0,1]); axes[0,1].set_title('B');
df['C'].plot(ax=axes[1,0]); axes[1,0].set_title('C');
df['D'].plot(ax=axes[1,1]); axes[1,1].set_title('D');

 