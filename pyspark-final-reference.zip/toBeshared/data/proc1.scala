scala> val lns = scala.io.Source.fromFile("xy.txt").getLines.toList
lns: List[String] = List(qbcd, abcd, abcd, "", cdfe, cdef, "", "", "", abcd, abs, "", "", abcd)

def pr( r:collection.mutable.ListBuffer[collection.mutable.ListBuffer[String]], e:String)=
    {if (! e.isEmpty ) r.last.append(e) else if(e.isEmpty && r.last.isEmpty) r  else r.append(collection.mutable.ListBuffer());r}

scala> lns.foldLeft(ListBuffer[ListBuffer[String]](ListBuffer[String]()))(pr _)
res46: scala.collection.mutable.ListBuffer[scala.collection.mutable.ListBuffer[String]] = ListBuffer(ListBuffer(qbcd, abcd, abcd), 
ListBuffer(cdfe, cdef), ListBuffer(abcd, abcs), ListBuffer(abcd))
