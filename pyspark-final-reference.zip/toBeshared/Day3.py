Day-3
    Spark DataSource 
        � HDFS, csv, json 
        � Hive, Parquet, Avro 
    Spark external Data source 
        � External Hive
        � RDBMS 
        � AWS S3,Azure Wasb 
        � Mongo DB , cassandra 
    Spark structured Streaming 
        � Spark Streaming VS structured streaming 
        � Structured streaming for HDFS and socket 
        � Structured Kafka  
        � Streaming  API for Kinesis and Flume 
    Spark Data analytics 
        � MLib vs ML 
        � Classifications and Regression 
----------------------------------------------------
###*** Command line arguments 
--jars JARS                 Comma-separated list of jars to include on the driver
                            and executor classpaths.
                            spark doesn't hit maven but it will search specified jar 
                            in the local file system 
                            it also supports following URL scheme hdfs/http/https/ftp.


--packages                  Comma-separated list of maven coordinates of jars to include
                            on the driver and executor classpaths. Will search the local
                            maven repo, then maven central and any additional remote
                            repositories given by --repositories. The format for the
                            coordinates should be groupId:artifactId:version.
                            spark will search specific package in local maven repo 
                            then central maven repo or any repo provided by --repositories 
                            and then download it.
                            
                            
###+++ Spark - DataFrame - Data Source 
#sql.DataFrameReader(returned from spark.read) and sql.DataFrameWriter(returned from spark.write)
#Note DF can be converted to RDD by df.rdd 
#and RDD can be converted to DF by sparkSession.createDataFrame(rdd)

class pyspark.sql.DataFrameReader(spark)
    Use sparkSession.read to access this.
    csv(path, schema=None, sep=None, encoding=None, quote=None, 
                escape=None, comment=None, header=None, inferSchema=None, 
                ignoreLeadingWhiteSpace=None, ignoreTrailingWhiteSpace=None, 
                nullValue=None, nanValue=None, positiveInf=None, negativeInf=None, 
                dateFormat=None, timestampFormat=None, maxColumns=None, maxCharsPerColumn=None, 
                maxMalformedLogPerPartition=None, mode=None)
        Loads a CSV file and returns the result as a DataFrame.
        Automatically infer input schema if inferSchema is enabled. 
        or specify the schema explicitly using schema.
        >>> df = spark.read.csv('ages.csv')
        >>> df.dtypes
        [('_c0', 'string'), ('_c1', 'string')]
    format(source)
        Specifies the input data source format.
        source � string, name of the data source, e.g. 'json', 'parquet', 'jdbc', 'csv', 'libsvm'
        >>> df = spark.read.format('json').load('people.json')
        >>> df.dtypes
        [('age', 'bigint'), ('name', 'string')]
    jdbc(url, table, column=None, lowerBound=None, upperBound=None, 
                numPartitions=None, predicates=None, properties=None)
        Construct a DataFrame representing the database table 
        �url � a JDBC URL of the form jdbc:subprotocol:subname
        �table � the name of the table
        �properties � a dictionary of JDBC database connection arguments. 
           For example { 'user' : 'SYSTEM', 'password' : 'mypassword' }
        column � the name of an integer column that will be used for partitioning; 
            if this parameter is specified, then numPartitions, lowerBound (inclusive), 
            and upperBound (exclusive) will form partition strides for generated WHERE clause expressions used to split the column column evenly
        �lowerBound � the minimum value of column used to decide partition stride
        �upperBound � the maximum value of column used to decide partition stride
        �numPartitions � the number of partitions
        �predicates � a list of expressions suitable for inclusion in WHERE clauses;
            each one defines one partition of the DataFrame
    json(path, schema=None, primitivesAsString=None, prefersDecimal=None, 
            allowComments=None, allowUnquotedFieldNames=None, allowSingleQuotes=None, 
            allowNumericLeadingZero=None, allowBackslashEscapingAnyCharacter=None, 
            mode=None, columnNameOfCorruptRecord=None, dateFormat=None, timestampFormat=None)
        Loads a JSON file (JSON Lines text format or newline-delimited JSON) 
        or an RDD of Strings storing JSON objects (one object per record) 
        and returns the result as a DataFrame
        >>> df1 = spark.read.json('people.json')
        >>> df1.dtypes
        [('age', 'bigint'), ('name', 'string')]
        >>> rdd = sc.textFile('python/test_support/sql/people.json')
        >>> df2 = spark.read.json(rdd)
        >>> df2.dtypes
        [('age', 'bigint'), ('name', 'string')]
    load(path=None, format=None, schema=None, **options)
        Loads data from a data source and returns it as DataFrame
        �path � optional string or a list of string for file-system backed data sources.
        �format � optional string for format of the data source. Default to 'parquet'.
        �schema � optional pyspark.sql.types.StructType for the input schema.
        �options � all other string options
        >>> df = spark.read.load('parquet_partitioned', opt1=True, opt2=1, opt3='str')
        >>> df.dtypes
        [('name', 'string'), ('year', 'int'), ('month', 'int'), ('day', 'int')]
        >>> df = spark.read.format('json').load(['people.json','people1.json'])
        >>> df.dtypes
        [('age', 'bigint'), ('aka', 'string'), ('name', 'string')]
    option(key, value)
        Adds an input option for the underlying data source.
    options(**options)
        Adds input options, key=value, for the underlying data source 
    orc(path)
        Loads an ORC file, returning the result as a DataFrame.
        Currently ORC support is only available together with Hive support.
        >>> df = spark.read.orc('orc_partitioned')
        >>> df.dtypes
        [('a', 'bigint'), ('b', 'int'), ('c', 'int')]
    parquet(*paths)
        Loads a Parquet file, returning the result as a DataFrame.
        �mergeSchema: sets whether we should merge schemas collected from all Parquet part-files. 
        This will override spark.sql.parquet.mergeSchema. 
        The default value is specified in spark.sql.parquet.mergeSchema.
        >>> df = spark.read.parquet('parquet_partitioned')
        >>> df.dtypes
        [('name', 'string'), ('year', 'int'), ('month', 'int'), ('day', 'int')]
    schema(schema)
        Specifies the input schema.
        Some data sources (e.g. JSON) can infer the input schema automatically from data.
        schema � a pyspark.sql.types.StructType object 
    table(tableName)
        Returns the specified SPARK-SQL table as a DataFrame.
        tableName � string, name of the table. 
        >>> df = spark.read.parquet('parquet_partitioned')
        >>> df.createOrReplaceTempView('tmpTable')
        >>> spark.read.table('tmpTable').dtypes
        [('name', 'string'), ('year', 'int'), ('month', 'int'), ('day', 'int')]
    text(paths)
        Loads text files and returns a DataFrame 
        whose schema starts with a string column named 'value', 
        Each line in the text file is a new row in the resulting DataFrame.
        paths � string, or list of strings, for input path(s). 
        You can set the following text-specific option(s) for reading text files:
            wholetext ( default false): If true, read a file as a single row and not split by "\n".
        #Example 
        >>> df = spark.read.text('text-test.txt')
        >>> df.collect()
        [Row(value=u'hello'), Row(value=u'this')]
        >>> df = spark.read.text('python/test_support/sql/text-test.txt', wholetext=True)
        >>> df.collect()
        [Row(value='hello\nthis')]




class pyspark.sql.DataFrameWriter(df)
    Use df.write to access this.
    Example  
        df = spark.read.parquet('parquet_partitioned')        
    bucketBy(numBuckets, col, *cols)
        Buckets the output by the given columns.
        Applicable for file-based data sources in combination with DataFrameWriter.saveAsTable().
        If specified, the output is laid out on the file system similar to Hive�s bucketing scheme.
        �numBuckets � the number of buckets to save
        �col � a name of a column, or a list of names.
        �cols � additional names (optional). If col is a list it should be empty.
        #Example 
        df.write.format('parquet')  
            .bucketBy(100, 'year', 'month')
            .mode("overwrite")
            .saveAsTable('bucketed_table')
    csv(path, mode=None, compression=None, sep=None, 
                quote=None, escape=None, header=None, nullValue=None, 
                escapeQuotes=None, quoteAll=None, dateFormat=None, 
                timestampFormat=None)
        Saves the content of the DataFrame in CSV format at the specified path.
            mode � specifies the behavior of the save operation when data already exists.
                'append': Append contents of this DataFrame to existing data.
                'overwrite': Overwrite existing data.
                'ignore': Silently ignore this operation if data already exists.
                'error' (default case): Throw an exception if data already exists.
        >>> df.write.csv(os.path.join(tempfile.mkdtemp(), 'data'))
    format(source)
        Specifies the underlying output data source.
        source � string, name of the data source, e.g. 'json', 'parquet', 'jdbc', 'csv'
        >>> df.write.format('json').save(os.path.join(tempfile.mkdtemp(), 'data'))
    insertInto(tableName, overwrite=False)
        Inserts the content of the DataFrame to the Hive/SPARK-SQL table.
        It requires that the schema of the DataFrame is the same as the schema of the table.
        Unlike saveAsTable, insertInto ignores the column names and just uses position-based resolution. 
        Because it inserts data to an existing table, format or options will be ignored.
        >>> sc.parallelize([(1, 2)]).toDF(["i", "j"]).write.mode("overwrite").saveAsTable("t1")
        >>> sc.parallelize([(3, 4)]).toDF(["j", "i"]).write.insertInto("t1")
        >>> sc.parallelize([(5, 6)]).toDF(["a", "b"]).write.insertInto("t1")
        >>> spark.sql("select * from t1").show()
        +---+---+
        |  i|  j|
        +---+---+
        |  5|  6|
        |  3|  4|
        |  1|  2|
        +---+---+

    jdbc(url, table, mode=None, properties=None)
        Saves the content of the DataFrame to an external database table via JDBC.
        �url � a JDBC URL of the form jdbc:subprotocol:subname
        �table � Name of the table in the external database.
        �mode � specifies the behavior of the save operation when data already exists.
                'append': Append contents of this DataFrame to existing data.
                'overwrite': Overwrite existing data.
                'ignore': Silently ignore this operation if data already exists.
                'error' (default case): Throw an exception if data already exists.
        �properties � a dictionary of JDBC database connection arguments. 
               For example { 'user' : 'SYSTEM', 'password' : 'mypassword' }
    json(path, mode=None, compression=None, dateFormat=None, timestampFormat=None)
        Saves the content of the DataFrame in JSON format at the specified path.
        >>> df.write.json(os.path.join(tempfile.mkdtemp(), 'data'))
    mode(saveMode)
        Specifies the behavior when data or table already exists.
        Options include:
                'append': Append contents of this DataFrame to existing data.
                'overwrite': Overwrite existing data.
                'ignore': Silently ignore this operation if data already exists.
                'error' (default case): Throw an exception if data already exists.      
       >>> df.write.mode('append').parquet(os.path.join(tempfile.mkdtemp(), 'data'))
    option(key, value)
        Adds an output option for the underlying data source.
    options(**options)
        Adds output options for the underlying data source.
    orc(path, mode=None, partitionBy=None, compression=None)
        Saves the content of the DataFrame in ORC format at the specified path.
        Currently ORC support is only available together with Hive support. 
        >>> orc_df = spark.read.orc('python/test_support/sql/orc_partitioned')
        >>> orc_df.write.orc(os.path.join(tempfile.mkdtemp(), 'data'))
    parquet(path, mode=None, partitionBy=None, compression=None)
        Saves the content of the DataFrame in Parquet format at the specified path.
        >>> df.write.parquet(os.path.join(tempfile.mkdtemp(), 'data'))
    partitionBy(*cols)
        Partitions the output by the given columns on the file system.
        >>> df.write.partitionBy('year', 'month').parquet(os.path.join(tempfile.mkdtemp(), 'data'))
    save(path=None, format=None, mode=None, partitionBy=None, **options)
        Saves the contents of the DataFrame to a data source.
        �path � the path in a Hadoop supported file system
        �format � the format used to save
        �mode �specifies the behavior of the save operation when data already exists.
            'append': Append contents of this DataFrame to existing data.
            'overwrite': Overwrite existing data.
            'ignore': Silently ignore this operation if data already exists.
            'error' (default case): Throw an exception if data already exists.     
        �partitionBy � names of partitioning columns
        �options � all other string options
        >>> df.write.mode('append').parquet(os.path.join(tempfile.mkdtemp(), 'data'))
    saveAsTable(name, format=None, mode=None, partitionBy=None, **options)
        Saves the content of the DataFrame as the HIVE/SPARK-SQL table.
            �name � the table name
            �format � the format used to save
            �mode � one of append, overwrite, error, ignore (default: error)
            �partitionBy � names of partitioning columns
            �options � all other string options
        The default location that Spark saves to is controlled by the HiveMetastore
        Unlike insertInto, saveAsTable will use the column names to find the correct column positions. 
        >>> sc.parallelize([(1, 2)]).toDF(["i", "j"]).write.mode("overwrite").saveAsTable("t1")
        >>> sc.parallelize([(3, 4)]).toDF(["j", "i"]).write.mode("append").saveAsTable("t1")
        >>> spark.sql("select * from t1").show()
        +---+---+
        |  i|  j|
        +---+---+
        |  1|  2|
        |  4|  3|
        +---+---+
    text(path, compression=None)
        Saves the content of the DataFrame in a text file at the specified path.
        df.write.text("/path/to/output")
    sortBy(col, *cols)
        Sorts the output in each bucket by the given columns on the file system.
        Parameters:
            �col � a name of a column, or a list of names.
            �cols � additional names (optional). If col is a list it should be empty.
        (df.write.format('parquet')  
            .bucketBy(100, 'year', 'month')
            .sortBy('day')
            .mode("overwrite")
            .saveAsTable('sorted_bucketed_table'))


    
    
###Spark - DataFrame - Data Source - Saving to Persistent Tables
#DataFrames can also be saved as persistent tables into Hive metastore 
df.write.saveAsTable(table_name) 
#and loaded by 
spark.read.table(table_name) 

#Notice existing Hive deployment is not necessary to use this feature. 
#Spark will create a default local Hive metastore (using Derby, filebased DB) 
 
#By default saveAsTable will create a 'managed table', 
#meaning that the location of the data will be controlled by Hive metastore. 
#Managed tables will also have their data deleted automatically when a table is dropped.
   
df.write.mode("overwrite").saveAsTable("tablename")
df = df.read.table("tablename")
   
   
###Default load and save -  parquet file 
usersDF = spark.read.load("file:///D:/Desktop/PPT/spark/data/users.parquet")  #unicode escape because of backward-slash-and-u, so use /
usersDF.select("name", "favorite_color").write.save("file:///D:/Desktop/PPT/spark/data/namesAndFavColors.parquet")

###Spark - DataFrame - Data Source - Manually Specifying Options   
df = spark.read.load("people.json", format="json")
df.select("name", "age").write.save("namesAndAges.parquet", format="parquet")  
    
    
###Spark - DataFrame - Data Source -  Run SQL on files directly  
df = spark.sql("SELECT * FROM parquet.`users.parquet`")   
                           

###*** Parquet Files and spark 
#Parquet is a columnar format that is supported by many other data processing systems
#default format is parquet
peopleDF = spark.read.json("people.json")

# DataFrames can be saved as Parquet files, maintaining the schema information.
peopleDF.write.parquet("people.parquet")

# Read in the Parquet file created above.
# Parquet files are self-describing so the schema is preserved.
# The result of loading a parquet file is also a DataFrame.
parquetFile = spark.read.parquet("people.parquet")

# Parquet files can also be used to create a temporary view and then used in SQL statements.
parquetFile.createOrReplaceTempView("parquetFile")
teenagers = spark.sql("SELECT name FROM parquetFile WHERE age >= 13 AND age <= 19")
teenagers.show()
# +------+
# |  name|
# +------+
# |Justin|
# +------+

  
##Table partitioning 
#In a partitioned table, data are usually stored in different directories, 
#with partitioning column values encoded in the path of each partition directory. 
#All built-in file sources (including Text/CSV/JSON/ORC/Parquet) are able to discover and infer partitioning information automatically

#gender and country as partitioning columns:

path
+-- to
    +-- table
        +-- gender=male
        �   +-- ...
        �   �
        �   +-- country=US
        �   �   +-- data.parquet
        �   +-- country=CN
        �   �   +-- data.parquet
        �   +-- ...
        +-- gender=female
            +-- ...
            �
            +-- country=US
            �   +-- data.parquet
            +-- country=CN
            �   +-- data.parquet
            +-- ...

#By passing path/to/table to either SparkSession.read.parquet or SparkSession.read.load, 
#Spark SQL will automatically extract the partitioning information from the paths. 
#the data types of the partitioning columns are automatically inferred.
root
|-- name: string (nullable = true)
|-- age: long (nullable = true)
|-- gender: string (nullable = true)
|-- country: string (nullable = true)


##partition discovery 
#only finds partitions under the given paths by default. 
#For the above example, if users pass path/to/table/gender=male as path in spark API 
#gender will not be considered as a partitioning column. 
#If users need to specify the base path that partition discovery should start with, 
#they can set basePath in the data source options. 
#For example, when path/to/table/gender=male is the path of the data 
#and users set basePath to path/to/table/, gender will be a partitioning column.




  
  
###Spark - Parquet - Schema Merging
#Like ProtocolBuffer, Avro, and Thrift, Parquet also supports schema evolution. 
#Users can start with a simple schema, and gradually add more columns to the schema as needed. 

#enable it by
1.setting data source option mergeSchema to true when reading Parquet files 
#OR 
2.setting the global SQL option spark.sql.parquet.mergeSchema to true.

#Exampe 
from pyspark.sql import Row

# spark is from the previous example.
# Create a simple DataFrame, stored into a partition directory
sc = spark.sparkContext

squaresDF = spark.createDataFrame(sc.parallelize(range(1, 6)).map(lambda i: Row(single=i, double=i ** 2)))
squaresDF.write.parquet("data/test_table/key=1")

# Create another DataFrame in a new partition directory,
# adding a new column and dropping an existing column
cubesDF = spark.createDataFrame(sc.parallelize(range(6, 11)).map(lambda i: Row(single=i, triple=i ** 3)))
cubesDF.write.parquet("data/test_table/key=2")

# Read the partitioned table
mergedDF = spark.read.option("mergeSchema", "true").parquet("data/test_table")
mergedDF.printSchema()



###Hive metastore Parquet table conversion
#When reading from and writing to Hive metastore Parquet tables, 
#Spark SQL will try to use its own Parquet support instead of Hive SerDe for better performance. 
#This behavior is controlled by the spark.sql.hive.convertMetastoreParquet configuration, 
#and is turned on by default.

#Spark reconcile Hive metastore schema with Parquet schema 
#(check https://spark.apache.org/docs/2.2.0/sql-programming-guide.html#hiveparquet-schema-reconciliation)
#Spark DataFrame column name and HIVE column name must match exactly 


###Spark - DataFrame - Data Source - Metadata Refreshing
#Spark SQL caches Parquet metadata for better performance
spark.catalog.refreshTable("my_table")



###Spark - Parquet - Configuration
#Configuration of Parquet can be done using the spark.conf.set() method on SparkSession 
#or by running 'SET key=value' commands using SQL.
#http://spark.apache.org/docs/latest/sql-programming-guide.html#configuration





###*** Spark and JSON Datasets
# spark is from the previous example.
sc = spark.sparkContext

# A JSON dataset is pointed to by path.
# The path can be either a single text file or a directory storing text files
path = "people.json"
peopleDF = spark.read.json(path)

jsonStrings = ['{"name":"Yin","address":{"city":"Columbus","state":"Ohio"}}']
otherPeopleRDD = sc.parallelize(jsonStrings)
otherPeople = spark.read.json(otherPeopleRDD)
otherPeople.show()



#Complete example 
#JSON Lines (newline-delimited JSON) is supported by default. 
#For JSON (one record per file), set the multiLine parameter to true.
#If the schema parameter is not specified, 
#this function goes through the input once to determine the input schema
#put rec*.json to input-json

df = spark.read \
  .format("json").option("multiLine", "true")\
  .load("data/spark/input-json")
  
schema = df.schema

#spread one record by * 
df.select(F.col("empId"), F.col("details.phoneNumbers")[0].alias("phs"))\
  .select("empId", "phs.*").show()
  
#or only office phone 
df.select(F.col("empId"), F.col("details.phoneNumbers.number")[1].alias("phs"))

#OR Explode 
df.select(F.col("empId"), F.explode(F.col("details.phoneNumbers")).alias("phs"))\
.select("empId", "phs.*").show()
#empId|      number|  type

df.select(F.col("empId"), F.explode(F.col("details.phoneNumbers")).alias("phs"))\
  .select("empId", "phs.*").where("type == 'office'").select("empId", "number")\
  .repartition(1).write\
  .format("csv")\
  .save("data/spark/output-csv-from_json")

  

  

  
#With Structured Streaming feature 
from pyspark.sql import * 
import pyspark.sql.functions as F 
from pyspark.sql.types import * 

schema = df.schema  #from above 


#schema is must , not without groupBy , "complete" is not allowed as state requirement is high 
q1 = spark.readStream\
  .format("json")\
  .schema(schema).option("multiLine", "true")\
  .load("data/spark/input-json")\
  .select(F.col("empId"), F.explode(F.col("details.phoneNumbers")).alias("phs"))\
  .select("empId", "phs.*").where("type == 'office'").select("empId", "number")\
  .writeStream\
  .outputMode("append")\
  .trigger(processingTime="10 seconds")\
  .format("console")\
  .start()

#  
q2 = spark.readStream\
  .format("json")\
  .schema(schema).option("multiLine", "true")\
  .load("data/spark/input-json")\
  .select(F.col("empId"), F.explode(F.col("details.phoneNumbers")).alias("phs"))\
  .select("empId", "phs.*").where("type == 'office'").select("empId", "number")\
  .groupBy("empId").agg(F.first("number").alias("first_office_number"))\
  .writeStream\
  .outputMode("complete")\
  .trigger(processingTime="10 seconds")\
  .format("console")\
  .start()
















###***Spark and  Avro - data serialization system
#Can use backend as Hive 

#using command ine 
$ bin/spark-submit --packages com.databricks:spark-avro_2.11:4.0.0
$ pyspark   --packages com.databricks:spark-avro_2.11:4.0.0
 
##Spark - Avro -   Avro -> Spark SQL conversion

#Avro type       Spark SQL type
boolean         BooleanType 
int             IntegerType 
long            LongType 
float           FloatType 
double          DoubleType 
bytes           BinaryType 
string          StringType 
record          StructType 
enum            StringType 
array           ArrayType 
map             MapType 
fixed           BinaryType 
union           1. union(int, long)  will be mapped to  LongType .
                2. union(float, double)  will be mapped to  DoubleType .
                3. union(something, null) , where  something  is any supported Avro type. 
                   This will be mapped to the same Spark SQL type as that of  something , with  nullable  set to  true .
                4. All other  union  types are considered complex. 
                   They will be mapped to  StructType  where field names are  member0 ,  member1 , etc., in accordance with members of the  union . 
                   This is consistent with the behavior when converting between Avro and Parquet.

##Spark - Avro -   Spark SQL -> Avro conversion
#Spark SQL type     Avro type
ByteType            int 
ShortType           int 
DecimalType         string 
BinaryType          bytes 
TimestampType       long 
StructType          record 



#Example schema - Json notation 
#user.avsc 
{"namespace": "example.avro",
 "type": "record",
 "name": "User",
 "fields": [
     {"name": "name", "type": "string"},
     {"name": "favorite_color", "type": ["string", "null"]},
     {"name": "favorite_numbers", "type": {"type": "array", "items": "int"}}
 ]
}



##Spark - Avro -   reading & and writing
# The Avro records get converted to Spark types, filtered, and
#then written back out as Avro records
#schema implicit , creates Dataframe( ie Row)
df = spark.read.format("com.databricks.spark.avro").load(r"./data/spark/users.avro")

#  Saves the subset of the Avro records read in
subset = df.where("name = 'Ben'")
subset.write.mode('overwrite').format("com.databricks.spark.avro").save(r"./data/spark/output")
 
#with schema 
schema_rdd = spark.sparkContext.textFile(r"./data/spark/user.avsc").collect()
s = "".join(schema_rdd)
df = spark.read.format("com.databricks.spark.avro").option("avroSchema", s).load(r"./data/spark/users.avro")





###*** Spark and  libsvm
#org.apache.spark.ml.source.libsvm.LibSVMDataSource


#The loaded DataFrame has two columns: label containing labels stored as doubles 
#and features containing feature vectors stored as Vectors.
df = spark.read.format("libsvm")
  .option("numFeatures", "780")
  .load("data/sample_libsvm_data.txt")


#LIBSVM data source supports the following options:
"numFeatures"
    number of features. 
    If unspecified or nonpositive, the number of features will be determined automatically 
    at the cost of one additional pass. 
    This is also useful when the dataset is already split into multiple files 
    and you want to load them separately, because some features may not present in certain files, 
    which leads to inconsistent feature dimensions.
"vectorType"
    feature vector type, "sparse" (default) or "dense". 

    
    
### Spark - DataFrame - Data Source - JDBC To Other Databases
#This functionality should be preferred over using JdbcRDD
# --conf spark.executor.extraClassPath=postgresql-9.4.1207.jar if required in executor  
$ pyspark --driver-class-path postgresql-9.4.1207.jar --jars postgresql-9.4.1207.jar
$ spark-submit --driver-class-path postgresql-9.4.1207.jar --jars postgresql-9.4.1207.jar
#mysql 
$ spark-submit --driver-class-path mysql-connector-java-5.1.34.jar  --jars mysql-connector-java-5.1.34.jar
$ pyspark --driver-class-path mysql-connector-java-5.1.34.jar --jars mysql-connector-java-5.1.34.jar
#sqlite 
$ spark-submit --driver-class-path sqlite-jdbc-3.21.0.1.jar  --jars sqlite-jdbc-3.21.0.1.jar
$ pyspark --driver-class-pathsqlite-jdbc-3.21.0.1.jar --jars sqlite-jdbc-3.21.0.1.jar


# Note: JDBC loading and saving can be achieved via either the load/save or jdbc methods
# Loading data from a JDBC source
jdbcDF = spark.read \
    .format("jdbc") \
    .option("url", "jdbc:postgresql:dbserver") \
    .option("driver", "org.postgresql.Driver") \
    .option("dbtable", "schema.tablename") \
    .option("user", "username") \
    .option("password", "password") \
    .load()

jdbcDF2 = spark.read.jdbc("jdbc:postgresql:dbserver", "schema.tablename",
          properties={"user": "username", "password": "password"})

# Saving data to a JDBC source
jdbcDF.write \
    .format("jdbc") \
    .option("url", "jdbc:postgresql:dbserver") \
    .option("driver", "org.postgresql.Driver") \
    .option("dbtable", "schema.tablename") \
    .option("user", "username") \
    .option("password", "password") \
    .save()

jdbcDF2.write.jdbc("jdbc:postgresql:dbserver", "schema.tablename",
          properties={"user": "username", "password": "password"})
  

  
##Example - mysql 
jdbcHostname = "<hostname>"
jdbcDatabase = "employees"
jdbcPort = 3306
jdbcUrl = "jdbc:mysql://{0}:{1}/{2}?user={3}&password={4}".format(jdbcHostname, jdbcPort, jdbcDatabase, username, password)
#OR 
jdbcUrl = "jdbc:mysql://{0}:{1}/{2}".format(jdbcHostname, jdbcPort, jdbcDatabase)
connectionProperties = {
  "user" : jdbcUsername,
  "password" : jdbcPassword,
  "driver" : "com.mysql.jdbc.Driver"
}
#pushdown_query is used to limit the data 
pushdown_query = "(select * from employees where emp_no < 10008) emp_alias"
df = spark.read.jdbc(url=jdbcUrl, table=pushdown_query, properties=connectionProperties)
display(df)

##Read from JDBC connections across multiple workers
#creates a partition based on 'column'
df = spark.read.jdbc(url=jdbcUrl, table='employees', column='emp_no', lowerBound=1, upperBound=100000, numPartitions=100)
display(df)  
 
##Example - Sqlite 
df = spark.read.json("people.json")

driverClass = "org.sqlite.JDBC"
df.write.format("jdbc").options(url = "jdbc:sqlite:file.db",
                 driver="org.sqlite.JDBC",
                 dbtable="persons").mode("append").save()
dfs = spark.read.format("jdbc").options(url= "jdbc:sqlite:file.db",
                 driver= driverClass,
                 dbtable= "persons").load()

#Checking all Data 
metaData = spark.read.format("jdbc")
    .options(url="jdbc:sqlite:file.db",driver=driverClass,
    dbtable="(SELECT * FROM sqlite_master) AS t")).load()  #pushdown query 

myTableNames = metaData.select("tbl_name").rdd.map(lambda r : r[0]).collect()

for t in myTableNames:
    print(t)
    tableData = spark read.format("jdbc").options(url= "jdbc:sqlite:file.db",driver= driverClass, dbtable= t).load()
    tableData.show()



    
    
    
### DataSource - Hive Tables
#Spark SQL also supports reading and writing data stored in Apache Hive.

##Supproted versions of Hive - Default Hive 1.2.1 is included in spark 
#https://github.com/apache/spark/blob/master/sql/hive/src/main/scala/org/apache/spark/sql/hive/client/IsolatedClientLoader.scala 
def hiveVersion(version: String): HiveVersion = version match { 
    case "12" | "0.12" | "0.12.0" => hive.v12 
    case "13" | "0.13" | "0.13.0" | "0.13.1" => hive.v13 
    case "14" | "0.14" | "0.14.0" => hive.v14 
    case "1.0" | "1.0.0" => hive.v1_0 
    case "1.1" | "1.1.0" => hive.v1_1 
    case "1.2" | "1.2.0" | "1.2.1" | "1.2.2" => hive.v1_2 
    case "2.0" | "2.0.0" | "2.0.1" => hive.v2_0 
    case "2.1" | "2.1.0" | "2.1.1" => hive.v2_1 
    case "2.2" | "2.2.0" => hive.v2_2 
    case "2.3" | "2.3.0" | "2.3.1" | "2.3.2" | "2.3.3" => hive.v2_3 
} 
###Options setup  
#If Hive 1.2.1 is used, then there is no need to any setup 
#Else set below options via SparkSession.builder().config() or put them in conf/spark-default.conf 
#check https://github.com/apache/spark/blob/master/sql/hive/src/main/scala/org/apache/spark/sql/hive/HiveUtils.scala
spark.sql.hive.metastore.version 
    Default:1.2.1 
    Version of the Hive metastore. Available options are 0.12.0 through 2.3.3
spark.sql.hive.metastore.jars 
    Default: builtin 
    Location of the jars that should be used to instantiate the HiveMetastoreClient. 
    Specify the classpath to JARS for Hive, Hive dependencies, and Hadoop
    Options are 
    1. builtin
        only for val builtinHiveVersion: String = "1.2.1" as given in HiveUtils.scala 
    2. maven
        For any other version of Hive, download from maven - slow for productions 
    3. A classpath in the standard format for the JVM. 
        This classpath must include all of Hive and its dependencies, including the correct version of Hadoop. 
        These jars only need to be present on the driver, 
        but if you are running in yarn cluster mode then fatjar must include these         
        For example Spark 1.5.2 with Hive 1.2 you can set the following classpath: 
        /hadoop-2.7.0/etc/hadoop:/hadoop-2.7.0/share/hadoop/common/lib/*:/hadoop-2.7.0/share/hadoop/common/*:/hadoop-2.7.0/share/hadoop/mapreduce/*:/hadoop-2.7.0/share/hadoop/yarn/*:/hive-1.2/lib/accumulo-core-1.6.0.jar:/hive-1.2/lib/hive-contrib-1.2.0-mapr-1508.jar:/hive-1.2/lib/*
    In Production, the best option is 
    1.Create a cluster that has spark.sql.hive.metastore.jars set to maven 
      with spark.sql.hive.metastore.version to match the version of your metastore.
    2.Once the cluster is running, search the driver log and find a line like the following:
        17/11/18 22:41:19 INFO IsolatedClientLoader: Downloaded metastore jars to /tmp/hive-v2_1-2037efa9-99ed-45be-9a04-83be817f1f0e
      The directory /tmp/hive-v2_1-2037efa9-99ed-45be-9a04-83be817f1f0e is the location of downloaded JARs 
      in the driver node of the cluster.
    3.Use %sh cp -r /tmp/hive-v2_1-2037efa9-99ed-45be-9a04-83be817f1f0e /hdfs/hive_metastore_jar 
    4.Copy /hdfs/hive_metastore_jar to each node /local/hive_metastore_jars/
    5.Set spark.sql.hive.metastore.jars to use /local/hive_metastore_jars/*
spark.sql.hive.metastore.sharedPrefixes 
    com.mysql.jdbc,org.postgresql,com.microsoft.sqlserver,oracle.jdbc 
    A comma separated list of class prefixes that should be loaded using the classloader 
    that is shared between Spark SQL and a specific version of Hive. 
    An example of classes that should be shared is JDBC drivers that are needed to talk to the metastore.
    Other classes that need to be shared are those that interact with classes that are already shared. 
    For example, custom appenders that are used by log4j. 
spark.sql.hive.metastore.barrierPrefixes 
    (empty) 
    A comma separated list of class prefixes that should explicitly be reloaded for each version of Hive 
    that Spark SQL is communicating with.
    For example, Hive UDFs that are declared in a prefix that typically would be shared 
    (i.e. org.apache.spark.*). 
 


##Summary 
#check - create table syntax 
#https://docs.databricks.com/spark/latest/spark-sql/language-manual/create-table.html

#managed means droping table => drop data, external means= drop table => does not drop data, only drops metastore data 
#spark dataframe column name/type and Hive table column name/type must be exactly same for interoperability
spark-SQL 
    Using HIVE as data source for Hive Table 
    Has TEMPORAY table (session scoped) Also has temporary View 
    Has managed (default), external (when LOCATION is set) table (note no external key word)
    Can use AS <select_statement> for pupulating table (but don't mention column name)(and can not be used with TEMPORARY, use TEMPORARY view instead)
    Has PARTITIONED BY (COL) for creating partition(dir struture) based on COL 
    Has CLUSTERED BY (COL) INTO n  - Each partition is  split into an buckets by COL 
    USING <data source> - TEXT, CSV, JSON, JDBC, PARQUET, ORC, HIVE, and LIBSVM
    Use spark.sql.sources.partitionOverwriteMode as 'dynamic' to only overwrite required partition, else by default whole data would be overwritten 
    Note USEING HIVE takes many options which complements HIVEQL syntax 
    eg fileFormat for STORED AS 
    CREATE TABLE src(id int) USING hive OPTIONS(fileFormat='parquet', ) 
    eg with "textfile" fileFormat, use fieldDelim, escapeDelim, collectionDelim, mapkeyDelim, lineDelim

HIVEQL 
    STORED AS  - for format, could be TEXTFILE, SEQUENCEFILE, RCFILE, ORC, PARQUET, and AVRO
    No TEMPORARY table or VIEW 
    Has managed (default), EXTERNAL (when LOCATION is set) table (Has EXTERNAL keyword)
    has PARTITIONED BY (COL)  (no cluster by) 
    Can use AS <select_statement> for pupulating table (but don't mention column name)
    has ROW FORMAT SERDE or ROW FORMAT DELIMITED FIELDS TERMINATED BY 'one_char'
    By default only overwrites required partition 
    For tables in Hive, where partitioned data already exists in S3 or HDFS, 
    run below command to update the Hive Metastore with the table's partition structure
    spark.sql("MSCK REPAIR TABLE hive_part_tbl")

#Note Spark uses own parquet SerDe for performance reason  and converts Hive to own Serde , 
#check more https://spark.apache.org/docs/latest/sql-programming-guide.html#hiveparquet-schema-reconciliation
#OR disbale by   spark.sql.hive.convertMetastoreParquet  as false (default true)

#Table partitioning - stored as dir with partition key 
#partition discovery only finds partitions under the given paths by default. 
#or set basePath along with path arg to a keyed dir 

#WHile INSERT INTO TABLE or INSERT OVERWRITE TABLE(for only required partition overwrite)
#PARTITION (COL=value,COL=value) , value can be literal only 
#if value needs to be variable, use hive.exec.dynamic.partition", "true" and "hive.exec.dynamic.partition.mode", "nonstrict"
#DF equivalent is df.write.partitionBy(colName)


###CONCEPTS 
#Metastore - generaly mysql etc to store schema and other details of table 
#warehouse - HDFS location where actual data is stored , actual data chunk is in DataNode(in each node of cluster), managed by NameNode 

Hive 
    hadoop-conf core-site.xml gives fs.default.name => hdfs://localhost:19000
    If core-site.xml in path, above would be default prefix filesystem ie HDFS would be enforced 
    hive-conf hive-site.xml gives default location for hive table storage in 
    hive.metastore.warehouse.dir (default:/user/hive/warehouse)(might be local or HDFS if core-site.xml in CLASSPATH)
    OR user can use store as EXTERNAL table in CREATE TABLE ... LOCATION 'path/path/...'
    
    Hive stores schema and other details of table in metastore (generally RDBMS) 
    as given in hive-conf hive-site.xml property javax.jdo.option.ConnectionURL
    
    Hive may store data based on partition (CREATE TABLE .. PARTITION BY...)
    which can be static partition(fixed value as column value) of dynamic partition(based on column variable as key) 
    Dynamic partition can be enabled by 
    SET hive.exec.dynamic.partition = true;
    SET hive.exec.dynamic.partition.mode = nonstrict;

    #Example 
    DROP TABLE IF EXISTS stats;

    CREATE EXTERNAL TABLE stats (
        ad              STRING,
        impressions     INT,
        clicks          INT
    ) PARTITIONED BY (country STRING, year INT, month INT, day INT)
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' 
    LINES TERMINATED BY '\n';

    MSCK REPAIR TABLE stats;

    -- Specify static partitions
    INSERT OVERWRITE TABLE stats 
    PARTITION(country = 'US', year = 2017, month = 3, day = 1)
    SELECT ad, SUM(impressions), SUM(clicks)
    FROM impression_logs
    WHERE log_day = 1
    GROUP BY ad;

    -- Load data into partitions dynamically
    SET hive.exec.dynamic.partition = true;
    SET hive.exec.dynamic.partition.mode = nonstrict;

    INSERT OVERWRITE TABLE stats 
    PARTITION(country = 'US', year = 2017, month = 3, day) -- day is variable 
    SELECT ad, SUM(impressions), SUM(clicks), log_day
    FROM impression_logs
    GROUP BY ad;

    The OVERWRITE keyword tells Hive to delete the contents of the partitions into which data is being inserted. 
    Hive only deletes data for the partitions it�s going to write into. 
    All the other partitions remain intact(unlike SPARK)

    Default database is "default" or create by 
    CREATE DATABASE IF NOT EXISTS new_db 
    USE new_db
    After that all Creation etc goes to above new database 
    
    Hive stores table as directory structure(local/HDFS) in database/tableName/Partition/files.. 
  
    To view default location, use 
    hadoop fs -ls /user/hive/warehouse
    or 
    http://NAMENODE_MACHINE_NAME:50070/
    Utilities > Browse the file system
    or
    http://localhost:50070/explorer.html#/

    For default location or EXTERNAL table, get the location by DESCRIBE FORMATTED <table_name> command.
    $ hive -S -e "describe formatted <table_name> ;" | grep 'Location' | awk '{ print $NF }'
    #or for dbname 
    hive> describe formatted dbname.tablename
    #or for partition location 
    hive> describe formatted dbname.tablename partition (name=value)

    To get Default location 
    hive> set hive.metastore.warehouse.dir;
    (it will print the path)

Spark 
    Spark supports SQL syntax(based on HIVEQL) called SPARK-SQL 
    Hence spark-sql supports PARTITION BY , LOCATION etc , just like HIVEQL 
    Moreover it supports USING <data source> syntax , which specifies the file format to use for this table. 
    The data source may be one of TEXT, CSV, JSON, JDBC, PARQUET, ORC, HIVE and LIBSVM
    
    Spark uses own bundled HIVE jars and hive can be enabled with .enableHiveSupport()
    It uses spark.sql.warehouse.dir for warehouse location(default ./spark-warehouse) for storing tables (in file directory structures)
    and uses embedded Derby DB (file based) for metastore (default ./metastore_db)
    
    The warehouse location has to be set up before the HiveContext / SQLContext / SparkSession initialization
    ie during spark creation, SparkSession.builder..config("spark.sql.warehouse.dir", warehouseLocation)   
    
    While using spark with external HIVE, spark loads  hive-site.xml , core-site.xml etc if found it CLASSPATH 
    Also if external Hive jars are found in CLASSPATH, it loads them instead of HIVE bundled with spark 
    
    #check https://github.com/apache/spark/blob/master/sql/core/src/main/scala/org/apache/spark/sql/internal/SharedState.scala
    Note hive.metastore.warehouse.dir is only read from hive-site.xml and spark ignores hive.metastore.warehouse.dir if set by .config("hive.metastore.warehouse.dir", path)
    If hive.metastore.warehouse.dir is found, but spark.sql.warehouse.dir is not set, update spark.sql.warehouse.dir with value of hive.metastore.warehouse.dir
    if spark.sql.warehouse.dir  is set, overwrites value of hive.metastore.warehouse.dir ie hive.metastore.warehouse.dir points to spark.sql.warehouse.dir 
    Hence if SPARK and external HIVE uses the same location for storing, set both *.dir to same location 
    When neither spark.sql.warehouse.dir nor hive.metastore.warehouse.dir is set,SPARK sets hive.metastore.warehouse.dir to the default value of spark.sql.warehouse.dir.
    
    There exist three types of non-temporary cataloged tables in Spark: EXTERNAL, MANAGED, and VIEW. 
    VIEW is used for persistent views; EXTERNAL and MANAGED are used for tables. 

    Like Hive, when dropping an EXTERNAL table, Spark only drops the metadata but keeps the data files intact. 
    When dropping a MANAGED table, Spark removes both metadata and data files. 

    Find out the table type by the SparkSession API spark.catalog.getTable(tableName) 
    or the DDL command DESC EXTENDED / DESC FORMATTED
    
    #The location of t5 data files is {current_working_directory}/spark-warehouse/t5	
    spark.sql(CREATE TABLE t5 (i int) USING HIVE);
    # The created tables are EXTERNAL
    spark.sql(CREATE TABLE t6 (i int) USING HIVE OPTIONS('path'='/tmp/tables/t6');

    DataFrameWriter provides options to create either EXTERNAL or MANAGED tables, as shown below.
    df = Seq(1,2).toDF()
    #The created tables are MANAGED.
    df.write.saveAsTable("t10")
    #The created tables are EXTERNAL
    df.write.option("path", "/tmp/tables/t9").saveAsTable("t9")
    
    To enable dynamic partition, where partion is value of col("key") use 
    .config("hive.exec.dynamic.partition", "true") 
    .config("hive.exec.dynamic.partition.mode", "nonstrict")
    df.write.partitionBy("key").format("hive").saveAsTable("hive_part_tbl")
    
    Note Spark either OVERWRITEs all partitions or appends to the partitions. 
    Spark doesn�t natively support the same behavior as Hive. 
    In the OVERWRITE mode, Spark deletes all the partitions, even the ones it would not have written into
    #Example : If we run the job to backfill the data for just 1 day, 
    #then Spark will delete the data for all other days if we were to run the above code.
    impressionsDF
        .write.mode("overwrite")
        .partitionBy("country", "year", "month", "day")
        .json("s3://output_bucket/stats")
    Solution is to use SQL (for spark 2.3.0,set "spark.sql.sources.partitionOverwriteMode", "dynamic")
    #Create SparkSession with Hive dynamic partitioning enabled
    spark = SparkSession
            .builder
            .appName("StatsAnalyzer")
            .enableHiveSupport()
            .config("hive.exec.dynamic.partition", "true")
            .config("hive.exec.dynamic.partition.mode", "nonstrict")
            .getOrCreate()
    #Register the dataframe as a Hive table
    impressionsDF.createOrReplaceTempView("impressions_dataframe")
    #Create the output Hive table
    spark.sql("""
          CREATE EXTERNAL TABLE stats (
             ad            STRING,
             impressions   INT,
             clicks        INT
          ) PARTITIONED BY (country STRING, year INT, month INT, day INT)
          ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' LINES TERMINATED BY '\n'
        """ )
    #Write the data into disk as Hive partitions
    spark.sql("""
          INSERT OVERWRITE TABLE stats 
          PARTITION(country = 'US', year = 2017, month = 3, day)
          SELECT ad, SUM(impressions), SUM(clicks), day
          FROM impressions_dataframe
          GROUP BY ad
        """)
HiveServer
    Hive has a Driver which parses the SQL query, creates the plan and executes it. 
    It also talks to Metastore to get/store the table metadata.
    When you run Hive CLI it loads the Driver object directly in its process. 
    With HiveServer the communication between Driver object and CLI is changed. 
    HiveServer runs a service which accepts the queries sent by CLI (or JDBC/ODBC), 
    executes the query and sents the results back. 
    All communication is over the network. 
    Spark does not need HiveServer 
    #Start by 
    $ hive --service hiveserver2 "$@"
    Advantages are  
     1. clients are thin and varied (such as JDBC/ODBC clients)
     2. Multiple users can use the same Hive service.
    There are two types of HiveServers:
     1. HiveServer: First implementation. It has concurrency and security issues.
     2. HiveServer2: Second implementation which solved the drawbacks in HiveServer.
Metastore:
    It talks to the backend such as Derby/MySql to store and retrieve table metadata. 
    If any Hive component wants to get/set metadata, it calls the MetaStore APIs.
    APIs are such getTable(tableName), createDatabase(dbName, ...) etc. 
    Basically metastore abstracts and provides backend (derby/mysql/postgres) independent API layer. 
    Similar to HiveServer this can also run as a server. 
    If there is no metastore server running, then the Driver will load the metastore in its process. 
    If metastore is running as a separate server then the Driver object communicates 
    with the metastore over network. This is called Remote Mode 
    #Start metastore 
    $ hive --service metastore 
    Above runs a Thrift server , configure it in conf/hive-site.xml 
    <property>
      <name>hive.metastore.uris</name>
      <value>thrift://localhost:9083</value>
      <description>IP address (or fully-qualified domain name) and port of the metastore host</description>
    </property>
    Spark can use this remote server, copy conf/hive-site.xml to spark/conf 
    And set it via 
    SparkSession.builder().config("hive.metastore.uris", "thrift://localhost:9083")
    
    
    

###Enable DEBUG logging level for HiveContext to see what happens inside.
#Add the following line to conf/log4j.properties:
log4j.logger.org.apache.spark.sql.hive.HiveContext=DEBUG


###Deletion of Partition in HIVE 
#This table is partitioned by the year of joining. 
#Our requirement is to drop multiple partitions in hive.

#Add Multiple Partitions
alter table employee add partition (year=2005) partition (year=2006) partition (year=2007) partition (year=2008) partition (year=2009) partition (year=2010) partition (year=2011) partition (year=2014);

#Drop Specific Partitions
ALTER TABLE db_bdpbase.Employee DROP IF EXISTS PARTITION (year=2008), PARTITION(year=2009), PARTITION(year=2010);

#Drop Range Partition
#to drop all partition above the value of 2010. 
ALTER TABLE db_bdpbase.Employee DROP IF EXISTS PARTITION(year>2010);




###Overwriting partition in Hive and Spark 
df.write
 .mode(SaveMode.Overwtite)
 .partitionBy("day","hour")
 .option("compression", "gzip")
 .parquet(s3Path) #or orc or saveAsTable for hive  or..
 
#https://issues.apache.org/jira/browse/SPARK-20236
#When we overwrite a partitioned data source table, before spark 2.3.0 Spark will truncate the entire table to write new data, 
#or truncate a bunch of partitions according to the given static partitions.

#For example, INSERT OVERWRITE tbl ... will truncate the entire table, 
#INSERT OVERWRITE tbl PARTITION (a=1, b) will truncate all the partitions that starts with a=1.

#However, hive has a different behavior that it only overwrites related partitions, 
#e.g. INSERT OVERWRITE tbl SELECT 1,2,3 will only overwrite partition a=2, b=3, assuming tbl has only one data column and is partitioned by a and b.


#The only solution with Spark up to 2.0 is to write directly into the partition directory, e.g.,
df.write.mode(SaveMode.Overwrite).save("/root/path/to/data/partition_col=value")

#For Spark prior to 2.0, stop Spark from emitting metadata files (because they will break automatic partition discovery) using:
sc.hadoopConfiguration.set("parquet.enable.summary-metadata", "false")

#For Spark prior to 1.6.2, delete the _SUCCESS file in /root/path/to/data/partition_col=value 
#or its presence will break automatic partition discovery. 

#Since Spark 2.3.0 this is an option when overwriting a table
#for PySpark users make sure to set overwrite=True in the insertInto as well 
spark.conf.set("spark.sql.sources.partitionOverwriteMode","DYNAMIC")
data.write.insertInto("partitioned_table", overwrite=True)

#Do a repartition based on partition column before writing, so you won't end up with huge number of  files per folder.

#or in the SQL version works fine.
INSERT OVERWRITE TABLE [db_name.]table_name [PARTITION part_spec] select_statement


###Hive Example 
#Either no external support ie no hive-site.xml in spark/conf 
#or a hive-site.xml in spark/conf 



from os.path import expanduser, join, abspath

from pyspark.sql import SparkSession
from pyspark.sql import Row

# warehouse_location points to the default location for managed databases and tables
warehouse_location = abspath('spark-warehouse')

spark = SparkSession \
    .builder \
    .appName("Python Spark SQL Hive integration example") \
    .config("spark.sql.warehouse.dir", warehouse_location) \
    .enableHiveSupport() \
    .getOrCreate()

#enableHiveSupport: support, including connectivity to a persistent Hive metastore, 
#support for Hive serdes, and Hive user-defined functions
                       
# spark is an existing SparkSession
spark.sql("CREATE TABLE IF NOT EXISTS src (key INT, value STRING) USING hive")
spark.sql("LOAD DATA LOCAL INPATH 'data/spark/kv1.txt' INTO TABLE src")

# Queries are expressed in HiveQL
spark.sql("SELECT * FROM src").show()
# +---+-------+
# |key|  value|
# +---+-------+
# |238|val_238|
# | 86| val_86|
# |311|val_311|
# ...

# Aggregation queries are also supported.
spark.sql("SELECT COUNT(*) FROM src").show()
# +--------+
# |count(1)|
# +--------+
# |    500 |
# +--------+

# The results of SQL queries are themselves DataFrames and support all normal functions.
sqlDF = spark.sql("SELECT key, value FROM src WHERE key < 10 ORDER BY key")

# The items in DataFrames are of type Row, which allows you to access each column by ordinal.
stringsDS = sqlDF.rdd.map(lambda row: "Key: %d, Value: %s" % (row.key, row.value))
for record in stringsDS.collect():
    print(record)
# Key: 0, Value: val_0
# Key: 0, Value: val_0
# Key: 0, Value: val_0
# ...

# You can also use DataFrames to create temporary views within a SparkSession.
Record = Row("key", "value")
recordsDF = spark.createDataFrame([Record(i, "val_" + str(i)) for i in range(1, 101)])
recordsDF.createOrReplaceTempView("records")

# Queries can then join DataFrame data with data stored in Hive.
spark.sql("SELECT * FROM records r JOIN src s ON r.key = s.key").show()
# +---+------+---+------+
# |key| value|key| value|
# +---+------+---+------+
# |  2| val_2|  2| val_2|
# |  4| val_4|  4| val_4|
# |  5| val_5|  5| val_5|
# ...

# Create a Hive managed Parquet table, with HQL syntax instead of the Spark SQL native syntax
# `USING hive`
spark.sql("CREATE TABLE hive_records(key int, value string) STORED AS PARQUET")
# Save DataFrame to the Hive managed table
df = spark.table("src")
df.write.mode("overwrite").saveAsTable("hive_records")
# After insertion, the Hive managed table has data now
spark.sql("SELECT * FROM hive_records").show()
# +---+-------+
# |key|  value|
# +---+-------+
# |238|val_238|
# | 86| val_86|
# |311|val_311|
# ...

# Prepare a Parquet data directory
dataDir = "data/spark/parquet_data"
spark.range(10).write.parquet(dataDir)
# Create a Hive external Parquet table
spark.sql("CREATE EXTERNAL TABLE hive_ints(key int) STORED AS PARQUET LOCATION '%s'" % (dataDir,) )
# The Hive external table should already have data
spark.sql("SELECT * FROM hive_ints").show()
# +---+
# |key|
# +---+
# |  0|
# |  1|
# |  2|
# ...

# Turn on flag for Hive Dynamic Partitioning
spark.conf.set("hive.exec.dynamic.partition", "true")
spark.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
# Create a Hive partitioned table using DataFrame API
df.write.partitionBy("key").format("hive").saveAsTable("hive_part_tbl")
# Partitioned column `key` will be moved to the end of the schema.
spark.sql("SELECT * FROM hive_part_tbl").show()
# +-------+---+
# |  value|key|
# +-------+---+
# |val_238|238|
# | val_86| 86|
# |val_311|311|
# ...

spark.stop()





###Hive Functions
len(spark.sql("show functions").collect())
>>> spark.sql("show functions").show(False)
16/04/10 15:22:08 INFO HiveSqlParser: Parsing command: show functions
+---------------------+
|function             |
+---------------------+
|!                    |
|%                    |
|&                    |
|*                    |
|+                    |
|-                    |
|/                    |
|<                    |
|<=                   |
|<=>                  |
|=                    |
|==                   |
|>                    |
|>=                   |
|^                    |
|abs                  |
|acos                 |
|add_months           |
|and                  |
|approx_count_distinct|
+---------------------+
only showing top 20 rows

###current_database function
#current_database function returns the current database of Hive metadata.

>>> spark.sql("select current_database()").show(False)
16/04/09 13:52:13 INFO HiveSqlParser: Parsing command: select current_database()
+-----------------+
|currentdatabase()|
+-----------------+
|default          |
+-----------------+

##Create new Database 
#default database name is "default"
CREATE DATABASE IF NOT EXISTS new_db 
USE new_db
#After tha all Creation etc goes to above new database 



###SPARK-SQL: Specifying storage format for Hive tables - default is text format 
#Note Spark also supports HIVE-SQL create format 
#https://docs.databricks.com/spark/latest/spark-sql/language-manual/create-table.html
#HDFS files-->InputFileFormat--> --> Deserializer --> Row object 
#Row object -->Serializer --> --> OutputFileFormat --> HDFS files
#When you create a Hive table, you need to define how this table should read/write data from/to file system, 
#i.e. the �input format� and �output format�. 
#You also need to define how this table should deserialize the data to rows, or serialize rows to data, i.e. the �serde�. 
CREATE TABLE src(id int) USING hive OPTIONS(fileFormat='parquet', ) 

#OPTIONS Property Name
#All other properties defined with OPTIONS will be regarded as Hive serde properties.
fileFormat
    A fileFormat is kind of a package of storage format specifications, including "serde", "input format" and "output format". 
    Currently 6 fileFormats: 'sequencefile', 'rcfile', 'orc', 'parquet', 'textfile' and 'avro'.  
inputFormat, outputFormat 
    These 2 options specify the name of a corresponding `InputFormat` and `OutputFormat` class as a string literal, 
    e.g. `org.apache.hadoop.hive.ql.io.orc.OrcInputFormat`.
    These 2 options must be appeared in pair, and you can not specify them if you already specified the `fileFormat` option.  
serde 
    This option specifies the name of a serde class. 
    When the `fileFormat` option is specified, do not specify this option if the given `fileFormat` already include the information of serde. 
    Currently "sequencefile", "textfile" and "rcfile" don't include the serde information 
    and you can use this option with these 3 fileFormats.  
fieldDelim, escapeDelim, 
collectionDelim, mapkeyDelim, lineDelim 
    These options can only be used with "textfile" fileFormat. 
    They define how to read delimited files into rows.  

###SPARK-SQL  
CREATE [TEMPORARY] TABLE [IF NOT EXISTS] [db_name.]table_name
    [(col_name1 col_type1 [COMMENT col_comment1], ...)]
    USING datasource
    [OPTIONS (key1=val1, key2=val2, ...)]
    [PARTITIONED BY (col_name1, col_name2, ...)]
    [CLUSTERED BY (col_name3, col_name4, ...) INTO num_buckets BUCKETS]
    [LOCATION path]
    [COMMENT table_comment]
    [TBLPROPERTIES (key1=val1, key2=val2, ...)]
    [AS select_statement]

#Example 
create table studentpq3 (id STRING, name STRING, phone STRING, email STRING) 
    USING hive OPTIONS(fileFormat='parquet', path="t4")

-- CREATE a HIVE SerDe table using the CREATE TABLE USING syntax.
CREATE TABLE my_table (name STRING, age INT, hair_color STRING)
    USING HIVE
    OPTIONS(
        INPUTFORMAT 'org.apache.hadoop.mapred.SequenceFileInputFormat',
        OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.HiveSequenceFileOutputFormat',
        SERDE 'org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe')
    PARTITIONED BY (hair_color)
    TBLPROPERTIES ('status'='staging', 'owner'='andrew')

#HIVE-SQL 
CREATE [EXTERNAL] TABLE [IF NOT EXISTS] [db_name.]table_name
    [(col_name1[:] col_type1 [COMMENT col_comment1], ...)]
    [COMMENT table_comment]
    [PARTITIONED BY (col_name2[:] col_type2 [COMMENT col_comment2], ...)]
    [ROW FORMAT row_format]
    [STORED AS file_format]
    [LOCATION path]
    [TBLPROPERTIES (key1=val1, key2=val2, ...)]
    [AS select_statement]

row_format:
    : SERDE serde_cls [WITH SERDEPROPERTIES (key1=val1, key2=val2, ...)]
    | DELIMITED [FIELDS TERMINATED BY char [ESCAPED BY char]]
        [COLLECTION ITEMS TERMINATED BY char]
        [MAP KEYS TERMINATED BY char]
        [LINES TERMINATED BY char]
        [NULL DEFINED AS char]

file_format:
    : TEXTFILE | SEQUENCEFILE | RCFILE | ORC | PARQUET | AVRO
    | INPUTFORMAT input_fmt OUTPUTFORMAT output_fmt
#Example 
CREATE TABLE my_table (name STRING, age INT)
    COMMENT 'This table specifies a custom SerDe'
    ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.orc.OrcSerde'
    STORED AS
        INPUTFORMAT 'org.apache.hadoop.hive.ql.io.orc.OrcInputFormat'
        OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.orc.OrcOutputFormat'

CREATE TABLE IF NOT EXISTS employee ( eid int, name String,
    salary String, destination String)
COMMENT "Employee details"
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
LINES TERMINATED BY '\n'
STORED AS TEXTFILE;








###*** MONGODB - Installation of Mongo DB 
##Download mongodb, - http://downloads.mongodb.org/win32/mongodb-win32-x86_64-2008plus-ssl-3.4.15.zip
#unzip to c:\mongodb , create data under it and add bin to Path 

##Start the service 
c:\mongodb\bin\mongod.exe --dbpath c:\mongodb\data --config c:\mongodb\mongod.cfg --service

##Test 
$ mongo 
> use mydb   ## use DB mydb
> show dbs	
> db		# show current db
> show collections
> j = { name : "mongo" }
> k = { x : 3 }
> db.examples.insert( j )  # on fly  create collections 'examples'
> db.testData.insert( k )
> show collections
examples
system.indexes
testData
> db.testData.find()
{ "_id" : ObjectId("59709077f0d01b563cb7bef5"), "x" : 3 }


###Update with Test data 
#Retrieve the dataset from https://raw.githubusercontent.com/mongodb/docs-assets/primer-dataset/primer-dataset.json? 
#save to a file named c:\mongodb\primer-dataset.json.

$ mongoimport --db test --collection restaurants --drop --file c:/mongodb/primer-dataset.json

##Quick - DML 
db.my_collection.insertOne(one_dict)
db.my_collection.insertMany([dict1, dict2,..])

db.my_collection.updateOne(<filter>, <update>, <options>)
db.my_collection.updateMany(<filter>, <update>, <options>)
db.my_collection.replaceOne(<filter>, <update>, <options>)
    <filter>
        { <field1>: { <operator1>: <value1> }, ... } where operator1 is  $gt, $lt,  https://docs.mongodb.com/manual/reference/operator/query/#query-selectors
        or { <field1>: <value1>, ... } for particular value 
    <update>
        where update operators are $set , https://docs.mongodb.com/manual/reference/operator/update
        {
          <update operator>: { <field1>: <value1>, ... },
          <update operator>: { <field2>: <value2>, ... },
          ...
        }

db.my_collection.deleteMany(<filter>)
db.my_collection.deleteOne(<filter>)
    <filter>
        { <field1>: { <operator1>: <value1> }, ... } where operator1 is  $gt, $lt,  https://docs.mongodb.com/manual/reference/operator/query/#query-selectors
        or { <field1>: <value1>, ... } for particular value 


##Quick - Querying 

##pecify Equality Conditions
#Syntax for a field 
{ <field1>: <value1>, <field2>: <value2>, ... }

#Query by a Top Level Field
db.restaurants.find( { "borough": "Manhattan" } )

#Query by a Field in an Embedded Document
#zipcode is part of address 
db.restaurants.find( { "address.zipcode": "10075" } )

#Query by a Field in an Array
#The 'grades' array contains embedded documents as its elements. All 'grade' 
db.restaurants.find( { "grades.grade": "B" } )


#Specify Conditions with Operators
#syntax
{ <field1>: { <operator1>: <value1> } }


#Greater Than Operator ($gt), Less Than Operator ($lt)
db.restaurants.find( { "grades.score": { $gt: 30 } } )
db.restaurants.find( { "grades.score": { $lt: 10 } } )


#Logical AND
db.restaurants.find( { "cuisine": "Italian", "address.zipcode": "10075" } )

#Logical OR
db.restaurants.find(
   { $or: [ { "cuisine": "Italian" }, { "address.zipcode": "10075" } ] }
)



##Quick - Aggregation 
db._my_collection(pipeline=[
    { match_stage eg $match:{field1:value1,..}},
    {group_stage eg $group :{_id:"$col" , new_col: {$sum:"$col2",..} }}
    ], <options>)


##$match
{ $match: { <query> } }
#You cannot use $where in $match queries as part of the aggregation pipeline.
#To use $text in the $match stage, the $match stage has to be the first stage of the pipeline.

#for 
{ "_id" : ObjectId("512bc95fe835e68f199c8686"), "author" : "dave", "score" : 80, "views" : 100 }
{ "_id" : ObjectId("512bc962e835e68f199c8687"), "author" : "dave", "score" : 85, "views" : 521 }
{ "_id" : ObjectId("55f5a192d4bede9ac365b257"), "author" : "ahn", "score" : 60, "views" : 1000 }
{ "_id" : ObjectId("55f5a192d4bede9ac365b258"), "author" : "li", "score" : 55, "views" : 5000 }
{ "_id" : ObjectId("55f5a1d3d4bede9ac365b259"), "author" : "annT", "score" : 60, "views" : 50 }
{ "_id" : ObjectId("55f5a1d3d4bede9ac365b25a"), "author" : "li", "score" : 94, "views" : 999 }
{ "_id" : ObjectId("55f5a1d3d4bede9ac365b25b"), "author" : "ty", "score" : 95, "views" : 1000 }

#Equality Match
db.articles.aggregate(
    [ { $match : { author : "dave" } } ]
);
#output
{ "_id" : ObjectId("512bc95fe835e68f199c8686"), "author" : "dave", "score" : 80, "views" : 100 }
{ "_id" : ObjectId("512bc962e835e68f199c8687"), "author" : "dave", "score" : 85, "views" : 521 }

#Perform a Count
#using the $match and then pipes to the $group to compute a count of the documents:

db.articles.aggregate( [
  { $match: { $or: [ { score: { $gt: 70, $lt: 90 } }, { views: { $gte: 1000 } } ] } },
  { $group: { _id: null, count: { $sum: 1 } } }
] );
#output 
{ "_id" : null, "count" : 5 }


###* Examples - $limit
{ $limit: <positive integer> }

#returns only the first 5 documents
db.article.aggregate(
    { $limit : 5 }
);



## $skip
{ $skip: <positive integer> }
#skips the first 5 documents
db.article.aggregate(
    { $skip : 5 }
);

   

##group
{ $group: { _id: <expression>, <field1>: { <accumulator1> : <expression1> }, ... } }

#Calculate Count, Sum, and Average
#for 
{ "_id" : 1, "item" : "abc", "price" : 10, "quantity" : 2, "date" : ISODate("2014-03-01T08:00:00Z") }
{ "_id" : 2, "item" : "jkl", "price" : 20, "quantity" : 1, "date" : ISODate("2014-03-01T09:00:00Z") }
{ "_id" : 3, "item" : "xyz", "price" : 5, "quantity" : 10, "date" : ISODate("2014-03-15T09:00:00Z") }
{ "_id" : 4, "item" : "xyz", "price" : 5, "quantity" : 20, "date" : ISODate("2014-04-04T11:21:39.736Z") }
{ "_id" : 5, "item" : "abc", "price" : 10, "quantity" : 10, "date" : ISODate("2014-04-04T21:23:13.331Z") }

#to group the documents by the month, day, and year 
#and calculates the total price and the average quantity as well as counts the documents per each group:
db.sales.aggregate(
   [
      {
        $group : {
           _id : { month: { $month: "$date" }, day: { $dayOfMonth: "$date" }, year: { $year: "$date" } },
           totalPrice: { $sum: { $multiply: [ "$price", "$quantity" ] } },
           averageQuantity: { $avg: "$quantity" },
           count: { $sum: 1 }
        }
      }
   ]
)
#output 
{ "_id" : { "month" : 3, "day" : 15, "year" : 2014 }, "totalPrice" : 50, "averageQuantity" : 10, "count" : 1 }
{ "_id" : { "month" : 4, "day" : 4, "year" : 2014 }, "totalPrice" : 200, "averageQuantity" : 15, "count" : 2 }
{ "_id" : { "month" : 3, "day" : 1, "year" : 2014 }, "totalPrice" : 40, "averageQuantity" : 1.5, "count" : 2 }

#Group by null
#specifies a group _id of null, calculating the total price and the average quantity as well as counts for all documents in the collection:
db.sales.aggregate(
   [
      {
        $group : {
           _id : null,
           totalPrice: { $sum: { $multiply: [ "$price", "$quantity" ] } },
           averageQuantity: { $avg: "$quantity" },
           count: { $sum: 1 }
        }
      }
   ]
)

#output 
{ "_id" : null, "totalPrice" : 290, "averageQuantity" : 8.6, "count" : 5 }

#Retrieve Distinct Values
#for 
{ "_id" : 1, "item" : "abc", "price" : 10, "quantity" : 2, "date" : ISODate("2014-03-01T08:00:00Z") }
{ "_id" : 2, "item" : "jkl", "price" : 20, "quantity" : 1, "date" : ISODate("2014-03-01T09:00:00Z") }
{ "_id" : 3, "item" : "xyz", "price" : 5, "quantity" : 10, "date" : ISODate("2014-03-15T09:00:00Z") }
{ "_id" : 4, "item" : "xyz", "price" : 5, "quantity" : 20, "date" : ISODate("2014-04-04T11:21:39.736Z") }
{ "_id" : 5, "item" : "abc", "price" : 10, "quantity" : 10, "date" : ISODate("2014-04-04T21:23:13.331Z") }

#to group the documents by the item to retrieve the distinct item values
db.sales.aggregate( [ { $group : { _id : "$item" } } ] )
#output 
{ "_id" : "xyz" }
{ "_id" : "jkl" }
{ "_id" : "abc" }

#Pivot Data
#for 
{ "_id" : 8751, "title" : "The Banquet", "author" : "Dante", "copies" : 2 }
{ "_id" : 8752, "title" : "Divine Comedy", "author" : "Dante", "copies" : 1 }
{ "_id" : 8645, "title" : "Eclogues", "author" : "Dante", "copies" : 2 }
{ "_id" : 7000, "title" : "The Odyssey", "author" : "Homer", "copies" : 10 }
{ "_id" : 7020, "title" : "Iliad", "author" : "Homer", "copies" : 10 }

#pivots the data in the books collection to have titles grouped by authors.
db.books.aggregate(
   [
     { $group : { _id : "$author", books: { $push: "$title" } } }
   ]
)
#output 
{ "_id" : "Homer", "books" : [ "The Odyssey", "Iliad" ] }
{ "_id" : "Dante", "books" : [ "The Banquet", "Divine Comedy", "Eclogues" ] }

#uses the $$ROOT system variable to group the documents by authors. 
#The resulting documents must not exceed the BSON Document Size limit.

db.books.aggregate(
   [
     { $group : { _id : "$author", books: { $push: "$$ROOT" } } }
   ]
)
#output 

{
  "_id" : "Homer",
  "books" :
     [
       { "_id" : 7000, "title" : "The Odyssey", "author" : "Homer", "copies" : 10 },
       { "_id" : 7020, "title" : "Iliad", "author" : "Homer", "copies" : 10 }
     ]
}

{
  "_id" : "Dante",
  "books" :
     [
       { "_id" : 8751, "title" : "The Banquet", "author" : "Dante", "copies" : 2 },
       { "_id" : 8752, "title" : "Divine Comedy", "author" : "Dante", "copies" : 1 },
       { "_id" : 8645, "title" : "Eclogues", "author" : "Dante", "copies" : 2 }
     ]
}




##$unwind
#Deconstructs an array field from the input documents to output a document for each element. 
#Each output document is the input document with the value of the array field replaced by the element.
{ $unwind: <field path> }
#or 
{
  $unwind:
    {
      path: <field path>,
      includeArrayIndex: <string>,
      preserveNullAndEmptyArrays: <boolean>
    }
}
path 	                    string 	Field path to an array field. To specify a field path, prefix the field name with a dollar sign $ and enclose in quotes.
includeArrayIndex 	        string 	Optional. The name of a new field to hold the array index of the element. The name cannot start with a dollar sign $.
preserveNullAndEmptyArrays 	boolean 	


#Unwind Array
#for 
{ "_id" : 1, "item" : "ABC1", sizes: [ "S", "M", "L"] }

db.inventory.aggregate( [ { $unwind : "$sizes" } ] )
#output 
{ "_id" : 1, "item" : "ABC1", "sizes" : "S" }
{ "_id" : 1, "item" : "ABC1", "sizes" : "M" }
{ "_id" : 1, "item" : "ABC1", "sizes" : "L" }

#for 
{ "_id" : 1, "item" : "ABC", "sizes": [ "S", "M", "L"] }
{ "_id" : 2, "item" : "EFG", "sizes" : [ ] }
{ "_id" : 3, "item" : "IJK", "sizes": "M" }
{ "_id" : 4, "item" : "LMN" }
{ "_id" : 5, "item" : "XYZ", "sizes" : null }

#equivalent operation 
db.inventory.aggregate( [ { $unwind: "$sizes" } ] )
db.inventory.aggregate( [ { $unwind: { path: "$sizes" } } ] )
#output 
{ "_id" : 1, "item" : "ABC", "sizes" : "S" }
{ "_id" : 1, "item" : "ABC", "sizes" : "M" }
{ "_id" : 1, "item" : "ABC", "sizes" : "L" }
{ "_id" : 3, "item" : "IJK", "sizes" : "M" }

#uses the includeArrayIndex option to output also the array index of the array element.
db.inventory.aggregate( [ { $unwind: { path: "$sizes", includeArrayIndex: "arrayIndex" } } ] )
#output 
{ "_id" : 1, "item" : "ABC", "sizes" : "S", "arrayIndex" : NumberLong(0) }
{ "_id" : 1, "item" : "ABC", "sizes" : "M", "arrayIndex" : NumberLong(1) }
{ "_id" : 1, "item" : "ABC", "sizes" : "L", "arrayIndex" : NumberLong(2) }
{ "_id" : 3, "item" : "IJK", "sizes" : "M", "arrayIndex" : null }

#uses the preserveNullAndEmptyArrays option to include in the output those documents where sizes field is missing, null or an empty array.
db.inventory.aggregate( [
   { $unwind: { path: "$sizes", preserveNullAndEmptyArrays: true } }
] )
#output
{ "_id" : 1, "item" : "ABC", "sizes" : "S" }
{ "_id" : 1, "item" : "ABC", "sizes" : "M" }
{ "_id" : 1, "item" : "ABC", "sizes" : "L" }
{ "_id" : 2, "item" : "EFG" }
{ "_id" : 3, "item" : "IJK", "sizes" : "M" }
{ "_id" : 4, "item" : "LMN" }
{ "_id" : 5, "item" : "XYZ", "sizes" : null }






##$sort
#Sorts all input documents and returns them to the pipeline in sorted order.
{ $sort: { <field1>: <sort order>, <field2>: <sort order> ... } }
#<sort order> can have one of the following values:
1 to specify ascending order.
-1 to specify descending order.
{ $meta: "textScore" } to sort by the computed textScore metadata in descending order. See Metadata Sort for an example.


#Ascending/Descending Sort
db.users.aggregate(
   [
     { $sort : { age : -1, posts: 1 } }
   ]
)

##$count
#Returns a document that contains a count of the number of documents input to the stage.
{ $count: <string> }

 
#for 
{ "_id" : 1, "subject" : "History", "score" : 88 }
{ "_id" : 2, "subject" : "History", "score" : 92 }
{ "_id" : 3, "subject" : "History", "score" : 97 }
{ "_id" : 4, "subject" : "History", "score" : 71 }
{ "_id" : 5, "subject" : "History", "score" : 79 }
{ "_id" : 6, "subject" : "History", "score" : 83 }

#The following aggregation operation has two stages:
#The $match stage excludes documents that have a score value of less than or equal to 80 to pass along the documents with score greater than 80 to the next stage.
#The $count stage returns a count of the remaining documents in the aggregation pipeline and assigns the value to a field called passing_scores.

db.scores.aggregate(
  [
    {
      $match: {
        score: {
          $gt: 80
        }
      }
    },
    {
      $count: "passing_scores"
    }
  ]
)

#output 
{ "passing_scores" : 4 }



##$sortByCount
#Groups incoming documents based on the value of a specified expression, 
#then computes the count of documents in each distinct group.
{ $sortByCount:  <expression> }

 
#The $sortByCount stage is equivalent to the following $group + $sort sequence:
{ $group: { _id: <expression>, count: { $sum: 1 } } },{ $sort: { count: -1 } }

#for 
{ "_id" : 1, "title" : "The Pillars of Society", "artist" : "Grosz", "year" : 1926, "tags" : [ "painting", "satire", "Expressionism", "caricature" ] }
{ "_id" : 2, "title" : "Melancholy III", "artist" : "Munch", "year" : 1902, "tags" : [ "woodcut", "Expressionism" ] }
{ "_id" : 3, "title" : "Dancer", "artist" : "Miro", "year" : 1925, "tags" : [ "oil", "Surrealism", "painting" ] }
{ "_id" : 4, "title" : "The Great Wave off Kanagawa", "artist" : "Hokusai", "tags" : [ "woodblock", "ukiyo-e" ] }
{ "_id" : 5, "title" : "The Persistence of Memory", "artist" : "Dali", "year" : 1931, "tags" : [ "Surrealism", "painting", "oil" ] }
{ "_id" : 6, "title" : "Composition VII", "artist" : "Kandinsky", "year" : 1913, "tags" : [ "oil", "painting", "abstract" ] }
{ "_id" : 7, "title" : "The Scream", "artist" : "Munch", "year" : 1893, "tags" : [ "Expressionism", "painting", "oil" ] }
{ "_id" : 8, "title" : "Blue Flower", "artist" : "O'Keefe", "year" : 1918, "tags" : [ "abstract", "painting" ] }

db.exhibits.aggregate( [ { $unwind: "$tags" },  { $sortByCount: "$tags" } ] )
#output 
{ "_id" : "painting", "count" : 6 }
{ "_id" : "oil", "count" : 4 }
{ "_id" : "Expressionism", "count" : 3 }
{ "_id" : "Surrealism", "count" : 2 }
{ "_id" : "abstract", "count" : 2 }
{ "_id" : "woodblock", "count" : 1 }
{ "_id" : "woodcut", "count" : 1 }
{ "_id" : "ukiyo-e", "count" : 1 }
{ "_id" : "satire", "count" : 1 }
{ "_id" : "caricature", "count" : 1 }









###Spark Mongo connector - mongo-spark-connector
 
#Connects to port 27017 by default. db=test, collection=myCollection 
$ pyspark --conf "spark.mongodb.input.uri=mongodb://127.0.0.1/test.myCollection?readPreference=primaryPreferred" \
              --conf "spark.mongodb.output.uri=mongodb://127.0.0.1/test.myCollection" \
              --packages org.mongodb.spark:mongo-spark-connector_2.11:2.3.0

#The spark.mongodb.input.uri specifies the MongoDB server address (127.0.0.1), the database to connect (test), and the collection (myCollection) from which to read data, and the read preference.
#The spark.mongodb.output.uri specifies the MongoDB server address (127.0.0.1), the database to connect (test), and the collection (myCollection) to which to write data. 

#OR Creating via spark Session 

from pyspark.sql import SparkSession

my_spark = SparkSession \
    .builder \
    .appName("myApp") \
    .config("spark.mongodb.input.uri", "mongodb://127.0.0.1/test.coll") \
    .config("spark.mongodb.output.uri", "mongodb://127.0.0.1/test.coll") \
    .getOrCreate()

##Write to MongoDB
people = spark.createDataFrame([("Bilbo Baggins",  50), ("Gandalf", 1000), ("Thorin", 195), ("Balin", 178), ("Kili", 77),
   ("Dwalin", 169), ("Oin", 167), ("Gloin", 158), ("Fili", 82), ("Bombur", None)], ["name", "age"])

people.write.format("com.mongodb.spark.sql.DefaultSource").mode("append").save()

people.show()
#Output 
+-------------+----+
|         name| age|
+-------------+----+
|Bilbo Baggins|  50|
|      Gandalf|1000|
|       Thorin| 195|
|        Balin| 178|
|         Kili|  77|
|       Dwalin| 169|
|          Oin| 167|
|        Gloin| 158|
|         Fili|  82|
|       Bombur|null|
+-------------+----+
people.printSchema()
#Output 
root
 |-- _id: struct (nullable = true)
 |    |-- oid: string (nullable = true)
 |-- age: long (nullable = true)
 |-- name: string (nullable = true)


#to write to a different MongoDB collection, use the .option() method with .write().
people.write.format("com.mongodb.spark.sql.DefaultSource").mode("append").
    option("database","people").option("collection", "contacts").save()

    
    
##Read from MongoDB
#from default input uri  
df = spark.read.format("com.mongodb.spark.sql.DefaultSource").load()

#to read from a different MongoDB collection, use the .option method when reading data into a DataFrame.
df = spark.read.format("com.mongodb.spark.sql.DefaultSource").option("uri","mongodb://127.0.0.1/people.contacts").load()



##Aggregation while reading 
#collection named fruit
{ "_id" : 1, "type" : "apple", "qty" : 5 }
{ "_id" : 2, "type" : "orange", "qty" : 10 }
{ "_id" : 3, "type" : "banana", "qty" : 15 }


pipeline = "{'$match': {'type': 'apple'}}"
df = spark.read.format("com.mongodb.spark.sql.DefaultSource").option("pipeline", pipeline).load()
df.show()
#Output 
+---+---+-----+
|_id|qty| type|
+---+---+-----+
|1.0|5.0|apple|
+---+---+-----+

##Filters
df = spark.read.format("com.mongodb.spark.sql.DefaultSource").load()
df.filter(df['qty'] >= 10).show()
#Output 

+---+----+------+
|_id| qty|  type|
+---+----+------+
|2.0|10.0|orange|
|3.0|15.0|banana|
+---+----+------+


#SQL
df.createOrReplaceTempView("temp")
some_fruit = spark.sql("SELECT type, qty FROM temp WHERE type LIKE '%e%'")
some_fruit.show()
#output 

+------+----+
|  type| qty|
+------+----+
| apple| 5.0|
|orange|10.0|
+------+----+





###*** AWS EMR and spark 

#Amazon EMR processes big data across a Hadoop cluster of virtual servers 
#on Amazon Elastic Compute Cloud (EC2) and Amazon Simple Storage Service (S3). 
 
#You can also run other popular distributed frameworks such as Apache Spark, HBase, Presto, and Flink in Amazon EMR, 
#and interact with data in other AWS data stores such as Amazon S3 and Amazon DynamoDB

#login to aws.amazon.com  and create EMR cluster where you can setup what components to be configured 
#Check further 
#https://towardsdatascience.com/end-to-end-distributed-ml-using-aws-emr-apache-spark-pyspark-and-mongodb-tutorial-with-4d1077f68381



###*** Accessing AWS S3 from PySpark 

#https://docs.aws.amazon.com/AmazonS3/latest/user-guide/create-bucket.html

#Currently, there are three ways one can read files: s3, s3n and s3a. 
#Use s3a only as it is the fastest., Note s3 would not be available in future releases.

#v4 authentication: AWS S3 supports two versions of authentication-v2 and v4, 
#new regions like Mumbai and Frankfurt only have v4.

$ pyspark --packages org.apache.hadoop:hadoop-aws:2.7.1

#Code 
from pyspark import SparkContext
from pyspark.sql import SparkSession
from pyspark import SparkConf

#Without below, the job would not run in a cluster mode. 
conf = (SparkConf().set("spark.executor.extraJavaOptions","-Dcom.amazonaws.services.s3.enableV4=true").set("spark.driver.extraJavaOptions","-Dcom.amazonaws.services.s3.enableV4=true"))

#If running on a local cluster, no need to specify above .
sc = SparkContext(conf=conf)
sc.setSystemProperty("com.amazonaws.services.s3.enableV4", "true")

#Install hadoop  on master and all nodes of the cluster 
#then set configuration 
'''
note for S3n 
sc._jsc.hadoopConfiguration().set("fs.s3n.awsAccessKeyId", aws_id)
sc._jsc.hadoopConfiguration().set("fs.s3n.awsSecretAccessKey", aws_key)
'''
hadoopConf = sc._jsc.hadoopConfiguration()
hadoopConf.set("fs.s3a.awsAccessKeyId", "XXXXX")
hadoopConf.set("fs.s3a.awsSecretAccessKey", "XXXXX")
hadoopConf.set("fs.s3a.endpoint", "s3-ap-south-1.amazonaws.com") #https://docs.aws.amazon.com/general/latest/gr/rande.html
hadoopConf.set("com.amazonaws.services.s3a.enableV4", "true")
hadoopConf.set("fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")

#To set AWS credential using other methods 
#check https://www.cloudera.com/documentation/enterprise/5-9-x/topics/spark_s3.html

##Using SC - s3a://bucket/fileName 
sonnets = sc.textFile("s3a://s3-to-ec2/sonnets.txt")
counts = sonnets.flatMap(lambda line :line.split(" ")).map(lambda word : (word, 1)).reduceByKey(lambda r,e : r+e)
counts.saveAsTextFile("s3a://s3-to-ec2/output")

#Using SparkSession , mention schema specifically 
spark = SparkSession(sc)
#some schema 
schema = StructType([
  StructField("code",StringType(),False),
  StructField("description",StringType(),False),
  StructField("total_emp",IntegerType(),False),
  StructField("salary",IntegerType(),False)])

csv_df = sql.read.option('header', 'true').schema(schema).csv('s3a://s3-to-ec2/sample_07.csv')
csv_df.write.parquet("s3a://s3-to-ec2/sample_07.parquet")

##Using new Hodoop file format 
from pyspark import SparkContext, SparkConf
conf = SparkConf().setAppName("first")
sc = SparkContext(conf=conf)

sc._jsc.hadoopConfiguration().set("fs.s3n.awsAccessKeyId", aws_id)
sc._jsc.hadoopConfiguration().set("fs.s3n.awsSecretAccessKey", aws_key)


lines = sc.hadoopFile("s3n://one_bucket/dataset.json",
                    'org.apache.hadoop.mapred.TextInputFormat',
                    'org.apache.hadoop.io.Text',
                    'org.apache.hadoop.io.LongWritable')
                    
fileLines = sc.newAPIHadoopFile('s3n://one_bucket/one_dir/*', 
    'org.apache.hadoop.mapreduce.lib.input.TextInputFormat',
    'org.apache.hadoop.io.LongWritable',
    'org.apache.hadoop.io.Text',
    conf={'mapreduce.input.fileinputformat.input.dir.recursive':'true'} #other configuration files 
    )



####*** Azure wasb and Spark 

$ pyspark --packages org.apache.hadoop:hadoop-azure:2.7.3 #bring all dependendts packages eg azure-storage

 
#Code 
spark = ...

hadoopConf =  spark.sparkContext._jsc.hadoopConfiguration()
hadoopConf.set("fs.azure", "org.apache.hadoop.fs.azure.NativeAzureFileSystem")
hadoopConf.set("fs.azure.account.key.yourAccount.blob.core.windows.net", "yourKey ")

baseDir = "wasb[s]://BlobStorageContainer@yourUser.blob.core.windows.net/"

df_csv  = spark.read.option("header", true).csv(baseDir + "pathToCsvFile")
df_text = spark.read.textFile(baseDir + "pathToTextFile")
  
df_text.write.mode("append").json(baseDir + outputPath)
 



###*** Cassandra and spark 

##Using direct com.datastax.spark:spark-cassandra-connector
#Check version compatibility : https://github.com/datastax/spark-cassandra-connector#version-compatibility
#set the host address via command line (must)
$pyspark --packages com.datastax.spark:spark-cassandra-connector_2.11:2.3.0 --conf spark.cassandra.connection.host=127.0.0.1

#Example 
#Check example - https://github.com/datastax/spark-cassandra-connector/blob/master/doc/14_data_frames.md
user = spark
    .read
    .format("org.apache.spark.sql.cassandra")
    .options(keyspace="training", table="user").load.cache()
adults = user.where(user.age > 21) 
user.select("age", "user_id", "name").write.format("org.apache.spark.sql.cassandra").options(table="users_by_age", keyspace="training").save(mode="append") 


## Using PySpark Cassandra
$ pyspark --packages anguenot/pyspark-cassandra:0.9.0 --conf spark.cassandra.connection.host=your,cassandra,node,names

#Check https://github.com/anguenot/pyspark-cassandra for full API 
import pyspark_cassandra

conf = SparkConf() \
	.setAppName("PySpark Cassandra Test") \
	.setMaster("spark://spark-master:7077") \
	.set("spark.cassandra.connection.host", "cas-1")

sc = CassandraSparkContext(conf=conf)

#Read 
sc \
	.cassandraTable("keyspace", "table") \
	.select("col-a", "col-b") \
	.where("key=?", "x") \
	.filter(lambda r: r["col-b"].contains("foo")) \
	.map(lambda r: (r["col-a"], 1)
	.reduceByKey(lambda a, b: a + b)
	.collect()

#Write 
rdd = sc.parallelize([{
	"key": k,
	"stamp": datetime.now(),
	"val": random() * 10,
	"tags": ["a", "b", "c"],
	"options": {
		"foo": "bar",
		"baz": "qux",
	}
} for k in ["x", "y", "z"]])

rdd.saveToCassandra(
	"keyspace",
	"table",
	ttl=timedelta(hours=1),
)

#Modify CQL collections::
# Cassandra test table schema
# create table test (user_id text, city text,  test_set set<text>, test_list list<text>, test_map map<text,text>, PRIMARY KEY (user_id));

rdd = sc.parallelize([{"user_id":"123","city":"berlin","test_set":["a"],"test_list":["a"],"test_map":{"a":"1"}}])

rdd.saveToCassandra("ks","test")

rdd = sc.parallelize([{"user_id":"123","city":"berlin","test_set":["a"],"test_list":["b"],"test_map":{"b":"2"}}])

rdd.saveToCassandra("ks","test", {"user_id":"", "city":"", "test_set":"remove", "test_list":"prepend", "test_map":"append"})

#Using DStream 
from pyspark.streaming import StreamingContext
from pyspark_cassandra import streaming

ssc = StreamingContext(sc, 2)

ssc \
    .socketTextStream("localhost", 9999) \
    .flatMap(lambda l: ((w,) for w in (l,))) \
    .saveToCassandra('keyspace', 'words')

ssc.start()

#Joining with Cassandra:

joined = rdd \
    .joinWithCassandraTable('keyspace', 'accounts') \
    .on('id') \
    .select('e-mail', 'followers')

#Or with a DStream:

joined = dstream.joinWithCassandraTable(self.keyspace, self.table, \
    ['e-mail', 'followers'], ['id'])






















    



###*** Impala and  spark 
#Impal package not in maven, hence download from http://www.cloudera.com/downloads/connectors/impala/jdbc/2-5-30.html
#and use --jars commands 
$ pyspark  --driver-class-path ImpalaJDBC41.jar --jars ImpalaJDBC41.jar 

#Example 
JDBCDriver = "com.cloudera.impala.jdbc41.Driver"
ConnectionURL = "jdbc:impala://url.server.net:21050/default;auth=noSasl"

df = spark.read.format("jdbc").options(url=ConnectionURL,
                 driver=JDBCDriver, dbtable="impala_table")).load() 
                 
                 
                 
                 
###*** Hbase and spark 
#check other options  - https://diogoalexandrefranco.github.io/interacting-with-hbase-from-pyspark/

$ pyspark --packages com.hortonworks:shc-core:1.1.1-2.1-s_2.11 --repositories http://repo.hortonworks.com/content/groups/public/  --files <some_path>/hbase-site.xml
#https://github.com/hortonworks-spark/shc


catalog = ''.join("""
    {
        'table': {
            'namespace': 'default',
            'name': 'books'
        },
        'rowkey': 'key',
        'columns': {
            'title': {'cf': 'rowkey', 'col': 'key', 'type': 'string'},
            'author': {'cf': 'info', 'col': 'author', 'type': 'string'}
        }
    }
""".split())

      
df = spark \
    .read \
    .options(catalog=catalog) \
    .format('org.apache.spark.sql.execution.datasources.hbase') \
    .load()

df.show()

# Writing
df.write\
.options(catalog=catalog)\  # alternatively: .option('catalog', catalog)
.format('org.apache.spark.sql.execution.datasources.hbase')\
.save()

#Check scala example 
#https://docs.microsoft.com/en-us/azure/hdinsight/hdinsight-using-spark-query-hbase







###+++ Spark Streaming Vs Structured Streaming 
Spark Streaming 
    No waterMark concept 
    Main: spark-streaming_2.11_2.2.0.jar
        Kafka 	spark-streaming-kafka-0-8_2.11
        Flume 	spark-streaming-flume_2.11
        Kinesis	spark-streaming-kinesis-asl_2.11
    Has StreamingContext 
    has DStream, InputDStream, PairDStreamFunctions
    Has below trsnformations 
        map(func)                   
        flatMap(func)               
        filter(func)                
        repartition(numPartitions)  
        union(otherStream)          
        count()                     
        reduce(func)                
        countByValue()                 
        reduceByKey(func, [numTasks])  
        join(otherStream, [numTasks])  
        cogroup(otherStream, [numTasks])
        transform(func)                 
        updateStateByKey(func)    
        mapWithState(func)
    Has below Actions 
        print(), saveAsObjectFiles(prefix, [suffix]) , saveAsHadoopFiles(prefix, [suffix])  
        saveAsTextFiles(prefix, [suffix])  
        foreachRDD(func)  
Structured Streaming 
    Better performance than spark streaming and also has Watermark concept 
    Use the DataFrame API 
    Note df.rdd are not supported, so we don't have map. flatMap etc in python (scala-OK), 
    Use sql.functions to transform each column 
        below are not supported 
            Multiple streaming aggregations (i.e. a chain of aggregations on a streaming DF) are not yet supported on streaming Datasets.
            Limit and take first N rows are not supported on streaming Datasets.
            Distinct operations on streaming Datasets are not supported.
            Sorting operations are supported on streaming Datasets only after an aggregation 
                and in Complete Output Mode.
            Outer joins between a streaming and a static Datasets are conditionally supported.
                Full outer join with a streaming Dataset is not supported
                Left outer join with a streaming Dataset on the right is not supported
                Right outer join with a streaming Dataset on the left is not supported
            Any kind of joins between two streaming Datasets is not yet supported.
            count() - Cannot return a single count from a streaming Dataset. 
                Instead, use ds.groupBy().count() which returns a streaming Dataset containing a running count.
            foreach() - Instead use ds.writeStream.foreach(...) #not available in python 
            show() - Instead use the console sink 
    Reading  by spark.readStream, writing by spark.writeStream
    Then use DataStreamReader and DataStreamWriter 
    
#Example Streaming - DStream based 
from pyspark import *      
from pyspark.streaming  import *        #StreamingContext, DStream

#run at first ,    $ nc -lk 9999
 
import sys 

if len(sys.argv) < 3 :
    print("Usage: NetworkWordCount <hostname> <port>")
    sys.exit()

#Create the context with a 1 second batch size
sparkConf = new SparkConf().setAppName("NetworkWordCount")
ssc = new StreamingContext(sparkConf, 1) #batchDuration=1 sec 

#Create a socket stream on target ip:port and count the
#words in input stream of \n delimited text (eg. generated by 'nc')
#Note that no duplication in storage level only for running locally.
#Replication necessary in distributed scenario for fault tolerance.
lines = ssc.socketTextStream(sys.argv[1], int(sys.argv[2]), StorageLevel.MEMORY_AND_DISK_SER)
words = lines.flatMap( lambda e: e.split(" "))
wordCounts = words.map(lambda x : (x, 1)).reduceByKey(_ + _)
wordCounts.print()
ssc.start()
ssc.awaitTermination()


#Example - Structured Streaming - DataFrame based 
from pyspark import *                   
from pyspark.sql import *               
from pyspark.sql.functions import * 
from pyspark.sql.types import * 

#Usage: StructuredNetworkWordCountWindowed <hostname> <port> <window duration> [<slide duration>]
# <hostname> and <port> describe the TCP server that Structured Streaming
# would connect to receive data.
# <window duration> gives the size of window, specified as integer number of seconds
# <slide duration> gives the amount of time successive windows are offset from one another,
# given in the same units as above. <slide duration> should be less than or equal to
# <window duration>. If the two are equal, successive windows have no overlap. If
# <slide duration> is not provided, it defaults to <window duration>.
#To run this on your local machine, you need to first run a Netcat server
$ nc -lk 9999
#One recommended <window duration>, <slide duration> pair is 10, 5

import sys 

if len(sys.argv) < 4 :
    print("Usage: StructuredNetworkWordCountWindowed <hostname> <port> <window duration in seconds> [<slide duration in seconds>]")
    sys.exit()

host = sys.argv[1]
port = int(sys.argv[2])
windowSize = int(sys.argv[3])
slideSize = windowSize
if len(sys.argv) == 5:
    slideSize = int(sys.argv[4])
if slideSize > windowSize: 
    print("<slide duration> must be less than or equal to <window duration>")
    slideSize = windowSize
    
windowDuration = "%d seconds" % (windowSize, )
slideDuration = "%d seconds"  % (slideSize, )

spark = SparkSession
  .builder
  .appName("StructuredNetworkWordCountWindowed")
  .getOrCreate()

#Create DataFrame representing the stream of input lines from connection to host:port
lines = spark.readStream.format("socket").option("host", host).option("port", port).option("includeTimestamp", True).load()
#DataFrame[value: string, timestamp: timestamp]
#Split the lines into words, retaining timestamps
#(String, Timestamp)
#DataFrame does not have flatMap , .rdd can not be used in streaming DataFrame 

words = lines.select( explode(split(lines.value, " ")).alias("word"), col("timestamp"))

#Group the data by window and word and compute the count of each group
windowedCounts = words.withWatermark("timestamp", "10 minutes").groupBy(window(col("timestamp"), windowDuration, slideDuration), col("word")).count().orderBy("window")

#Start running the query that prints the windowed word counts to the console
query = windowedCounts.writeStream.outputMode("complete").format("console").option("truncate", "false").start()

query.awaitTermination()







    
###Spark - Legacy Streaming -  Integration with Flume

#Download from 
#http://www.apache.org/dyn/closer.lua/flume/1.8.0/apache-flume-1.8.0-bin.tar.gz
#Start agent based on configuration file 


#Apache Flume is a distributed system for efficiently collecting, aggregating 
#and moving large amounts of log data from many different sources 
#to a centralized data store.

#Flume agent is a (JVM) process that hosts the components(source, channel, sink - each one could be many)
#One flow is One source to one channel to one sink 
#Source produces events based on source.type, events goes to channel before being picked by a sink.type
#A source can specify multiple channels for outputs 
#but a sink can only specify one channel for input 
#Channel - Buffer place with many inputs(each connected to a source) and one output(connected to a sink)

#Each component (source, sink or channel) has a name, type, and set of properties



#conf/first.conf.properties
#A single-node Flume configuration
# Sources, channels and sinks are defined per agent, 
# in this case named 'a1'

# Name the components on this agent eg sources, sinks, channels - names are r1,k1,c1
a1.sources = r1  
a1.sinks = k1
a1.channels = c1

# Describe/configure the source
a1.sources.r1.type = netcat
a1.sources.r1.bind = localhost
a1.sources.r1.port = 44444

# Describe the sink
a1.sinks.k1.type = logger

# Use a channel which buffers events in memory
a1.channels.c1.type = memory
a1.channels.c1.capacity = 1000
a1.channels.c1.transactionCapacity = 100

##Start the agent - named a1 
bin\flume-ng.cmd agent --conf conf --conf-file conf\first.conf.properties --name a1 -property "flume.root.logger=INFO,console"
#You can put all properties, env variable in conf\flume-env.ps1(check template conf\flume-env.ps1.template)

#Here comes logger output from all telnets commond prompts 
2018-02-16 16:55:06,085 (SinkRunner-PollingRunner-DefaultSinkProcessor) [INFO -org.apache.flume.sink.LoggerSink.process(LoggerSink.java:95)] Event: { headers:{} body: 68 65 6C 6C 6F 20 77 6F 72 6C 64 20 66 72 6F 6D hello world from }

##Start in two cmds - pushing data  
$ telnet localhost 44444
$ telnet localhost 44444

##Using environment variables as values in configuration files
a1.sources.r1.port = ${NC_PORT}

##Logging production environment 
-property "flume.root.logger=INFO,console;org.apache.flume.log.printconfig=true;org.apache.flume.log.rawdata=true"

##Appending more classpath 
-classpath  "value1;value2; .."

##Syntax- Configuration file syntax 
#list the sources, sinks and channels for the given agent, 
#and then point the source and sink to a channel. 


# list the sources, sinks and channels for the agent
<Agent>.sources = <Source>
<Agent>.sinks = <Sink>
<Agent>.channels = <Channel1> <Channel2>

# set channel for source
<Agent>.sources.<Source>.channels = <Channel1> <Channel2> ...
# set channel for sink
<Agent>.sinks.<Sink>.channel = <Channel1>

# properties for sources
<Agent>.sources.<Source>.<someProperty> = <someValue>
# properties for channels
<Agent>.channel.<Channel>.<someProperty> = <someValue>
# properties for sinks
<Agent>.sources.<Sink>.<someProperty> = <someValue>
 
#Example 
agent_foo.sources = avro-AppSrv-source
agent_foo.sinks = hdfs-Cluster1-sink
agent_foo.channels = mem-channel-1

# properties of avro-AppSrv-source
agent_foo.sources.avro-AppSrv-source.type = avro
agent_foo.sources.avro-AppSrv-source.bind = localhost
agent_foo.sources.avro-AppSrv-source.port = 10000

# properties of mem-channel-1
agent_foo.channels.mem-channel-1.type = memory
agent_foo.channels.mem-channel-1.capacity = 1000
agent_foo.channels.mem-channel-1.transactionCapacity = 100

# properties of hdfs-Cluster1-sink
agent_foo.sinks.hdfs-Cluster1-sink.type = hdfs
agent_foo.sinks.hdfs-Cluster1-sink.hdfs.path = hdfs:#namenode/flume/webdata



##Syntax - Adding multiple flows in an agent
# list the sources, sinks and channels for the agent
<Agent>.sources = <Source1> <Source2>
<Agent>.sinks = <Sink1> <Sink2>
<Agent>.channels = <Channel1> <Channel2>

#Example 
# list the sources, sinks and channels in the agent
agent_foo.sources = avro-AppSrv-source1 exec-tail-source2
agent_foo.sinks = hdfs-Cluster1-sink1 avro-forward-sink2
agent_foo.channels = mem-channel-1 file-channel-2

# flow #1 configuration
agent_foo.sources.avro-AppSrv-source1.channels = mem-channel-1
agent_foo.sinks.hdfs-Cluster1-sink1.channel = mem-channel-1

# flow #2 configuration
agent_foo.sources.exec-tail-source2.channels = file-channel-2
agent_foo.sinks.avro-forward-sink2.channel = file-channel-2



##Syntax - Fan out syntax 
# List the sources, sinks and channels for the agent
<Agent>.sources = <Source1>
<Agent>.sinks = <Sink1> <Sink2>
<Agent>.channels = <Channel1> <Channel2>

# set list of channels for source (separated by space)
<Agent>.sources.<Source1>.channels = <Channel1> <Channel2>

# set channel for sinks
<Agent>.sinks.<Sink1>.channel = <Channel1>
<Agent>.sinks.<Sink2>.channel = <Channel2>

<Agent>.sources.<Source1>.selector.type = replicating


##Flume - sources 
#https://flume.apache.org/FlumeUserGuide.html#flume-sources
#type           Required properties 
avro            bind, port,channels 
thrift          bind,port,channels
exec            command,channels  #executing external command eg command=tail -F /var/log/secure
jms             channels,initialContextFactory ,connectionFactory ,providerURL ,destinationName ,destinationType 
spooldir        channels,spoolDir #The directory from which to read files from. 
TAILDIR         channels,filegroups, filegroups.<filegroupName> #put absolute REGEX file path in filegroups.<filegroupName>
netcat          channels,bind, port  #TCP Source
netcatudp       channels,bind, port  #UDP Source
org.apache.flume.source.kafka.KafkaSource   channels,kafka.bootstrap.servers,kafka.topics,kafka.topics.regex
seq             channels      #A simple sequence generator that continuously generates events with a counter that starts from 0, increments by 1 and stops at totalEvents
syslogtcp       channels,host, port  #Syslog TCP Source
syslogudp       channels,host, port  #Syslog UDP Source
http            port        #binds to all ips on this host and handles JSON(array of events) by default 

##Flume - Sinks
#https://flume.apache.org/FlumeUserGuide.html#flume-sinks
hdfs            channel,hdfs.path  #eg hdfs:#namenode/flume/webdata/, supports many formatting chars 
hive            channel,hive.metastore,hive.database,hive.table 
logger          channel        #Logs event at INFO level
avro            channel,hostname,port
thrift          channel,hostname,port
irc             channel,hostname,noc,chan  #IRC sink
file_roll       channel,sink.directory  #The directory where files will be stored
null            channel       #null sink 
hbase           channel,table, columnFamily
org.apache.flume.sink.kafka.KafkaSink       kafka.bootstrap.servers,kafka.topic #This is a Flume Sink implementation that can publish data to a Kafka topic
http            channel,endpoint #The fully qualified URL endpoint to POST to

##Flume - Channels
#https://flume.apache.org/FlumeUserGuide.html#flume-channels
memory          capacity  #The events are stored in an in-memory queue with configurable max size
jdbc            db.username.db.password  #Supports only DERBY
file                    #File Channel
org.apache.flume.channel.kafka.KafkaChannel         kafka.bootstrap.servers


##Reference 
class pyspark.streaming.flume.FlumeUtils
    classmethod createPollingStream(ssc, addresses, storageLevel=StorageLevel(True, True, False, False, 2), 
                maxBatchSize=1000, parallelism=5, bodyDecoder=<function utf8_decoder at 0x7f51eb4416e0>)
        Creates an input stream that is to be used with the Spark Sink deployed on a Flume agent. 
        This stream will poll the sink for data and will pull events as they are available.
        Parameters:
            �ssc � StreamingContext object
            �addresses � List of (host, port)s on which the Spark Sink is running.
            �storageLevel � Storage level to use for storing the received objects
            �maxBatchSize � The maximum number of events to be pulled from the Spark sink in a single RPC call
            �parallelism � Number of concurrent requests this stream should send to the sink. Note that having a higher number of requests concurrently being pulled will result in this stream using more threads
            �bodyDecoder � A function used to decode body (default is utf8_decoder)
        Returns:    A DStream object 
    classmethod createStream(ssc, hostname, port, storageLevel=StorageLevel(True, True, False, False, 2), 
                enableDecompression=False, bodyDecoder=<function utf8_decoder at 0x7f51eb4416e0>)
        Create an input stream that pulls events from Flume.
        Parameters:
        �ssc � StreamingContext object
        �hostname � Hostname of the slave machine to which the flume data will be sent
        �port � Port of the slave machine to which the flume data will be sent
        �storageLevel � Storage level to use for storing the received objects
        �enableDecompression � Should netty server decompress input stream
        �bodyDecoder � A function used to decode body (default is utf8_decoder)
        Returns:    A DStream object
        
        
        
##Spark - Flume - Approach 1: Flume-style Push-based Approach        
#Flume is designed to push data between Flume agents. 
#In this approach, Spark Streaming essentially sets up a receiver that acts an Avro agent for Flume, to which Flume can push the data.
       
#Choose a machine in your cluster such that
�When your Flume + Spark Streaming application is launched, 
 one of the Spark workers must run on that machine.
�Flume can be configured to push data to a port on that machine.

#Due to the push model, the streaming application needs to be up, 
#with the receiver scheduled and listening on the chosen port, for Flume to be able push data.

##Configuration file - Fanout configuration 
#Note hat the hostname should be the same as the one used 
#by the resource manager in the cluster (Mesos, YARN or Spark Standalone), 
agent.sources = r1  
agent.sinks = avroSink k1
agent.channels = memoryChannel c1

# Describe/configure the source
agent.sources.r1.type = netcat
agent.sources.r1.bind = localhost
agent.sources.r1.port = 44444
agent.sources.r1.channels = memoryChannel c1
agent.sources.r1.selector.type = replicating

# Describe the sink
agent.sinks.k1.type = logger
agent.sinks.k1.channel = c1

agent.sinks.avroSink.type = avro
agent.sinks.avroSink.channel = memoryChannel
agent.sinks.avroSink.hostname = localhost 
agent.sinks.avroSink.port = 12345
     
agent.channels.memoryChannel.type = memory
agent.channels.memoryChannel.capacity = 1000
agent.channels.memoryChannel.transactionCapacity = 100       


# Use a channel which buffers events in memory
agent.channels.c1.type = memory
agent.channels.c1.capacity = 1000
agent.channels.c1.transactionCapacity = 100     
        
        
        
##Execution         
$ spark-submit --jars tobeShared/py/spark-streaming-flume-assembly_2.11-2.1.0.jar flume_wordcount.py localhost 12345    
#start flume 
$ bin\flume-ng.cmd agent --conf conf --conf-file conf\spark.conf.properties --name agent 
#Start source 
$ telnet localhost 44444



"""
 Counts words in UTF8 encoded, '\n' delimited text received from the network every second.
"""

from __future__ import print_function

import sys

from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.streaming.flume import FlumeUtils

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: flume_wordcount.py <hostname> <port>", file=sys.stderr)
        exit(-1)

    sc = SparkContext(appName="PythonStreamingFlumeWordCount")
    ssc = StreamingContext(sc, 1)

    hostname, port = sys.argv[1:]
    kvs = FlumeUtils.createStream(ssc, hostname, int(port))
    lines = kvs.map(lambda x: x[1])
    counts = lines.flatMap(lambda line: line.split(" ")) \
        .map(lambda word: (word, 1)) \
        .reduceByKey(lambda a, b: a+b)
    counts.pprint()

    ssc.start()
    ssc.awaitTermination()   
    
    
    
##Spark - Flume - Approach 2:   using a Custom Sink
#uses spark specific custom sink 

#Configuration 
1. download spark-streaming-flume-sink_2.11-2.2.1.jar
2. download commons-lang3-3.5.jar
3. download scala-library-2.11.8.jar
4. put them in C:\flume\lib (commandline options --classpath does not work)
   Delete old scala-library-2xx version 


#Configuration file : spark2.conf.properties 
agent.sources = r1  
agent.sinks = spark k1
agent.channels = memoryChannel c1

# Describe/configure the source
agent.sources.r1.type = netcat
agent.sources.r1.bind = localhost
agent.sources.r1.port = 44444
agent.sources.r1.channels = memoryChannel c1
agent.sources.r1.selector.type = replicating

# Describe the sink
agent.sinks.k1.type = logger
agent.sinks.k1.channel = c1

agent.sinks.spark.type = org.apache.spark.streaming.flume.sink.SparkSink
agent.sinks.spark.channel = memoryChannel
agent.sinks.spark.hostname = localhost 
agent.sinks.spark.port = 12345
     
agent.channels.memoryChannel.type = memory
agent.channels.memoryChannel.capacity = 1000
agent.channels.memoryChannel.transactionCapacity = 100       
# Use a channel which buffers events in memory
agent.channels.c1.type = memory
agent.channels.c1.capacity = 1000
agent.channels.c1.transactionCapacity = 100  


##Code change Only update below 
#Multiple agent sinks hostname and port can be given 
kvs = FlumeUtils.createPollingStream(ssc, [(hostname, int(port)),] )

    
    
    
    
   
###Spark - legacy Streaming -  Integration with Kinesis 
#Amazon Kinesis is a fully managed service for real-time processing of streaming data at massive scale. 
#The Kinesis receiver creates an input DStream using the Kinesis Client Library (KCL) provided by Amazon under the Amazon Software License (ASL).

#https://docs.aws.amazon.com/streams/latest/dev/before-you-begin.html
#AWS CLI 
#https://docs.aws.amazon.com/streams/latest/dev/kinesis-tutorial-cli-installation.html

$ pip install awscli 
$ aws kinesis help
$ aws configure
AWS Access Key ID [None]: ....
AWS Secret Access Key [None]: ....
Default region name [None]: us-west-2
Default output format [None]: json

#Step 1: Create a Stream
$ aws kinesis create-stream --stream-name Foo --shard-count 1
$ aws kinesis describe-stream --stream-name Foo
$ aws kinesis list-streams

#Step 2: Put a Record
$ aws kinesis put-record --stream-name Foo --partition-key 123 --data testdata

#Step 3: Get the Record
#Before you can get data from the stream ,obtain the shard iterator 
#for the shard you are interested in. 
#A shard iterator represents the position of the stream and shard from which the consumer (get-record command in this case) will read. 
$ aws kinesis get-shard-iterator --shard-id shardId-000000000000 --shard-iterator-type TRIM_HORIZON --stream-name Foo
$ aws kinesis get-records --shard-iterator AAAAAAAAAAHSywljv0zEgPX4NyKdZ5wryMzP9yALs8NeKbUjp1IxtZs1Sp+KEd9I6AJ9ZG4lNR1EMi+9Md/nHvtLyxpfhEzYvkTZ4D9DQVz/mBYWRO6OTZRKnW9gd+efGN2aHFdkH1rJl4BL9Wyrk+ghYG22D2T1Da2EyNSH1+LAbK33gQweTJADBdyMwlo5r6PqcP2dzhg=

#Step 4: Clean Up
$ aws kinesis delete-stream --stream-name Foo
    
    
##Reference   
    
class pyspark.streaming.kinesis.KinesisUtils
    classmethod  createStream(ssc, kinesisAppName, streamName, endpointUrl, regionName, 
                initialPositionInStream, checkpointInterval, storageLevel=StorageLevel(True, True, False, False, 2), 
                awsAccessKeyId=None, awsSecretKey=None, decoder=<function utf8_decoder at 0x7f51e9541d70>, stsAssumeRoleArn=None, stsSessionName=None, stsExternalId=None)
    Create an input stream that pulls messages from a Kinesis stream. 
    This uses the Kinesis Client Library (KCL) to pull messages from Kinesis.
    The given AWS credentials will get saved in DStream checkpoints 
    if checkpointing is enabled. 
    Make sure that your checkpoint directory is secure.
    Parameters:
        �ssc � StreamingContext object
        �initialPositionInStream � In the absence of Kinesis checkpoint info, 
                    this is the worker�s initial starting position in the stream. 
                    The values are either the beginning of the stream per Kinesis� limit
                    of 24 hours (InitialPositionInStream.TRIM_HORIZON) 
                    or the tip of the stream (InitialPositionInStream.LATEST).
        �storageLevel � Storage level to use for storing the received objects (default is StorageLevel.MEMORY_AND_DISK_2)
        �awsAccessKeyId � AWS AccessKeyId (default is None). 
        �awsSecretKey � AWS SecretKey (default is None). 
                Uses DefaultAWSCredentialsProviderChain to find credentials  in the following order:
                  Environment Variables - AWS_ACCESS_KEY_ID and AWS_SECRET_KEY
                  Java System Properties - aws.accessKeyId and aws.secretKey
                  Credential profiles file - default location (~/.aws/credentials) shared by all AWS SDKs
                  Instance profile credentials - delivered through the Amazon EC2 metadata service
        [Kinesis app name], kinesisAppName
            The application name that will be used to checkpoint the Kinesis sequence numbers in DynamoDB table(AWS). 
                1.The application name must be unique for a given account and region.
                2.If the table exists but has incorrect checkpoint information (for a different stream, or old expired sequenced numbers), 
                  then there may be temporary errors.
        [Kinesis stream name],streamName
            The Kinesis stream that this streaming application will pull data from.
        [endpoint URL],endpointUrl
            Valid Kinesis endpoints URL can be found here.
            http://docs.aws.amazon.com/general/latest/gr/rande.html#ak_region
        [region name],regionName
            Valid Kinesis region names can be found here.
            https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/using-regions-availability-zones.html
        [checkpoint interval],checkpointInterval
            The interval (e.g., Duration(2000) = 2 seconds) at which the Kinesis Client Library 
            saves its position in the stream. 
            For starters, set it to the same as the batch interval of the streaming application.
        �decoder � A function used to decode value (default is utf8_decoder)
        �stsAssumeRoleArn � ARN of IAM role to assume when using STS sessions to read from the Kinesis stream (default is None).
        �stsSessionName � Name to uniquely identify STS sessions used to read from Kinesis stream, if STS is being used (default is None).
        �stsExternalId � External ID that can be used to validate against the assumed IAM role�s trust policy, if STS is being used (default is None).
    Returns:A DStream object    
    
class pyspark.streaming.kinesis.InitialPositionInStream
    LATEST = 0
    TRIM_HORIZON = 1   
    
    
##Details of the arguments 

##Example:
#export AWS keys if necessary
$ set AWS_ACCESS_KEY_ID=<your-access-key>
$ set AWS_SECRET_KEY=<your-secret-key>

# run the example
$ bin/spark-submit --jars tobeShared/py/spark-streaming-kinesis-asl-assembly_2.11-2.0.0.jar kinesis_wordcount_asl.py myAppName mySparkStream https://kinesis.ap-south-1.amazonaws.com ap-south-1

#To generate random string data to put onto the Kinesis stream, in another terminal, 
$ bin/run-example streaming.KinesisWordProducerASL mySparkStream https://kinesis.ap-south-1.amazonaws.com 1000 10

   
    
    
##Code example 
"""
  Consumes messages from a Amazon Kinesis streams and does wordcount.

  This code """
from __future__ import print_function

import sys

from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.streaming.kinesis import KinesisUtils, InitialPositionInStream

if __name__ == "__main__":
    if len(sys.argv) != 5:
        print(
            "Usage: kinesis_wordcount_asl.py <app-name> <stream-name> <endpoint-url> <region-name>",
            file=sys.stderr)
        sys.exit(-1)

    sc = SparkContext(appName="PythonStreamingKinesisWordCountAsl")
    ssc = StreamingContext(sc, 1)
    appName, streamName, endpointUrl, regionName = sys.argv[1:]
    lines = KinesisUtils.createStream(ssc, appName, streamName, endpointUrl, regionName, InitialPositionInStream.LATEST, 2)
    counts = lines.flatMap(lambda line: line.split(" ")) \
        .map(lambda word: (word, 1)) \
        .reduceByKey(lambda a, b: a+b)
    counts.pprint()

    ssc.start()
    ssc.awaitTermination()
    
    
    
    
    
    


###+++ Spark - Streaming - Structured Stream - based on sql.DataFrame 
#https://spark.apache.org/docs/2.2.0/structured-streaming-programming-guide.html

#Structured Streaming attempts to unify streaming, interactive, 
#and batch queries over structured datasets for developing end-to-end stream processing applications 
    # Continuous streaming aggregations
    # Streaming watermark (for state expiration and late events)
    # Continuous window aggregations (aka windowing) using groupBy operator with window function
    # arbitrary stateful stream aggregation

    
#stream processing engine built on the Spark SQL engine
#API of DataFrameReader/Writer(non-streaming version) are similar 
SparkSession
    def  readStream: DataStreamReader 
        Returns a DataStreamReader that can be used to read streaming data in as a DataFrame.
        sparkSession.readStream.parquet("/path/to/directory/of/parquet/files")
        sparkSession.readStream.schema(schema).json("/path/to/directory/of/json/files")
DataFrame
    def writeStream: DataStreamWriter[T]
        Interface for saving the content of the streaming Dataset out into external storage. 
        
#Structured Streaming introduces streaming Datasets that are infinite datasets 
#with primitives like input streaming data sources and output streaming data sinks.

#A Dataset is streaming (aka continuous) when its logical plan is streaming.

#Here DataFrame represents an unbounded table containing the streaming data
#which is continuousely updated as and when data arrives 




###Reference - DataStreamReader, DataStreamWriter

#Note 'path' in all methods can be directory, and/or with glob patterns
#then any file moved to the directory would be returned as DF continuousely 
#Schema says file containing lines, each line is 'data' field 
sdf_schema = StructType([StructField("data", StringType(), False)])
sdf = spark.readStream.format('text').schema(sdf_schema).load('sql/streaming')
df = spark.readStream.format('text').load('sql/streaming')


class pyspark.sql.streaming.DataStreamReader(spark)
        Use spark.readStream to access this.
        Note spark.read returns DataFrameReader
        All these methods return sql.DataFrame 
    csv(path, schema=None, sep=None, encoding=None, quote=None, 
            escape=None, comment=None, header=None, inferSchema=None, 
            ignoreLeadingWhiteSpace=None, ignoreTrailingWhiteSpace=None, 
            nullValue=None, nanValue=None, positiveInf=None, negativeInf=None, 
            dateFormat=None, timestampFormat=None, maxColumns=None, maxCharsPerColumn=None, 
            maxMalformedLogPerPartition=None, mode=None)
        Loads a CSV file stream and returns the result as a DataFrame.
    format(source)
        Specifies the input data source format.
        source � string, name of the data source, e.g. 'socket', 'json', 'parquet','text','csv'
    json(path, schema=None, primitivesAsString=None, prefersDecimal=None, 
            allowComments=None, allowUnquotedFieldNames=None, allowSingleQuotes=None, 
            allowNumericLeadingZero=None, allowBackslashEscapingAnyCharacter=None, 
            mode=None, columnNameOfCorruptRecord=None, dateFormat=None, timestampFormat=None)
        Loads a JSON file stream (JSON Lines text format or newline-delimited JSON) 
        and returns a :class`DataFrame`.
    load(path=None, format=None, schema=None, **options)
        Loads a data stream from a data source and returns it as a DataFrame.
        >>> json_sdf = spark.readStream.format("json") \
                .schema(sdf_schema) \
                .load(tempfile.mkdtemp())
        >>> json_sdf.isStreaming
        True
        >>> json_sdf.schema == sdf_schema
        True
    option(key, value)
        Adds an input option for the underlying data source.
        >>> s = spark.readStream.option("x", 1)
    options(**options)
        Adds input options for the underlying data source.
        >>> s = spark.readStream.options(x="1", y=2)
    parquet(path)
        Loads a Parquet file stream, returning the result as a DataFrame.
        >>> parquet_sdf = spark.readStream.schema(sdf_schema).parquet(tempfile.mkdtemp())
        >>> parquet_sdf.isStreaming
        True
        >>> parquet_sdf.schema == sdf_schema
        True
    schema(schema)
        Specifies the input schema.
        schema � a pyspark.sql.types.StructType object or a DDL-formatted string (For example col0 INT, col1 DOUBLE). 
        >>> s = spark.readStream.schema(sdf_schema)
        >>> s = spark.readStream.schema("col0 INT, col1 DOUBLE")
    text(path)
        Loads a text file stream and returns a DataFrame 
        whose schema starts with a string column named 'value', 
        and followed by partitioned columns if there are any.
        Each line in the text file is a new row in the resulting DataFrame.
        >>> text_sdf = spark.readStream.text(tempfile.mkdtemp())
        >>> text_sdf.isStreaming
        True
        >>> "value" in str(text_sdf.schema)
        True



class pyspark.sql.streaming.DataStreamWriter(df)
        Use DataFrame.writeStream to access this.
    format(source)
        Specifies the underlying output data source.
        source � string, name of the data source, which for now can be 'parquet', 'console'
        >>> writer = sdf.writeStream.format('json')
    option(key, value)
        Adds an output option for the underlying data source.
    options(**options)
        Adds output options for the underlying data source.
    outputMode(outputMode)
        Specifies how data of a streaming DataFrame/Dataset is written to a streaming sink.
        Options include:
            append:Only the new rows in the streaming DataFrame/Dataset will be written tothe sink
            complete:All the rows in the streaming DataFrame/Dataset will be written to the sinkevery time these is some updates
            update:only the rows that were updated in the streaming DataFrame/Dataset will be written to the sink every time there are some updates. 
                   If the query doesn�t contain aggregations, it will be equivalent to append mode.
    partitionBy(*cols)
        Partitions the output by the given columns on the file system.
    queryName(queryName)
        Specifies the name of the StreamingQuery that can be started with start(). 
        This name must be unique among all the currently active queries in the associated SparkSession.
        >>> writer = sdf.writeStream.queryName('streaming_query')
    start(path=None, format=None, partitionBy=None, queryName=None, **options)
        Streams the contents of the DataFrame to a data source.
        �path - dir where output would be saved
        �format � the format used to save           
        �partitionBy � names of partitioning columns
        �queryName � unique name for the query
        �options � All other string options. 
                   Current supported:
                        checkpointLocation
                            Directory for checkpointing (and to store query metadata like offsets before and after being processed, 
                            the query id, etc.). Not applicable for MemorySink 
        Returns StreamingQuery
        >>> sq = sdf.writeStream.format('memory').queryName('this_query').start()
        >>> sq.isActive
        True
        >>> sq.name
        u'this_query'
        >>> sq.stop()
        >>> sq.isActive
        False
        >>> sq = sdf.writeStream.trigger(processingTime='5 seconds').start(
            queryName='that_query', format='memory')
        >>> sq.name
        u'that_query'
        >>> sq.isActive
        True
        >>> sq.stop()
    trigger(*args, **kwargs)
        Set the trigger for the stream query. 
        If this is not set it will run the query as fast as possible, 
        which is equivalent to setting the trigger to processingTime='0 seconds'.
        processingTime 
            a processing time interval as a string, e.g. '5 seconds', '1 minute'. 
        # trigger the query for execution every 5 seconds
        >>> writer = sdf.writeStream.trigger(processingTime='5 seconds')
        
        

class pyspark.sql.streaming.StreamingQuery(jsq)
    A handle to a query that is executing continuously in the background as new data arrives.
    Returned from DF.writeStream.start()
    awaitTermination(timeout=None)
        Waits for the termination of this query, either by query.stop() or by an exception
    exception()
        Returns:the StreamingQueryException if the query was terminated by an exception, or None. 
    explain(extended=False)
        Prints the (logical and physical) plans to the console for debugging purpose.
        Parameters:
            extended � boolean, default False. If False, prints only the physical plan. 
        >>> sq = sdf.writeStream.format('memory').queryName('query_explain').start()
        >>> sq.processAllAvailable() # Wait a bit to generate the runtime plans.
        >>> sq.explain()
        == Physical Plan ==
        ...
        >>> sq.explain(True)
        == Parsed Logical Plan ==
        ...
        == Analyzed Logical Plan ==
        ...
        == Optimized Logical Plan ==
        ...
        == Physical Plan ==
        ...
        >>> sq.stop()
    id
        Returns the unique id of this query that persists across restarts from checkpoint data. That is, this id is generated when a query is started for the first time, and will be the same every time it is restarted from checkpoint data. There can only be one query with the same id active in a Spark cluster. Also see, runId.
    isActive
        Whether this streaming query is currently active or not.
    lastProgress
        Returns the most recent StreamingQueryProgress update of this streaming query or None if there were no progress updates 
        returns a map
        query = ...  # a StreamingQuery
        >>> print(query.lastProgress)
        {u'stateOperators': [], u'eventTime': {u'watermark': u'2016-12-14T18:45:24.873Z'}, u'name': u'MyQuery', u'timestamp': u'2016-12-14T18:45:24.873Z', u'processedRowsPerSecond': 200.0, u'inputRowsPerSecond': 120.0, u'numInputRows': 10, u'sources': [{u'description': u'KafkaSource[Subscribe[topic-0]]', u'endOffset': {u'topic-0': {u'1': 134, u'0': 534, u'3': 21, u'2': 0, u'4': 115}}, u'processedRowsPerSecond': 200.0, u'inputRowsPerSecond': 120.0, u'numInputRows': 10, u'startOffset': {u'topic-0': {u'1': 1, u'0': 1, u'3': 1, u'2': 0, u'4': 1}}}], u'durationMs': {u'getOffset': 2, u'triggerExecution': 3}, u'runId': u'88e2ff94-ede0-45a8-b687-6316fbef529a', u'id': u'ce011fdc-8762-4dcb-84eb-a77333e28109', u'sink': {u'description': u'MemorySink'}}
    name
        Returns the user-specified name of the query, or null if not specified. 
        This name can be specified in the org.apache.spark.sql.streaming.DataStreamWriter 
        as dataframe.writeStream.queryName("query").start(). 
        This name, if set, must be unique across all active queries.
    processAllAvailable()
        Blocks until all available data in the source has been processed 
        and committed to the sink. This method is intended for testing.
        In the case of continually arriving data, this method may block forever. 
    recentProgress
        Returns an array of the most recent StreamingQueryProgress updates for this query. 
        The number of progress updates retained for each stream is configured 
        by Spark session configuration spark.sql.streaming.numRecentProgressUpdates.
    runId
        Returns the unique id of this query that does not persist across restarts.
        That is, every query that is started (or restarted from checkpoint) 
        will have a different runId.
    status
        Returns the current status of the query.
        >>> print(query.status)
            {u'message': u'Waiting for data to arrive', u'isTriggerActive': False, u'isDataAvailable': False}
    stop()
        Stop this streaming query.

    
    
    
class pyspark.sql.streaming.StreamingQueryManager(jsqm)
    A class to manage all the StreamingQuery StreamingQueries active.
    Returned from spark.streams 
    active
        Returns a list of active queries associated with this SQLContext
        >>> sq = sdf.writeStream.format('memory').queryName('this_query').start()
        >>> sqm = spark.streams
        >>> # get the list of active streaming queries
        >>> [q.name for q in sqm.active]
        [u'this_query']
        >>> sq.stop()
    awaitAnyTermination(timeout=None)
        Wait until any of the queries on the associated SQLContext has terminated 
        since the creation of the context, or since resetTerminated() was called. 
    get(id)
        Returns an active query from this SQLContext or throws exception if an active query with this name doesn�t exist.
        >>> sq = sdf.writeStream.format('memory').queryName('this_query').start()
        >>> sq.name
        u'this_query'
        >>> sq = spark.streams.get(sq.id)
        >>> sq.isActive
        True
        >>> sq = sqlContext.streams.get(sq.id)
        >>> sq.isActive
        True
        >>> sq.stop()
    resetTerminated()
        Forget about past terminated queries 
        so that awaitAnyTermination() can be used again to wait for new terminations.
        >>> spark.streams.resetTerminated()


 





###Spark - Streaming - Structured Stream - General Steps 
1. Use spark.readStream.ANY_METHOD(..) or spark.readStream.format(..).option(k,v).load()
   to read continuousely from a file stream 
   (eg file getting continuousely updated or a directory containing files getting 'moved')
2. Use DataFrame methods to process that 
   Most of the common operations on DataFrame are supported for streaming   
        df = ...  # streaming DataFrame with IOT device data with schema { device: string, deviceType: string, signal: double, time: DateType }
        # Select the devices which have signal more than 10
        df.select("device").where("signal > 10")
        # Running count of the number of updates for each device type
        df.groupBy("deviceType").count()
        #temp view 
        df.createOrReplaceTempView("updates")
        spark.sql("select count(*) from updates")  # returns another streaming DF
        df.isStreaming() #true   
   Also windows operations are supported eg 
       windowedCounts = words.groupBy(
                    window(words.timestamp, "10 minutes", "5 minutes"),
                    words.word
                ).count()
   Use WaterMark to define late data and drop from aggregation 
   df.withWatermark("timestamp", "10 minutes") 
   says max col("timestamp") seen as of now  - 10mins would max time for late data 
   Any record with col("timestamp") value earlier than above is probably discarded(candidate for discarding when required)
3. use DataFrame.writeStream.format(..).option(k,v).trigger(..).queryName(..).outputMode(..).start(...)
   to start the stream , use checkpointLocation for production grade sinks 
4. start() returns  StreamingQuery, which can be used to stop()/awaitTermination() etc 
5. You can specify output mode of a streaming dataset 
   which is what gets written to a streaming sink (i.e. the infinite table) 
   when there is new data available.


###Complete Exmaple 
"""
 Counts words in UTF8 encoded, '\n' delimited text received from the network.
 Usage: structured_network_wordcount.py <hostname> <port>
   <hostname> and <port> describe the TCP server that Structured Streaming
   would connect to receive data.

 To run this on your local machine, you need to first run a Netcat server
    `$ nc -lk 9999`
 and then run the example
    `$ bin/spark-submit structured_network_wordcount.py  localhost 9999`
"""
from __future__ import print_function

import sys

from pyspark.sql import SparkSession
from pyspark.sql.functions import explode
from pyspark.sql.functions import split

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: structured_network_wordcount.py <hostname> <port>", file=sys.stderr)
        exit(-1)

    host = sys.argv[1]
    port = int(sys.argv[2])

    spark = SparkSession\
        .builder\
        .appName("StructuredNetworkWordCount")\
        .getOrCreate()

    # Create DataFrame representing the stream of input lines from connection to host:port
    lines = spark\
        .readStream\
        .format('socket')\
        .option('host', host)\
        .option('port', port)\
        .load()

    # Split the lines into words
    words = lines.select(
        # explode turns each item in an array into a separate row
        explode(
            split(lines.value, ' ')
        ).alias('word')
    )

    # Generate running word count
    wordCounts = words.groupBy('word').count()

    # Start running the query that prints the running counts to the console
    query = wordCounts\
        .writeStream\
        .outputMode('complete')\
        .format('console')\
        .start()

    query.awaitTermination()


###Streaming Data Source
##Sources Format 
FileStreamSource
    csv
    hive
    json
    libsvm
    orc
    parquet
    text
KafkaSource
    kafka
MemoryStream
    memory
RateStreamSource
    rate
TextSocketSource
    socket
	

#schema of Source Used when:
    1.KafkaSource generates a DataFrame with records from Kafka for a streaming batch
    2.FileStreamSource generates a DataFrame for a streaming batch
    3.RateStreamSource generates a DataFrame for a streaming batch
    4.StreamingExecutionRelation is created (for MemoryStream)
    
    
    
###FileStreamSource - Fault tolerant
#FileStreamSource is a Source that reads text files from path directory as they appear. 
    csv
    hive
    json
    libsvm
    orc
    parquet
    text
#You can provide the schema of the data (mst for json, csv etc)
#for text file, schema is 'value':String 

#Options
#Reads files written in a directory as a stream of data
#Supports glob paths, but does not support multiple comma-separated paths/globs. 
path
    path to the input directory, and common to all file formats.
    path can contain dir or glob pattern 
    file would be read only when moved to this directory     
maxFilesPerTrigger
    maximum number of new files to be considered in every trigger (default: no max) 
    It limits the file stream source to read the maxFilesPerTrigger number of files specified 
    at a time and hence enables rate limiting.
    It allows for a static set of files be used like a stream for testing 
    as the file set is processed maxFilesPerTrigger number of files at a time.
latestFirst
    whether to processs the latest new files first, (default: false) 
fileNameOnly
    whether to check new files based on only the filename instead of on the full path (default: false). 
    With this set to `true`, the following files would be considered as the same file, 
    because their filenames, "dataset.txt", are the same: 
     � "file://dataset.txt"
     � "s3://a/dataset.txt"
     � "s3n://a/b/dataset.txt"
     � "s3a://a/b/c/dataset.txt"
schema
    If the schema is specified at instantiation time (using optional dataSchema constructor parameter) 
    it is returned.
    Otherwise, fetchAllFiles internal method is called to list all the files in a directory.


# NOTE The source directory must exist
# mkdir text-logs

df = spark.readStream
  .format("text")
  .option("maxFilesPerTrigger", 1)
  .load("text-logs")

>>> df.printSchema
root
|-- value: string (nullable = true)


#json files 
schema = StructType([
  StructField("id", LongType(), nullable = False) ,
  StructField("name", StringType(), nullable = False) ,
  StructField("score", DoubleType(), nullable = False) ])

# You should have input-json directory available
df = spark.readStream
  .format("json")
  .schema(schema)
  .load("input-json")



#Enable DEBUG or TRACE logging level for org.apache.spark.sql.execution.streaming.FileStreamSource 
#to see what happens inside.
#Add the following line to conf/log4j.properties:
log4j.logger.org.apache.spark.sql.execution.streaming.FileStreamSource=TRACE



    
###RateStreamSource - Fault tolerant
#RateStreamSource is a streaming source that generates consecutive numbers with timestamp 
#that can be useful for testing and PoCs.

#RateStreamSource is created for rate format (that is registered by RateSourceProvider).

rates = spark.
  readStream.
  format("rate"). # <-- use RateStreamSource
  option("rowsPerSecond", 1).
  load()  #timestamp,value

##RateStreamSource�s Options Name 	
numPartitions
    (default parallelism)
    Number of partitions to use
rampUpTime
    e.g. 5s, default: 0s
rowsPerSecond
    1
    Number of rows to generate per second (has to be greater than 0)

##RateStreamSource uses a predefined schema that cannot be changed.
val schema = rates.schema
>>> println(schema.treeString)
root
 |-- timestamp: timestamp (nullable = true)
 |-- value: long (nullable = true)

#Where 
timestamp
    TimestampType
value
    LongType
    

##Enable INFO or DEBUG logging levels for org.apache.spark.sql.execution.streaming.RateStreamSource to see what happens inside.
#Add the following line to conf/log4j.properties:
log4j.logger.org.apache.spark.sql.execution.streaming.RateStreamSource=DEBUG



###TextSocketSource - No Fault tolerant

#TextSocketSource is a streaming source that reads lines from a socket 
#at the host and port (defined by parameters).

#It uses lines internal in-memory buffer to keep all of the lines that were read from a socket forever.
#This source is not for production use due to design contraints, 
#e.g. infinite in-memory collection of lines read and no fault recovery.


##TextSocketSource supports two schemas:
1.A single value field of String type.
2.value field of StringType type and timestamp field of TimestampType type
  (if option "includeTimestamp" is true) of format yyyy-MM-dd HH:mm:ss.

    
    
#Example 
# Connect to localhost:9999
# You can use "nc -lk 9999" for demos
textSocket = spark.
  readStream.
  format("socket").
  option("host", "localhost").
  option("port", 9999).
  load()

lines = textSocket.select(upper(col("value")).alias("upper"))
query = lines.writeStream.format("console").start()

# Start typing the lines in nc session
# They will appear UPPERCASE in the terminal

-------------------------------------------
Batch: 0
-------------------------------------------
+---------+
|    value|
+---------+
|UPPERCASE|
+---------+

>>> query.explain()
== Physical Plan ==
*SerializeFromObject [staticinvoke(class org.apache.spark.unsafe.types.UTF8String, StringType, fromString, input[0, java.lang.String, true], true) AS value#21]
+- *MapElements <function1>, obj#20: java.lang.String
   +- *DeserializeToObject value#43.toString, obj#19: java.lang.String
      +- LocalTableScan [value#43]

>>> query.stop()




###KafkaSource - Fault tolerant

#KafkaSource is a streaming source that generates DataFrames of records 
#from one or more topics in Apache Kafka.

#Kafka topics are checked for new records every trigger 
#and so there is some noticeable delay between when the records have arrived to Kafka topics 
#and when a Spark application processes them.

	

#Structured Streaming support for Kafka is in a separate 
#spark-sql-kafka-0-10 module (use  library dependency).

$ pyspark --packages org.apache.spark:spark-sql-kafka-0-10_2.11:2.3.0


#KafkaSource is created for kafka format (that is registered by KafkaSourceProvider).
val records = spark.
  readStream.
  format("kafka").  # <-- use KafkaSourceProvider
  option("subscribe", "raw-events").  #topic subscription policy , topic name 
  option("kafka.bootstrap.servers", "localhost:9092").
  option("startingoffsets", "earliest").
  option("maxOffsetsPerTrigger", 1).
  load()
  
  
##KafkaSource�s Options Name 	
kafkaConsumer.pollTimeoutMs
    default:512 
    The timeout in milliseconds to poll data from Kafka in executors. 
maxOffsetsPerTrigger
    (empty)
    Number of records to fetch per trigger.
    Use maxOffsetsPerTrigger option to limit the number of records to fetch per trigger.
    Unless defined, KafkaSource requests KafkaOffsetReader for the latest offsets.
startingoffsets
    Possible values:
        latest
        earliest
        JSON with topics, partition_number:their offsets, e.g.{"topicA":{"part":offset,...},...}
            eg .option("startingoffsets","""{"topic1":{"0":5,"4":-1},"topic2":{"0":-2}}""")
assign
    Topic subscription strategy that accepts a JSON with topic names and partitions, eg
    {"topicA":[0,1],"topicB":[0,1]}
    Exactly one topic subscription strategy is allowed 
    (that KafkaSourceProvider validates before creating KafkaSource).
subscribe
    Topic subscription strategy that accepts topic names as a comma-separated string, 
    e.g.topic1,topic2,topic3
	Exactly one topic subscription strategy is allowed 
    (that KafkaSourceProvider validates before creating KafkaSource).
subscribepattern
    Topic subscription strategy that uses Java�s java.util.regex.Pattern 
    e.g.  topic\d
    Eg option("subscribepattern", """topic\d""")
    Exactly one topic subscription strategy is allowed 
    (that KafkaSourceProvider validates before creating KafkaSource).

#Start Kafka producer 
$ kafka-console-producer.bat   --topic topic1 --broker-list localhost:9092  --property parse.key=true  --property key.separator=,

# Extract
records = spark.
  readStream.
  format("kafka").
  option("subscribepattern", """topic\d"""). # <-- topics with a digit at the end
  option("kafka.bootstrap.servers", "localhost:9092").
  option("startingoffsets", "latest").
  option("maxOffsetsPerTrigger", 1).
  load()
  
#KafkaSource uses a predefined fixed schema (and cannot be changed).
>>> records.printSchema
root
 |-- key: binary (nullable = true)
 |-- value: binary (nullable = true)
 |-- topic: string (nullable = true)
 |-- partition: integer (nullable = true)
 |-- offset: long (nullable = true)
 |-- timestamp: timestamp (nullable = true)
 |-- timestampType: integer (nullable = true)


#Transform
val result = records.select(
    col("key").cast("string"),   # deserialize keys
    col("value").cast("string"), #deserialize values
    col("topic"),
    col("partition"),
    col("offset")
# Load
sq = result.
  writeStream.
  format("console").
  option("truncate", False).
  trigger(processingTime = "10 seconds").
  outputMode("append").
  queryName("from-kafka-to-console").
  start()

# In the end, stop the streaming query
sq.stop()



##Use cast method (of Column) to cast BinaryType to a string (for key and value columns).
col("value").cast("string")

#KafkaSource also supports batch Datasets.
topic1 = spark
  .read #<-- read one batch only
  .format("kafka")
  .option("subscribe", "topic1")
  .option("kafka.bootstrap.servers", "localhost:9092")
  .load()
>>> topic1.printSchema
root
 |-- key: binary (nullable = true)
 |-- value: binary (nullable = true)
 |-- topic: string (nullable = true)
 |-- partition: integer (nullable = true)
 |-- offset: long (nullable = true)
 |-- timestamp: timestamp (nullable = true)
 |-- timestampType: integer (nullable = true)


 
###Spark - Streaming - Structured Stream - Not supported DF operations 
1.Multiple streaming aggregations (i.e. a chain of aggregations on a streaming DF) are not yet supported on streaming Datasets.
2.Limit and take first N rows are not supported on streaming Datasets.
3.Distinct operations on streaming Datasets are not supported.
4.Sorting operations are supported on streaming Datasets only after an aggregation and in Complete Output Mode.
5.Outer joins between a streaming and other streaming/static  are conditionally supported.
6.count() - Cannot return a single count from a streaming Dataset. 
  Instead, use ds.groupBy().count() which returns a streaming Dataset containing a running count.
7.foreach() - Instead use ds.writeStream.foreach(...) (only for Scala and Java)
8.show() - Instead use the console sink   


###Output Sinks
#File sink - Stores the output to a directory.
writeStream
    .format("parquet")        # can be "orc", "json", "csv", etc.
    .option("path", "path/to/destination/dir")
    .start()
    
#Kafka sink - Stores the output to one or more topics in Kafka.
writeStream
    .format("kafka")
    .option("kafka.bootstrap.servers", "host1:port1,host2:port2")
    .option("topic", "updates")
    .start()
    
#Console sink (for debugging) - Prints the output to the console/stdout every time there is a trigger. 
#Both, Append and Complete output modes, are supported. 
#the entire output is collected and stored in the driver�s memory after every trigger.
writeStream
    .format("console")
    .start()
    
#Memory sink (for debugging) - The output is stored in memory as an in-memory table. 
#Can have sql query on the table 
#Both, Append and Complete output modes, are supported. 
#the entire output is collected and stored in the driver�s memory. 
writeStream
    .format("memory")
    .queryName("tableName")
    .start()

##ConsoleSink for Showing DataFrames to Console
query = spark.
  readStream.
  format("rate").
  load().
  writeStream.
  format("console").  
  option("truncate", false).
  option("numRows", 10).
  trigger(processingTime="10 seconds").
  queryName("rate-console").
  start()

-------------------------------------------
Batch: 0
-------------------------------------------
+---------+-----+
|timestamp|value|
+---------+-----+
+---------+-----+

#Internally, addBatch records the input batchId in lastBatchId internal property.
#addBatch collects the input data DataFrame and creates a brand new DataFrame 
#that it then shows (per numRowsToShow and isTruncated properties).

-------------------------------------------
Batch: [batchId]
-------------------------------------------
+---------+-----+
|timestamp|value|
+---------+-----+
+---------+-----+

##FileStreamSink
#FileStreamSink supports Append output mode only.
#It uses spark.sql.streaming.fileSink.log.deletion (as isDeletingExpiredLog)

csv
hive
json
libsvm
orc
parquet
text


#FileStreamSink is the streaming sink for the parquet format by default 
out = inDs.
  writeStream.
  format("parquet").
  option("path", "parquet-output-dir").
  option("checkpointLocation", "checkpoint-dir").
  trigger(processingTime="10 seconds").
  outputMode("append").
  start()




###KafkaSink
#KafkaSink is a streaming sink that KafkaSourceProvider registers as the kafka format.

# start spark-shell or a Spark application with spark-sql-kafka-0-10 module
$ pyspark --packages org.apache.spark:spark-sql-kafka-0-10_2.11:2.3.0

spark.
  readStream.
  format("text").
  load("server-logs/*.out").
  writeStream.
  queryName("server-logs processor").
  format("kafka").  // <-- uses KafkaSink
  option("topic", "topic1").   #any other parameters 
  option("checkpointLocation", "data/spark/kafka-sink-checkpoint"). # <-- mandatory
  start()

# in another terminal
$ echo hello > server-logs/hello.out



   
    
    
###MemorySink
#MemorySink is a streaming Sink that stores records in memory. 
#It is particularly useful for testing.

#MemorySink is used for memory format and requires a query name 
#(by queryName method or queryName option).

logs = spark.readStream.textFile("logs/*.out")

>>> outStream = logs.writeStream
  .format("memory")
  .queryName("logs")
  .start()
  
#It creates a new DataFrame using MemoryPlan with MemorySink instance created earlier 
#and registers it as a temporary table (using DataFrame.registerTempTable method).
#At this point you can query the table as if it were a regular non-streaming table using sql method.

>>> sql("select * from logs").show(truncate = false)


#Use toDebugString to see the batches.
#Its aim is to allow users to test streaming applications in the Spark shell or other local tests.

#You can set checkpointLocation using option method 
#or it will be set to spark.sql.streaming.checkpointLocation property.
#If spark.sql.streaming.checkpointLocation is set, the code uses $location/$queryName directory.

#when no spark.sql.streaming.checkpointLocation is set, 
#a temporary directory memory.stream under java.io.tmpdir is used with offsets subdirectory inside.
#The directory is cleaned up at shutdown using ShutdownHookManager.registerShutdownDeleteDir.

#It creates MemorySink instance based on the schema of the DataFrame it operates on.

 
###Spark - Streaming - Structured Stream - Suported OutputMode 
Append mode (default) 
    This is the default mode, where only the new rows added to the Result Table 
    since the last trigger will be outputted to the sink. 
    This is supported for only those queries where rows added to the Result Table is never going to change. 
    Hence, this mode guarantees that each row will be output only once (assuming fault-tolerant sink).
    For example, queries with only select, where, map, flatMap, filter, join, etc. will support Append mode.
Complete mode 
    The whole Result Table will be outputted to the sink after every trigger. 
    This is supported for aggregation queries.
Update mode (from spark 2.1.1)
    Only the rows in the Result Table that were updated since the last trigger will be outputted to the sink. 

##Sink vs Supported Output mode 
File Sink 
    Append 
        path: path to the output directory, must be specified. 
        For file-format-specific options, see the related methods in DataFrameWriter 
        E.g. for "parquet" format options see DataFrameWriter.parquet()  
        Fault-tolerant:Yes (exactly-once) 
        Supports writes to partitioned tables. 
        Partitioning by time may be useful. 
Kafka Sink 
    Append, Update, Complete 
    Fault-tolerant:Yes (at-least-once) 
Console Sink 
    Append, Update, Complete 
        numRows: Number of rows to print every trigger (default: 20) 
        truncate: Whether to truncate the output if too long (default: true)  No  
Memory Sink 
    Append, Complete 
        But in Complete Mode, restarted query will recreate the full table. 
        Table name is the query name.     
    
##Query Type & Supported Output Modes
#'update' mode mostly works with all, use this 
Queries with aggregation 
    Aggregation on event-time with watermark 
        Append
            Append mode uses watermark to drop old aggregation state. 
            But the output of a windowed aggregation is delayed the late threshold specified in `withWatermark()` as by the modes semantics, 
            rows can be added to the Result Table only once after they are finalized (i.e. after watermark is crossed). 
        Update
            Update mode uses watermark to drop old aggregation state. 
        Complete 
            Complete mode does not drop old aggregation state since by definition this mode preserves all data in the Result Table.  
    Other aggregations 
        Complete, Update 
            Since no watermark is defined (only defined in other category), 
            old aggregation state is not dropped. 
            Append mode is not supported as aggregates can update thus violating the semantics of this mode.  
Queries with joins 
    Append 
        Update and Complete mode not supported yet. 
Other queries 
    Append, Update 
        Complete mode not supported as it is infeasible to keep all unaggregated data in the Result Table.  

    
##Example  
# ========== DF with no aggregations ==========
noAggDF = deviceDataDf.select("device").where("signal > 10")   

# Print new data to console
noAggDF \
    .writeStream \
    .format("console") \
    .start()

# Write new data to Parquet files
noAggDF \
    .writeStream \
    .format("parquet") \
    .option("checkpointLocation", "path/to/checkpoint/dir") \
    .option("path", "path/to/destination/dir") \
    .start()

# ========== DF with aggregation ==========
aggDF = df.groupBy("device").count()

# Print updated aggregations to console
aggDF \
    .writeStream \
    .outputMode("complete") \
    .format("console") \
    .start()

# Have all the aggregates in an in memory table. The query name will be the table name
aggDF \
    .writeStream \
    .queryName("aggregates") \
    .outputMode("complete") \
    .format("memory") \
    .start()

spark.sql("select * from aggregates").show()   # interactively query in-memory table   
    
    
    
###Triggers
#The trigger settings of a streaming query defines the timing of streaming data processing, 
#whether the query is going to executed as micro-batch query with a fixed batch interval 
#or as a continuous processing query. 
trigger(processingTime=None, once=None, continuous=None)
    Set the trigger for the stream query. 
    If this is not set it will run the query as fast as possible,
    which is equivalent to setting the trigger to processingTime='0 seconds'.
    �processingTime � a processing time interval as a string, e.g. �5 seconds�, �1 minute�. 
        Set a trigger that runs a query periodically based on the processing time. 
        Only one trigger can be set.
    �once � if set to True, set a trigger that processes only one batch of data in a streaming query 
        then terminates the query. Only one trigger can be set.
     

##Trigger type 
unspecified (default) 
    If no trigger setting is explicitly specified, 
    then by default, the query will be executed in micro-batch mode, 
    where micro-batches will be generated as soon as the previous micro-batch has completed processing.  
Fixed interval micro-batches 
    The query will be executed with micro-batches mode, 
    where micro-batches will be kicked off at the user-specified intervals. 
        �If the previous micro-batch completes within the interval, then the engine will wait until the interval is over before kicking off the next micro-batch.
        �If the previous micro-batch takes longer than the interval to complete (i.e. if an interval boundary is missed), then the next micro-batch will start as soon as the previous one completes (i.e., it will not wait for the next interval boundary).
        �If no new data is available, then no micro-batch will be kicked off.
One-time micro-batch 
    The query will execute *only one* micro-batch to process all the available data and then stop on its own. 
    This is useful in scenarios you want to periodically spin up a cluster, process everything that is available since the last period, and then shutdown the cluster. 
Continuous with fixed checkpoint interval
    The query will be executed in the new low-latency, continuous processing mode.

#Example 
# Default trigger (runs micro-batch as soon as it can)
df.writeStream \
  .format("console") \
  .start()

# ProcessingTime trigger with two-seconds micro-batch interval
df.writeStream \
  .format("console") \
  .trigger(processingTime='2 seconds') \
  .start()

# One-time trigger
df.writeStream \
  .format("console") \
  .trigger(once=True) \
  .start()

# Continuous trigger with one-second checkpointing interval
df.writeStream
  .format("console")
  .trigger(continuous='1 second')
  .start()

#Example 
query = spark.  \
  readStream.\
  format("rate").\
  load().\
  writeStream.\
  format("console").\
  option("truncate", False).\
  trigger(once=True). \
  queryName("rate-once").\
  start()

>>> query.isActive
False

>>> import pprint
>>> pprint.pprint(query.lastProgress)
{
  "id" : "2ae4b0a4-434f-4ca7-a523-4e859c07175b",
  "runId" : "24039ce5-906c-4f90-b6e7-bbb3ec38a1f5",
  "name" : "rate-once",
  "timestamp" : "2017-07-04T18:39:35.998Z",
  "numInputRows" : 0,
  "processedRowsPerSecond" : 0.0,
  "durationMs" : {
    "addBatch" : 1365,
    "getBatch" : 29,
    "getOffset" : 0,
    "queryPlanning" : 285,
    "triggerExecution" : 1742,
    "walCommit" : 40
  },
  "stateOperators" : [ ],
  "sources" : [ {
    "description" : "RateSource[rowsPerSecond=1, rampUpTimeSeconds=0, numPartitions=8]",
    "startOffset" : null,
    "endOffset" : 0,
    "numInputRows" : 0,
    "processedRowsPerSecond" : 0.0
  } ],
  "sink" : {
    "description" : "org.apache.spark.sql.execution.streaming.ConsoleSink@7dbf277"
  }
}
###Continuous Processing
#Continuous processing is a new, experimental streaming execution mode introduced in Spark 2.3 
#that enables low (~1 ms) (compared to microbatch  ~100ms at best) end-to-end latency with at-least-once fault-tolerance guarantees. 

spark \
  .readStream \
  .format("kafka") \
  .option("kafka.bootstrap.servers", "host1:port1,host2:port2") \
  .option("subscribe", "topic1") \
  .load() \
  .selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)") \
  .writeStream \
  .format("kafka") \
  .option("kafka.bootstrap.servers", "host1:port1,host2:port2") \
  .option("topic", "topic1") \
  .trigger(continuous="1 second") \     # only change in query
  .start()

##Supported Queries
Operations
    Only map-like Dataset/DataFrame operations are supported in continuous mode, 
    that is, only projections (select, map, flatMap, mapPartitions, etc.) 
    and selections (where, filter, etc.). 
    All SQL functions are supported except aggregation functions , current_timestamp() and current_date() 
Sources: 
    Kafka source: All options are supported.
    Rate source: Good for testing with options  numPartitions and rowsPerSecond.
�Sinks: 
    Kafka sink: All options are supported.
    Memory sink: Good for debugging.
    Console sink: Good for debugging. 
 
#Note 
1.Continuous processing engine launches multiple long-running tasks that continuously read data from sources, 
  process it and continuously write to sinks. 
  The number of tasks required by the query depends on how many partitions the query can read from the sources in parallel. 
  Therefore, before starting a continuous processing query, you must ensure there are enough cores in the cluster to all the tasks in parallel. For example, if you are reading from a Kafka topic that has 10 partitions, then the cluster must have at least 10 cores for the query to make progress.
2.Stopping a continuous processing stream may produce spurious task termination warnings. 
  These can be safely ignored.
3.There are currently no automatic retries of failed tasks. 
  Any failure will lead to the query being stopped and it needs to be manually restarted from the checkpoint.
   
    


###Spark - Streaming - Structured Stream - Handling Late Data and Watermarking
#eventTime is the time embedded in the data itself,
#each event from the devices is a row in the table, and event-time is a column value in the row. 
#whereas processing time is time when Spark starts processing the data 

##Conditions 
1.Preferably eventTime comes from data source directly and embedded in data for spark consumption, 
  If DF does not contain any time columns, to emulate event-time 
  Include "includeTimestamp" option , the DF contains one column as "timestamp"
  or use F.current_timestamp().alias("eventTime")
2.The aggregation must have either the event-time column, 
  or a window on the event-time column
3.Output mode must be Append or Update. 
  Complete mode requires all aggregate data to be preserved, and hence cannot use watermarking to drop intermediate state
4.withWatermark must be called on the same column as the timestamp(eventTime) column used in the aggregate. 
  df.withWatermark("time", "1 min").groupBy("time2").count() is invalid , 
  as watermark is defined on a different column from the aggregation column.
5.withWatermark must be called before the aggregation 
  for the watermark details to be used. 
  df.groupBy("time").count().withWatermark("time", "1 min") is invalid .
6.A watermark delay (set with withWatermark) of '2 hours' guarantees 
  that the engine will never drop any data that is less than 2 hours delayed. 
  In other words, any data less than 2 hours behind (in terms of eventTime) 
  the latest data processed till then is guaranteed to be aggregated.
7.However, the guarantee is strict only in one direction. 
  Data delayed by more than 2 hours is not guaranteed to be dropped;
  it may or may not get aggregated. 
  More delayed is the data, less likely is the engine going to process it.


#To count words within 10 minute windows, updating every 5 minutes(slideDuration). 
#That is, word counts in words received between 10 minute windows 12:00 - 12:10, 12:05 - 12:15, 12:10 - 12:20, etc. 
#Note that 12:00 - 12:10 means data that arrived after 12:00 but before 12:10. 
#Now, consider a word that was received with event-time 12:07. 
#This word should increment the counts corresponding to two windows 12:00 - 12:10 and 12:05 - 12:15. So the counts will be indexed by both, the grouping key (i.e. the word) and the window (can be calculated from the event-time).
#Check data\windowing_on_event_time.png

words = ...  # streaming DataFrame of schema { timestamp: Timestamp, word: String }
# Group the data by window and word and compute the count of each group
windowedCounts = words.groupBy(
    window(words.timestamp, "10 minutes", "5 minutes"), #words.timestamp=event-time, windowDuration, slideDuration
    words.word
).count()




#Now consider what happens if one of the events arrives late to the application. 
#For example, say, a word generated at 12:04 (i.e. event time) could be received by the application at (processing time)12:11. 
#The application should use the time 12:04 instead of 12:11 to update the older counts for the window 12:00 - 12:10.
#Structured Streaming can maintain the intermediate state for partial aggregates for a long period of time 
#such that late data can update aggregates of old windows correctly, 
#however increases the state table size , To resolve this use watermark 
#Check data\windowing_with_late_data.png


#watermarking :which lets the engine automatically track the current event time (in data source)
#and attempt to clean up old state accordingly if event time is too late 
#Note that using withWatermark on a non-streaming Dataset is no-op. 

words = ...  # streaming DataFrame of schema { timestamp: Timestamp, word: String }
# Group the data by window and word and compute the count of each group
windowedCounts = words \
    .withWatermark("timestamp", "10 minutes") \  #timestamp=event-time column, delay-threashold=10 min 
    .groupBy(
        window(words.timestamp, "10 minutes", "5 minutes"),  #words.timestamp=event-time, windowDuration, slideDuration
        words.word) \
    .count()

    
#For a specific window starting at time T, the engine will maintain state and allow late data to update the state 
#until (max event time seen by the engine - late threshold > T). 
#In other words, late data within the threshold will be aggregated, 
#but data later than the threshold will start getting dropped

#For example, with delay threashold of 10 min, window size of 10 min with sliding every 5 min and trigger time as 5 min 
#For Update as output mode, at each trigger time , the engine will keep updating counts of a window in the Result Table 
#until the window is older than the watermark, which lags behind event-time 'timestamp' by 10 minutes
#check data\windowing_with_watermark.png
#For example, when the watermark is updated to 12:11, the intermediate state for window (12:00 - 12:10) is cleared, 
#and all subsequent data (e.g. (12:04, donkey)) is considered 'too late' and therefore ignored. 
#Note that after every trigger, the updated counts (i.e. purple rows) are written to sink as the trigger output, as dictated by the Update mode

#Some sinks (e.g. files) may not supported fine-grained updates that Update Mode requires. 
#To work with them, use Append Mode, where only the final counts are written to sink. 
#Check data\windowing_with_watermark_append.png
#The engine waits for '10 mins' for late date to be counted, 
#then drops intermediate state of a window < watermark, and appends the final counts to the Result Table/sink. 
#For example, the final counts of window 12:00 - 12:10 is appended to the Result Table only after the watermark is updated to 12:11.
 

    
    
    
###Spark - Streaming - Structured Stream - Join Operations
#Structured Streaming supports joining a streaming Dataset/DataFrame with a static Dataset/DataFrame as well as another streaming Dataset/DataFrame. 
#The result of the streaming join is generated incrementally

#Left Input     Right Input     Join Type
Static          Static          All types Supported, since its not on streaming data even though it can be present in a streaming query  

Stream          Static          Inner Supported, not stateful 
                                Left Outer Supported, not stateful 
                                Right Outer Not supported 
                                Full Outer Not supported 
                                
Static          Stream          Inner Supported, not stateful 
                                Left Outer Not supported 
                                Right Outer Supported, not stateful 
                                Full Outer Not supported 
                                
Stream Stream                   Inner Supported, optionally specify watermark on both sides + time constraints for state cleanup  
                                Left Outer Conditionally supported, must specify watermark on right + time constraints for correct results, optionally specify watermark on left for all state cleanup  
                                Right Outer Conditionally supported, must specify watermark on left + time constraints for correct results, optionally specify watermark on right for all state cleanup  
                                Full Outer Not supported 
    
#Joins can be cascaded, that is,df1.join(df2, ...).join(df3, ...).join(df4, ....).
#use joins only when the query is in Append output mode. 
#you cannot use other non-map-like operations before joins. 
#for example, Cannot use streaming aggregations before joins.


##Stream-static Joins
staticDf = spark.read. ...
streamingDf = spark.readStream. ...
streamingDf.join(staticDf, "type")  # inner equi-join with a classmethod DF, both has column 'type' 
streamingDf.join(staticDf, "type", "right_join")  # right outer join with a classmethod DF
  
##Stream-stream Joins-Inner Joins with optional Watermarking
#Inner joins on any kind of columns along with any kind of join conditions are supported
#but to manage state table size, 
1.Define watermark delays on both inputs such that the engine knows how delayed the input can be 
2.Define a constraint on event-time across the two inputs such that the engine can figure out 
  when old rows of one input is not going to be required (i.e. will not satisfy the time constraint) for matches with the other input. 
  This constraint can be defined in one of the two ways.
    1.Time range join conditions (e.g. ...JOIN ON leftTime BETWEN rightTime AND rightTime + INTERVAL 1 HOUR),
    2.Join on event-time windows (e.g. ...JOIN ON leftTimeWindow = rightTimeWindow).

#Example 
from pyspark.sql.functions import expr

impressions = spark.readStream. ...
clicks = spark.readStream. ...

# Apply watermarks on event-time columns
impressionsWithWatermark = impressions.withWatermark("impressionTime", "2 hours")
clicksWithWatermark = clicks.withWatermark("clickTime", "3 hours")

# Join with event-time constraints
impressionsWithWatermark.join(
  clicksWithWatermark,
  expr("""
    clickAdId = impressionAdId AND
    clickTime >= impressionTime AND
    clickTime <= impressionTime + interval 1 hour
    """)
)

##Stream-stream Joins-Outer Joins with Watermarking(must)
#This is because for generating the NULL results in outer join, the engine must know when an input row is not going to match with anything in future
1.The outer NULL results will be generated with a delay that depends on the specified watermark delay and the time range condition. 
  This is because the engine has to wait for that long to ensure there were no matches and there will be no more matches in future.
2.In the current implementation in the micro-batch engine, watermarks are advanced at the end of a micro-batch, 
  and the next micro-batch uses the updated watermark to clean up state and output outer results. 
  Since Spark triggers a micro-batch only when there is new data to be processed, 
  the generation of the outer result may get delayed if there no new data being received in the stream. 
  In short, if any of the two input streams being joined does not receive data for a while, 
  the outer (both cases, left or right) output may get delayed.

#Example 
impressionsWithWatermark.join(
  clicksWithWatermark,
  expr("""
    clickAdId = impressionAdId AND
    clickTime >= impressionTime AND
    clickTime <= impressionTime + interval 1 hour
    """),
  "leftOuter"                 # can be "inner", "leftOuter", "rightOuter"
)




  
  
  
  



###Managing Streaming Queries
#The StreamingQuery object created when a query is started can be used to monitor and manage the query.

query = df.writeStream.format("console").start()   # get the query object

query.id()          # get the unique identifier of the running query that persists across restarts from checkpoint data

query.runId()       # get the unique id of this run of the query, which will be generated at every start/restart

query.name()        # get the name of the auto-generated or user-specified name

query.explain()   # print detailed explanations of the query

query.stop()      # stop the query

query.awaitTermination()   # block until query is terminated, with stop() or with error

query.exception()       # the exception if the query has been terminated with error

query.recentProgress()  # an array of the most recent progress updates for this query

query.lastProgress()    # the most recent progress update of this streaming query



#You can start any number of queries in a single SparkSession. 
#They will all be running concurrently sharing the cluster resources. 
#You can use sparkSession.streams() to get the StreamingQueryManager 
spark = ...  # spark session

spark.streams().active  # get the list of currently active streaming queries

spark.streams().get(id)  # get a query object by its unique id

spark.streams().awaitAnyTermination()  # block until any one of them terminates


###Monitoring Streaming Queries
##Reading Metrics Interactively
streamingQuery.status()
    Returns  a dictionary
    It gives information about what the query is immediately doing - is a trigger active, is data being processed, etc.
streamingQuery.lastProgress() 
    returns  a dictionary 
    It has all the information about the progress made in the last trigger of the stream 
    - what data was processed, what were the processing rates, latencies, etc. 
streamingQuery.recentProgress 
    which returns an array of last few progresses.
#Example 
query = ...  # a StreamingQuery
print(query.lastProgress)
{u'stateOperators': [], u'eventTime': {u'watermark': u'2016-12-14T18:45:24.873Z'}, u'name': u'MyQuery', u'timestamp': u'2016-12-14T18:45:24.873Z', u'processedRowsPerSecond': 200.0, u'inputRowsPerSecond': 120.0, u'numInputRows': 10, u'sources': [{u'description': u'KafkaSource[Subscribe[topic-0]]', u'endOffset': {u'topic-0': {u'1': 134, u'0': 534, u'3': 21, u'2': 0, u'4': 115}}, u'processedRowsPerSecond': 200.0, u'inputRowsPerSecond': 120.0, u'numInputRows': 10, u'startOffset': {u'topic-0': {u'1': 1, u'0': 1, u'3': 1, u'2': 0, u'4': 1}}}], u'durationMs': {u'getOffset': 2, u'triggerExecution': 3}, u'runId': u'88e2ff94-ede0-45a8-b687-6316fbef529a', u'id': u'ce011fdc-8762-4dcb-84eb-a77333e28109', u'sink': {u'description': u'MemorySink'}}

print(query.status)
{u'message': u'Waiting for data to arrive', u'isTriggerActive': False, u'isDataAvailable': False}


##Reporting Metrics using Dropwizard
#Spark supports reporting metrics using the Dropwizard Library. 
#To enable metrics of Structured Streaming queries to be reported as well, 
#enable the configuration spark.sql.streaming.metricsEnabled in the SparkSession.
#All queries started in the SparkSession after this configuration has been enabled will report metrics through Dropwizard to whatever sinks have been configured (e.g. Ganglia, Graphite, JMX, etc.).
spark.conf.set("spark.sql.streaming.metricsEnabled", "true")
# or
spark.sql("SET spark.sql.streaming.metricsEnabled=true")






###Spark - Streaming - Structured Stream - Recovering from Failures with Checkpointing  
#query will save all the progress information (i.e. range of offsets processed in each trigger)
#and the running aggregates (e.g. word counts ) to the checkpoint location(must be HDFS)
   
aggDF \
    .writeStream \
    .outputMode("complete") \
    .option("checkpointLocation", "path/to/HDFS/dir") \
    .format("memory") \
    .start() 
    
    
    
###Spark - Streaming - Structured Stream - Streaming Deduplication
#You can deduplicate records in data streams using a unique identifier in the events
#you can use deduplication with or without watermarking
1.With watermark - you can define a watermark on a event time column 
  and deduplicate using both the guid and the event time columns. 
  The query will use the watermark to remove old state data from past records that are not expected to get any duplicates any more. 
  This bounds the amount of the state the query has to maintain.
2.Without watermark - Since there are no bounds on when a duplicate record may arrive, 
  the query stores the data from all the past records as state.

#Example 
streamingDf = spark.readStream. ...

#Without watermark using guid column
streamingDf.dropDuplicates("guid")  #column name 

#With watermark using guid and eventTime columns
streamingDf \
  .withWatermark("eventTime", "10 seconds") \
  .dropDuplicates("guid", "eventTime")
  
  

##Example - dropDuplicates Operator�Streaming Deduplication
dropDuplicates(subset=None):DataFrame
#For a streaming Dataset, dropDuplicates will keep all data across triggers 
#as intermediate state to drop duplicates rows. 
#You can use withWatermark operator to limit how late the duplicate data can be 
#and system will accordingly limit the state. 
#In addition, too late data older than watermark will be dropped to avoid any possibility of duplicates.
#Subset is list of ColName strings 

# Start a streaming query

rates = spark.  \
  readStream.\
  format("rate").  \
  option("rowsPerSecond", 1).\
  load()  #timestamp,value as long type 

ids = rates.withColumn("id", col("value").cast("string")).dropDuplicates(["id"])

>>> ids.explain(True)
== Parsed Logical Plan ==
Deduplicate [id#14]
+- AnalysisBarrier
      +- Project [timestamp#2, value#3L, cast(value#3L as string) AS id#14]
         +- StreamingRelationV2 org.apache.spark.sql.execution.streaming.RateSourceProvider@4df15842, rate, Map(rowsPerSecond -> 1), [timestamp#2, value#3L], StreamingRelation DataSource(org.apache.spark.sql.SparkSession@4e64ab0b,rate,List(),None,List(),None,Map(rowsPerSecond -> 1),None), rate, [timestamp#0, value#1L]

== Analyzed Logical Plan ==
timestamp: timestamp, value: bigint, id: string
Deduplicate [id#14]
+- Project [timestamp#2, value#3L, cast(value#3L as string) AS id#14]
   +- StreamingRelationV2 org.apache.spark.sql.execution.streaming.RateSourceProvider@4df15842, rate, Map(rowsPerSecond -> 1), [timestamp#2, value#3L], StreamingRelation DataSource(org.apache.spark.sql.SparkSession@4e64ab0b,rate,List(),None,List(),None,Map(rowsPerSecond -> 1),None), rate, [timestamp#0, value#1L]

== Optimized Logical Plan ==
org.apache.spark.sql.AnalysisException: Queries with streaming sources must be executed with writeStream.start();;
rate
== Physical Plan ==
org.apache.spark.sql.AnalysisException: Queries with streaming sources must be executed with writeStream.start();;


#Write 
q = ids.
  writeStream.
  format("memory").
  queryName("dups").
  outputMode("append").
  trigger(processingTime="30 seconds").
  option("checkpointLocation", "checkpoint-dir"). # <-- use checkpointing to save state between restarts
  start()

q.processAllAvailable()

# Check out how dropDuplicates removes duplicates
# --> per single streaming batch (easy)
>>> spark.table("dups").show()
+----+---+
|time| id|
+----+---+
|   1|  1|
+----+---+


# --> across streaming batches (harder)
>>> spark.table("dups").show()
+----+---+
|time| id|
+----+---+
|   1|  1|
|   5|  2|
+----+---+

# Check out the internal state
>>> print(q.lastProgress["stateOperators"][0])
{
  "numRowsTotal" : 2,
  "numRowsUpdated" : 1,
  "memoryUsedBytes" : 17751
}

# You could use web UI's SQL tab instead
# Use Details for Query

>>> spark.table("dups").show
+----+---+
|time| id|
+----+---+
|   1|  1|
|   5|  2|
+----+---+

# Check out the internal state
>>> print(q.lastProgress["stateOperators"][0])
{
  "numRowsTotal" : 2,
  "numRowsUpdated" : 0,
  "memoryUsedBytes" : 17751
}

# Restart the streaming query
q.stop()
#but Complete is only available with a streaming aggregation
#We get Exceptions 
q = ids.
  writeStream.
  format("memory").
  queryName("dups").
  outputMode("complete").  # <-- memory sink supports checkpointing for Complete output mode only
  trigger(processingTime="30 seconds").
  option("checkpointLocation", "checkpoint-dir"). # <-- use checkpointing to save state between restarts
  start

# Use groupBy to pass the requirement of having streaming aggregation for Complete output mode
counts = ids.groupBy("id").agg(first(col("timestamp")).alias("first_time"))
>>> counts.explain()
== Physical Plan ==
*HashAggregate(keys=[id#246], functions=[first(time#255L, false)])
+- StateStoreSave [id#246], StatefulOperatorStateInfo(<unknown>,3585583b-42d7-4547-8d62-255581c48275,0,0), Append, 0
   +- *HashAggregate(keys=[id#246], functions=[merge_first(time#255L, false)])
      +- StateStoreRestore [id#246], StatefulOperatorStateInfo(<unknown>,3585583b-42d7-4547-8d62-255581c48275,0,0)
         +- *HashAggregate(keys=[id#246], functions=[merge_first(time#255L, false)])
            +- *HashAggregate(keys=[id#246], functions=[partial_first(time#255L, false)])
               +- *Project [cast(time#250 as bigint) AS time#255L, id#246]
                  +- StreamingDeduplicate [id#246], StatefulOperatorStateInfo(<unknown>,3585583b-42d7-4547-8d62-255581c48275,1,0), 0
                     +- Exchange hashpartitioning(id#246, 200)
                        +- *Project [cast(_1#242 as timestamp) AS time#250, _2#243 AS id#246]
                           +- StreamingRelation MemoryStream[_1#242,_2#243], [_1#242, _2#243]
q = counts.
  writeStream.
  format("memory").
  queryName("dups").
  outputMode("complete").  // <-- memory sink supports checkpointing for Complete output mode only
  trigger(processingTime="30 seconds").
  option("checkpointLocation", "checkpoint-dir"). // <-- use checkpointing to save state between restarts
  start()


# wait till the batch is triggered
>>> spark.table("dups").show()
+---+----------+
| id|first_time|
+---+----------+
|  1|         0|
+---+----------+



###Example - groupBy Operator 
groupBy(*cols)
    cols � list of columns to group by. 
    Each element should be a column name (string) or an expression (Column). 
    
#Quick GroupedData Methods   
class pyspark.sql.GroupedData
    agg(*exprs)
        exprs � a dict mapping from column name (string)(could be *) to aggregate functions (string), 
        or a list/varargs of Column. 
    apply(udf)
        udf � a grouped map user-defined function returned by pyspark.sql.functions.pandas_udf()
              Taking pandas.DataFrame of this spark.DataFrame and returns pandas.DataFrame
    avg(*cols)
        cols � list/var args  of column names (string). 
               Non-numeric columns are ignored. 
    count()
    max(*cols)
    mean(*cols)
    min(*cols)
    pivot(pivot_col, values=None)
        pivot_col � Name of the column to pivot ie grouping on unique values of this column
        values � List of values of pivot_col on whose values above grouping would be done 
                 if None, all unique values of pivot_col is used 
    sum(*cols)


$ pyspark --packages org.apache.spark:spark-sql-kafka-0-10_2.11:2.3.0

##Code 
fromTopic1 = spark.
  readStream.
  format("kafka").
  option("subscribe", "topic1").
  option("kafka.bootstrap.servers", "localhost:9092").
  load()

# extract event time et al
# time,key,value
/*
2017-08-23T00:00:00.002Z,1,now
2017-08-23T00:05:00.002Z,1,5 mins later
2017-08-23T00:09:00.002Z,1,9 mins later
2017-08-23T00:11:00.002Z,1,11 mins later
2017-08-23T01:00:00.002Z,1,1 hour later
# late event = watermark should be (1 hour - 10 minutes) already
2017-08-23T00:49:59.002Z,1,==>  in aggregation as too late 
*/

timedValues = fromTopic1.
  select(col("value").cast("string")).           //'
  withColumn("tokens", split(col("value"), ",")).    
  withColumn("time", to_timestamp(col("tokens").getItem(0))).
  withColumn("key", col("tokens").getItem(0).cast("int")).
  withColumn("value", col("tokens").getItem(2)).
  select("time", "key", "value")

# aggregation with watermark
counts = timedValues.
  withWatermark("time", "10 minutes").
  groupBy("key").
  agg(collect_list(col("value")).alias("values"), collect_list(col("time")).alias("times"))

# Note that StatefulOperatorStateInfo is mostly generic
# since no batch-specific values are currently available
# only after the first streaming batch
>>> counts.explain()
== Physical Plan ==
ObjectHashAggregate(keys=[key#27], functions=[collect_list(value#33, 0, 0), collect_list(time#22-T600000ms, 0, 0)])
+- Exchange hashpartitioning(key#27, 200)
   +- StateStoreSave [key#27], StatefulOperatorStateInfo(<unknown>,25149816-1f14-4901-af13-896286a26d42,0,0), Append, 0
      +- ObjectHashAggregate(keys=[key#27], functions=[merge_collect_list(value#33, 0, 0), merge_collect_list(time#22-T600000ms, 0, 0)])
         +- Exchange hashpartitioning(key#27, 200)
            +- StateStoreRestore [key#27], StatefulOperatorStateInfo(<unknown>,25149816-1f14-4901-af13-896286a26d42,0,0)
               +- ObjectHashAggregate(keys=[key#27], functions=[merge_collect_list(value#33, 0, 0), merge_collect_list(time#22-T600000ms, 0, 0)])
                  +- Exchange hashpartitioning(key#27, 200)
                     +- ObjectHashAggregate(keys=[key#27], functions=[partial_collect_list(value#33, 0, 0), partial_collect_list(time#22-T600000ms, 0, 0)])
                        +- EventTimeWatermark time#22: timestamp, inter10 minutes
                           +- *Project [cast(split(cast(value#1 as string), ,)[0] as timestamp) AS time#22, cast(split(cast(value#1 as string), ,)[1] as int) AS key#27, split(cast(value#1 as string), ,)[2] AS value#33]
                              +- StreamingRelation kafka, [key#0, value#1, topic#2, partition#3, offset#4L, timestamp#5, timestampType#6]


sq = counts.writeStream.
  format("console").
  option("truncate", False).
  trigger(processingTime="30 seconds").
  outputMode("update").  # <-- only Update or Complete acceptable because of groupBy aggregation
  start()

# After StreamingQuery was started,
# the physical plan is complete (with batch-specific values)
>>> sq.explain()
== Physical Plan ==
ObjectHashAggregate(keys=[key#27], functions=[collect_list(value#33, 0, 0), collect_list(time#22-T600000ms, 0, 0)])
+- Exchange hashpartitioning(key#27, 200)
   +- StateStoreSave [key#27], StatefulOperatorStateInfo(file:/private/var/folders/0w/kb0d3rqn4zb9fcc91pxhgn8w0000gn/T/temporary-635d6519-b6ca-4686-9b6b-5db0e83cfd51/state,855cec1c-25dc-4a86-ae54-c6cdd4ed02ec,0,0), Update, 0
      +- ObjectHashAggregate(keys=[key#27], functions=[merge_collect_list(value#33, 0, 0), merge_collect_list(time#22-T600000ms, 0, 0)])
         +- Exchange hashpartitioning(key#27, 200)
            +- StateStoreRestore [key#27], StatefulOperatorStateInfo(file:/private/var/folders/0w/kb0d3rqn4zb9fcc91pxhgn8w0000gn/T/temporary-635d6519-b6ca-4686-9b6b-5db0e83cfd51/state,855cec1c-25dc-4a86-ae54-c6cdd4ed02ec,0,0)
               +- ObjectHashAggregate(keys=[key#27], functions=[merge_collect_list(value#33, 0, 0), merge_collect_list(time#22-T600000ms, 0, 0)])
                  +- Exchange hashpartitioning(key#27, 200)
                     +- ObjectHashAggregate(keys=[key#27], functions=[partial_collect_list(value#33, 0, 0), partial_collect_list(time#22-T600000ms, 0, 0)])
                        +- EventTimeWatermark time#22: timestamp, inter10 minutes
                           +- *Project [cast(split(cast(value#76 as string), ,)[0] as timestamp) AS time#22, cast(split(cast(value#76 as string), ,)[1] as int) AS key#27, split(cast(value#76 as string), ,)[2] AS value#33]
                              +- Scan ExistingRDD[key#75,value#76,topic#77,partition#78,offset#79L,timesta
                              
#'     


                         
##groupByKey Operator - does not exist in Python 
#Use UDF or pandas_udf 
#The following example code shows how to apply groupByKey operator to a structured stream of timestamped values of different devices.

# input stream
signals = spark.\
  readStream.\
  format("rate").\
  option("rowsPerSecond", 1).\
  load().\
  withColumn("value", col("value") % 10).  \
  withColumn("deviceId", lit(random.randint(0,10))) # <-- 10 devices randomly assigned to values
 
>>> signals.printSchema()
root
 |-- timestamp: timestamp (nullable = true)
 |-- value: long (nullable = true)
 |-- deviceId: integer (nullable = false)
 
 
@udf(returnType=IntegerType())
def genKey(*cols):
    return cols[-1]
 

>>> signalsByDevice = signals.groupBy(genKey(col("timestamp"),col("value"),col("deviceId")))
<pyspark.sql.group.GroupedData object at 0x00000099E6BD0C18>

    
    
###Example - withWatermark Operator�Event Time Watermark

#The current watermark is computed by looking at the maximum eventTime seen across 
#all of the partitions in a query minus a user-specified delayThreshold. 
#Due to the cost of coordinating this value across partitions, the actual watermark used is only guaranteed to be at least delayThreshold behind the actual event time.
#In some cases Spark may still process records that arrive more than delayThreshold late.


#WaterMark is used with 'window' function 
functions.window(timeColumn, windowDuration, slideDuration=None, startTime=None)
    Durations are provided as strings, e.g. �1 second�, �1 day 12 hours�, �2 minutes�. 
    Valid interval strings are �week�, �day�, �hour�, �minute�, �second�, �millisecond�, �microsecond�. 
    If the slideDuration is not provided, the windows will be tumbling windows.
    The output column will be a struct called �window� by default with the nested columns �start� and �end�, 
    where �start� and �end� will be of pyspark.sql.types.TimestampType.

#Note there another Window Functionality - which is realted to no of rows inand around current row 
#this is called over window , Few sql.functions are used exclusively for it 
from pyspark.sql import Window
window = Window.partitionBy("name").orderBy("age").rowsBetween(-1, 1)
from pyspark.sql.functions import rank, min
df.select(rank().over(window), min('age').over(window))

#windowDuration and slideDuration are strings specifying the width of the window 
#for duration and sliding identifiers, respectively.

#There are a couple of rules governing the durations:
    1.The window duration must be greater than 0
    2.The slide duration must be greater than 0.
    3.The start time must be greater than or equal to 0.
    4.The slide duration must be less than or equal to the window duration.
    5.The start time must be less than the slide duration.
#Only one window expression is supported in a query.
#null values are filtered out in window expression.

#Tumbling windows are a series of fixed-sized, non-overlapping and contiguous time intervals.

>>> timeColumn = window(col("time"), "5 seconds")

#timeColumn should be of TimestampType

import datetime 
data = map(lambda t: (datetime.datetime(*t[0]),t[1]), [
  #datetime(year, month, day[, hour[, minute[, second[, microsecond[,tzinfo]]]]])
  # (year, month, dayOfMonth, hour, minute, second)
  ((2012, 12, 12, 12, 12, 12), 5),
  ((2012, 12, 12, 12, 12, 14), 9),
  ((2012, 12, 12, 13, 13, 14), 4),
  ((2016, 8,  13, 0, 0, 0), 10),
  ((2017, 5,  27, 0, 0, 0), 15)])

levels = sc.parallelize(  list(data) ).toDF(["time", "level"])
#DataFrame[time: timestamp, level: bigint]
>>> levels.show()
+-------------------+-----+
|               time|level|
+-------------------+-----+
|2012-12-12 12:12:12|    5|
|2012-12-12 12:12:14|    9|
|2012-12-12 13:13:14|    4|
|2016-08-13 00:00:00|   10|
|2017-05-27 00:00:00|   15|
+-------------------+-----+

q = levels.select(window("time", "5 seconds"), "level") #DataFrame[window: struct<start:timestamp,end:timestamp>, level: bigint]
>>> q.show(truncate = False)
+---------------------------------------------+-----+
|window                                       |level|
+---------------------------------------------+-----+
|[2012-12-12 12:12:10.0,2012-12-12 12:12:15.0]|5    |
|[2012-12-12 12:12:10.0,2012-12-12 12:12:15.0]|9    |
|[2012-12-12 13:13:10.0,2012-12-12 13:13:15.0]|4    |
|[2016-08-13 00:00:00.0,2016-08-13 00:00:05.0]|10   |
|[2017-05-27 00:00:00.0,2017-05-27 00:00:05.0]|15   |
+---------------------------------------------+-----+

>>> q.printSchema()
root
 |-- window: struct (nullable = true)
 |    |-- start: timestamp (nullable = true)
 |    |-- end: timestamp (nullable = true)
 |-- level: integer (nullable = false)

# calculating the sum of levels every 5 seconds
sums = levels.\
  groupBy(window("time", "5 seconds")).\
  agg(sum("level").alias("level_sum")).\
  select("window.start", "window.end", "level_sum")
>>> sums.show()
+-------------------+-------------------+---------+
|              start|                end|level_sum|
+-------------------+-------------------+---------+
|2012-12-12 13:13:10|2012-12-12 13:13:15|        4|
|2012-12-12 12:12:10|2012-12-12 12:12:15|       14|
|2016-08-13 00:00:00|2016-08-13 00:00:05|       10|
|2017-05-27 00:00:00|2017-05-27 00:00:05|       15|
+-------------------+-------------------+---------+






###Example -  groupBy Streaming Aggregation with Append Output Mode
##Append output mode requires that a streaming aggregation defines a watermark 
#(using withWatermark operator) on at least one of the grouping expressions 
#(directly or using window function).

#withWatermark operator has to be used before the aggregation operator (for the watermark to be used).

#In Append output mode the current watermark level is used to:
    # Output saved state rows that became expired (as Expired state in the events table)
    #Drop late events, i.e. don�t save them to a state store or include in aggregation (as Late events in the events table)

#Sorting is only supported on streaming aggregated Datasets with Complete output mode.




# 1st streaming batch
$ cat /tmp/1
1,1,1
15,2,1

#https://github.com/edenhill/kafkacat
$ kafkacat -P -b localhost:9092 -t topic1 -l /tmp/1

# Alternatively (and slower due to JVM bootup)
$ cat /tmp/1 | ./bin/kafka-console-producer.sh --topic topic1 --broker-list localhost:9092

$ pyspark --packages org.apache.spark:spark-sql-kafka-0-10_2.11:2.3.0


# it has to define a streaming event time watermark using withWatermark operator
# UnsupportedOperationChecker makes sure that the requirement holds
idsPerBatch = spark.
  readStream.
  format("kafka").
  option("subscribe", "topic1").
  option("kafka.bootstrap.servers", "localhost:9092").
  load().
  withColumn("tokens", split(col("value"), ",")).
  withColumn("seconds", col("tokens").getItem(0).cast("long")).
  withColumn("event_time", to_timestamp(from_unixtime(col("seconds")))). #<-- Event time has to be a timestamp
  withColumn("id", col("tokens").getItem(1)).
  withColumn("batch", col("tokens").getItem(2).cast("int")).
  withWatermark(eventTime = "event_time", delayThreshold = "10 seconds"). # <-- define watermark (before groupBy!)
  groupBy("event_time"). # <-- use event_time for grouping
  agg(collect_list("batch").alias("batches"), collect_list("id").alias("ids")).
  withColumn("event_time", to_timestamp(col("event_time"))) # <-- convert to human-readable date

# idsPerBatch is a streaming Dataset with just one Kafka source
# so it knows nothing about output mode or the current streaming watermark yet
# - Output mode is defined on writing side
# - streaming watermark is read from rows at runtime
# That's why StatefulOperatorStateInfo is generic (and uses the default Append for output mode)
# and no batch-specific values are printed out
# They will be available right after the first streaming batch
# Use explain on a streaming query to know the trigger-specific values
>>> idsPerBatch.explain()
== Physical Plan ==
*Project [event_time#36-T10000ms AS event_time#97, batches#90, ids#92]
+- ObjectHashAggregate(keys=[event_time#36-T10000ms], functions=[collect_list(batch#61, 0, 0), collect_list(id#48, 0, 0)])
   +- Exchange hashpartitioning(event_time#36-T10000ms, 1)
      +- StateStoreSave [event_time#36-T10000ms], StatefulOperatorStateInfo(<unknown>,7c5641eb-8ff9-447b-b9ba-b347c057d08f,0,0), Append, 0
         +- ObjectHashAggregate(keys=[event_time#36-T10000ms], functions=[merge_collect_list(batch#61, 0, 0), merge_collect_list(id#48, 0, 0)])
            +- Exchange hashpartitioning(event_time#36-T10000ms, 1)
               +- StateStoreRestore [event_time#36-T10000ms], StatefulOperatorStateInfo(<unknown>,7c5641eb-8ff9-447b-b9ba-b347c057d08f,0,0)
                  +- ObjectHashAggregate(keys=[event_time#36-T10000ms], functions=[merge_collect_list(batch#61, 0, 0), merge_collect_list(id#48, 0, 0)])
                     +- Exchange hashpartitioning(event_time#36-T10000ms, 1)
                        +- ObjectHashAggregate(keys=[event_time#36-T10000ms], functions=[partial_collect_list(batch#61, 0, 0), partial_collect_list(id#48, 0, 0)])
                           +- EventTimeWatermark event_time#36: timestamp, inter10 seconds
                              +- *Project [cast(from_unixtime(cast(split(cast(value#1 as string), ,)[0] as bigint), yyyy-MM-dd HH:mm:ss, Some(Europe/Berlin)) as timestamp) AS event_time#36, split(cast(value#1 as string), ,)[1] AS id#48, cast(split(cast(value#1 as string), ,)[2] as int) AS batch#61]
                                 +- StreamingRelation kafka, [key#0, value#1, topic#2, partition#3, offset#4L, timestamp#5, timestampType#6]

# Start the query and hence StateStoreSaveExec
# Note Append output mode

sq = idsPerBatch.
  writeStream.
  format("console").
  option("truncate", false).
  trigger(processingTime="5 seconds").
  outputMode("append"). # <-- Append output mode
  start()

-------------------------------------------
Batch: 0
-------------------------------------------
+----------+-------+---+
|event_time|batches|ids|
+----------+-------+---+
+----------+-------+---+

# there's only 1 stateful operator and hence 0 for the index in stateOperators
>>> println(sq.lastProgress["stateOperators"[0])
{
  "numRowsTotal" : 0,
  "numRowsUpdated" : 0,
  "memoryUsedBytes" : 77
}

# Current watermark
# We've just started so it's the default start time
>>> println(sq.lastProgress["eventTime"]["watermark"])
1970-01-01T00:00:00.000Z

-------------------------------------------
Batch: 1
-------------------------------------------
+----------+-------+---+
|event_time|batches|ids|
+----------+-------+---+
+----------+-------+---+

# it's Append output mode so numRowsTotal is...FIXME
# no keys were available earlier (it's just started!) and so numRowsUpdated is 0
>>> println(sq.lastProgress["stateOperators"[0])
{
  "numRowsTotal" : 2,
  "numRowsUpdated" : 2,
  "memoryUsedBytes" : 669
}

# Current watermark
# One streaming batch has passed so it's still the default start time
# that will get changed the next streaming batch
# watermark is always one batch behind
>>> println(sq.lastProgress["eventTime"]["watermark"])
1970-01-01T00:00:00.000Z

# Could be 0 if the time to update the lastProgress is short
# FIXME Explain it in detail
>>> println(sq.lastProgress["numInputRows"])
2

-------------------------------------------
Batch: 2
-------------------------------------------
+-------------------+-------+---+
|event_time         |batches|ids|
+-------------------+-------+---+
|1970-01-01 01:00:01|[1]    |[1]|
+-------------------+-------+---+

>>> println(sq.lastProgress["stateOperators"[0])
{
  "numRowsTotal" : 2,
  "numRowsUpdated" : 2,
  "memoryUsedBytes" : 701
}

# Current watermark
# Updated and so the output with the final aggregation (aka expired state)
>>> println(sq.lastProgress["eventTime"]["watermark"])
1970-01-01T00:00:05.000Z

>>> println(sq.lastProgress["numInputRows"])
3

-------------------------------------------
Batch: 3
-------------------------------------------
+-------------------+-------+------+
|event_time         |batches|ids   |
+-------------------+-------+------+
|1970-01-01 01:00:15|[2, 1] |[2, 2]|
+-------------------+-------+------+


# In the end...
sq.stop()



###*** Example - Spark Streaming 
##Break 
def breakFiles(file, n, ext_length = 3):
    import os.path
    def write(fileName, lst):
        with open(fileName, "wt") as f:
            f.writelines(lst) 
        #print(fileName, "written", len(lst))
    def sliding(lst, w, s):
        res = [] 
        n = ((len(lst)-w)/s)+1
        for i in range(0, int(n)):
            start = i*s 
            end = w + s*i 
            res.append(lst[start:end])
        #last segment 
        if  lst[end:]:
                res.append(lst[end:])
        return res     
    def grouped(lst, n):
        return sliding(lst, n, n)        
    onlyFileName, ext = file[0: len(file)-ext_length-1], file[len(file)-ext_length:]
    with open(file, "rt") as f:
        lines = f.readlines()
    howmany = len(lines) // n 
    gr = grouped(lines, howmany)
    if len(gr) > n : #extra last part      
        gr[-2] += gr[-1]
        del gr[-1]         
    #now len(gr) == n 
    names = [ onlyFileName+str(i)+"."+ext     for i in range(1,len(gr)+1)]
    #print(names, n, len(gr))
    for lst, n in zip(gr, names):
        write(n,lst)


##Example  CSV
from pyspark import *
from pyspark.rdd import *
from pyspark.sql import *
from pyspark.sql.types import *
from pyspark.sql.functions import *
from  pyspark.sql.streaming import *


conf = SparkConf().setAppName("CSV").setMaster("local[*]")
sc = SparkContext(conf)
sqlContext=SQLContext(sc)
spark=sqlContext.sparkSession



##Schema 
mySchema = StructType([
 StructField("id", IntegerType()),
 StructField("name", StringType()),
 StructField("year", IntegerType()),
 StructField("rating", DoubleType()),
 StructField("duration", IntegerType())
])
##Put csv file (eg check data/kakfa-csv.csv) in ./kafka-csv dir
df = spark.readStream.schema(mySchema).csv("./stream-csv/*.csv")

##Publish the Stream to Kafka
sq1 = df.selectExpr("CAST(id AS STRING) AS key", "to_json(struct(*)) AS value").
  writeStream.
  format("csv").option("header","true").
  option("checkpointLocation", "./csv_streaming"). ## So whenever there is restart, spark first recovers the old state and then start processing data from the stream
  trigger(processingTime='10 seconds').start( "csv-out" )
  
##put in console 
sq2 = df.writeStream.
    format("console").
    option("truncate","false").trigger(processingTime='10 seconds').start()
    
##sq.awaitTermination()  ##blocks 
##sq.stop() 
sq1.processAllAvailable()  ##testng purpose only , only once triggered   
sq2.processAllAvailable() 


##Example - Streaming Query for Running Counts (over Words from Socket with Output to Console)
##You need to run nc -lk 9999 first before running the example.
##note socket is not production grade 


##groupBy only supports Complete 
lines = spark.readStream
  .format("socket")
  .option("host", "localhost")
  .option("port", 9999)
  ##.option("includeTimestamp", True)  ##sends epoch time 
  .load.withColumn("timestamp", current_timestamp())



scala> words.printSchema
root
 |-- _1: array (nullable = true)
 |    |-- element: string (containsNull = true)
 |-- _2: timestamp (nullable = true)
 
words = lines.map( t => (t._1.split("\\s+"), t._2))
all_words = words.select(explode(col("_1")).alias("value"), col("_2").alias("timestamp"))
counter = all_words.groupBy("value").count ##pyspark.sql.DataFrame = [value: string, count: bigint]

##to have late data effect, original record should have record date as "current_timestamp" always changes the data 
counter = all_words.withWatermark("timestamp", "2 minutes") ##late data = data is not late if data arrives within current eventtime - 2 min , current event time is the max eventtime seen by processor 
    .groupBy(col("value"), window(col("timestamp"), "1 minutes"))
    .agg(count(col("value")).alias("count")).withColumn("now", current_timestamp())
    .select(col("value"), col("count"), col("window"), col("now"))
    



query = counter.writeStream
  .outputMode("complete")
  .format("console").trigger(processingTime='10 seconds')
  .start

query.stop



##Example - Kafka structured streaming - uses Kafka API 

$ pyspark --packages pyspark:spark-sql-kafka-0-10_2.11:2.3.0

##cd  to zookeeper dir and then kafka dir 
$ zookeeper-server-start.bat  conf/zoo.cfg  ##client binds to ..:2181
$ kafka-server-start.bat config/server.properties   ##server binds to localhost:9092, called broker-list 

$ kafka-console-producer.bat --broker-list localhost:9092 --topic topic1

##Example 


 
## time,key,value
2017-08-23T00:00:00.002Z,"mine",20
2017-08-23T00:05:00.002Z,"mine",30
2017-08-23T00:09:00.002Z,"mine",40
2017-08-23T00:11:00.002Z,"mine",50
2017-08-23T01:00:00.002Z,"mine",60
2017-08-23T00:49:59.002Z,"mine",70

### DataFrame w/ schema [eventTime: timestamp, deviceId: string, signal: bigint]
rawData  = spark.
  readStream.
  format("kafka").
  option("subscribe", "topic1").
  option("kafka.bootstrap.servers", "localhost:9092").
  load() 

>>> rawData.printSchema()
root
 |-- key: binary (nullable = true)
 |-- value: binary (nullable = true)
 |-- topic: string (nullable = true)
 |-- partition: integer (nullable = true)
 |-- offset: long (nullable = true)
 |-- timestamp: timestamp (nullable = true)  ##ingestion time 
 |-- timestampType: integer (nullable = true)
 
 
eventsDF = rawData.
  select(col("value").cast("string")).          
  withColumn("tokens", split(col("value"), ",")).    
  withColumn("eventTime", to_timestamp(col("tokens").getItem(0))).
  withColumn("deviceId", col("tokens").getItem(1).cast("string")).
  withColumn("signal", col("tokens").getItem(2).cast("int")).
  select("eventTime", "deviceId", "signal")

avgSignalDF = eventsDF.groupBy("deviceId").avg("signal")

##With only window 
windowedAvgSignalDF = eventsDF.
    groupBy(window("eventTime", "5 minute")).
    count()

##OR sliding window 
windowedAvgSignalDF =  eventsDF.
    groupBy(window("eventTime", "10 minutes", "5 minutes")).
    count()
    
##With deviceId and window 
windowedCountsDF = eventsDF.
    groupBy(
      "deviceId",
      window("eventTime", "10 minutes", "5 minutes")).  ##duration, sliding duration 
    count()

##Watermarking to Limit State while Handling Late Data
windowedCountsDF =  eventsDF.
    withWatermark("eventTime", "20 minutes"). ##late data = records with eventtime before (currentEventtime - 20 min)
    groupBy(
      col("deviceId"),
      window(col("eventTime"), "5 minutes")).  ##eventtime in record is currentEventtime, tumbling window of 5 minutes 
    agg(collect_list(col("signal")).alias("signals")).
    select(col("deviceId"), col("signals"), size(col("signals")).alias("count"), col("window"))

sq = windowedCountsDF.writeStream.
  format("console").
  option("truncate", False).
  trigger(ProcessingTime(10.seconds)).
  outputMode("update").  
  start()
  
sq.processAllAvailable()  ##testng purpose only , only once triggered   
  
## After StreamingQuery was started,
## the physical plan is complete (with batch-specific values)
>>> sq.explain()

##input 
2017-08-23T00:00:00.002Z,"mine",20
2017-08-23T00:05:00.002Z,"mine",30
2017-08-23T00:09:00.002Z,"mine",40
2017-08-23T00:11:00.002Z,"mine",50
2017-08-23T01:00:00.002Z,"mine",60
2017-08-23T00:49:59.002Z,"mine",70
2017-08-23T00:00:00.002Z,"mine",20
2017-08-23T00:05:00.002Z,"mine",30
2017-08-23T00:09:00.002Z,"mine",40
2017-08-23T00:11:00.002Z,"mine",50
2017-08-23T01:00:00.002Z,"mine",60
2017-08-23T00:49:59.002Z,"mine",70
2017-08-23T00:00:00.002Z,"mine",20
2017-08-23T00:00:00.002Z,"mine",20

  
##Output 
-------------------------------------------
Batch: 1
-------------------------------------------
+--------+----------------+-----+------------------------------------------+
|deviceId|signals         |count|window                                    |
+--------+----------------+-----+------------------------------------------+
|"mine"  |[70]            |1    |[2017-08-23 06:15:00, 2017-08-23 06:20:00]|
|"mine"  |[60, 60]        |2    |[2017-08-23 06:30:00, 2017-08-23 06:35:00]|
|"mine"  |[30, 40, 30, 40]|4    |[2017-08-23 05:35:00, 2017-08-23 05:40:00]|
|"mine"  |[20, 20]        |2    |[2017-08-23 05:30:00, 2017-08-23 05:35:00]|
|"mine"  |[50, 50]        |2    |[2017-08-23 05:40:00, 2017-08-23 05:45:00]|
+--------+----------------+-----+------------------------------------------+

-------------------------------------------
Batch: 2
-------------------------------------------
+--------+--------+-----+------------------------------------------+
|deviceId|signals |count|window                                    |
+--------+--------+-----+------------------------------------------+
|"mine"  |[70, 70]|2    |[2017-08-23 06:15:00, 2017-08-23 06:20:00]|
+--------+--------+-----+------------------------------------------+

-------------------------------------------
Batch: 3
-------------------------------------------
+--------+-------+-----+------+
|deviceId|signals|count|window|
+--------+-------+-----+------+
+--------+-------+-----+------+




###Example - Kafka sink 
##Schema 
mySchema = StructType([
 StructField("id", IntegerType()),
 StructField("name", StringType()),
 StructField("year", IntegerType()),
 StructField("rating", DoubleType()),
 StructField("duration", IntegerType())
))
##Put csv file (eg check data/kakfa-csv.csv) in ./kafka-csv dir
streamingDataFrame = spark.readStream.schema(mySchema).csv("kafka-csv")

##Publish the Stream to Kafka
streamingDataFrame.selectExpr("CAST(id AS STRING) AS key", "to_json(struct(*)) AS value").
  writeStream
  .format("kafka")
  .option("topic", "topicName")
  .option("kafka.bootstrap.servers", "localhost:9092")
  .option("checkpointLocation", "./kafka-checkpoint") ## <-- mandatory
  .start()



###*** Spark - ML and MLIB 
#ML - recomended to use this 
�New
�Pipelines
�Dataframes
�Easier to construct a practical machine learning pipeline

#MLlib
�Old
�RDD
�More features


###spliting  on RDD and DF 

rdd.randomSplit(weights, seed=None)
    Randomly splits this RDD with the provided weights.
#Example 
>>> rdd = sc.parallelize(range(500), 1)
>>> rdd1, rdd2 = rdd.randomSplit([2, 3], 17)
>>> len(rdd1.collect() + rdd2.collect())
500
>>> 150 < rdd1.count() < 250
True
>>> 250 < rdd2.count() < 350
True

#for DF   
df.randomSplit(weights, seed=None)
    Randomly splits this DataFrame with the provided weights.
#Example 
df4 = sc.parallelize([Row(course="dotNET", year=2012, earnings=10000),
                           Row(course="Java",   year=2012, earnings=20000),
                           Row(course="dotNET", year=2012, earnings=5000),
                           Row(course="dotNET", year=2013, earnings=48000),
                           Row(course="Java",   year=2013, earnings=30000)]).toDF()

>>> splits = df4.randomSplit([1.0, 2.0], 24)
>>> splits[0].count()
1
>>> splits[1].count()
3
#Example 
df = sc.parallelize(map(lambda e:Row(value=e),range(10000))).toDF()
df1,df2,df3,df4,df5 = df.randomSplit([1.0,1.0,1.0,1.0,1.0]) #spliting into five 


###Machine learning  Steps 
1. Feature extractors (generally for Text data)
   Feature selection if input features are of high numbers 
   Feature Transformers to transform input data    
   model=CLASS().fit(df)  #pure transformers do not have this step 
   new_transformed_df= model.transform(DF)
   input data is 
    ML: DataFrame with columns designated by parameter inputCol or inputCols
    MLIB: Local or Distributed Vector, Matrix 
   Output data:
    ML: DataFrame with columns designated by parameter outputCol or outputCols
    MLIB: transformed Local or Distributed Vector, Matrix 
   Note data  could be dense or sparse Vector 
   sparse vector is identified by [# of_features, [indices], [corresponding_values]]
2. Random split input data into training and test by  rdd_OR_df.randomSplit(weights, seed=None)
3. Instantiate Classification or regression Estimator class, say instance
4. Fit of training data to get 'model' , model=instance.fit(data)
5. predictions = model.transform(testData) to get prediction 
   in MLIB, predictions = model.predict(testData)
   input data is 
        ML: DataFrame with columns designated by parameter labelCol and featuresCol
        MLIB: list of LabeledPoint ie (label, features_vector)
   all feature columns in 2D data are part of only one column 'features' in final DF 
   Use VectorAssembler or sql.functions.array() to merge all seperate feature columns to one 'features' column 
   For ML, use setInputCol/setOutputCol/setLabelCol/setFeaturesCol etc to set columns name for operation 
   features_vector, featuresCol features columns - could be dense or sparse Vector 
   sparse vector is identified by [# of_features, [indices], [corresponding_values]]   
   Output data:
        ML: DataFrame with columns designated by parameter predictionCol , probabilityCol
        MLIB: prediction vectors 
6. Evaluate :
   ML:Use instance.evaluate(predictions) or instance.evaluate(predictions, {instance.metricName: "accuracy"}), where instance from 
       BinaryClassificationEvaluator(predictionCol="prediction")
       MulticlassClassificationEvaluator(predictionCol="prediction")
       RegressionEvaluator(predictionCol="prediction")
      MulticlassClassificationEvaluator supports metricName as "f1" (default), "weightedPrecision", "weightedRecall", "accuracy"
      BinaryClassificationEvaluator supports "areaUnderROC" (default), "areaUnderPR")
      RegressionEvaluator supports "rmse" (default): root mean squared error,"mse": mean squared error,"r2": R2 metric,"mae": mean absolute error 
   MLIB, similarly use  Metrics classes 
7. Note for Binary classification or regression  , 
   can get summary by model.summary 
        BinaryLogisticRegressionSummary, LinearRegressionSummary, GeneralizedLinearRegressionSummary 
   BinaryLogisticRegressionSummary have summary.predictions(a DF with columns ['label', 'features', 'rawPrediction', 'probability', 'prediction'])
   RegressionSummary have summary.pValues,summary.coefficientStandardErrors(form normal solver), summary.residuals, summary.aic (for GLM)

#Optional STeps 
1. For Pipeline, use Pipeline
  For tuning use CrossValidator, TrainValidationSplit along with ParamGridBuilder
  all above and any classification, regression class have .params, .explainParams, .extractParamMap, 
  then use .setParamName to set any params
2. Pipline,classification, regression class, CrossValidator,TrainValidationSplit trains on 
  'label' and 'fetaures' columns of DF (which is SparseVector or DenseVector of all features- Use VectorAssembler to create such)
  or set those columns by setLabelCol and setFeaturesCol
  Outputs are in generally 'prediction' and 'probability' columns of 'transform' DF 
  or set them by setPredictionCol, setProbabilityCol
3. Model has .save(path) and ObjectModel.load(path) for saving/loading model 
   Check the model class name, after .fit(dataFrame) 




###Spark - ML - Parameter 
#Param and Params represent a parameter or parameters of a Transformer, Estimator etc 

#Example - Standard Input columns in input DataFrame for Estimator 
#Param name  Type(s)     Default column name      Description
labelCol    Double      "label"                     Label to predict 
featuresCol Vector      "features"                  Feature vector 

#Example - Standard Output columns in output DataFrame from a fitted Model
#Param name          Type(s)     Default column name         Description
predictionCol       Double      "prediction"                 Predicted label  
rawPredictionCol    Vector      "rawPrediction"              Vector of length # classes, with the counts of training instance labels at the tree node which makes the prediction Classification only 
probabilityCol      Vector      "probability"                Vector of length # classes equal to rawPrediction normalized to a multinomial distribution Classification only 
varianceCol         Double                                   The biased sample variance of prediction Regression only 



#Some Transformation works on Column of Vector or convert Vector to Vector or simple element to Vector 
#Before ML regression/classifications, DF has two columns 
#,"label" should be Double and "features" should be vector (dense or Sparse - eg (20,[0,5,9,17],[1.0,1.0,1.0,2.0])  )



###Spark - ML - QuickSummary - Feature Extractors , use with pyspark.ml.feature 
�Extraction:        Extracting features from 'raw' data
�Transformation:    Scaling, converting, or modifying features
�Selection:         Selecting a subset from a larger set of features

#Note almost all  have HasInputCol, HasOutputCol mixins 
#Hence one input/output column(which might be Vector)
#If mixin is HasInputCols, then multiple input columns eg list of columns 

#inputCol and outputCol can be pyspark.ml.linalg.DenseVector  or pyspark.ml.linalg.SparseVector 
#DenseVector format - [value1, value2,...]
#Sparse Vector format - (# of_features, [indices], [corresponding_values])

###Spark - ML - QuickSummary - Feature Extractors , use with pyspark.ml.feature 
?TF-IDF     
    Term frequency-inverse document frequency (TF-IDF) is 
    multiplication of TF(HashingTF and CountVectorizer) and IDF 
    Reflects the importance of a term to a document 
    TF - generates the term frequency vectors
    IDF -  it down-weights columns which appear frequently in the corpus 
    #Example Result 
    #inputCol-sentence, Tokenizer outputCol - words, TF outputCol -rawfeatures, final outputCol(TF-IDF)- features
    +-----+-----------------------------------+------------------------------------------+-----------------------------------------+----------------------------------------------------------------------------------------------------------------------+
    |label|sentence                           |words                                     |rawFeatures                              |features                                                                                                              |
    +-----+-----------------------------------+------------------------------------------+-----------------------------------------+----------------------------------------------------------------------------------------------------------------------+
    |0.0  |Hi I heard about Spark             |[hi, i, heard, about, spark]              |(20,[0,5,9,17],[1.0,1.0,1.0,2.0])        |(20,[0,5,9,17],[0.6931471805599453,0.6931471805599453,0.28768207245178085,1.3862943611198906])                        |
    |0.0  |I wish Java could use case classes |[i, wish, java, could, use, case, classes]|(20,[2,7,9,13,15],[1.0,1.0,3.0,1.0,1.0]) |(20,[2,7,9,13,15],[0.6931471805599453,0.6931471805599453,0.8630462173553426,0.28768207245178085,0.28768207245178085]) |
    |1.0  |Logistic regression models are neat|[logistic, regression, models, are, neat] |(20,[4,6,13,15,18],[1.0,1.0,1.0,1.0,1.0])|(20,[4,6,13,15,18],[0.6931471805599453,0.6931471805599453,0.28768207245178085,0.28768207245178085,0.6931471805599453])|
    +-----+-----------------------------------+------------------------------------------+-----------------------------------------+----------------------------------------------------------------------------------------------------------------------+

?Word2Vec
    Transforms each column of Vector into a vector using the average of all words in the document
    #Example Result 
    #inputCol-text, outputCol - result
    +------------------------------------------+----------------------------------------------------------------+
    |text                                      |result                                                          |
    +------------------------------------------+----------------------------------------------------------------+
    |[Hi, I, heard, about, Spark]              |[-0.008142343163490296,0.02051363289356232,0.03255096450448036] |
    |[I, wish, Java, could, use, case, classes]|[0.043090314205203734,0.035048123182994974,0.023512658663094044]|
    |[Logistic, regression, models, are, neat] |[0.038572299480438235,-0.03250147425569594,-0.01552378609776497]|
    +------------------------------------------+----------------------------------------------------------------+

    
?CountVectorizer
    Converts a collection of text documents to vectors of token counts.
    #Example Result 
    #inputCol-words, outputCol - features
    +---+---------------+-------------------------+
    |id |words          |features                 |
    +---+---------------+-------------------------+
    |0  |[a, b, c]      |(3,[0,1,2],[1.0,1.0,1.0])|
    |1  |[a, b, b, c, a]|(3,[0,1,2],[2.0,2.0,1.0])|
    +---+---------------+-------------------------+

    
    
    
###Spark - ML - QuickSummary - Feature Transformers , use with pyspark.ml.feature 
?RegexTokenizer
    takes text (such as a sentence) and breakes it into individual terms (usually words). 
    #Example Result 
    #inputCol-sentence, outputCol - words , extra Param: .setPattern("\\W"))
    +---+-----------------------------------+------------------------------------------+
    |id |sentence                           |words                                     |
    +---+-----------------------------------+------------------------------------------+
    |0  |Hi I heard about Spark             |[hi, i, heard, about, spark]              |
    |1  |I wish Java could use case classes |[i, wish, java, could, use, case, classes]|
    |2  |Logistic,regression,models,are,neat|[logistic, regression, models, are, neat] |
    +---+-----------------------------------+------------------------------------------+
    
?StopWordsRemover
    Removes Stop words are words which should be excluded from the input, 
    typically because the words appear frequently and don't carry as much meaning.
    #Example Result 
    #inputCol-raw, outputCol - filtered 
    +---+----------------------------+--------------------+
    |id |raw                         |filtered            |
    +---+----------------------------+--------------------+
    |0  |[I, saw, the, red, balloon] |[saw, red, balloon] |
    |1  |[Mary, had, a, little, lamb]|[Mary, little, lamb]|
    +---+----------------------------+--------------------+
    
?NGram
     transform input feature/a Column Vector into sequence of n tokens (typically words) for some integer n
     #Example Result 
     #inputCol-words, outputCol - ngrams , extra Param: .setN(2)
    +---+------------------------------------------+------------------------------------------------------------------+
    |id |words                                     |ngrams                                                            |
    +---+------------------------------------------+------------------------------------------------------------------+
    |0  |[Hi, I, heard, about, Spark]              |[Hi I, I heard, heard about, about Spark]                         |
    |1  |[I, wish, Java, could, use, case, classes]|[I wish, wish Java, Java could, could use, use case, case classes]|
    |2  |[Logistic, regression, models, are, neat] |[Logistic regression, regression models, models are, are neat]    |
    +---+------------------------------------------+------------------------------------------------------------------+

     

?Binarizer
    Converts numerical features to binary (0/1) features using a threashold
    #Example Result 
    #inputCol-feature, outputCol - binarized_feature , extra Param .setThreshold(0.5)
    +---+-------+-----------------+
    |id |feature|binarized_feature|
    +---+-------+-----------------+
    |0  |0.1    |0.0              |
    |1  |0.8    |1.0              |
    |2  |0.2    |0.0              |
    +---+-------+-----------------+
    
?PCA
    Converts a set of observations of possibly correlated variables into a set of values 
    of linearly uncorrelated variables called principal components
    #Example Result 
    #inputCol-features, outputCol - pcaFeatures , extra param setK(3)  
    +---------------------+-----------------------------------------------------------+
    |features             |pcaFeatures                                                |
    +---------------------+-----------------------------------------------------------+
    |(5,[1,3],[1.0,7.0])  |[1.6485728230883807,-4.013282700516296,-5.524543751369388] |
    |[2.0,0.0,3.0,4.0,5.0]|[-4.645104331781534,-1.1167972663619026,-5.524543751369387]|
    |[4.0,0.0,0.0,6.0,7.0]|[-6.428880535676489,-5.337951427775355,-5.524543751369389] |
    +---------------------+-----------------------------------------------------------+
    
?PolynomialExpansion
    expands your features into a polynomial space, To include higher degree terms of features 
    which is formulated by an n-degree combination of original dimensions.
    #Example Result 
    #inputCol-features, outputCol - polyFeatures , extra param: .setDegree(3)
    +----------+------------------------------------------+
    |features  |polyFeatures                              |
    +----------+------------------------------------------+
    |[2.0,1.0] |[2.0,4.0,8.0,1.0,2.0,4.0,1.0,2.0,1.0]     |
    |[0.0,0.0] |[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]     |
    |[3.0,-1.0]|[3.0,9.0,27.0,-1.0,-3.0,-9.0,1.0,3.0,-1.0]|
    +----------+------------------------------------------+
    
?Discrete Cosine Transform (DCT)
    transforms a length N real-valued Vector Column in the time domain 
    into another length N real-valued Vector COlumn  in the frequency domain
    #Example Result 
    #inputCol-features, outputCol - featuresDCT
    +--------------------+----------------------------------------------------------------+
    |features            |featuresDCT                                                     |
    +--------------------+----------------------------------------------------------------+
    |[0.0,1.0,-2.0,3.0]  |[1.0,-1.1480502970952693,2.0000000000000004,-2.7716385975338604]|
    |[-1.0,2.0,4.0,-7.0] |[-1.0,3.378492794482933,-7.000000000000001,2.9301512653149677]  |
    |[14.0,-2.0,-5.0,1.0]|[4.0,9.304453421915744,11.000000000000002,1.5579302036357163]   |
    +--------------------+----------------------------------------------------------------+
 
    
?StringIndexer
    used for string labels 
    Converts a string column  to a column of indices(numerical value)
    The indices are in [0, numLabels), ordered by label frequencies, so the most frequent label gets index 0
    #Example Result 
    #inputCol-category, outputCol - categoryIndex
    +---+--------+-------------+
    |id |category|categoryIndex|
    +---+--------+-------------+
    |0  |a       |0.0          |
    |1  |b       |2.0          |
    |2  |c       |1.0          |
    |3  |a       |0.0          |
    |4  |a       |0.0          |
    |5  |c       |1.0          |
    +---+--------+-------------+
   
?IndexToString (inverse of StringIndexer)
    Converts column of label indices back to a column containing the original labels as strings
    #Example Result 
    #inputCol-categoryIndex, outputCol - originalCategory
    +---+--------+-------------+----------------+
    |id |category|categoryIndex|originalCategory|
    +---+--------+-------------+----------------+
    |0  |a       |0.0          |a               |
    |1  |b       |2.0          |b               |
    |2  |c       |1.0          |c               |
    |3  |a       |0.0          |a               |
    |4  |a       |0.0          |a               |
    |5  |c       |1.0          |c               |
    +---+--------+-------------+----------------+
 
 
?OneHotEncoder
    Maps a numeric column of label indices to a column of binary vectors, with at most a single 1 value
    This encoding allows algorithms which expect continuous features
    such as Logistic Regression, to use categorical features
    eg Use StringIndexer and the OneHotEncoder to convert string category to column to be used for Logit 
    #Example Result 
    #inputCol-categoryIndex, outputCol - categoryVec
    +---+--------+-------------+-------------+
    |id |category|categoryIndex|categoryVec  |
    +---+--------+-------------+-------------+
    |0  |a       |0.0          |(2,[0],[1.0])|
    |1  |b       |2.0          |(2,[],[])    |
    |2  |c       |1.0          |(2,[1],[1.0])|
    |3  |a       |0.0          |(2,[0],[1.0])|
    |4  |a       |0.0          |(2,[0],[1.0])|
    |5  |c       |1.0          |(2,[1],[1.0])|
    +---+--------+-------------+-------------+
    
?VectorIndexer
    Takes an input columns of type Vector and a parameter maxCategories 
    Decide which features should be categorical based on the number of distinct values, where features with at most maxCategories are declared categorical.
    Compute 0-based category indices for each categorical feature
    and transform original feature values to indices
    #Example Result 
    #inputCol-features, outputCol - indexed , extra param .setMaxCategories(2)
    +---+--------------+--------------+
    |id |features      |indexed       |
    +---+--------------+--------------+
    |0  |[1.0,0.5,-1.0]|[0.0,0.0,-1.0]|
    |1  |[1.0,1.0,1.0] |[0.0,1.0,1.0] |
    |2  |[4.0,0.5,2.0] |[1.0,0.0,2.0] |
    +---+--------------+--------------+
    
    
?Interaction #(py not available)
    Takes vector or double-valued columns, and generates a single vector column 
    that contains the product of all combinations of one value from each input column
    #Example Result 
    #vec1<- VectorAssembler("id2", "id3", "id4"), 
    #vec2 <-VectorAssembler("id5", "id6", "id7")
    #inputCols-[vec1,vec2], outputCol - interactedCol
    +---+---+---+---+---+---+---+--------------+--------------+------------------------------------------------------+
    |id1|id2|id3|id4|id5|id6|id7|vec1          |vec2          |interactedCol                                         |
    +---+---+---+---+---+---+---+--------------+--------------+------------------------------------------------------+
    |1  |1  |2  |3  |8  |4  |5  |[1.0,2.0,3.0] |[8.0,4.0,5.0] |[8.0,4.0,5.0,16.0,8.0,10.0,24.0,12.0,15.0]            |
    |2  |4  |3  |8  |7  |9  |8  |[4.0,3.0,8.0] |[7.0,9.0,8.0] |[56.0,72.0,64.0,42.0,54.0,48.0,112.0,144.0,128.0]     |
    |3  |6  |1  |9  |2  |3  |6  |[6.0,1.0,9.0] |[2.0,3.0,6.0] |[36.0,54.0,108.0,6.0,9.0,18.0,54.0,81.0,162.0]        |
    |4  |10 |8  |6  |9  |4  |5  |[10.0,8.0,6.0]|[9.0,4.0,5.0] |[360.0,160.0,200.0,288.0,128.0,160.0,216.0,96.0,120.0]|
    |5  |9  |2  |7  |10 |7  |3  |[9.0,2.0,7.0] |[10.0,7.0,3.0]|[450.0,315.0,135.0,100.0,70.0,30.0,350.0,245.0,105.0] |
    |6  |1  |1  |4  |2  |8  |4  |[1.0,1.0,4.0] |[2.0,8.0,4.0] |[12.0,48.0,24.0,12.0,48.0,24.0,48.0,192.0,96.0]       |
    +---+---+---+---+---+---+---+--------------+--------------+------------------------------------------------------+

?Normalizer
    Normalizer is a Transformer which transforms a dataset of Vector rows, 
    normalizing each Vector to have unit norm(eg across all features)
    Note inputCol is Vector of all features 
    #Example Result 
    #inputCol-features, outputCol - normFeatures , extra param :setP(1.0)
    +---+--------------+------------------+
    |id |features      |normFeatures      |
    +---+--------------+------------------+
    |0  |[1.0,0.5,-1.0]|[0.4,0.2,-0.4]    |
    |1  |[2.0,1.0,1.0] |[0.5,0.25,0.25]   |
    |2  |[4.0,10.0,2.0]|[0.25,0.625,0.125]|
    +---+--------------+------------------+
 
?StandardScaler
    StandardScaler transforms a dataset of Vector rows, 
    normalizing each feature to have unit standard deviation and/or zero mean.
    Note inputCol is Vector of all features 
    #Example Result 
    #inputCol-features, outputCol - normFeatures , extra param setWithStd(True),setWithMean(False)
    +---+--------------+------------------------------------------------------------+
    |id |features      |scaledFeatures                                              |
    +---+--------------+------------------------------------------------------------+
    |0  |[1.0,0.5,-1.0]|[0.6546536707079771,0.09352195295828246,-0.6546536707079771]|
    |1  |[2.0,1.0,1.0] |[1.3093073414159542,0.18704390591656492,0.6546536707079771] |
    |2  |[4.0,10.0,2.0]|[2.6186146828319083,1.8704390591656492,1.3093073414159542]  |
    +---+--------------+------------------------------------------------------------+

    
?MinMaxScaler
    MinMaxScaler transforms a dataset of Vector rows, 
    rescaling each feature to a specific range (often [0, 1]).
    Note inputCol is Vector of all features 
    #Example Result 
    #inputCol-features, outputCol - scaledFeatures 
    +---+--------------+--------------+
    |id |features      |scaledFeatures|
    +---+--------------+--------------+
    |0  |[1.0,0.1,-1.0]|[0.0,0.0,0.0] |
    |1  |[2.0,1.1,1.0] |[0.5,0.1,0.5] |
    |2  |[3.0,10.1,3.0]|[1.0,1.0,1.0] |
    +---+--------------+--------------+

 
?MaxAbsScaler
    MaxAbsScaler transforms a dataset of Vector rows, 
    rescaling each feature to range [-1, 1] by dividing through the maximum absolute value in each feature.
    Note inputCol is Vector of all features 
    #Example Result 
    #inputCol-features, outputCol - scaledFeatures
    +---+--------------+----------------+
    |id |features      |scaledFeatures  |
    +---+--------------+----------------+
    |0  |[1.0,0.1,-8.0]|[0.25,0.01,-1.0]|
    |1  |[2.0,1.0,-4.0]|[0.5,0.1,-0.5]  |
    |2  |[4.0,10.0,8.0]|[1.0,1.0,1.0]   |
    +---+--------------+----------------+
   
?Bucketizer
    transforms a column of continuous feature to a column of feature bucket index after n splits
    #Example Result 
    #inputCol-features, outputCol - bucketedFeatures , with .setSplits(Array(Double.NegativeInfinity, -0.5, 0.0, 0.5, Double.PositiveInfinity))
    +--------+----------------+
    |features|bucketedFeatures|
    +--------+----------------+
    |-999.9  |0.0             |
    |-0.5    |1.0             |
    |-0.3    |1.0             |
    |0.0     |2.0             |
    |0.2     |2.0             |
    |999.9   |3.0             |
    +--------+----------------+

 
?ElementwiseProduct
    scales each column/feature  of the dataset by a scalar multiplier.
     Note inputCol is Vector of all features 
    #Example Result 
    #inputCol-features, outputCol - transformedVector , with Vectors.dense(0.0, 1.0, 2.0)
    +---+-------------+-----------------+
    |id |vector       |transformedVector|
    +---+-------------+-----------------+
    |a  |[1.0,2.0,3.0]|[0.0,2.0,6.0]    |
    |b  |[4.0,5.0,6.0]|[0.0,5.0,12.0]   |
    +---+-------------+-----------------+
    
?SQLTransformer
    transforms column via SQL statement 
    #Example Result "SELECT *, (v1 + v2) AS v3, (v1 * v2) AS v4 "
    +---+---+---+---+----+
    |id |v1 |v2 |v3 |v4  |
    +---+---+---+---+----+
    |0  |1.0|3.0|4.0|3.0 |
    |2  |2.0|5.0|7.0|10.0|
    +---+---+---+---+----+
    
?VectorAssembler
    combines a given list of columns into a single vector column
    This is very Imp operation as all ML regression/classifications requires only one 'features' column
    #Example Result 
    #inputCols-["hour", "mobile", "userFeatures"]  , outputCol - features ,    
    +---+----+------+--------------+-------+-----------------------+
    |id |hour|mobile|userFeatures  |clicked|features               |
    +---+----+------+--------------+-------+-----------------------+
    |0  |18  |1.0   |[0.0,10.0,0.5]|1.0    |[18.0,1.0,0.0,10.0,0.5]|
    +---+----+------+--------------+-------+-----------------------+
    
?QuantileDiscretizer
    takes a column with continuous feature 
    and outputs a column of indexes to binned categorical feature( eg n bin)
    #Example Result 
    #inputCol-hour, outputCol - result , with extra Param: setNumBuckets(3)
    +---+----+------+
    |id |hour|result|
    +---+----+------+
    |0  |18.0|2.0   |
    |1  |19.0|2.0   |
    |2  |8.0 |1.0   |
    |3  |5.0 |1.0   |
    |4  |2.2 |0.0   |
    +---+----+------+

    
###Spark - ML - QuickSummary - Feature Selectors , use with pyspark.ml.feature 
?VectorSlicer
    extracts subfeatures(few indexes) from a vector column.
    Note inputCol is Vector of all features 
    #Example Result 
    #inputCol-userFeatures, outputCol - features , with extra Param: setIndices([1]) or setIndices([1,2])
    +--------------------+-------------+
    |userFeatures        |features     |
    +--------------------+-------------+
    |(3,[0,1],[-2.0,2.3])|(2,[0],[2.3])|
    |[-2.0,2.3,0.0]      |[2.3,0.0]    |
    +--------------------+-------------+
    
?RFormula
    selects columns specified by an R model formula
    #Example Result 
    #.setFormula("clicked ~ country + hour").setFeaturesCol("features").setLabelCol("label")
    # hence label from 'clicked' , features from 'country' and 'hour'
    +---+-------+----+-------+--------------+-----+
    |id |country|hour|clicked|features      |label|
    +---+-------+----+-------+--------------+-----+
    |7  |US     |18  |1.0    |[0.0,0.0,18.0]|1.0  |
    |8  |CA     |12  |0.0    |[1.0,0.0,12.0]|0.0  |
    |9  |NZ     |15  |0.0    |[0.0,1.0,15.0]|0.0  |
    +---+-------+----+-------+--------------+-----+

    
?ChiSqSelector
    uses the Chi-Squared test of independence to decide 
    which features to choose(by numTopFeatures, percentile , fpr)
    #Example Result - top 1 features selected,
    #inputCol-features, outputCol - selectedFeatures , with extra param .setNumTopFeatures(1)
    +---+------------------+-------+----------------+
    |id |features          |clicked|selectedFeatures|
    +---+------------------+-------+----------------+
    |7  |[0.0,0.0,18.0,1.0]|1.0    |[18.0]          |
    |8  |[0.0,1.0,12.0,0.0]|0.0    |[12.0]          |
    |9  |[1.0,0.0,15.0,0.1]|0.0    |[15.0]          |
    +---+------------------+-------+----------------+
    
    
?Locality Sensitive Hashing
    A class of hashing techniques
    Two algorithms 
        Bucketed Random Projection for Euclidean Distance(hash bucket based on Euclidian distance)
        MinHash for Jaccard Distance 
    Various operations possibles
    #Example - Bucketed Random Projection for Euclidean Distance
    #inputCol-keys, outputCol - values , with extra Param .setBucketLength(2.0).setNumHashTables(3)
    +---+-----------+-----------------------+
    |id |keys       |values                 |
    +---+-----------+-----------------------+
    |0  |[1.0,1.0]  |[[0.0], [0.0], [-1.0]] |
    |1  |[1.0,-1.0] |[[-1.0], [-1.0], [0.0]]|
    |2  |[-1.0,-1.0]|[[-1.0], [-1.0], [0.0]]|
    |3  |[-1.0,1.0] |[[0.0], [0.0], [-1.0]] |
    +---+-----------+-----------------------+

    #Example - Approximate similarity join with threashold= 1.5 
    #inputCol = datasetA,datasetB (from above), outputCol= below full DF 
    #check each row, eg id 1 is joined with id 4 with distCol = 1.0 (min)
    +---------------------------------------------------+--------------------------------------------------+-------+
    |datasetA                                           |datasetB                                          |distCol|
    +---------------------------------------------------+--------------------------------------------------+-------+
    |[1,[1.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])] |[4,[1.0,0.0],WrappedArray([0.0], [-1.0], [-1.0])] |1.0    |
    |[0,[1.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]   |[6,[0.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]  |1.0    |
    |[1,[1.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])] |[7,[0.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])]|1.0    |
    |[3,[-1.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]  |[5,[-1.0,0.0],WrappedArray([-1.0], [0.0], [0.0])] |1.0    |
    |[0,[1.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]   |[4,[1.0,0.0],WrappedArray([0.0], [-1.0], [-1.0])] |1.0    |
    |[3,[-1.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]  |[6,[0.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]  |1.0    |
    |[2,[-1.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])]|[7,[0.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])]|1.0    |
    |[2,[-1.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])]|[5,[-1.0,0.0],WrappedArray([-1.0], [0.0], [0.0])] |1.0    |
    +---------------------------------------------------+--------------------------------------------------+-------+
    #Example  - Approximate nearest neighbor search, for Vectors.dense(1.0, 0.0)
    #inputCol = datsetA(from above), outputCol= below DF showing which ids are nearer via distCol=1.0 min 
    +---+----------+-----------------------+-------+
    |id |keys      |values                 |distCol|
    +---+----------+-----------------------+-------+
    |1  |[1.0,-1.0]|[[-1.0], [-1.0], [0.0]]|1.0    |
    |0  |[1.0,1.0] |[[0.0], [0.0], [-1.0]] |1.0    |
    +---+----------+-----------------------+-------+
    
    


###+++ ML Rgression and classification 


##Example - Boston Housing Price Prediction - GradientBoostingRegressor
#Note in GradientBoostedTrees - In Python, predict cannot currently be used within an RDD transformation or action. Call predict directly on the RDD instead.
 
 
from sklearn import datasets

# Load data
boston = datasets.load_boston() #boston.data=np, boston.target, boston.feature_names
print(boston.DESCR)

pdf = pd.DataFrame(boston.data, columns=boston.feature_names)
pdf['MEDV'] = boston.target

data = spark.createDataFrame(pdf)
assembler = VectorAssembler().setInputCols(boston.feature_names.tolist()).setOutputCol("features")
df = assembler.transform(data)


trainingData, testData = df.randomSplit([3.0,1.0], 24)

# If data has categorical features 
#Automatically identify categorical features, and index them.
# Set maxCategories so features with > 4 distinct values are treated as continuous.
#In our case all are continuous, hence not needed 
#note this is a transformer, hence call fit
#featureIndexer = VectorIndexer(inputCol="features", outputCol="indexedFeatures", maxCategories=4).fit(df)
#gbt = GBTRegressor(featuresCol="indexedFeatures",labelCol='MEDV', predictionCol='prediction', maxIter=10)
#pipeline = Pipeline(stages=[featureIndexer, gbt])


gbt = GBTRegressor(featuresCol="features",labelCol='MEDV', predictionCol='prediction', maxIter=10)
#Pipeline(stages=[Transformer1, Transformer2,...,Estimator1,Estimator2,...])
#Transformer means which has .transform method, Estimator is one having .fit and .transform 
pipeline = Pipeline(stages=[gbt])
model = pipeline.fit(trainingData)


#Training error 
predictions = model.transform(trainingData)
predictions.select("prediction", "MEDV", "features").show(5)
# rmse - root mean squared error (default) mse - mean squared error r2 - r^2 metric mae - mean absolute error
evaluator = RegressionEvaluator(labelCol="MEDV", predictionCol="prediction", metricName="r2")
r2 = evaluator.evaluate(predictions) #not so good 


# Test Error 
predictions = model.transform(testData)
r2 = evaluator.evaluate(predictions) 


#Tune parameter - Advantage of ML 
#GBTRegressor(featuresCol='features', labelCol='label', predictionCol='prediction', maxDepth=5, maxBins=32, minInstancesPerNode=1, minInfoGain=0.0, maxMemoryInMB=256, cacheNodeIds=False, subsamplingRate=1.0, checkpointInterval=10, lossType='squared', maxIter=20, stepSize=0.1, seed=None, impurity='variance')
gbt.explainParams() #check all parameters 
paramGrid = ParamGridBuilder()\
    .addGrid(gbt.maxDepth, [5,3,7]) \
    .addGrid(gbt.maxIter, [10,20,25])\
    .build()

# In this case the estimator is simply the linear regression.
#CrossValidator - expensive, but reliable for small data set, 
# requires an Estimator, a set of Estimator ParamMaps, and an Evaluator.
tvs = TrainValidationSplit(estimator=pipeline,
                           estimatorParamMaps=paramGrid,
                           evaluator=RegressionEvaluator(labelCol="MEDV", predictionCol="prediction", metricName="r2"),
                           # 80% of the data will be used for training, 20% for validation.
                           trainRatio=0.8)

# Run TrainValidationSplit, and choose the best set of parameters.
model = tvs.fit(trainingData)

#Check now 
predictions = model.transform(testData)
predictions.select("prediction", "MEDV", "features").show(5)
evaluator = RegressionEvaluator(labelCol="MEDV", predictionCol="prediction", metricName="r2")
r2 = evaluator.evaluate(predictions)

model.getEstimatorParamMaps() #params for all combination 
model.validationMetrics #metric for each combination 
np.argmax(model.validationMetrics)
model.getEstimatorParamMaps()[np.argmax(model.validationMetrics)] #best model 




##Example - Iris Classifications  - GradientBoostedTrees
#Binary and Multiclass(set numClasses)
    LogisticRegression with family="multinomial")
    DecisionTreeClassifier
    RandomForestClassifier
    NaiveBayes with modelType='multinomial'
#Only Binary 
    LinearSVC
    GBTClassifier


#Example 
from sklearn import datasets

# Load data
iris = datasets.load_iris() #iris.data=np, iris.target, iris.feature_names
print(iris.DESCR)

pdf = pd.DataFrame(iris.data, columns=iris.feature_names)
pdf['Name'] = iris.target

data = spark.createDataFrame(pdf)
assembler = VectorAssembler().setInputCols(iris.feature_names).setOutputCol("features")
df = assembler.transform(data)


# If label contains string category or number category, this transforms to [0,numlabels)
#In our case target is already processed 
#Note this is Transformer, hence call .fit
#labelIndexer = StringIndexer(inputCol="Name", outputCol="indexedLabel").fit(df)

# Automatically identify categorical features, and index them.
# Set maxCategories so features with > 4 distinct values are treated as continuous.
##In our case features are continuous
#Note this is Transformer, hence call .fit 
#featureIndexer = VectorIndexer(inputCol="features", outputCol="indexedFeatures", maxCategories=4).fit(df)

# Train a RandomForest model. Note labelCol, featuresCol 
#this is Estimators 
#rf = RandomForestClassifier(labelCol="indexedLabel", featuresCol="indexedFeatures", numTrees=10)

# Convert indexed labels back to original labels.
#Note later stages has to be Estimators 
#labelConverter = IndexToString(inputCol="prediction", outputCol="predictedLabel",  labels=labelIndexer.labels)

# Chain indexers and forest in a Pipeline
#Pipeline(stages=[Transformer1, Transformer2,...,Estimator1,Estimator2,...]
#Transformer means whihc has .transform method, Estimator is one having .fit and .transform 
#pipeline = Pipeline(stages=[labelIndexer, featureIndexer, rf, labelConverter])




trainingData, testData = df.randomSplit([3.0,1.0], 24)

rf = RandomForestClassifier(labelCol="Name", featuresCol="features", numTrees=10)
pipeline = Pipeline(stages=[rf])
# Train model.  This also runs the indexers.
model = pipeline.fit(trainingData)

# Training error 
predictions = model.transform(trainingData)
predictions.select("prediction", "Name", "features").show(5)
#f1|weightedPrecision|weightedRecall|accuracy)
#f1 means weightedFMeasure ie  averages of all labels, ie fMeasure(category, beta) * count.toDouble / labelCount
evaluator = MulticlassClassificationEvaluator(labelCol="Name", predictionCol="prediction", metricName="f1")
f1 = evaluator.evaluate(predictions)


#Test Error 
predictions = model.transform(testData)
f1 = evaluator.evaluate(predictions)

