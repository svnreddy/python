'''
dummy 
    Django authetication
    how to handle signup form and handle users 
    upload a file 
    download a file 
    send a mail 
'''