''' basic - book
        model layer 
        admin module               
        ListView as standard view 
        
Objectives- Basic Model 
Generic display views, Query Performance, Migration concepts
'''