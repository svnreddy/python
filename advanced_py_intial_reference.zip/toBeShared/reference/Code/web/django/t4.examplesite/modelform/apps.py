from django.apps import AppConfig


class ModelformConfig(AppConfig):
    name = 'modelform'
