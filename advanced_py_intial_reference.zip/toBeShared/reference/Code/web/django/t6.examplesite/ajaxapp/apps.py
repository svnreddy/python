from django.apps import AppConfig


class AjaxappConfig(AppConfig):
    name = 'ajaxapp'
