'''
Django AJAX                                   
    csrf 
'''