from django.apps import AppConfig


class BaeappConfig(AppConfig):
    name = 'baeapp'
