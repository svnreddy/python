'''
examplesite from setup to Production deplyoment 
    urls, views and settings, template language 
    Objective- Understanding  Application development
settings, urls, views(inc class based) and deployment steps
'''